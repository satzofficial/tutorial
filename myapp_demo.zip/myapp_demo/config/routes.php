<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
| example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
| https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
| $route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
| $route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
| $route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples: my-controller/index -> my_controller/index
|   my-controller/my-method -> my_controller/my_method
*/

$front_prefix                       = 'tenrealm_front/';
$route['default_controller']                = 'tenrealm_front/user/testnew';

$route['bala_work']                = 'tenrealm_front/common/index';

// $route['(:any)']                       = $front_prefix.'common/index';


$route['translate_uri_dashes']                = TRUE;
$route['emush_admin']                   = 'emush_admin/admin';
$route['emush_admin/(:any)']              = 'emush_admin/$1';
$route['emush_admin/(:any)/(:any)']           = 'emush_admin/$1/$2';
$route['emush_admin/(:any)/(:any)/(:any)']        = 'emush_admin/$1/$2/$3';
$route['emush_admin/(:any)/(:any)/(:any)/(:any)']     = 'emush_admin/$1/$2/$3/$4';
$route['emush_admin/admin/(:any)']            = 'emush_admin/admin/$1';


$route['update_usd_price']                  = $front_prefix.'common/update_usd_price';
$route['update_euro_price']                 = $front_prefix.'common/update_euro_price';
$route['coinprice']                     = $front_prefix.'common/coinprice';
$route['switchLang/(:any)']                                 = $front_prefix.'common/switchLang/$1';
$route['home']                        = $front_prefix.'common/index';
$route['/']                         = $front_prefix.'common/index';
$route['reg_subscribe']                   = $front_prefix.'common/reg_subscribe';
$route['cms/(:any)']                    = $front_prefix.'common/cms/$1';
$route['faq']                       = $front_prefix.'common/faq';
$route['membership']                    = $front_prefix.'common/membership';
$route['fee']                       = $front_prefix.'common/fee';
$route['news']                        = $front_prefix.'common/news';
$route['news/(:any)']                   = $front_prefix.'common/news_detail/$1';
$route['fees']                        = $front_prefix.'common/fees';
$route['transaction']                                       = $front_prefix.'user/transaction';
$route['get_csrf_token']                  = $front_prefix.'user/get_csrf_token';
$route['login']                       = $front_prefix.'user/signin';
$route['login_check']                     = $front_prefix.'user/login_check';
$route['logout']                      = $front_prefix.'user/logout';
$route['settings']                      = $front_prefix.'user/settings';
$route['settings/(:any)']                   = $front_prefix.'user/settings/$1';
$route['oldpassword_exist']                 = $front_prefix.'user/oldpassword_exist';
$route['register']                      = $front_prefix.'user/signup';
$route['email_exist']                     = $front_prefix.'user/email_exist';
$route['username_exist']                  = $front_prefix.'user/username_exist';
$route['company_exist']                   = $front_prefix.'user/company_exist';
$route['verify_user/(:any)']                = $front_prefix.'user/verify_user/$1';
$route['profile']                         = $front_prefix.'user/profile';
$route['profile-edit']                    = $front_prefix.'user/editprofile';
$route['update_profileimage']                 = $front_prefix.'user/update_profileimage';
$route['kyc']                             = $front_prefix.'user/kyc';
$route['address_verification']                = $front_prefix.'user/address_verification';
$route['id_verification']                   = $front_prefix.'user/id_verification';
$route['photo_verification']                = $front_prefix.'user/photo_verification';
$route['change_password']                   = $front_prefix.'user/change_password';
$route['tfa']                             = $front_prefix.'user/tfa';
$route['support']                         = $front_prefix.'user/support';
$route['support_reply/(:any)']                    = $front_prefix.'user/support_reply/$1';
$route['dashboard']                     = $front_prefix.'user/dashboard';
$route['deposit_amt']                         = $front_prefix.'user/deposit_amount';
$route['deposit']                             = $front_prefix.'user/deposit';
$route['deposit/(:any)']                    = $front_prefix.'user/deposit/$1';
$route['withdraw']                        = $front_prefix.'user/withdraw';
$route['withdraw/(:any)']                   = $front_prefix.'user/withdraw/$1';
$route['change_address']                  = $front_prefix.'user/change_address';
$route['deposit_withdraw_coin']               = $front_prefix.'user/deposit_withdraw_coin';
$route['withdraw_coin_user_confirm/(:any)']         = $front_prefix.'user/withdraw_coin_user_confirm/$1';
$route['withdraw_coin_user_cancel/(:any)']              = $front_prefix.'user/withdraw_coin_user_cancel/$1';
$route['trade']                           = $front_prefix.'trade';
$route['trade/pro']                         = $front_prefix.'trade/pro';
$route['trade/(:any)']                    = $front_prefix.'trade/trade/$1';
$route['trade/pro/(:any)']                  = $front_prefix.'trade/trade_pro/$1';

$route['trade_integration/(:any)/(:any)']           = $front_prefix.'trade/trade_integration/$1/$2';
$route['trade_integration/(:any)/(:any)/(:any)']      = $front_prefix.'trade/trade_integration/$1/$2/$3';
$route['trade_integration/(:any)/(:any)/(:any)/(:any)']   = $front_prefix.'trade/trade_integration/$1/$2/$3/$4';

$route['get_chart_record']                  = $front_prefix.'common/get_chart_record';
$route['get_depthchart']                  = $front_prefix.'common/get_depthchart';
$route['localpair_details']                 = $front_prefix.'common/localpair_details';
$route['basic_localpair_details']               = $front_prefix.'common/basic_localpair_details';
$route['localpair_details_crypto']              = $front_prefix.'common/localpair_details_crypto';
$route['getcurrency_localdetails']              = $front_prefix.'common/getcurrency_localdetails';
$route['newget_chart_record']                 = $front_prefix.'common/newget_chart_record';
$route['newget_chart_record/(:any)/(:any)']         = $front_prefix.'common/newget_chart_record/$1/$2';
$route['newdepthchart']                   = $front_prefix.'common/newdepthchart';
$route['newdepthchart/(:any)']                = $front_prefix.'common/newdepthchart/$1';
$route['add_favpair']                     = $front_prefix.'trade/add_favpair';
$route['remove_favpair']                  = $front_prefix.'trade/remove_favpair';

$route['rem_favpair_trade']                 = $front_prefix.'trade/rem_favpair';

$route['add_favpair_trade']                 = $front_prefix.'trade/add_favpair';
$route['search_pair']                     = $front_prefix.'common/search_pair';
$route['favsearch_pair']                  = $front_prefix.'common/favsearch_pair';

$route['search_pair_trade']                 = $front_prefix.'trade/search_pair';
$route['favsearch_pair_trade']                = $front_prefix.'trade/favsearch_pair';

$route['appendfav']                     = $front_prefix.'trade/appendfav';

$route['buytoken']                      = $front_prefix.'common/buytoken';
$route['history']                       = $front_prefix.'user/history';
$route['wallet']                      = $front_prefix.'user/wallet';
$route['ipn']                         = $front_prefix.'paypal/ipn';
$route['pay/(:any)']                    = $front_prefix.'common/pay/$1';
$route['bankwire']                      = $front_prefix.'common/bankwire';
$route['paypal/success']                  = $front_prefix.'common/success';
$route['forgot-password']                   = $front_prefix.'user/forgot_user';
$route['forgot-check']                    = $front_prefix.'user/forgot_check';
$route['reset_pw_user/(:any)/(:any)']                = $front_prefix.'user/reset_pw_user/$1/$2';
$route['download_support/(:any)']               = $front_prefix.'user/download_support/$1';
$route['download_deposit_history/(:any)']           = $front_prefix.'user/download_deposit_history/$1'; 
$route['download_withdraw_history/(:any)']          = $front_prefix.'user/download_withdraw_history/$1'; 
$route['unsubscribe/(:any)']                = $front_prefix.'common/unsubscribe/$1'; 
$route['blockip']                       = $front_prefix.'common/blockips';
$route['block_ip']                      = $front_prefix.'common/blockips';

$route['deposit_page/(:any)']               = $front_prefix.'user/deposit_page/$1';
$route['withdraw_page/(:any)']                = $front_prefix.'user/withdraw_page/$1';
$route['update_adminbalance']                   = $front_prefix.'common/admin_wallet_balance';
$route['update_adminaddress']                   = $front_prefix.'common/update_adminaddress';

$route['contact-us']                      = $front_prefix.'common/contact_us';
$route['contact']                       = $front_prefix.'common/storecontact';
$route['bank_transfer']                   = $front_prefix.'user/bank_transfer';
$route['getValue']                      = $front_prefix.'user/getValue';
// $route['euronordic-payment']                 = $front_prefix.'common/shasta_payment';
$route['verify_company']                  = $front_prefix.'user/verify_company';
$route['bank_details/(:any)']                 = $front_prefix.'user/bank_details/$1';
$route['move_to_admin_wallet/(:any)']             = $front_prefix.'user/move_to_admin_wallet/$1';
$route['token']                       = $front_prefix.'common/token';
$route['close_allactive_order']               = $front_prefix.'trade/close_allactive_order';
$route['close_active_order']                = $front_prefix.'trade/close_active_order';
$route['close_active_orders']                 = $front_prefix.'common/close_active_order';

$route['common_test_details']                 = $front_prefix.'common/common_test_details';
$route['add_coin']                      = $front_prefix.'user/add_coin';

$route['account']                     = $front_prefix.'user/account';

$route['update_bank_details']               = $front_prefix.'user/update_bank_details';

$route['security']                      = $front_prefix.'user/security';
$route['change_address_withdraw']             = $front_prefix.'user/change_address_withdraw';

$route['buy_crypto']                    = $front_prefix.'user/buy_crypto';

//$route['market_trades/(:any)'] = $front_prefix.'trade/market_trades/$1';


$route['get_dailylimit']                  = $front_prefix.'user/get_dailylimit';

/*$route['market_trades']       = $front_prefix.'common/market_trades';*/

$route['market_api']                    = $front_prefix.'common/market_api';
$route['buycrpy']                       = $front_prefix.'user/buycrpy';
$route['getresponse_wyre/(:any)']               = $front_prefix.'user/getresponse_wyre/$1';
$route['getfailureresponse_wyre/(:any)']          = $front_prefix.'user/getfailureresponse_wyre/$1';
$route['rss_feed']                      = $front_prefix.'common/rss_feed';
$route['close_ticket/(:any)']               = $front_prefix.'user/close_ticket/$1';
$route['api_call_list']                   = $front_prefix.'common/api_call_list';
$route['api']                       = $front_prefix.'common/showApiList';
$route['fav_add']                     = $front_prefix.'common/fav_add';
$route['api/v1/ticker/list']                = $front_prefix.'api/getTickerLists';
$route['api/v1/ticker/(:any)']                = $front_prefix.'api/getTickerList/$1';
// $route['api/v1/depth/(:any)']  =   $front_prefix.'common/market_api_depth/$1';
// $route['api/v1/klines/(:any)']   =   $front_prefix.'common/market_api_klines/$1';

$route['api_orders']                    = $front_prefix.'common/market_api_orders';


$route['transfer_to_admin_wallet/(:any)']           = $front_prefix.'user/transfer_to_admin_wallet/$1';
$route['paypeaks_status']                 = $front_prefix.'user/paypeaks_status';
$route['paypeaks_product']                  = $front_prefix.'user/paypeaks_product';
$route['payment_status']                  = $front_prefix.'user/payment_status';
$route['settings_profile']                  = $front_prefix.'user/settings_profile';
$route['verify_email']                    = $front_prefix.'user/verify_email';
$route['markets']                       = $front_prefix.'common/markets';

$route['download_pdf/(:any)/(:any)']            = $front_prefix.'user/download_pdf/$1/$2';

$route['validaddress']                    = $front_prefix.'user/validaddress';
$route['crypto_address']                  = $front_prefix.'user/crypto_address';
$route['transaction_history/(:any)']            = $front_prefix.'user/transaction_history/$1';
$route['transaction_history_pdf/(:any)']          = $front_prefix.'user/transaction_history_pdf/$1';
$route['address_book']                    = $front_prefix.'user/address_book';
$route['add_address_book']                  = $front_prefix.'user/add_address_book';
$route['address_destroy']                   = $front_prefix.'user/address_destroy';
$route['delete_address/(:any)']               = $front_prefix.'user/delete_address/$1';

$route['loadpairWithCoinbase']                = $front_prefix.'user/loadpairWithCoinbase';
$route['basic-trade']                     = $front_prefix.'user/basic_trade';
$route['basic-home']                    = $front_prefix.'user/basic_home';
$route['basic-portfolio']                   = $front_prefix.'user/basic_portfolio';
$route['basic-notification']                = $front_prefix.'user/basic_notification';
$route['basic-chart/(:any)']                = $front_prefix.'user/basic_chart/$1';
$route['basic-wallet/(:any)']                 = $front_prefix.'user/basic_wallet/$1';
$route['get_chartData']                   = $front_prefix.'user/get_chartData';
$route['whitepaper/(:any)']                 = $front_prefix.'user/whitepaper/$1';
$route['basic-pay']                     = $front_prefix.'user/basic_pay';
$route['basicbuytransaction/(:any)']            = $front_prefix.'user/basicbuytransaction/$1';
$route['basicselltransaction/(:any)']             = $front_prefix.'user/basicselltransaction/$1';
$route['basic-exchange/(:any)']               = $front_prefix.'user/basic_exchange/$1';
$route['basic_execute_order']                 = $front_prefix.'user/basic_execute_order';
$route['trade_ajax/(:any)']                 = $front_prefix.'user/trade_ajax/$1';



// SATZ FEB 08, 2022
$route['register']                      = $front_prefix.'user/signup';
$route['packages']                      = $front_prefix.'user/packages';
$route['mywithdraw']                    = $front_prefix.'user/mywithdraw';
$route['payment']                     = $front_prefix.'user/user_deposit';
$route['activation']                    = $front_prefix.'user/user_activation';
$route['level-income']                    = $front_prefix.'user/level_activation_income';
$route['tree']                        = $front_prefix.'user/tree';


$route['team-level-income']                 = $front_prefix.'user/team_level_income';
$route['global-income']                   = $front_prefix.'user/global_income_chart';
$route['sponsor-income']                  = $front_prefix.'user/sponsor_income_chart';
$route['rewards']                     = $front_prefix.'user/reward';
$route['manual-user-deactivate']              = $front_prefix.'user/inactive_30_days';
$route['transactions']                    = $front_prefix.'user/transactions';





// Ajax Request
$route['get-deposit-details']               = $front_prefix.'user/get_deposit_details';
$route['withdraw-validation']               = $front_prefix.'user/withdraw_validation';
$route['is-completed-transaction']              = $front_prefix.'user/is_completed_transaction';
$route['is-not-email-exist']                = $front_prefix.'user/is_not_email_exist';
$route['is-activation']                   = $front_prefix.'user/package_before_purchasing_validation';
$route['is-email-exist']                  = $front_prefix.'user/email_exist';
$route['is-ref-exist']                    = $front_prefix.'user/refferal_exist';
$route['is-beb-exist']                    = $front_prefix.'user/beb_exist';
$route['is-user-details-available']             = $front_prefix.'user/print_user_details';
$route['display-global-income']               = $front_prefix.'user/display_global_income_chart';
$route['display-global-income-four-two-migration']      = $front_prefix.'user/display_global_income_migration_chart';
$route['display-sponsor-income']              = $front_prefix.'user/display_sponsor_income_chart';
$route['display-global-4x-income']              = $front_prefix.'user/display_global_4x_income_chart';
$route['display-sponsor-4x-income']             = $front_prefix.'user/display_sponsor_4x_income_chart';
$route['directs-list']                    = $front_prefix.'user/display_directs_income_chart';
$route['display-direct-list/(:num)']            = $front_prefix.'user/display_directs_list/$1';
$route['display-direct-popup-list/(:num)']          = $front_prefix.'user/display_directs_popup_list/$1';
$route['display-direct-list-personal']            = $front_prefix.'user/display_directs_person_list';
$route['level-income-list/(:num)']              = $front_prefix.'user/display_level_income_list/$1';
$route['auto-level-income-list/(:num)']           = $front_prefix.'user/display_auto_level_income_list/$1';
$route['display-level-list-personal']           = $front_prefix.'user/display_level_income_personal';
$route['claim']                       = $front_prefix.'user/user_claim';
$route['is-transaction-user-details-available']       = $front_prefix.'user/get_user_transfer_detail';
$route['transactions-ajax']                 = $front_prefix.'user/transactions_ajax';
$route['transfer-ajax']                   = $front_prefix.'user/transfer_ajax';
$route['transaction-details/(:any)']            = $front_prefix.'user/transaction_details/$1';

// Withdraw & Deposit Transaction
$route['get-past-transactions']               = $front_prefix.'user/get_past_transaction';
$route['transaction-search']                = $front_prefix.'user/transaction_search_filter';
$route['get-user-fund']                   = $front_prefix.'user/get_user_fund';

$route['update_user_ltc_address']             = $front_prefix.'user/update_user_ltc_address';

// PEER TO PEER TRANSACTION BY SATZ
$route['user-transfer']                   = $front_prefix.'user/wallet_transfer';
$route['transfer-search']                   = $front_prefix.'user/transfer_search';
$route['wallet-transfer']                   = $front_prefix.'user/wallet_transfer';
$route['create-manual-user']                = 'activeRecordController/company_user_add_manual';
$route['ltc-test']                      = 'activeRecordController/encryptionLTC';
$route['manual2x']                      = $front_prefix.'user/manual2x';
$route['manual4x']                      = $front_prefix.'user/manual4x';
$route['tester']                      = $front_prefix.'user/tester';
$route['testers']                      = $front_prefix.'user/testers';
$route['sample-pdf']                    = $front_prefix.'user/pdf';
$route['404_override']                    = 'errors/error404';
$route['ar/insert']                     = 'activerecordcontroller/store_order';
$route['test_db']                     =  $front_prefix.'user/test_db';
$route['update-rewards']                  = $front_prefix.'user/update_reward';





// TEST URL
$route['ci_info']                     = $front_prefix.'user/ci_info';
$route['register-wt-insert']                = $front_prefix.'user/register_wt_insert';
$route['coin_price_conversion']               = $front_prefix.'common/coin_price_conversion';


// Cron
$route['2xx']                       = $front_prefix.'user/cron_2x_profit';
$route['4xx']                       = $front_prefix.'user/cron_4x_profit';
$route['42xx']                        = $front_prefix.'user/cron_42x_profit';
$route['manual-user-deactivate']              = $front_prefix.'user/inactive_30_days';
$route['liveprice_update']                  = $front_prefix.'user/liveprice_update';
$route['update_onlineUSD']                  = $front_prefix.'common/update_onlineUSD';
$route['update_user_address']                 = $front_prefix.'user/update_user_address';
$route['update_crypto_deposits/(:any)']           = $front_prefix.'user/update_crypto_deposits/$1';
$route['update_user_coin_price']              = $front_prefix.'common/update_user_coin_price';
$route['signin']                      = $front_prefix.'user/signin';
$route['signup']                                            = $front_prefix.'user/signup_new';
// ADMIN CRON
$route['emush_admin/admin/over_all_ltc']            = 'emush_admin/admin/over_all_ltc';


// Cron
$route['remaining']            	= $front_prefix.'user/remaining';