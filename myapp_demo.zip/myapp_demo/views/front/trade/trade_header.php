<!DOCTYPE html>
<html>
<?php
    
    $user_id = $this->session->userdata('user_id');

    $favicon = $site_common['site_settings']->site_favicon;
    $sitelogo = $site_common['site_settings']->site_logo;
?>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="<?php echo $favicon;?>" />
    <title>IXToken - Trade</title>

    <!-- Bootstrap CSS File -->
    <link href="<?php echo front_lib();?>bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link href="<?php echo front_lib();?>font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo front_lib();?>animate/animate.min.css" rel="stylesheet">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:700|Roboto:400,500,700&display=swap" rel="stylesheet">

    <!--datatables-->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/w/bs4/dt-1.10.18/datatables.min.css" />

    <!--bootstrap-select-->
    <link rel="stylesheet" type="text/css" href="<?php echo front_lib();?>bootstrap/css/bootstrap-select.css" />
    <link href="<?php echo front_lib();?>dropdown/animate.min.css" rel="stylesheet">
    <link href="<?php echo front_lib();?>dropdown/bootstrap-dropdownhover.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="<?php echo front_css();?>style.css?v=<?php echo strtotime(date('d-m-Y H:i:s'));?>" rel="stylesheet">
    <link href="<?php echo front_css();?>header.css?v=<?php echo strtotime(date('d-m-Y H:i:s'));?>" rel="stylesheet">

    <!--styles-->
    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>style_trade.css?v=<?php echo strtotime(date('d-m-Y H:i:s'));?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo front_css();?>responsive_trade.css?v=<?php echo strtotime(date('d-m-Y H:i:s'));?>" />

    <link rel="stylesheet" href="<?php echo front_css();?>jquery.growl.css">


</head>

<body>

    <!--========================== Header ============================-->
    <header id="header" data-locale="en-us" data-hostnmae="" class="fedui-root fedui-header inner-header">
        <div class="fedui-header-pc container-fluid">
            <div class="fedui-header-left">
                <h1 class="fedui-header-logo">
                    <a href="<?php echo base_url();?>"><img src="<?php echo $sitelogo;?>"></a>
                </h1>
            </div>
            <div class="fedui-header-right" id="nav-menu-container">
                <nav class="fedui-header-nav">
                    <ul class="nav-menu mr-auto sf-js-enabled sf-arrows" style="touch-action: pan-y;">
                        <li><a class="fedui-theme-text" href="<?php echo base_url();?>">Home</a></li>

                        <li class="menu-active"><a href="<?php echo base_url();?>trade" class="fedui-theme-text">Exchange</a></li>
                        <?php
                        if(isset($user_id) && !empty($user_id)){
                            ?>
                            <li><a href="<?php echo base_url();?>wallet" class="fedui-theme-text">Wallet</a></li>
                            <?php
                        }
                        else{
                            ?>
                            <li><a href="<?php echo base_url();?>login" class="fedui-theme-text">Login</a></li>
                            <?php
                        }
                        ?>
                        
                        
                    </ul>
                    <?php
                        if(isset($user_id) && !empty($user_id)){
                            ?>
                    <div class="dropdown cus-header-dropdown">
                        <a href="#" class="btn dropdown-toggle" data-hover="dropdown" data-animations="flipInX flipInY flipInX flipInY" aria-expanded="false"><?php echo UserName($user_id);?> <span class="header-profile-arrow"><i class="fa fa-angle-down" aria-hidden="true"></i></span></a>
                        <ul class="dropdown-menu dropdownhover-bottom" role="menu">
                            <li><a href="<?php echo base_url();?>profile">Profile</a></li>
                            <li><a href="<?php echo base_url();?>settings">Settings</a></li>
                            <li><a href="<?php echo base_url();?>support">Support</a></li>
                            <li><a href="<?php echo base_url();?>logout">Logout</a></li>
                        </ul>
                    </div>
                    <?php
                }
                    ?>
                </nav>
            </div>
        </div>
    </header>