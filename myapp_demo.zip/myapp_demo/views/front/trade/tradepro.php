<?php $this->load->view('front/trade/tradepro_header'); ?>
<?php
$user_id = $this->session->userdata('user_id');
$from_currency_id = $this->common_model->customQuery("select * from ixtoken_currency where currency_symbol='".$pair[0]."'")->row('id');
$to_currency_id = $this->common_model->customQuery("select * from ixtoken_currency where currency_symbol='".$pair[1]."'")->row('id');
$from_curr_sym = $pair[0];
$to_curr_sym = $pair[1];
$pair_id = $pair_details->id;
$trading_price = tradeprice($pair_id);
$usermal = $this->db->where('id', $user_id)->get('ixtoken_users')->result();
$First_Currency = $pair[0];
if ($First_Currency == 'USD') {
  $num_format1 = 2;
} else {
  $num_format1 = 8;
}
$Second_Currency = $pair[1];
if ($Second_Currency == 'USD') {
  $num_format2 = 2;
} else {
  $num_format2 = 8;
}
if ($this->user_id != 0) {
  $from_cur = to_decimal($this->user_balance[$pair_details->from_symbol_id], 8);
  $to_cur = to_decimal($this->user_balance[$pair_details->to_symbol_id], 8);
} else {
  $from_cur = 0;
  $to_cur = 0;
}
if($from_currency_det->currency_symbol=='RVN')
{
$coin_name='ravencoin';
}
elseif($from_currency_det->currency_symbol=='BCH')
{
$coin_name = 'bitcoin-cash';
}
elseif($from_currency_det->currency_symbol=='ZEC')
{
$coin_name = 'zcash';
}
elseif($from_currency_det->currency_symbol=='XRP')
{
$coin_name = 'ripple';
}
elseif($from_currency_det->currency_symbol=='ETH')
{
$coin_name = 'ethereum';
}
$json     = file_get_contents('https://api.coingecko.com/api/v3/coins/'.$coin_name.'?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false&sparkline=false');
$newresult  = json_decode($json,true);
if($from_currency_det->currency_symbol=='XRP' && $to_currency_det->currency_symbol=='ETH')
{
$latest_price = $newresult['market_data']['current_price']['eth'];
$latestusd_price = $newresult['market_data']['current_price']['usd'];
}
elseif(($from_currency_det->currency_symbol=='RVN' && $to_currency_det->currency_symbol=='BTC') || ($from_currency_det->currency_symbol=='BCH' && $to_currency_det->currency_symbol=='BTC') || ($from_currency_det->currency_symbol=='ETH' && $to_currency_det->currency_symbol=='BTC') || ($from_currency_det->currency_symbol=='ZEC' && $to_currency_det->currency_symbol=='BTC'))
{
$latest_price = $newresult['market_data']['current_price']['btc'];
$latestusd_price = $newresult['market_data']['current_price']['usd'];
}
?>
<section class="main_body">
        <div class="container-fluid p-0">
            <div class="row no-gutters">
                <div class="col-xl-7">
                    <div class="p-1">
                        <div class="block">
                            <div class="trade_candle_chart">
                                <div class="trade_candle_light">
                                    <!-- TradingView Widget BEGIN -->
                                    <div class="tradingview-widget-container">
                                        <div id="tradingview_df685"></div>
                                        <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
                                        <script type="text/javascript">
                                            new TradingView.widget(
                                                {
                                                    "autosize": true,
                                                    "symbol": "Binance:<?php echo $First_Currency.$Second_Currency;?>",
                                                    "interval": "D",
                                                    "timezone": "Etc/UTC",
                                                    "theme": "Light",
                                                    "style": "1",
                                                    "locale": "in",
                                                    "toolbar_bg": "#f1f3f6",
                                                    "enable_publishing": false,
                                                    "allow_symbol_change": true,
                                                    "save_image": false,
                                                    "withdateranges": true,
                                                    "container_id": "tradingview_df685"
                                                }
                                            );
                                        </script>
                                    </div>
                                    <!-- TradingView Widget END -->
                                </div>
                                <div class="trade_candle_dark">
                                    <!-- TradingView Widget BEGIN -->
                                    <div class="tradingview-widget-container">
                                        <div id="tradingview_3d8bd"></div>
                                        <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
                                        <script type="text/javascript">
                                            new TradingView.widget(
                                                {
                                                    "autosize": true,
                                                    "symbol": "Binance:<?php echo $First_Currency.$Second_Currency;?>",
                                                    "interval": "D",
                                                    "timezone": "Etc/UTC",
                                                    "theme": "Dark",
                                                    "style": "1",
                                                    "locale": "in",
                                                    "toolbar_bg": "#f1f3f6",
                                                    "enable_publishing": false,
                                                    "allow_symbol_change": true,
                                                    "save_image": false,
                                                    "withdateranges": true,
                                                    "container_id": "tradingview_3d8bd"
                                                }
                                            );
                                        </script>
                                    </div>
                                    <!-- TradingView Widget END -->
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="p-1">
                        <div class="block block_left_bottom">
                            <div class="block_tab d-flex align-items-center">
                                <ul class="nav nav-tabs" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active" data-toggle="tab" href="#open_order_advance_tab">
                                            Open Orders
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-toggle="tab" href="#active_order_advance_tab">
                                            Active Trade Orders
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-toggle="tab" href="#stop_limit_order_advance_tab">
                                            Stop Limit Orders
                                        </a>
                                    </li>
                                </ul>
                                <ul class="check_list_exchange ml-auto">
                                    <li>
                                        <div class="custom-control custom-checkbox checkbox_exchange">
                                            <input type="checkbox" class="custom-control-input" id="hide_pair"
                                                name="example1">
                                            <label class="custom-control-label" for="hide_pair">Hide Other
                                                Pairs</label>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="tab-content">
                                <div id="open_order_advance_tab" class="tab-pane active">
                                    <div class="table_trade open_order_advance">
                                        <div class="table_responsive">
                                            <table id="open_order_advance" class="display nowrap" style="width:100%">
                                                <thead>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Pair</th>
                                                        <th>Type</th>
                                                        <th>Side</th>
                                                        <th>Price</th>
                                                        <th>Amount</th>
                                                        <th>Total</th>
                                                        <th>
                                                            <select
                                                                class="custom-select select_exchange select_open_order ml-auto">
                                                                <option selected="">Cancel All</option>
                                                                <option value="">Stop</option>
                                                                <option value="">Limit</option>
                                                                <option value="">Market</option>
                                                            </select>
                                                        </th>
                                                    </tr>
                                                </thead>
                                                <tbody class="open_orders">
                                                <?php 
                                                    if(count($open_orders)>0)
                                                    {
                                                     foreach($open_orders as $open)
                                                     {
                                                        $decimalpoints = 8;
                                                        $activefilledAmount=$open->totalamount;
                                                        $activePrice=$open->Price;
                                                        $Fee=number_format($open->Fee,$decimalpoints);
                                                        $activePrice=number_format($activePrice,$decimalpoints);
                                                        $activeAmount  = $open->Amount;
                                                        if($activefilledAmount)
                                                        {
                                                          $activefilledAmount = $activeAmount-$activefilledAmount;
                                                        }
                                                        else
                                                        {
                                                          $activefilledAmount = $activeAmount;
                                                        }
                                                        $activefilledAmount=number_format($activefilledAmount,$decimalpoints);
                                                        
                                                        $click="return cancel_order('".$open->trade_id."')";
                                                        $odr_type = $open->Type;
                                                        $odr_status = $open->status;
                                                        $odr_color = '';
                                                        if($odr_type=='buy')
                                                        {
                                                          $odr_color = 'text-green';
                                                          $activeCalcTotal = $activefilledAmount*$activePrice + $Fee;
                                                          $activeCalcTotal=number_format($activeCalcTotal,$decimalpoints);
                                                        }
                                                        else
                                                        {
                                                          $odr_color = 'text-red';
                                                          $activeCalcTotal = $activefilledAmount*$activePrice - $Fee;
                                                          $activeCalcTotal=number_format($activeCalcTotal,$decimalpoints);
                                                        }
                                                        if($odr_status=="partially")
                                                        {
                                                          $style_st = "display:none";
                                                        }
                                                        else
                                                        {
                                                          $style_st = "display:block";
                                                        }
                                                        $time = $open->trade_time;
                                                        $click="return cancel_order('".$open->trade_id."')";
                                                        $pair_symbol = $open->pair;
                                                        $pair_details = $this->common_model->getTableData('trade_pairs', array('id' => $pair_symbol,'status'=>1))->row();
                                       

                                        $from_symbol_active = $this->common_model->getTableData('currency', array('id' => $pair_details->from_symbol_id,'status'=>1))->row();

                                        $to_symbol_active = $this->common_model->getTableData('currency', array('id' => $pair_details->to_symbol_id,'status'=>1))->row();

                                        $pair_active = strtoupper($from_symbol_active->currency_symbol).'/'.strtoupper($to_symbol_active->currency_symbol);

                                        $order_type = $open->ordertype;
                                        if($order_type == 'limit') $ordertype = 'Limit';
                                        else if($order_type == 'stop') $ordertype = 'Stop Order';
                                        else if($order_type == 'instant') $ordertype = 'Market';
                                        else $ordertype = '-';

                                        $page_sym = $First_Currency."/".$Second_Currency;

                                        if($pair_active==$page_sym) $myclass = 'currentpair';
                                        else $myclass = 'differpair';
                                         ?>

                                                        <tr class="<?=$myclass?>">
                                                        <td><?php echo $time;?></td>
                                                        <td><?php echo $pair_symbol;?></td>
                                                        <td class='<?php echo $odr_color;?>'><?php echo ucfirst($odr_type);?></td>
                                                        <td>-</td>
                                                        <td><?php echo number_format($activePrice,6);?></td>
                                                        <td><?php echo number_format($activefilledAmount,3);?></td>
                                                        <td><?php echo number_format($activeCalcTotal,8);?></td>
                                                        <td>
                                                        <a class="text-red" href="javascript:void(0);" style="<?php echo $style_st;?>"><i class="fa fa-times" onclick="<?php echo $click;?>"></i>
                                                        </a>
                                                        </td>
                                                        </tr>

                                                     <?php } } else { echo '<tr><td></td><td></td><td>No Open Orders.</td><td></td><td></td><td></td><td></td></tr>'; }?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div id="active_order_advance_tab" class="tab-pane">
                                    <div class="table_trade active_trade_order_advance">
                                        <div class="table_responsive">
                                            <table id="active_trade_order_advance" class="display nowrap"
                                                style="width:100%">
                                                <thead>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Pair</th>
                                                        <th>Type</th>
                                                        <th>Side</th>
                                                        <th>Price</th>
                                                        <th>Amount</th>
                                                        <th>Total</th>
                                                    </tr>
                                                </thead>
                                                <tbody class="active_orders">
                                                <?php 
                                                if(count($active_orders)>0)
                                                {
                                                 foreach($active_orders as $act)
                                                 {
                                                    $decimalpoints = 8;
                                                    $activefilledAmount=$act->totalamount;
                                                    $activePrice=$act->Price;
                                                    $Fee=number_format($act->Fee,$decimalpoints);
                                                    $activePrice=number_format($activePrice,$decimalpoints);
                                                    $activeAmount  = $act->Amount;
                                                    if($activefilledAmount)
                                                    {
                                                      $activefilledAmount = $activeAmount-$activefilledAmount;
                                                    }
                                                    else
                                                    {
                                                      $activefilledAmount = $activeAmount;
                                                    }
                                                    $activefilledAmount=number_format($activefilledAmount,$decimalpoints);
                                                    
                                                    $click="return cancel_order('".$act->trade_id."')";
                                                    $odr_type = $act->Type;
                                                    $odr_status = $act->status;
                                                    $odr_color = '';
                                                    if($odr_type=='buy')
                                                    {
                                                      $odr_color = 'text-green';
                                                      $activeCalcTotal = $activefilledAmount*$activePrice + $Fee;
                                                      $activeCalcTotal=number_format($activeCalcTotal,$decimalpoints);
                                                    }
                                                    else
                                                    {
                                                      $odr_color = 'text-red';
                                                      $activeCalcTotal = $activefilledAmount*$activePrice - $Fee;
                                                      $activeCalcTotal=number_format($activeCalcTotal,$decimalpoints);
                                                    }
                                                    if($odr_status=="partially")
                                                    {
                                                      $style_st = "display:none";
                                                    }
                                                    else
                                                    {
                                                      $style_st = "display:block";
                                                    }
                                                    $time = $act->trade_time;
                                                    $click="return cancel_order('".$act->trade_id."')";
                                                    $pair_symbol = $act->pair_symbol; ?>

                                                    <tr>
                                                    <td><?php echo $time;?></td>
                                                    <td class='<?php echo $odr_color;?>'><?php echo ucfirst($odr_type);?></td>
                                                    <td><?php echo number_format($Fee,6);?></td>
                                                    <td><?php echo number_format($activePrice,6);?></td>
                                                    <td><?php echo number_format($activefilledAmount,3);?></td>
                                                    <td><?php echo number_format($activeCalcTotal,8);?></td>
                                                    <td>
                                                    <a class="text-red" href="javascript:void(0);" style="<?php echo $style_st;?>"><i class="fa fa-times" onclick="<?php echo $click;?>"></i>
                                                    </a>
                                                    </td>
                                                    </tr>

                                                 <?php } } else { echo '<tr><td></td><td></td><td>No Active Orders.</td><td></td><td></td><td></td><td></td></tr>'; }?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div id="stop_limit_order_advance_tab" class="tab-pane">
                                    <div class="table_trade stop_limit_order_advance">
                                        <div class="table_responsive">
                                            <table id="stop_limit_order_advance" class="display nowrap"
                                                style="width:100%">
                                                <thead>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Pair</th>
                                                        <th>Type</th>
                                                        <th>Side</th>
                                                        <th>Price</th>
                                                        <th>Amount</th>
                                                        <th>Total</th>
                                                    </tr>
                                                </thead>
                                                <tbody class="stop_orders">
                                                   <?php 
                                    if(count($stop_orders)>0 && $stop_orders>0)
                                    {
                                     foreach($stop_orders as $stop)
                                     {
                                        $decimalpoints = 8;
                                        $activefilledAmount=$stop->totalamount;
                                        $activePrice=$stop->Price;
                                        $Fee=number_format($stop->Fee,$decimalpoints);
                                        $activePrice=number_format($activePrice,$decimalpoints);
                                        $activeAmount  = $stop->Amount;
                                        if($activefilledAmount)
                                        {
                                          $activefilledAmount = $activeAmount-$activefilledAmount;
                                        }
                                        else
                                        {
                                          $activefilledAmount = $activeAmount;
                                        }
                                        $activefilledAmount=number_format($activefilledAmount,$decimalpoints);
                                        
                                        $click="return cancel_order('".$stop->trade_id."')";
                                        $odr_type = $stop->Type;
                                        $odr_status = $stop->status;
                                        $odr_color = '';
                                        if($odr_type=='buy')
                                        {
                                          $odr_color = 'text-green';
                                          $activeCalcTotal = $activefilledAmount*$activePrice + $Fee;
                                          $activeCalcTotal=number_format($activeCalcTotal,$decimalpoints);
                                        }
                                        else
                                        {
                                          $odr_color = 'text-red';
                                          $activeCalcTotal = $activefilledAmount*$activePrice - $Fee;
                                          $activeCalcTotal=number_format($activeCalcTotal,$decimalpoints);
                                        }
                                        if($odr_status=="partially")
                                        {
                                          $style_st = "display:none";
                                        }
                                        else
                                        {
                                          $style_st = "display:block";
                                        }
                                        $time = $stop->trade_time;
                                        $click="return cancel_order('".$stop->trade_id."')";
                                        $pair_symbol = $stop->pair; 
                                        $pair_details = $this->common_model->getTableData('trade_pairs', array('id' => $pair_symbol,'status'=>1))->row();

                                        $from_symbol_active = $this->common_model->getTableData('currency', array('id' => $pair_details->from_symbol_id,'status'=>1))->row();

                                        $to_symbol_active = $this->common_model->getTableData('currency', array('id' => $pair_details->to_symbol_id,'status'=>1))->row();

                                        $pair_active = strtoupper($from_symbol_active->currency_symbol).'/'.strtoupper($to_symbol_active->currency_symbol);

                                        $order_type = $stop->ordertype;
                                        if($order_type == 'limit') $ordertype = 'Limit';
                                        else if($order_type == 'stop') $ordertype = 'Stop Order';
                                        else if($order_type == 'instant') $ordertype = 'Market';
                                        else $ordertype = '-';

                                        if($pair_active==$page_sym) $myclass = 'currentpair';
                                        else $myclass = 'differpair';

                                        ?>

                                                 <tr class="<?=$myclass?>">
                                                    <td><?php echo $time;?></td>
                                                    <td><?php echo $pair_active;?></td>
                                                    <td class='<?php echo $odr_color;?>'><?php echo ucfirst($odr_type);?></td>
                                                    <td><?=$ordertype?></td> 
                                                    <td><?php echo number_format($activePrice,6);?></td>
                                        <td><?php echo number_format($activefilledAmount,3);?></td>
                                        <td><?php echo number_format($activeCalcTotal,8);?></td>
                                                    <td>
                                                   <a class="text-red" href="javascript:void(0);" style="<?php echo $style_st;?>"><i class="fa fa-times" onclick="<?php echo $click;?>"></i>
                                        </a>
                                                    </td>
                                                    </tr>

                                                  <?php } 
                                 } else { echo '<tr><td></td><td></td><td>No Stop Orders.</td><td></td><td></td><td></td><td></td><td></td></tr>'; } ?>
                                                    
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-5">
                    <div class="row no-gutters">
                        <div class="col-md-6">
                            <div class="p-1">
                                <div class="block block_right_top_left">
                                    <div class="block_tab d-flex align-items-center">
                                        <ul class="nav nav-tabs" role="tablist">
                                            <li class="nav-item">
                                                <a class="nav-link active" data-toggle="tab" href="#buy_sell_order">
                                                    <img src="<?php echo base_url();?>assets/front/inner/img/buy_sell_order_icon.svg" width="20px"
                                                        class="img-fluid" alt="icon">
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" data-toggle="tab" href="#buy_order">
                                                    <img src="<?php echo base_url();?>assets/front/inner/img/buy_order_icon.svg" width="20px" class="img-fluid"
                                                        alt="icon">
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" data-toggle="tab" href="#sell_order">
                                                    <img src="<?php echo base_url();?>assets/front/inner/img/sell_order_icon.svg" width="20px" class="img-fluid"
                                                        alt="icon">
                                                </a>
                                            </li>
                                        </ul>
                                        <select class="custom-select select_exchange select_decimal ml-auto">
                                            <option value="3" selected>3 Decimal</option>
                                            <option value="4">4 Decimal</option>
                                            <option value="5">5 Decimals</option>
                                            <option value="6">6 Decimals</option>
                                        </select>
                                    </div>
                                    <div class="tab-content">
                                        <div id="buy_sell_order" class="tab-pane active">
                                            <div class="buy_sell_order_advance d-flex flex-column">
                                                <div class="table_trade">
                                                    <div class="table_responsive">
                                                        <table id="sell_order_table_advance_1" class="display nowrap"
                                                            style="width:100%">
                                                            <thead>
                                                                <tr>
                                                                    <th>Price</th>
                                                                    <th>Amount</th>
                                                                    <th>Total</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody class="buy_order">
                                                            <?php
                                                            $decimalpoints = 8;
                                                            if(count($buy_orders)>0)
                                                            {
                                                              
                                                              foreach($buy_orders as $buy)
                                                              {
                                                                $activefilledAmount=$buy->totalamount;
                                                                $activePrice=$buy->Price;
                                                                $Fee=$buy->Fee;
                                                                $activePrice=number_format($activePrice,$decimalpoints);
                                                                $activeAmount  = $buy->Amount;
                                                                if($activefilledAmount)
                                                                {
                                                                  $activefilledAmount = $activeAmount-$activefilledAmount;
                                                                }
                                                                else
                                                                {
                                                                  $activefilledAmount = $activeAmount;
                                                                }
                                                                $activefilledAmount=number_format($activefilledAmount,$decimalpoints);

                                                                $activeCalcTotal = $activefilledAmount*$activePrice + $Fee;
                                                                $activeCalcTotal=number_format($activeCalcTotal,$decimalpoints);
                                                                
                                                                $type="sell"; ?>
                                                                
                                                                <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($activePrice,$decimalpoints);?>,<?php echo number_format($activefilledAmount,$decimalpoints); ?>)" class="decimal_3">
                                                                <td class="text-red activeprice"><?php echo number_format($activePrice,3);?></td>
                                                                <td><?php echo number_format($activefilledAmount,3); ?></td>
                                                                <td><?php echo number_format($activeCalcTotal,8); ?></td>
                                                                </tr>
                                                                
                                                                <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($activePrice,$decimalpoints);?>,<?php echo number_format($activefilledAmount,$decimalpoints); ?>)" class="decimal_4">
                                                                <td class="text-red activeprice"><?php echo number_format($activePrice,4);?></td>
                                                                <td><?php echo number_format($activefilledAmount,3); ?></td>
                                                                <td><?php echo number_format($activeCalcTotal,8); ?></td>
                                                                </tr>

                                                                <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($activePrice,$decimalpoints);?>,<?php echo number_format($activefilledAmount,$decimalpoints); ?>)" class="decimal_5" style="display:none;">
                                                                <td class="text-red activeprice"><?php echo number_format($activePrice,5);?></td>
                                                                <td><?php echo number_format($activefilledAmount,3); ?></td>
                                                                <td><?php echo number_format($activeCalcTotal,8); ?></td>
                                                                </tr>

                                                                <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($activePrice,$decimalpoints);?>,<?php echo number_format($activefilledAmount,$decimalpoints); ?>)" class="decimal_6" style="display:none;">
                                                                <td class="text-red activeprice"><?php echo number_format($activePrice,6);?></td>
                                                                <td><?php echo number_format($activefilledAmount,3); ?></td>
                                                                <td><?php echo number_format($activeCalcTotal,8); ?></td>
                                                                </tr>

                                                            <?php }  }
                                                              else
                                                              { 

                                                                if(count($api_buyorders)>0)
                                                                {
                                                                 
                                                                  foreach($api_buyorders as $buy)
                                                                  {
                                                                   
                                                                    $type="'sell'";

                                                                    $buy_totl = number_format($buy['quantity']*$buy['price'],8);
                                                                    ?>
                                                                    <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($buy['price'],$decimalpoints);?>,<?php echo number_format($buy['quantity'],$decimalpoints); ?>)" class="decimal_3">
                                                                    <td class="text-red activeprice"><?php echo number_format($buy['price'],3);?></td>
                                                                    <td><?php echo number_format($buy['quantity'],3); ?></td>
                                                                    <td><?php echo number_format($buy_totl,8); ?></td>
                                                                    </tr>

                                                                    <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($buy['price'],$decimalpoints);?>,<?php echo number_format($buy['quantity'],$decimalpoints); ?>)" class="decimal_4" style="display:none;">
                                                                    <td class="text-red activeprice"><?php echo number_format($buy['price'],4);?></td>
                                                                    <td><?php echo number_format($buy['quantity'],3); ?></td>
                                                                    <td><?php echo number_format($buy_totl,8); ?></td>
                                                                    </tr>

                                                                    <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($buy['price'],$decimalpoints);?>,<?php echo number_format($buy['quantity'],$decimalpoints); ?>)" class="decimal_5" style="display:none;">
                                                                    <td class="text-red activeprice"><?php echo number_format($buy['price'],5);?></td>
                                                                    <td><?php echo number_format($buy['quantity'],3); ?></td>
                                                                    <td><?php echo number_format($buy_totl,8); ?></td>
                                                                    </tr>

                                                                    <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($buy['price'],$decimalpoints);?>,<?php echo number_format($buy['quantity'],$decimalpoints); ?>)" class="decimal_6" style="display:none;">
                                                                    <td class="text-red activeprice"><?php echo number_format($buy['price'],6);?></td>
                                                                    <td><?php echo number_format($buy['quantity'],3); ?></td>
                                                                    <td><?php echo number_format($buy_totl,8); ?></td>
                                                                    </tr>
                                                                     
                                                                <?php } } }
                                                              ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="price_stats">
                                                    <h4 class="text-green"><?php echo number_format($trading_price,6);?>
                                                     <i class="fa fa-long-arrow-alt-up"></i>
                                                        <small>$ <?php echo number_format($latestusd_price,2); ?></small>
                                                    </h4>
                                                </div>
                                                <div class="table_trade">
                                                    <div class="table_responsive">
                                                        <table id="buy_order_table_advance_1" class="display nowrap"
                                                            style="width:100%">
                                                            <thead>
                                                                <tr>
                                                                    <th>Price</th>
                                                                    <th>Amount</th>
                                                                    <th>Total</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody class="sell_order">
                                                            <?php
                                                            if(count($sell_orders)>0)
                                                            {
                                                              foreach($sell_orders as $sell)
                                                              {
                                                                $activefilledAmount=$sell->totalamount;
                                                                $activePrice=$sell->Price;
                                                                $Fee=$sell->Fee;
                                                                $activePrice=number_format($activePrice,8);
                                                                $activeAmount  = $sell->Amount;
                                                                if($activefilledAmount)
                                                                {
                                                                  $activefilledAmount = $activeAmount-$activefilledAmount;
                                                                }
                                                                else
                                                                {
                                                                  $activefilledAmount = $activeAmount;
                                                                }
                                                                $activefilledAmount=number_format($activefilledAmount,8);

                                                                $activeCalcTotal = $activefilledAmount*$activePrice - $Fee;
                                                                $activeCalcTotal=number_format($activeCalcTotal,8);
                                                                
                                                                $type="sell"; ?>
                                                                
                                                                <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($activePrice,3);?>,<?php echo number_format($activefilledAmount,8); ?>)" class="decimal_3">
                                                                <td class="text-green activeprice"><?php echo number_format($activePrice,3);?></td>
                                                                <td><?php echo number_format($activefilledAmount,3); ?></td>
                                                                <td><?php echo number_format($activeCalcTotal,8); ?></td>
                                                                </tr>

                                                                <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($activePrice,4);?>,<?php echo number_format($activefilledAmount,8); ?>)" class="decimal_4">
                                                                <td class="text-green activeprice"><?php echo number_format($activePrice,4);?></td>
                                                                <td><?php echo number_format($activefilledAmount,3); ?></td>
                                                                <td><?php echo number_format($activeCalcTotal,8); ?></td>
                                                                </tr>

                                                                <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($activePrice,5);?>,<?php echo number_format($activefilledAmount,8); ?>)" class="decimal_5">
                                                                <td class="text-green activeprice"><?php echo number_format($activePrice,5);?></td>
                                                                <td><?php echo number_format($activefilledAmount,3); ?></td>
                                                                <td><?php echo number_format($activeCalcTotal,8); ?></td>
                                                                </tr>

                                                                <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($activePrice,6);?>,<?php echo number_format($activefilledAmount,8); ?>)" class="decimal_6">
                                                                <td class="text-green activeprice"><?php echo number_format($activePrice,6);?></td>
                                                                <td><?php echo number_format($activefilledAmount,3); ?></td>
                                                                <td><?php echo number_format($activeCalcTotal,8); ?></td>
                                                                </tr>
                                                                

                                                            <?php }  }
                                                              else
                                                              { 

                                                                if(count($api_sellorders)>0)
                                                                {
                                                                 
                                                                  foreach($api_sellorders as $sell)
                                                                  {
                                                                   
                                                                    $type="'sell'";

                                                                    $sell_totl = number_format($sell['quantity']*$sell['price'],8);
                                                                    ?>
                                                                    <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($sell['price'],3);?>,<?php echo number_format($sell['quantity'],8); ?>)" class="decimal_3">
                                                                    <td class="text-green activeprice"><?php echo number_format($sell['price'],3);?></td>
                                                                    <td><?php echo number_format($sell['quantity'],3); ?></td>
                                                                    <td><?php echo number_format($sell_totl,8); ?></td>
                                                                    </tr>

                                                                    <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($sell['price'],4);?>,<?php echo number_format($sell['quantity'],8); ?>)" class="decimal_4">
                                                                    <td class="text-green activeprice"><?php echo number_format($sell['price'],4);?></td>
                                                                    <td><?php echo number_format($sell['quantity'],3); ?></td>
                                                                    <td><?php echo number_format($sell_totl,8); ?></td>
                                                                    </tr>

                                                                    <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($sell['price'],5);?>,<?php echo number_format($sell['quantity'],8); ?>)" class="decimal_5">
                                                                    <td class="text-green activeprice"><?php echo number_format($sell['price'],5);?></td>
                                                                    <td><?php echo number_format($sell['quantity'],3); ?></td>
                                                                    <td><?php echo number_format($sell_totl,8); ?></td>
                                                                    </tr>

                                                                    <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($sell['price'],6);?>,<?php echo number_format($sell['quantity'],8); ?>)" class="decimal_6">
                                                                    <td class="text-green activeprice"><?php echo number_format($sell['price'],6);?></td>
                                                                    <td><?php echo number_format($sell['quantity'],3); ?></td>
                                                                    <td><?php echo number_format($sell_totl,8); ?></td>
                                                                    </tr>
                                                                     
                                                                <?php } } } ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="buy_order" class="tab-pane">
                                            <div class="price_stats">
                                                <h4 class="text-green"><?php echo number_format($trading_price,6);?> <i class="fa fa-long-arrow-alt-up"></i>
                                                    <small>$ <?php echo number_format($latestusd_price,2);?></small>
                                                </h4>
                                            </div>
                                            <div class="table_trade buy_order_table_advance_2">
                                                <div class="table_responsive">
                                                    <table id="buy_order_table_advance_2" class="display nowrap"
                                                        style="width:100%">
                                                        <thead>
                                                            <tr>
                                                                <th>Price</th>
                                                                <th>Amount</th>
                                                                <th>Total</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="sell_order">
                                                        <?php
                                                        if(count($sell_orders)>0)
                                                        {
                                                          foreach($sell_orders as $sell)
                                                          {
                                                            $activefilledAmount=$sell->totalamount;
                                                            $activePrice=$sell->Price;
                                                            $Fee=$sell->Fee;
                                                            $activePrice=number_format($activePrice,8);
                                                            $activeAmount  = $sell->Amount;
                                                            if($activefilledAmount)
                                                            {
                                                              $activefilledAmount = $activeAmount-$activefilledAmount;
                                                            }
                                                            else
                                                            {
                                                              $activefilledAmount = $activeAmount;
                                                            }
                                                            $activefilledAmount=number_format($activefilledAmount,8);

                                                            $activeCalcTotal = $activefilledAmount*$activePrice - $Fee;
                                                            $activeCalcTotal=number_format($activeCalcTotal,8);
                                                            
                                                            $type="sell"; ?>
                                                            
                                                            <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($activePrice,3);?>,<?php echo number_format($activefilledAmount,8); ?>)" class="decimal_3">
                                                            <td class="text-green activeprice"><?php echo number_format($activePrice,3);?></td>
                                                            <td><?php echo number_format($activefilledAmount,3); ?></td>
                                                            <td><?php echo number_format($activeCalcTotal,8); ?></td>
                                                            </tr>

                                                            <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($activePrice,4);?>,<?php echo number_format($activefilledAmount,8); ?>)" class="decimal_4">
                                                            <td class="text-green activeprice"><?php echo number_format($activePrice,4);?></td>
                                                            <td><?php echo number_format($activefilledAmount,3); ?></td>
                                                            <td><?php echo number_format($activeCalcTotal,8); ?></td>
                                                            </tr>

                                                            <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($activePrice,5);?>,<?php echo number_format($activefilledAmount,8); ?>)" class="decimal_5">
                                                            <td class="text-green activeprice"><?php echo number_format($activePrice,5);?></td>
                                                            <td><?php echo number_format($activefilledAmount,3); ?></td>
                                                            <td><?php echo number_format($activeCalcTotal,8); ?></td>
                                                            </tr>

                                                            <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($activePrice,6);?>,<?php echo number_format($activefilledAmount,8); ?>)" class="decimal_6">
                                                            <td class="text-green activeprice"><?php echo number_format($activePrice,6);?></td>
                                                            <td><?php echo number_format($activefilledAmount,3); ?></td>
                                                            <td><?php echo number_format($activeCalcTotal,8); ?></td>
                                                            </tr>
                                                            

                                                        <?php }  }
                                                          else
                                                          { 

                                                            if(count($api_sellorders)>0)
                                                            {
                                                             
                                                              foreach($api_sellorders as $sell)
                                                              {
                                                               
                                                                $type="'sell'";

                                                                $sell_totl = number_format($sell['quantity']*$sell['price'],8);
                                                                ?>
                                                                <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($sell['price'],3);?>,<?php echo number_format($sell['quantity'],8); ?>)" class="decimal_3">
                                                                <td class="text-green activeprice"><?php echo number_format($sell['price'],3);?></td>
                                                                <td><?php echo number_format($sell['quantity'],3); ?></td>
                                                                <td><?php echo number_format($sell_totl,8); ?></td>
                                                                </tr>

                                                                <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($sell['price'],4);?>,<?php echo number_format($sell['quantity'],8); ?>)" class="decimal_4">
                                                                <td class="text-green activeprice"><?php echo number_format($sell['price'],4);?></td>
                                                                <td><?php echo number_format($sell['quantity'],3); ?></td>
                                                                <td><?php echo number_format($sell_totl,8); ?></td>
                                                                </tr>

                                                                <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($sell['price'],5);?>,<?php echo number_format($sell['quantity'],8); ?>)" class="decimal_5">
                                                                <td class="text-green activeprice"><?php echo number_format($sell['price'],5);?></td>
                                                                <td><?php echo number_format($sell['quantity'],3); ?></td>
                                                                <td><?php echo number_format($sell_totl,8); ?></td>
                                                                </tr>

                                                                <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($sell['price'],6);?>,<?php echo number_format($sell['quantity'],8); ?>)" class="decimal_6">
                                                                <td class="text-green activeprice"><?php echo number_format($sell['price'],6);?></td>
                                                                <td><?php echo number_format($sell['quantity'],3); ?></td>
                                                                <td><?php echo number_format($sell_totl,8); ?></td>
                                                                </tr>
                                                                 
                                                            <?php } } } ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="sell_order" class="tab-pane">
                                            <div class="table_trade sell_order_table_advance_2">
                                                <div class="table_responsive">
                                                    <table id="sell_order_table_advance_2" class="display nowrap"
                                                        style="width:100%">
                                                        <thead>
                                                            <tr>
                                                                <th>Price</th>
                                                                <th>Amount</th>
                                                                <th>Total</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="buy_order">
                                                        <?php
                                                        $decimalpoints = 8;
                                                        if(count($buy_orders)>0)
                                                        {
                                                          
                                                          foreach($buy_orders as $buy)
                                                          {
                                                            $activefilledAmount=$buy->totalamount;
                                                            $activePrice=$buy->Price;
                                                            $Fee=$buy->Fee;
                                                            $activePrice=number_format($activePrice,$decimalpoints);
                                                            $activeAmount  = $buy->Amount;
                                                            if($activefilledAmount)
                                                            {
                                                              $activefilledAmount = $activeAmount-$activefilledAmount;
                                                            }
                                                            else
                                                            {
                                                              $activefilledAmount = $activeAmount;
                                                            }
                                                            $activefilledAmount=number_format($activefilledAmount,$decimalpoints);

                                                            $activeCalcTotal = $activefilledAmount*$activePrice + $Fee;
                                                            $activeCalcTotal=number_format($activeCalcTotal,$decimalpoints);
                                                            
                                                            $type="sell"; ?>
                                                            
                                                            <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($activePrice,$decimalpoints);?>,<?php echo number_format($activefilledAmount,$decimalpoints); ?>)" class="decimal_3">
                                                            <td class="text-red activeprice"><?php echo number_format($activePrice,3);?></td>
                                                            <td><?php echo number_format($activefilledAmount,3); ?></td>
                                                            <td><?php echo number_format($activeCalcTotal,8); ?></td>
                                                            </tr>
                                                            
                                                            <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($activePrice,$decimalpoints);?>,<?php echo number_format($activefilledAmount,$decimalpoints); ?>)" class="decimal_4">
                                                            <td class="text-red activeprice"><?php echo number_format($activePrice,4);?></td>
                                                            <td><?php echo number_format($activefilledAmount,3); ?></td>
                                                            <td><?php echo number_format($activeCalcTotal,8); ?></td>
                                                            </tr>

                                                            <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($activePrice,$decimalpoints);?>,<?php echo number_format($activefilledAmount,$decimalpoints); ?>)" class="decimal_5" style="display:none;">
                                                            <td class="text-red activeprice"><?php echo number_format($activePrice,5);?></td>
                                                            <td><?php echo number_format($activefilledAmount,3); ?></td>
                                                            <td><?php echo number_format($activeCalcTotal,8); ?></td>
                                                            </tr>

                                                            <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($activePrice,$decimalpoints);?>,<?php echo number_format($activefilledAmount,$decimalpoints); ?>)" class="decimal_6" style="display:none;">
                                                            <td class="text-red activeprice"><?php echo number_format($activePrice,6);?></td>
                                                            <td><?php echo number_format($activefilledAmount,3); ?></td>
                                                            <td><?php echo number_format($activeCalcTotal,8); ?></td>
                                                            </tr>

                                                        <?php }  }
                                                          else
                                                          { 

                                                            if(count($api_buyorders)>0)
                                                            {
                                                             
                                                              foreach($api_buyorders as $buy)
                                                              {
                                                               
                                                                $type="'sell'";

                                                                $buy_totl = number_format($buy['quantity']*$buy['price'],8);
                                                                ?>
                                                                <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($buy['price'],$decimalpoints);?>,<?php echo number_format($buy['quantity'],$decimalpoints); ?>)" class="decimal_3">
                                                                <td class="text-red activeprice"><?php echo number_format($buy['price'],3);?></td>
                                                                <td><?php echo number_format($buy['quantity'],3); ?></td>
                                                                <td><?php echo number_format($buy_totl,8); ?></td>
                                                                </tr>

                                                                <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($buy['price'],$decimalpoints);?>,<?php echo number_format($buy['quantity'],$decimalpoints); ?>)" class="decimal_4" style="display:none;">
                                                                <td class="text-red activeprice"><?php echo number_format($buy['price'],4);?></td>
                                                                <td><?php echo number_format($buy['quantity'],3); ?></td>
                                                                <td><?php echo number_format($buy_totl,8); ?></td>
                                                                </tr>

                                                                <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($buy['price'],$decimalpoints);?>,<?php echo number_format($buy['quantity'],$decimalpoints); ?>)" class="decimal_5" style="display:none;">
                                                                <td class="text-red activeprice"><?php echo number_format($buy['price'],5);?></td>
                                                                <td><?php echo number_format($buy['quantity'],3); ?></td>
                                                                <td><?php echo number_format($buy_totl,8); ?></td>
                                                                </tr>

                                                                <tr onclick="placeorder(<?php echo $type; ?>,<?php echo number_format($buy['price'],$decimalpoints);?>,<?php echo number_format($buy['quantity'],$decimalpoints); ?>)" class="decimal_6" style="display:none;">
                                                                <td class="text-red activeprice"><?php echo number_format($buy['price'],6);?></td>
                                                                <td><?php echo number_format($buy['quantity'],3); ?></td>
                                                                <td><?php echo number_format($buy_totl,8); ?></td>
                                                                </tr>
                                                                 
                                                            <?php } } }
                                                          ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                            <div class="price_stats">
                                                <h4 class="text-green"><?php echo number_format($trading_price,6);?> <i class="fa fa-long-arrow-alt-up"></i>
                                                    <small>$ <?php echo number_format($latestusd_price,2); ?></small>
                                                </h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <?php if($user_id!='' && $user_id>0) { ?>
                            <div class="p-1">
                                <div class="block block_right_top_right">
                                    <div class="table_trade trade_history_advance">
                                        <div class="table_responsive">
                                            <table id="trade_history" class="display nowrap" style="width:100%">
                                                <thead>
                                                    <tr>
                                                        <th>Price</th>
                                                        <th>Amount</th>
                                                        <th>Date and Time</th>
                                                    </tr>
                                                </thead>
                                                <tbody class="transactionhistory">
                                                 <?php
                                    if(count($transactionhistory)>0)
                                  {
                                  $historys = "";
                                  $decimalpoints = 8;
                                  foreach($transactionhistory as $trans)
                                  {
                                  if($trans->trade_id!='')
                                  {
                                  $time3 = $trans->tradetime;
                                  $price3 = $trans->Price;
                                  $amount3 = $trans->Amount;
                                  $times3 = $time3;
                                  $type3 = $trans->Type;
                                  $hist_clr = "";
                                    if($type3=="Buy")
                                    {
                                      $hist_clr = "text-green";
                                    }
                                    else
                                    {
                                      $hist_clr = "text-red";
                                    }

                                    $historys='<tr><td class='.$hist_clr.'>'.number_format($price3,6).'</td><td>'.number_format($amount3,3).'</td><td>'.$time3.'</td></tr>';
                                    }
                                    else
                                    {    
                                        
                                        $askAmount=$trans->askAmount;
                                        $buy_userId = $trans->buyerUserid;
                                        $sell_userId = $trans->sellerUserid;
                                        $buyer_trade_id=$trans->buyer_trade_id;
                                        $seller_trade_id=$trans->seller_trade_id;
                                        $filledAmount=$trans->filledAmount;
                                        $filledAmount=number_format($filledAmount,$decimalpoints);

                                        if($buy_userId==$user_id)
                                        {
                                          $type1="Buy";
                                          $askPrice=$trans->buyaskPrice;
                                          $askPrice=number_format($askPrice,$decimalpoints);
                                          $sellaskPrice=$trans->sellaskPrice;
                                          $sellaskPrice=number_format($sellaskPrice,$decimalpoints);
                                          $orderTime1=$trans->buyertime;
                                          $orderTime2=$trans->sellertime;
                                          $time1 = $orderTime1;
                                          $historys.='<tr><td class="text-green">'.number_format($askPrice,6).'</td><td>'.number_format($filledAmount,3).'</td><td>'.$time1.'</td></tr>';
                                          
                                        }
                                        else if($sell_userId==$user_id)
                                        {
                                          $type1="Sell";
                                          $askPrice=$trans->sellaskPrice;
                                          $askPrice=number_format($askPrice,$decimalpoints);
                                          $sellaskPrice=$trans->buyaskPrice;
                                          $sellaskPrice=number_format($sellaskPrice,$decimalpoints);
                                          $orderTime1=$trans->buyertime;
                                          $orderTime2=$trans->sellertime;
                                          $time2 = $orderTime2;
                                          $historys.='<tr><td class="text-red">'.number_format($askPrice,6).'</td><td>'.number_format($filledAmount,3).'</td><td>'.$time2.'</td></tr>';
                          
                                        }
                                        
                                    }

                                }
                                echo $historys;
                                
                            } ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        </div>
                        <div class="col-md-12">
                            <div class="p-1">
                                <div class="block">
                                    <div class="buy_sell_tab d-flex align-items-center">
                                        <ul class="nav nav-tabs" role="tablist">
                                            <?php 
                                            echo form_open();
                                            echo form_close();
                                            ?>
                                            <li class="nav-item">
                                                <a class="nav-link active" data-toggle="tab" href="#limit">
                                                    Limit
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" data-toggle="tab" href="#market">
                                                    Market
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" data-toggle="tab" href="#stop">
                                                    Stop
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="tab-content">
                                    <div id="limit" class="tab-pane active">
                                        <div class="buy_sell_block p-2">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <form id="limit_buy">
                                                    <input type="hidden" name="buy_order_limit" id="buy_order_limit" value="limit">
                                                    <div class="buy_sell_block_inner">
                                                        <?php if($user_id !='') { ?>
                                                        <h4 class="d-flex">Buy <?php echo $First_Currency;?> <span class="ml-auto">
                                                            <i class="fa fa-wallet"></i> <span class="buy_bal"><?php echo $to_cur;?> <?php echo $Second_Currency;?></span></span>
                                                        </h4>
                                                        <?php } else { ?>
                                                        <h4 class="d-flex">Buy <?php echo $First_Currency;?> <span class="ml-auto"><i
                                                                    class="fa fa-wallet"></i> - <?php echo $Second_Currency;?></span>
                                                        </h4>
                                                        <?php } ?>
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                                    <label>Price :</label>
                                                                    <input type="number" class="form-control"
                                                                        name="buy_price" id="buy_price" onKeyUp="calculation('buy','limit');" value="" placeholder="0.001703" >
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                                    <label>Amount :</label>
                                                                    <input type="number" class="form-control"
                                                                        name="buy_amount" id="buy_amount" onKeyUp="calculation('buy','limit');" value="" placeholder="">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange_buy_sell align-items-center mb-1">
                                                                    <label></label>
                                                                    <ul class="buy_sell_percent d-flex flex-fill">
                                                                        <li><a href="#" onclick="change_buytrade(this,'limit','buy','25');">25%</a></li>
                                                                        <li><a href="#" onclick="change_buytrade(this,'limit','buy','50');">50%</a></li>
                                                                        <li><a href="#" onclick="change_buytrade(this,'limit','buy','75');">75%</a></li>
                                                                        <li><a href="#" onclick="change_buytrade(this,'limit','buy','100');">100%</a></li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                                    <label>Total :</label>
                                                                    <input type="number" class="form-control" name="buy_tot" id="buy_tot" value="">
                                                                    <input type="hidden" name="buy_fee_tot" id="buy_fee_tot">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div class="total_fee mb-4">
                                                                    <span class="text-green">Fee <?php echo number_format($this->maker,1); ?>%
                                                                        <small id="mbuy_totfee">2.5000000</small></span>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div class="d-block alert_outer_block">
                                                                    <div class="alert_content d-flex">
                                                                     <div id="alert_err_buy">
                                                                       <span id="error_msg_buy" class="text-red"></span>
                                                                     </div>
                                                                     <div id="alert_succ_buy">
                                                                       <span id="success_msg_buy" class="text-green"></span>
                                                                     </div>
                                                                     </div>
                                                                    <?php if($user_id!=''){ ?>
                                                                    <button type="button"
                                                                        class="btn-buy w-100 buybutton" onClick="order_placed('buy','limit')">Buy</button>
                                                                    <?php } else { ?>
                                                                    <button type="button"
                                                                        class="btn-buy w-100 buybutton" onClick="checking()">Buy</button>
                                                                    <?php } ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                                </div>
                                                <div class="col-md-6">
                                                    <form id="limit_sell">
                                                    <input type="hidden" name="sell_order_limit" id="sell_order_limit" value="limit">
                                                    <div class="buy_sell_block_inner">
                                                        <?php if($user_id !='') { ?>
                                                        <h4 class="d-flex">Sell <?php echo $First_Currency;?> <span class="ml-auto"><i
                                                                    class="fa fa-wallet"></i> <span class="sell_bal"><?php echo $from_cur;?> <?php echo $First_Currency;?></span></h4>
                                                        <?php } else { ?>
                                                        <h4 class="d-flex">Sell <?php echo $First_Currency;?> <span class="ml-auto"><i
                                                                    class="fa fa-wallet"></i> - <?php echo $First_Currency;?></h4>
                                                        <?php } ?>
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                                    <label>Price :</label>
                                                                    <input type="number" class="form-control"
                                                                        placeholder="0.001703" name="sell_price" id="sell_price" onKeyUp="calculation('sell','limit');" value="">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                                    <label>Amount :</label>
                                                                    <input type="number" class="form-control"
                                                                        placeholder="" name="sell_amount" id="sell_amount" onKeyUp="calculation('sell','limit');" value="">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange_buy_sell align-items-center mb-1">
                                                                    <label></label>
                                                                    <ul class="buy_sell_percent d-flex flex-fill">
                                                                        <li><a href="#" onclick="change_selltrade(this,'limit','sell','25');">25%</a></li>
                                                                        <li><a href="#" onclick="change_selltrade(this,'limit','sell','50');">50%</a></li>
                                                                        <li><a href="#" onclick="change_selltrade(this,'limit','sell','75');">75%</a></li>
                                                                        <li><a href="#" onclick="change_selltrade(this,'limit','sell','100');">100%</a></li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                                    <label>Total :</label>
                                                                     <input type="number" class="form-control" name="sell_tot" id="sell_tot">
                                                                    <input type="hidden" name="sell_fee_tot" id="sell_fee_tot">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div class="total_fee mb-4">
                                                                    <span class="text-red">Fee <?php echo number_format($this->taker,1); ?>%
                                                                        <small id="msell_totfee">2.5000000</small></span>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div class="d-block alert_outer_block">
                                                                    <div class="alert_content d-flex">
                                                                     <div id="alert_err_sell">
                                                                       <span id="error_msg_sell" class="text-red"></span>
                                                                     </div>
                                                                     <div id="alert_succ_sell">
                                                                       <span id="success_msg_sell" class="text-green"></span>
                                                                     </div>
                                                                     </div>
                                                                    <?php if($user_id!=''){ ?>
                                                                    <button type="button"
                                                                        class="btn-sell w-100 sellbutton" onClick="order_placed('sell','limit')">Sell</button>
                                                                    <?php } else { ?>
                                                                    <button type="button"
                                                                        class="btn-sell w-100 sellbutton" onClick="checking()">Sell</button>
                                                                    <?php } ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="market" class="tab-pane">
                                        <div class="buy_sell_block p-2">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <form id="market_buy">
                                                    <input type="hidden" name="buy_order_instant" id="buy_order_instant" value="instant">
                                                    <input type="hidden" name="current_currency" id="current_currency" value="<?php echo $Second_Currency; ?>">
                                                    <input type="hidden" id="currency_value" name="currency_value" value="<?=$to_cur?>">
                                                    <div class="buy_sell_block_inner">
                                                        <?php if($user_id !='') { ?>
                                                        <h4 class="d-flex">Buy <?php echo $First_Currency; ?> <span class="ml-auto"><i
                                                                    class="fa fa-wallet"></i> <span class="buy_bal"><?php echo $to_cur;?> <?php echo $Second_Currency;?></span></span>
                                                        </h4>
                                                        <?php } else { ?>
                                                        <h4 class="d-flex">Buy <?php echo $First_Currency; ?> <span class="ml-auto"><i
                                                                    class="fa fa-wallet"></i> - <?php echo $Second_Currency;?></span>
                                                        </h4>
                                                        <?php } ?>
                                                        
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                                    <label>Price :</label>
                                                                    <input type="number" class="form-control"
                                                                        name="buy_prices" id="buy_prices" onKeyUp="calculation('buy','instant');" value="" placeholder="0.001703">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                                    <label>Amount :</label>
                                                                    <input type="number" class="form-control" name="buy_amounts" id="buy_amounts" onKeyUp="calculation('buy','instant');" value="" placeholder="">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange_buy_sell align-items-center mb-1">
                                                                    <label></label>
                                                                    <ul class="buy_sell_percent d-flex flex-fill">
                                                                        <li><a href="#" onclick="change_buytrade(this,'instant','buy','25');">25%</a></li>
                                                                        <li><a href="#" onclick="change_buytrade(this,'instant','buy','50');">50%</a></li>
                                                                        <li><a href="#" onclick="change_buytrade(this,'instant','buy','75');">75%</a></li>
                                                                        <li><a href="#" onclick="change_buytrade(this,'instant','buy','100');">100%</a></li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                                    <label>Total :</label>
                                                                    <input type="number" class="form-control" name="buy_tots" id="buy_tots"
                                                                        placeholder="">
                                                                    <input type="hidden" name="buy_fee_tots" id="buy_fee_tots" value="">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div class="total_fee mb-4">
                                                                    <span class="text-green">Fee <?php echo number_format($this->maker,1); ?>%
                                                                        <small id="mbuy_totfees">2.5000000</small></span>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div class="d-block alert_outer_block">
                                                                    <div class="alert_content d-flex">
                                                                     <div id="alert_errs_buy">
                                                                       <span id="error_msgs_buy" class="text-red"></span>
                                                                     </div>
                                                                     <div id="alert_succs_buy">
                                                                       <span id="success_msgs_buy" class="text-green"></span>
                                                                     </div>
                                                                     </div>
                                                                    <?php if($user_id!=''){ ?>
                                                                    <button type="button"
                                                                        class="btn-buy w-100 buybutton" onClick="order_placed('buy','instant')">Buy</button>
                                                                    <?php } else { ?>
                                                                    <button type="button"
                                                                        class="btn-buy w-100 buybutton" onClick="checking()">Buy</button>
                                                                    <?php } ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    </form>
                                                </div>
                                                <div class="col-md-6">
                                                    <form id="market_sell">   
                                                    <input type="hidden" name="sell_order_instant" id="sell_order_instant" value="instant">
                                                    <input type="hidden" name="scurrent_currency" id="scurrent_currency" value="<?php echo $First_Currency; ?>">
                                                    <input type="hidden" id="scurrency_value" name="scurrency_value" value="<?=$from_cur?>">
                                                    <div class="buy_sell_block_inner">
                                                        <?php if($user_id !='') { ?>
                                                        <h4 class="d-flex">Sell <?php echo $First_Currency;?> <span class="ml-auto"><i
                                                                    class="fa fa-wallet"></i> <span class="sell_bal"><?php echo $from_cur;?> <?php echo $First_Currency;?></span></h4>
                                                        <?php } else { ?>
                                                        <h4 class="d-flex">Sell <?php echo $First_Currency;?> <span class="ml-auto"><i
                                                                    class="fa fa-wallet"></i> - <?php echo $First_Currency;?></h4>
                                                        <?php } ?>
                                                        
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                                    <label>Price :</label>
                                                                    <input type="number" class="form-control" name="sell_prices" id="sell_prices" onKeyUp="calculation('sell','instant');" value="" placeholder="0.001703">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                                    <label>Amount :</label>
                                                                    <input type="number" class="form-control" name="sell_amounts" id="sell_amounts" onKeyUp="calculation('sell','instant');" value="" placeholder="">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange_buy_sell align-items-center mb-1">
                                                                    <label></label>
                                                                    <ul class="buy_sell_percent d-flex flex-fill">
                                                                        <li><a href="#" onclick="change_selltrade(this,'instant','sell','25');">25%</a></li>
                                                                        <li><a href="#" onclick="change_selltrade(this,'instant','sell','50');">50%</a></li>
                                                                        <li><a href="#" onclick="change_selltrade(this,'instant','sell','75');">75%</a></li>
                                                                        <li><a href="#" onclick="change_selltrade(this,'instant','sell','100');">100%</a></li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                                    <label>Total :</label>
                                                                    <input type="number" class="form-control" name="sell_tots" id="sell_tots" value=""placeholder="">
                                                                    <input type="hidden" name="sell_fee_tots" id="sell_fee_tots" value="">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div class="total_fee mb-4">
                                                                    <span class="text-red">Fee <?php echo number_format($this->taker,1); ?>%
                                                                        <small id="msell_totfees">2.5000000</small></span>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div class="d-block alert_outer_block">
                                                                    <div class="alert_content d-flex">
                                                                     <div id="alert_errs_sell">
                                                                       <span id="error_msgs_sell" class="text-red"></span>
                                                                     </div>
                                                                     <div id="alert_succs_sell">
                                                                       <span id="success_msgs_sell" class="text-green"></span>
                                                                     </div>
                                                                     </div>
                                                                    <?php if($user_id!=''){ ?>
                                                                    <button type="button"
                                                                        class="btn-sell w-100 sellbutton" onClick="order_placed('sell','instant')">Sell</button>
                                                                    <?php } else { ?>
                                                                    <button type="button"
                                                                        class="btn-sell w-100 sellbutton" onClick="checking()">Sell</button>
                                                                    <?php } ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="stop" class="tab-pane">
                                        <div class="buy_sell_block p-2">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <form id="stop_buy">       
                                                    <input type="hidden" name="buy_order_stop" id="buy_order_stop" value="stop">
                                                    <div class="buy_sell_block_inner">
                                                        <?php if($user_id !='') { ?>
                                                        <h4 class="d-flex">Buy <?php echo $First_Currency;?> <span class="ml-auto"><i
                                                                    class="fa fa-wallet"></i> <span class="buy_bal"><?php echo $to_cur;?> <?php echo $Second_Currency;?></span></span>
                                                        </h4>
                                                        <?php } else { ?>
                                                        <h4 class="d-flex">Buy <?php echo $First_Currency;?> <span class="ml-auto"><i
                                                                    class="fa fa-wallet"></i> - <?php echo $Second_Currency;?></span>
                                                        </h4>
                                                        <?php } ?>
                                                        
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                                    <label>Stop :</label>
                                                                    <input type="number" class="form-control" name="buy_pricess" id="buy_pricess" onKeyUp="calculation('buy','stop');" placeholder="0.001703">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                                    <label>Limit :</label>
                                                                    <input type="number" class="form-control" name="buy_limit" id="buy_limit" value=""placeholder="0.001703">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                                    <label>Amount :</label>
                                                                    <input type="number" class="form-control" name="buy_amountss" id="buy_amountss" onKeyUp="calculation('buy','stop');" placeholder="">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange_buy_sell align-items-center mb-1">
                                                                    <label></label>
                                                                    <ul class="buy_sell_percent d-flex flex-fill">
                                                                        <li><a href="#" onclick="change_buytrade(this,'stop','buy','25');">25%</a></li>
                                                                        <li><a href="#" onclick="change_buytrade(this,'stop','buy','50');">50%</a></li>
                                                                        <li><a href="#" onclick="change_buytrade(this,'stop','buy','75');">75%</a></li>
                                                                        <li><a href="#" onclick="change_buytrade(this,'stop','buy','100');">100%</a></li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                                    <label>Total :</label>
                                                                    <input type="number" class="form-control" name="buy_totss" id="buy_totss" value=""placeholder="">
                                                                    <input type="hidden" name="buy_fee_totss" id="buy_fee_totss" value="">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div class="total_fee mb-4">
                                                                    <span class="text-green">Fee <?php echo number_format($this->maker,1); ?>%
                                                                        <small id="mbuy_totfeess">2.5000000</small></span>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div class="d-block alert_outer_block">
                                                                    <div class="alert_content d-flex">
                                                                     <div id="alert_errss_buy">
                                                                       <span id="error_msgss_buy" class="text-red"></span>
                                                                     </div>
                                                                     <div id="alert_succss_buy">
                                                                       <span id="success_msgss_buy" class="text-green"></span>
                                                                     </div>
                                                                     </div>
                                                                    <?php if($user_id!=''){ ?>
                                                                    <button type="button"
                                                                        class="btn-buy w-100 buybutton" onClick="order_placed('buy','stop')">Buy</button>
                                                                    <?php } else { ?>
                                                                    <button type="button"
                                                                        class="btn-buy w-100 buybutton" onClick="checking()">Buy</button>
                                                                    <?php } ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                   </form>
                                                </div>
                                                <div class="col-md-6">
                                                    <form id="stop_sell">    
                                                    <input type="hidden" name="sell_order_stop" id="sell_order_stop" value="stop">
                                                    <div class="buy_sell_block_inner">
                                                        <?php if($user_id !='') { ?>
                                                        <h4 class="d-flex">Sell <?php echo $First_Currency;?> <span class="ml-auto"><i
                                                                    class="fa fa-wallet"></i> <span class="sell_bal"><?php echo $from_cur;?> <?php echo $First_Currency;?></span></h4>
                                                        <?php } else { ?>
                                                        <h4 class="d-flex">Sell <?php echo $First_Currency;?> <span class="ml-auto"><i
                                                                    class="fa fa-wallet"></i> - <?php echo $First_Currency;?></h4>
                                                        <?php } ?>
                                                        
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                                    <label>Stop :</label>
                                                                    <input type="number" class="form-control" name="sell_pricess" id="sell_pricess" onKeyUp="calculation('sell','stop');" value="" placeholder="0.001703">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                                    <label>Limit :</label>
                                                                    <input type="number" class="form-control" name="sell_limit" id="sell_limit" value=""placeholder="0.001703">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                                    <label>Amount :</label>
                                                                    <input type="number" class="form-control" name="sell_amountss" id="sell_amountss" onKeyUp="calculation('sell','stop');" value="" placeholder="">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange_buy_sell align-items-center mb-1">
                                                                    <label></label>
                                                                    <ul class="buy_sell_percent d-flex flex-fill">
                                                                        <li><a href="#" onclick="change_selltrade(this,'stop','sell','25');">25%</a></li>
                                                                        <li><a href="#" onclick="change_selltrade(this,'stop','sell','50');">50%</a></li>
                                                                        <li><a href="#" onclick="change_selltrade(this,'stop','sell','75');">75%</a></li>
                                                                        <li><a href="#" onclick="change_selltrade(this,'stop','sell','100');">100%</a></li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div
                                                                    class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                                    <label>Total :</label>
                                                                    <input type="number" class="form-control" name="sell_totss" id="sell_totss" value="" placeholder="">
                                                                    <input type="hidden" name="sell_fee_totss" id="sell_fee_totss" value="">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div class="total_fee mb-4">
                                                                    <span class="text-red">Fee <?php echo number_format($this->taker,1); ?>%
                                                                        <small id="msell_totfeess">2.5000000</small></span>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div class="d-block alert_outer_block">
                                                                    <div class="alert_content d-flex">
                                                                     <div id="alert_errss_sell">
                                                                       <span id="error_msgss_sell" class="text-red"></span>
                                                                     </div>
                                                                     <div id="alert_succss_sell">
                                                                       <span id="success_msgss_sell" class="text-green"></span>
                                                                     </div>
                                                                     </div>
                                                                    <?php if($user_id!=''){ ?>
                                                                    <button type="button"
                                                                        class="btn-sell w-100 sellbutton" onClick="order_placed('sell','stop')">Sell</button>
                                                                    <?php } else { ?>
                                                                    <button type="button"
                                                                        class="btn-sell w-100 sellbutton" onClick="checking()">Sell</button>
                                                                    <?php } ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                  </form>
                                                </div>
                                            </div>
                                        </div>
                                      </div>
                                   </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php $this->load->view('front/trade/tradepro_footer'); ?>