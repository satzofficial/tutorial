<?php

        $settings = $site_common['site_settings']; 
        $user_id=$this->session->userdata('user_id');

        $url = $this->uri->segment(2);
        $Exp = explode('_', $url);
        $First_Currency = $Exp[0];
        $Second_Currency = $Exp[1];

        $apikey = getCryptoCompareKey();
        $seg1 = $this->uri->segment(1);

if($seg1=='trade') {
?>
  
<script type="text/javascript" src="<?php echo base_url(); ?>chart_library/charting_library/charting_library.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>chart_library/datafeeds/udf/dist/polyfills.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>chart_library/datafeeds/udf/dist/bundle.js?v=<?php echo date('Ymdhis'); ?>"></script> 

<?php }?>

<!--dark-light-toggle-->
<script>


    function toggleDarkLight() {

        var body = document.getElementById("body");
        var currentClass = body.className;

        if(currentClass=='main_body light_mode'){
            tradingview_chart('chart_library_dark','#181B1F');
            sessionStorage.setItem("chart_theme", "main_body dark_mode");
        }
        else{
            tradingview_chart('chart_library','#FFF');
            sessionStorage.setItem("chart_theme", "main_body light_mode");
        }
        body.className = currentClass == "main_body light_mode" ? "main_body dark_mode" : "main_body light_mode";
    }
</script>

<!--datatables-->
<script type="text/javascript" src="https://cdn.datatables.net/w/bs4/dt-1.10.18/datatables.min.js"></script>
<script>
    $(document).ready(function() {
        $('#buy_order_table_1').DataTable({
            "scrollY": 305,
            "scrollX": true,
            "paging": false,
            "info": false,
            "searching": false,
            "language": {
                "decimal": ",",
                "thousands": "."
            }
        });
        $('#sell_order_table_1').DataTable({
            "scrollY": 305,
            "scrollX": true,
            "paging": false,
            "info": false,
            "searching": false,
            "language": {
                "decimal": ",",
                "thousands": "."
            }
        });
        $('#buy_order_table_2').DataTable({
            "scrollY": 625,
            "scrollX": true,
            "paging": false,
            "info": false,
            "searching": false,
            "language": {
                "decimal": ",",
                "thousands": "."
            }
        });
        $('#sell_order_table_2').DataTable({
            "scrollY": 625,
            "scrollX": true,
            "paging": false,
            "info": false,
            "searching": false,
            "language": {
                "decimal": ",",
                "thousands": "."
            }
        });
        $('#pair_favourite').DataTable({
            "scrollY": 270,
            "scrollX": true,
            "paging": false,
            "info": false,
            "searching": false,
            "language": {
                "decimal": ",",
                "thousands": "."
            }
        });
        $('#pair_BTC').DataTable({
            "scrollY": 270,
            "scrollX": true,
            "paging": false,
            "info": false,
            "searching": false,
            "language": {
                "decimal": ",",
                "thousands": "."
            }
        });
        $('#pair_ETH').DataTable({
            "scrollY": 270,
            "scrollX": true,
            "paging": false,
            "info": false,
            "searching": false,
            "language": {
                "decimal": ",",
                "thousands": "."
            }
        });
        $('#trade_history').DataTable({
            "scrollY": 275,
            "scrollX": true,
            "paging": false,
            "info": false,
            "searching": false,
            "language": {
                "decimal": ",",
                "thousands": "."
            }
        });
        $('#open_order').DataTable({
            "scrollY": 200,
            "scrollX": true,
            "paging": false,
            "info": false,
            "searching": false,
            "language": {
                "decimal": ",",
                "thousands": "."
            }
        });
        $('#trade_history_tab').DataTable({
            "scrollY": 200,
            "scrollX": true,
            "paging": false,
            "info": false,
            "searching": false,
            "language": {
                "decimal": ",",
                "thousands": "."
            }
        });
    });
</script>
<script>
    $('a[data-toggle="tab"]').on('shown.bs.tab', function(e) {
        $($.fn.dataTable.tables(true)).DataTable()
            .columns.adjust();
    });
</script>


    <script type="text/javascript">
      var newjson_pair = '<?php echo $First_Currency . $Second_Currency?>';
    var newjson_pairs = '<?php echo $First_Currency . "_" . $Second_Currency?>';

    function tradingview_chart(lib,clr){

        var trade_feed = new Datafeeds.UDFCompatibleDatafeed("<?php echo base_url(); ?>newget_chart_record/" + newjson_pairs, 10000);
      
        var interval = "1";
       var widget = window.tvWidget = new TradingView.widget({
            debug: false,
            fullscreen: true,
            //toolbar_bg: "#4aa832",
            symbol: newjson_pair,
            interval: interval,
            width: 980,
            widgetbar: false,
            name: "Share Coin Exchange",
            height: 800,
            timezone: "Africa/Accra",
            theme: "Light",
            container_id: "tradingview_3d8bd",
            datafeed: trade_feed,
            library_path: "<?php echo base_url(); ?>"+lib+"/charting_library/",
            locale: "en",
            drawings_access: {type: 'black', tools: [{name: "Regression Trend"}]},
            disabled_features: ["use_localstorage_for_settings"],
            autosize: true,
            has_intraday: true,
            intraday_multipliers: ['1', '3', '5', '15', '30', '60', '120', '240', '360', '720', '1D', '1M'],
            has_daily: true,
            has_weekly_and_monthly: true,
            overrides: {
                "paneProperties.background": clr,
                "paneProperties.vertGridProperties.color": "#181B1F",
                "paneProperties.horzGridProperties.color": "#181B1F",
                "symbolWatermarkProperties.transparency": 90,
                "scalesProperties.textColor": "#000",
                "mainSeriesProperties.candleStyle.wickUpColor": '#1e5530',
                "mainSeriesProperties.candleStyle.wickDownColor": '#772830',
                "mainSeriesProperties.candleStyle.upColor": "#52d321",
                "mainSeriesProperties.candleStyle.downColor": "#f1440b"
            },
            exchanges: [{"value": "", "name": "All Exchanges", "desc": ""}, {
                "value": "POLONIEX",
                "name": "POLONIEX",
                "desc": "POLONIEX"
            }
            ],
        });
    }


var chart_theme = sessionStorage.getItem("chart_theme");
seg1 = '<?=$seg1?>';
if(seg1=='trade') {


    TradingView.onready(function () {

var body = document.getElementById("body");

  if(chart_theme=='main_body light_mode'){
      tradingview_chart('chart_library','#FFF');
      body.className = "main_body light_mode";
  }
  else if(chart_theme=='main_body dark_mode'){
      tradingview_chart('chart_library_dark','#181B1F');
      body.className = "main_body dark_mode";
  }
else{
  tradingview_chart('chart_library','#FFF');
}
});
}

</script>

<script>
Number.prototype.noExponents= function(){
    var data= String(this).split(/[eE]/);    
    if(data.length== 1) return data[0]; 

    var  z= '', sign= this<0? '-':'',
    str= data[0].replace('.', ''),
    mag= Number(data[1])+ 1;

    if(mag<0){
        z= sign + '0.';
        while(mag++) z += '0';
        return z + str.replace(/^\-/,'');
    }
    mag -= str.length;  
    while(mag--) z += '0';
    return str + z;
}

  $(".tradeaction").on('click',function(){
    var mytradev = $(this).data("ftrade"); 
    $("#tradeactions").val(mytradev)
  });

  function placeorder_basic(type,price,amount,total)
  { 
    if(type=='buy') {
      $('#instant_'+type+'_amount').val(total);
      $('#instant_'+type+'_price').val(price);
      calculation_basic(type, 'instant');
    } else {
      $('#instant_'+type+'_tot').val(amount);
      $('#instant_'+type+'_price').val(price);
      calculation_with_total(type, 'instant');
      // $('.sorting_type').val('total');
    }

  }

  function placeorder(type,price,amount)
  {  
      var _Ord = $("#tradeactions").val(); 
      var usd_price = "<?php echo $from_currdet->online_usdprice;?>";
      if(type =='buy'){ api_type = _Ord+"_buy"; }
      else { api_type = _Ord+"_sell"; }

     // console.log("#"+api_type+"_amount");
      $("#"+api_type+"_amount").val(amount);
      $("#"+api_type+"_price").val(price);
      var usd_value = (parseFloat(amount)*parseFloat(usd_price)).toFixed(2);
      $("#"+api_type+"_amount_usd").val(usd_value);
      $("#"+api_type+"_price").trigger('change');


      if(api_type == 'buy') { var maker = maker_fee;}
      else { var maker = taker_fee;}
      var step1 = (amount*price*(maker/100));
      var step2 = (amount*price);
      if(api_type == 'buy') { var total = (step1+step2).toFixed(8);}
      else { var total = (step2-step1).toFixed(8); }
      $("#"+api_type+"_tot").val(total);
      $("#"+api_type+"_tot").text(total);
      $("#"+api_type+"_fee_tot").val(parseFloat(step1).toFixed(8));
      $("#m"+api_type+"_totfee").text(parseFloat(step1).toFixed(8));          
  }
</script>
<script>
    
      var user_id='<?php echo $this->user_id; ?>';
      var base_url='<?php echo base_url(); ?>';
      var front_url='<?php echo front_url(); ?>';
      var tenrealm_userid = "<?php echo $this->user_id; ?>";
      var from_currency = "<?php echo $from_cur; ?>";

      // console.log( from_currency+'***' )
      var to_currency = "<?php echo $to_cur; ?>";
      var maker_fee = "<?php echo $this->maker; ?>";
      var taker_fee = "<?php echo $this->taker; ?>";
      var pair = "<?php echo implode('_',$pair); ?>";
      var pair_id = "<?php echo $pair_details->id; ?>";
      var checkapi = "<?php echo checkapi($pair_details->id); ?>";

      var current_buy_price = "<?php echo $this->marketprice; ?>";
      var current_sell_price = "<?php echo $this->marketprice; ?>";


      // console.log(current_sell_price)
      var sellratevalue = $('#sellratevalue').val();
      var buyratevalue = $('#buyratevalue').val();
      
      var usd_price = "<?php echo coinprice($Second_Currency,2, '.', '');?>"; //alert("mani"+usd_price);
      var minimum_trade_amount = "<?php echo $this->minimum_trade_amount; ?>";
      var lastmarketprice = "<?php echo $this->lastmarketprice; ?>";
      var dummyimg='<?php echo dummyuserImg(); ?>';
      var pagetype='<?php echo $pagetype; ?>';
      var first_id              = "<?php echo isset($pair[0])?currency_id($pair[0]):''; ?>";
      var second_id              = "<?php echo isset($pair[1])?currency_id($pair[1]):''; ?>";
      var port                  = "<?php //echo $port; ?>";
      var host                  = "<?php //echo $host; ?>";
      var date                  = "<?php echo date('Y-m-d H:i:s') ?>";
      var First_Currency = "<?php echo $First_Currency;?>";
      var Second_Currency = "<?php echo $Second_Currency;?>";
      var from_id = "<?php //echo $from_currency_id; ?>";
      var to_id = "<?php //echo $to_currency_id; ?>";
      var formt = 8;
      
      var wsurl = 'wss://www.sharecoin.it/ws/';
      
      var ws = new WebSocket(wsurl);
      // console.log(ws)
      
      $(".market_prices").val(current_buy_price); 
      $(".instant_price").val(current_buy_price);
      $(".instant_prices").val(current_sell_price);
      $(".sell_pricesm").val(current_sell_price);
      $("#sell_prices").val(current_sell_price);

      var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';
      $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
              if (options.type.toLowerCase() == 'post') {
                  options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
                  if (options.data.charAt(0) == '&') {
                      options.data = options.data.substr(1);
                  }
              }
          });

      $( document ).ajaxComplete(function( event, xhr, settings ) {
        if (settings.type.toLowerCase() == 'post') {
          $.ajax({
              url: front_url+"get_csrf_token", 
              type: "GET",
              cache: false,             
              processData: false,      
              success: function(data) {
                $("input[name="+csrfName+"]").val(data);
              }
            });
          }
      }); 
    function check_user_login()
    {
        if(user_id==''||user_id==undefined||user_id==0)
        {
            Swal.fire('Please Login the site.')
            return false;
        }
        return true;
    }
    /*function change_buytrade(orderrtype,percrens)
    {
       //alert(thiss);
       var typre = $('#'+orderrtype+'_order_type').val();

       var usd_price = "<?php echo $from_currdet->online_usdprice;?>";
       //var To_usd_price = "<?php echo $to_currdet->usd_cap;?>";
       var To_usd_price = "<?php echo coinprice($Second_Currency,2, '.', '');?>";
       // alert("USDR"+To_usd_price)
       $('#buy_amount_usd').val(usd_price);
       $('#buy_amount_usd').text(usd_price);

       var marketprice = current_buy_price;
       var current_currency = $("#current_currency").val();
       if(current_currency == 'USD') { var format = 2;}
       else { var format = 8;}
       var balance = $("#currency_value").val();
       var total = ((percrens/100)*balance).toFixed(format);
       $("#"+order_type+"_buy_tot").html(total); // APPEND TOTAL

       var tot_usd = (parseFloat(total) * parseFloat(To_usd_price)).toFixed(2);
       $("#"+order_type+"_buy_tot_usd").html(tot_usd);
       
       var amount_calc = total/marketprice;
       var trade_fee = maker_fee/100;
       var fee_calc = parseFloat(amount_calc * trade_fee).toFixed(format);
       
       var amount_calculation = parseFloat((total/marketprice)-trade_fee).toFixed(format);
       if(user_id==''||user_id==undefined||user_id==0 || balance=='' || balance==undefined || balance==0)
       {
         amount_calculation = 0;
         total = 0;
         trade_fee = 0;
       }
       //alert(marketprice);alert(amount_calculation); alert(typre);
       
         $("#buy_price").val(marketprice); 
         $('#buy_amount').val(amount_calculation); // APPEND AMOUNT
      
       
    }*/

    /*function change_selltrade(orderrtype,percrens)
    {
     
       var typre = $('#'+orderrtype+'_order_type').val(); 

       var usd_price = "<?php echo $from_currdet->online_usdprice;?>";
      // var To_usd_price = "<?php echo $to_currdet->usd_cap;?>";
       var To_usd_price = "<?php echo coinprice($Second_Currency,2, '.', '');?>";
       $('#sell_amount_usd').val(usd_price);
       $('#sell_amount_usd').text(usd_price);

       var marketprice = current_sell_price;
       var current_currency = $("#current_currency").val();
       if(current_currency == 'USD') { var format = 2;}
       else { var format = 8;}
       var balance = $("#currency_value").val();
       var amount = ((percrens/100)*balance).toFixed(format);
       $('#sell_amount').val(amount); // APPEND AMOUNT
       
       var trade_fee = taker_fee/100;
       var total_calc = amount*marketprice;
       var fee_calc = parseFloat(total_calc * trade_fee).toFixed(format);
       $("#sell_fee_tot").val(fee_calc);
       var total_calculation = ((amount*marketprice)-trade_fee).toFixed(format);
       if(user_id==''||user_id==undefined||user_id==0 || balance=='' || balance==undefined || balance==0)
       {
       total_calculation = 0;
       amount = 0;
       trade_fee = 0;
       }
       $("#sell_price").val(marketprice);
       $("#sell_tot").html(total_calculation);

       var tot_usd = (parseFloat(total_calculation) * parseFloat(To_usd_price)).toFixed(2);
       $("#sell_tot_usd").html(tot_usd);
    }*/


function usd_value(a){

        var usd_price = "<?php echo $from_currdet->online_usdprice;?>";
        var usd_amount = $("#"+a+"_amount_usd").val();

        if(usd_amount!="" && usd_amount!=0 && !isNaN(usd_amount))
                  {

                    var buy_amt = (parseFloat(usd_amount)/parseFloat(usd_price)).toFixed(8);
                    
                      $('#'+a+'_amount').val(buy_amt);
                  }
                  else
                  {
                   $('#'+a+'_amount').val(0);
                  }
                 // calculation_re(a);
}

  function change_buytrade(orderrtype,percrens,order)
  {
     var typre = $('#'+orderrtype+'_order_type').val();

     var marketprice = current_buy_price;
     var current_currency = $("#current_currency").val();
     if(current_currency == 'USD') { var format = 2;}
     else { var format = 8;}
     var balance = $("#to_currency_value").val();
     var total = ((percrens/100)*balance).toFixed(format);

     $("#"+order+"_buy_tot").val(total); 
     
     var amount_calc = total/marketprice;
     var trade_fee = maker_fee/100;
     var fee_calc = parseFloat(amount_calc * trade_fee).toFixed(format);

     var fees = parseFloat(total) * parseFloat(trade_fee);

     var total1 = parseFloat(total)-parseFloat(fees);
     
     var amount_calculation = parseFloat((total1/marketprice)).toFixed(format);
     if(parseFloat(amount_calculation)<0){
      amount_calculation = 0;
     }
     if(user_id==''||user_id==undefined||user_id==0 || balance=='' || balance==undefined || balance==0)
     {
       amount_calculation = 0;
       total = 0;
       trade_fee = 0;
     }
        // console.log( buyratevalue )
        $("#"+order+"_buy_price").val(buyratevalue); 
        // $("#"+order+"_buy_price").val(marketprice); 
        $('#'+order+'_buy_amount').val(amount_calculation); 
        $('#'+'buy_'+order+'_fees').html(fees);
    
     
  }

    function change_selltrade(orderrtype,percrens,order)
    {
     
       var typre = $('#'+orderrtype+'_order_type').val(); 

       var marketprice = current_sell_price;
       var current_currency = $("#current_currency").val();
       if(current_currency == 'USD') { var format = 2;}
       else { var format = 8;}
       var balance = $("#from_currency_value").val();
       var amount = (((percrens/100)*balance)).toFixed(format);
       $('#'+order+'_sell_amount').val(amount); // APPEND AMOUNT
       
       var trade_fee = taker_fee/100;
       var total_calc = amount*marketprice;
       var fee_calc = parseFloat(total_calc * trade_fee).toFixed(format);
       console.log(trade_fee+'--'+fee_calc+' MARKET '+marketprice)
       $("#sell_fee_tot").val(fee_calc);
       var total_calculation = ((amount*marketprice)-fee_calc).toFixed(format);
       if(user_id==''||user_id==undefined||user_id==0 || balance=='' || balance==undefined || balance==0)
       {
       total_calculation = 0;
       amount = 0;
       trade_fee = 0;
       }
       
       $("#"+order+"_sell_price").val(sellratevalue);
       // $("#"+order+"_sell_price").val(marketprice);
       $("#"+order+"_sell_tot").val(total_calculation);
       $('#'+'sell_'+order+'_fees').html(fee_calc);
    }

    function calculation_with_total(a,_Otype)
    {
      var order_type = _Otype; 
      $('#sorting_type').val('total');
      if(order_type=='instant') // market
      {
        var total      = $('#'+order_type+'_'+a+'_tot').val();
        var buy_price   = $('#'+order_type+'_'+a+'_price').val();
        var sell_price  = $('#'+order_type+'_'+a+'_price').val();

        First_Currency = '<?=$First_Currency?>';
        var maker_fee = "<?php echo $this->maker; ?>";
        var taker_fee = "<?php echo $this->taker; ?>";
        if(a=='buy')
        { 
          if(buy_price!='' && total!='')
          {
            var sumTot = parseFloat(total) * parseFloat(buy_price);
            var fees  = (parseFloat(sumTot) * maker_fee/100);
            var tot = parseFloat(sumTot) + parseFloat(fees);
            // final_amount = Math.round(tot);
            final_amount = tot;
            $('#'+order_type+'_'+a+'_amount').val(parseFloat(final_amount).toFixed(8));
            $('#'+'buy_'+order_type+'_fees').html(parseFloat(fees).toFixed(8));
    
            $.getJSON('https://min-api.cryptocompare.com/data/pricemulti?fsyms=EUR&tsyms='+First_Currency, function(data) {
              $.each(data, function (cur, rate) { 
                obj = Object.entries(rate);  
                val = obj[0][1];
                online_price = parseFloat(final_amount) * parseFloat(val);

                if(First_Currency=='LIR') price = parseFloat(final_amount).toFixed(8);
                    else price = formatter.format(online_price);
	            if(isNaN(price)) { 
	              $('.'+a+'-convert').val('');
	            } else {
                buyHtml = '<label class="form-label col-3 col-form-label"><?=$this->lang->line("Value in")?> '+First_Currency+'</label><div class="col"><input type="text" class="form-control buy-convert" value="'+price+' '+First_Currency+'"></div>';
                $('.buyRate-wrapper').html(buyHtml);
	            } 
                // console.log( sum+'---'+fees+'---'+val )
              });
            }); 
     
          }
        }
        else 
        {
        	if(sell_price!='' && total!='')
            {
            	var fees = (parseFloat(total) * taker_fee/100);
            	var sum = parseFloat(total) - parseFloat(fees);
            	var tot = parseFloat(sum)/parseFloat(sell_price);
            	var final_amount = parseFloat(tot).toFixed(8);

              // console.log(total+'--'+taker_fee/100+'--'+sell_price+'--'+sum+'--'+tot+'--'+final_amount)
            	$('#'+order_type+'_'+a+'_amount').val(parseFloat(final_amount).toFixed(8));
              $('#'+'sell_'+order_type+'_fees').html(parseFloat(fees).toFixed(8));

              parsed_sumTot = parseInt(total);
              if (parsed_sumTot >= 10) {
                  $('.error-minimum-'+a).html('');
              } else {
                  $('.error-minimum-'+a).html('Enter a Minimum Total 10');
              }

            	$.getJSON('https://min-api.cryptocompare.com/data/pricemulti?fsyms='+First_Currency+'&tsyms=EUR', function(data) {
	              $.each(data, function (cur, rate) { 
	                obj = Object.entries(rate);  
	                val = obj[0][1];
	                online_price = parseFloat(final_amount) * parseFloat(val);

                  if(First_Currency=='LIR') price = parseFloat(final_amount).toFixed(8);
                    else price = formatter.format(online_price);
	                // console.log(online_price)
		            if(isNaN(price)) {
		              $('.'+a+'-convert').val('');
		            } else {
                  sellHtml = '<label class="form-label col-3 col-form-label"><?=$this->lang->line("Value in")?> Euro</label><div class="col"><input type="text" class="form-control sell-convert" value="'+price+' EUR"></div>';
                    $('.sellRate-wrapper').html(sellHtml);
		            } 
	                // console.log( sum+'---'+fees+'---'+val )
	              });
	            }); 

            }
        }
      }
    }

    function calculation_with_total_advance(a,_Otype)
    {
      var order_type = _Otype; 
      if(order_type=='instant') // market
      {
        var total      = $('#'+order_type+'_'+a+'_tot').val();
        var buy_price   = current_buy_price;
        var sell_price  = current_sell_price;
        var maker_fee = "<?php echo $this->maker; ?>";
        var taker_fee = "<?php echo $this->taker; ?>";
        if(a=='buy')
        { 
          if(buy_price!='' && total!='')
          {
            var fees = (parseFloat(total) * maker_fee/100);
            var sum = parseFloat(total) - parseFloat(fees);
            var tot = parseFloat(sum)/parseFloat(current_buy_price);
            var final_amount = parseFloat(tot).toFixed(8);
            // final_amount = Math.round(final_amount);
            $('#'+order_type+'_'+a+'_amount').val(final_amount);
          }
        }
        else 
        {
          if(sell_price!='' && total!='')
          {
            var fees = (parseFloat(total) * taker_fee/100);
            var sum = parseFloat(total) + parseFloat(fees);
            var tot = parseFloat(sum)/parseFloat(current_sell_price);
            var final_amount = parseFloat(tot).toFixed(8);
            $('#'+order_type+'_'+a+'_amount').val(final_amount);
          }
        }
      }
    }

    function change_instant_trade(a, input, _Otype)
    {
      if(a=='buy') { 
        $('#'+_Otype+'_'+a+'_amount').val(input);
        calculation_basic(a,_Otype);
      } else {
        $('#'+_Otype+'_'+a+'_tot').val(input);
        calculation_with_total(a,_Otype);
      }
    }

    function calculation_basic(a,_Otype)
    { 
        var order_type = $('#'+a+'_order_type').val(); 
        var order_type = _Otype; 

        $('#sorting_type').val('amount'); 
        if(order_type=='instant') // market
        {
            var amount      = $('#'+order_type+'_'+a+'_amount').val();
            // var buy_price   = current_buy_price;
            // var sell_price  = current_sell_price;
            var buy_price   = $('#'+order_type+'_'+a+'_price').val();
            var sell_price  = $('#'+order_type+'_'+a+'_price').val();
            var parsed_val = parseInt(amount);
            
            euroAmt = amount;
            First_Currency = '<?=$First_Currency?>';

            if(a=='buy') { 
            	if (parsed_val >= 10) {
	                $('.error-minimum-'+a).html('');
	            } else {
	                $('.error-minimum-'+a).html('Enter a Minimum amount 10');
	            }

            	$.getJSON('https://min-api.cryptocompare.com/data/pricemulti?fsyms=EUR&tsyms='+First_Currency, function(data) {

		            $.each(data.EUR, function (cur, rate) { 
                  if(cur=='LIR') fromAmt = amount;
                    else fromAmt = euroAmt * rate;
		              
		              fromRate = formatter.format(fromAmt);
		              if(isNaN(fromAmt)) {
		                $('.'+a+'-convert').val('');
		              } else {
                    buyHtml = '<label class="form-label col-3 col-form-label"><?=$this->lang->line("Value in")?> '+First_Currency+'</label><div class="col"><input type="text" class="form-control buy-convert" value="'+fromRate+' '+First_Currency+'"></div>';
                    $('.buyRate-wrapper').html(buyHtml);
		              } 
		            });
		        });

            } else {

            	$.getJSON('https://min-api.cryptocompare.com/data/pricemulti?fsyms='+First_Currency+'&tsyms=EUR', function(data) {
		            $.each(data, function (cur, rate) { 
                  if(cur=='LIR') fromAmt = amount;
                    else fromAmt = euroAmt * rate.EUR;

		              fromRate = formatter.format(fromAmt);
		              if(isNaN(fromAmt)) {
		                $('.'+a+'-convert').val('');
		              } else {
                    sellHtml = '<label class="form-label col-3 col-form-label"><?=$this->lang->line("Value in")?> Euro</label><div class="col"><input type="text" class="form-control sell-convert" value="'+fromRate+' EUR"></div>';
                    $('.sellRate-wrapper').html(sellHtml);
		              } 
		            });
		        });
            }

            if(a=='buy')
            { 
              if(buy_price!='' && amount!='')
              {

                  var maker_fee = "<?php echo $this->maker; ?>";
                  var taker_fee = "<?php echo $this->taker; ?>";

                  var fees  = (parseFloat(amount)*parseFloat(maker_fee)/100);
                  var amt = parseFloat(amount) - parseFloat(fees);
                  var tot   = (parseFloat(amt)/parseFloat(buy_price)).toFixed(8);
                     
                  fees = (/e/.test(fees)) ? fees.noExponents() : fees;

                  var n = tot.toString();
                  var n1 = fees.toString();
                  
                  if(tot>0)
                  {
                      // var FinelTot = (parseFloat(tot)+parseFloat(fees)).toFixed(8);
                      var FinelTot = parseFloat(tot).toFixed(8);
                  }
                  else
                  {
                      var FinelTot = 0;
                  }

                  if(amount!="" && amount!=0 && !isNaN(amount)&&n.indexOf("e")==-1&&n1.indexOf("e")==-1)
                  {  
                      $("#"+order_type+"_buy_tot").val(FinelTot);  
                      $('#'+'buy_'+order_type+'_fees').html(parseFloat(fees).toFixed(8));
                  }
                  else
                  {
                      if(n.indexOf("e")>-1||n1.indexOf("e")>-1)
                      {
                        $(".trade-loader").fadeOut("slow");
                        $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Please enter valid amount and price');?>"});
                          return false;
                      }
                      $("#"+order_type+"_buy_tot").val(0);  
                      //$('#'+order_type+'_buy_price').val(current_buy_price);
                      $('#buy_amount').val(0);
                  }
              }
              else
              {
                $("#"+order_type+"_buy_tot").val(0);  
              }
            }
            else
            { 
              if(sell_price!='' && amount!='')
              {
                    var maker_fee = "<?php echo $this->maker; ?>";
                    var taker_fee = "<?php echo $this->taker; ?>";
                    
                    var tot   = (parseFloat(amount)*parseFloat(sell_price)).toFixed(8);
                    var fees = (parseFloat((parseFloat(amount)*parseFloat(sell_price)*taker_fee/100))).toFixed(8);
                    var sumTot = (parseFloat(tot)-parseFloat(fees)); 
                    parsed_sumTot = parseInt(sumTot);
                    if (parsed_sumTot >= 10) {
                        $('.error-minimum-'+a).html('');
                    } else {
                        $('.error-minimum-'+a).html('Enter a Minimum Total 10');
                    }

                    fees = (/e/.test(fees)) ? fees.noExponents() : fees;
                      var n = tot.toString();
                      var n1 = fees.toString();

                      if(tot>0)
                      {
                          var FinelTot = parseFloat(parseFloat(sumTot).toFixed(8));
                          // var FinelTot = Math.round(sumTot);
                      }
                      else
                      {
                          var FinelTot = 0;
                      }
                      if(amount!="" && amount!=0 && !isNaN(amount)&&n.indexOf("e")==-1&&n1.indexOf("e")==-1)
                      {
                          $("#"+order_type+"_sell_tot").val(FinelTot);  
                          $('#'+'sell_'+order_type+'_fees').html(parseFloat(fees).toFixed(8));
                      }
                      else
                      {
                          if(n.indexOf("e")>-1||n1.indexOf("e")>-1)
                          {
                            $(".trade-loader").fadeOut("slow");
                            $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Please enter valid amount and price');?>"}); 
                              return false;
                          }
                          $("#"+order_type+"_sell_tot").val(0);
                      }
              }
              else
              {
                $("#"+order_type+"_sell_tot").val(0);
              }
            }
        }
    }

    function calculation(a,_Otype)
    {    
        var order_type = $('#'+a+'_order_type').val(); 
        var order_type = _Otype; 

        if(order_type=='instant') // market
        {
           var amount      = $('#'+order_type+'_'+a+'_amount').val();
           var buy_price   = $('#'+order_type+'_'+a+'_price').val();
           var sell_price  = $('#'+order_type+'_'+a+'_price').val();
           // var buy_price   = current_buy_price;
           // var sell_price  = current_sell_price;

            if(a=='buy')
            { 
              if(buy_price!='' && amount!='')
              {
                  var maker_fee = "<?php echo $this->maker; ?>";
                  var taker_fee = "<?php echo $this->taker; ?>";

                  var tot   = (parseFloat(amount)*parseFloat(buy_price)).toFixed(8);
                  var fees  = (parseFloat((parseFloat(amount)*parseFloat(buy_price)*maker_fee/100))).toFixed(8);
                  var n = tot.toString();
                  var n1 = fees.toString();
                  
                  if(tot>0)
                  {
                      var tot = (parseFloat(tot)+parseFloat(fees)).toFixed(8);
                  }
                  else
                  {
                      var tot = 0;
                  }

                  if(amount!="" && amount!=0 && !isNaN(amount)&&n.indexOf("e")==-1&&n1.indexOf("e")==-1)
                  {  
                    $("#"+order_type+"_buy_tot").val(tot);  
                    $('#'+'buy_'+order_type+'_fees').html(fees);
                  }
                  else
                  {
                      if(n.indexOf("e")>-1||n1.indexOf("e")>-1)
                      {
                        $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Please enter valid amount and price');?>"});
                          return false;
                      }
                      $("#"+order_type+"_buy_tot").val(0);  
                      //$('#'+order_type+'_buy_price').val(current_buy_price);
                      $('#buy_amount').val(0);
                  }
              }
              else
              {
                $("#"+order_type+"_buy_tot").val(0);  
              }
            }
            else
            { 
              if(sell_price!='' && amount!='')
              {
                 var maker_fee = "<?php echo $this->maker; ?>";
                 var taker_fee = "<?php echo $this->taker; ?>";

                  var tot   = (parseFloat(amount)*parseFloat(sell_price)).toFixed(8);
                  var fees = (parseFloat((parseFloat(amount)*parseFloat(sell_price)*taker_fee/100))).toFixed(8);
                
                  var n = tot.toString();
                  var n1 = fees.toString();
                  if(tot>0)
                  {
                      var tot = (parseFloat(tot)-parseFloat(fees)).toFixed(8);
                  }
                  else
                  {
                      var tot = 0;
                  }
                  if(amount!="" && amount!=0 && !isNaN(amount)&&n.indexOf("e")==-1&&n1.indexOf("e")==-1)
                  {
                      $("#"+order_type+"_sell_tot").val(tot);  
                      $('#'+'sell_'+order_type+'_fees').html(fees);
                  }
                  else
                  {
                      if(n.indexOf("e")>-1||n1.indexOf("e")>-1)
                      {
                        $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Please enter valid amount and price');?>"}); 
                          return false;
                      }
                      $("#"+order_type+"_sell_tot").val(0);
                  }
              }
              else
              {
                $("#"+order_type+"_sell_tot").val(0);
              }
            }
        }
        else if(order_type=='limit') // limit
        {
            var amount      = $('#'+order_type+'_'+a+'_amount').val();
            var buy_price   = $('#'+order_type+'_'+a+'_price').val();
            var sell_price  = $('#'+order_type+'_'+a+'_price').val();
            if(a=='buy')
            {
              if(buy_price!='' && amount!='')
              {
                    var maker_fee = "<?php echo $this->maker; ?>";
                    var taker_fee = "<?php echo $this->taker; ?>";

                    var tot   = (parseFloat(amount)*parseFloat(buy_price)).toFixed(8);
                    var fees  = (parseFloat((parseFloat(amount)*parseFloat(buy_price)*maker_fee/100))).toFixed(8);
                    var n = tot.toString();
                    var n1 = fees.toString();
                    if(tot>0)
                    {
                        var tot = (parseFloat(tot)+parseFloat(fees)).toFixed(8);
                    }
                    else
                    {
                        var tot = 0;
                    }
                    if(amount!="" && amount!=0 && !isNaN(amount)&&n.indexOf("e")==-1&&n1.indexOf("e")==-1)
                    {
                        $("#"+order_type+"_buy_tot").val(tot);
                        $('#'+'buy_'+order_type+'_fees').html(fees);
                    }
                    else
                    {
                        if(n.indexOf("e")>-1||n1.indexOf("e")>-1)
                        {
                          $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Please enter valid amount and price');?>"});
                            return false;

                        }
                        $("#"+order_type+"_buy_tot").val(0);  
                        $('#'+order_type+'_buy_price').val(0);
                        $('#buy_amount').val(0);
                    }
              }
              else
              {
                $("#"+order_type+"_buy_tot").val(0);  
              }
            }
            else
            {
              if(sell_price!='' && amount!='')
              {
                     var maker_fee = "<?php echo $this->maker; ?>";
                     var taker_fee = "<?php echo $this->taker; ?>";

                      var tot   = (parseFloat(amount)*parseFloat(sell_price)).toFixed(8);
                      var fees = (parseFloat((parseFloat(amount)*parseFloat(sell_price)*taker_fee/100))).toFixed(8);
                    
                      var n = tot.toString();
                      var n1 = fees.toString();
                      if(tot>0)
                      {
                          var tot = (parseFloat(tot)-parseFloat(fees)).toFixed(8);
                      }
                      else
                      {
                          var tot = 0;
                      }
                      if(amount!="" && amount!=0 && !isNaN(amount)&&n.indexOf("e")==-1&&n1.indexOf("e")==-1)
                      {
                          $("#"+order_type+"_sell_tot").val(tot);
                          $('#'+'sell_'+order_type+'_fees').html(fees);
                      }
                      else
                      {
                          if(n.indexOf("e")>-1||n1.indexOf("e")>-1)
                          {
                            $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Please enter valid amount and price');?>"});  
                              return false;
                          }
                          $("#"+order_type+"_sell_tot").val(0);
                      }
              }
              else
              {
                $("#"+order_type+"_sell_tot").val(0);
              }
            }
        }
        else // Stop limit
        { 
            var amount      = $('#'+order_type+'_'+a+'_amount').val();
            var buy_price   = $('#'+order_type+'_'+a+'_price').val();
            var sell_price  = $('#'+order_type+'_'+a+'_price').val(); 
            if(a=='buy')
            { 
              if(buy_price!='' && amount!='' && buy_price!=0 && amount!=0 && !isNaN(buy_price) && !isNaN(amount))
              {
                      var maker_fee = "<?php echo $this->maker; ?>";
                      var taker_fee = "<?php echo $this->taker; ?>";
                      var tot   = (parseFloat(amount)*parseFloat(buy_price)).toFixed(8);
                      var fees  = (parseFloat((parseFloat(amount)*parseFloat(buy_price)*maker_fee/100))).toFixed(8);
                      var n = tot.toString();
                      var n1 = fees.toString();
                    if(tot>0)
                    {
                        var tot = (parseFloat(tot)+parseFloat(fees)).toFixed(8);
                    }
                    else
                    {
                        var tot = 0;
                    }
                    if(amount!="" && buy_price!="" && amount!=0 && buy_price!=0&&!isNaN(amount)&&n.indexOf("e")==-1&&n1.indexOf("e")==-1)
                    {
                        $("#"+order_type+"_buy_tot").val(tot);
                        $('#'+'buy_'+order_type+'_fees').html(fees);
                    }
                    else
                    {
                        if(n.indexOf("e")>-1||n1.indexOf("e")>-1)
                        {
                          $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Please enter valid amount and price');?>"});
                            return false;
                        }
                    }
              }
              else
              {
                $("#"+order_type+"_buy_tot").val('');  
              }
            }
            else
            { 
              if(sell_price!='' && amount!='' && sell_price!=0 && amount!=0 && !isNaN(sell_price) && !isNaN(amount))
              { 
                      var maker_fee = "<?php echo $this->maker; ?>";
                      var taker_fee = "<?php echo $this->taker; ?>";
                      var tot   = (parseFloat(amount)*parseFloat(sell_price)).toFixed(8);
                      var fees = (parseFloat((parseFloat(amount)*parseFloat(sell_price)*taker_fee/100))).toFixed(8);
                      var n = tot.toString();
                      var n1 = fees.toString();
                      if(tot>0)
                      {
                      var tot = (parseFloat(tot)-parseFloat(fees)).toFixed(8);
                      }
                      else
                      {
                      var tot = 0;
                      }
                      if(amount!="" && sell_price!="" && amount!="" && sell_price!=""&&!isNaN(amount)&&n.indexOf("e")==-1&&n1.indexOf("e")==-1)
                      {  
                      $("#"+order_type+"_sell_tot").val(tot);
                      $('#'+'sell_'+order_type+'_fees').html(fees);
                      }
                      else
                      { 
                      if(n.indexOf("e")>-1||n1.indexOf("e")>-1)
                      {
                        $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Please enter valid amount and price');?>"});
                        return false;
                      }
                      $("#"+order_type+"_sell_tot").val(0);  
                      $('#'+order_type+'_sell_price').val(0);
                      $('#sell_amount').val(0);
                      }
              }
              else
              { 
                $("#"+order_type+"_sell_tot").val('0.00');
              }
            }
        }
    }
    
    function order_placed(a,_Otype)
    {  
    	$(".trade-loader").fadeIn("slow");
        var ordertype = $('#'+a+'_order_type').val();
        var ordertype = _Otype;

        exchange_type = document.getElementById("exchange_type").value;
        basic_pairId = ['4','7','8','9','10'];

        if((jQuery.inArray(pair_id, basic_pairId) != -1)&&(ordertype=='instant')) {
          if(a=='buy') {
            euroAmt = $('#'+ordertype+'_'+a+'_amount').val();
            parsed_val = parseInt(euroAmt)
            if (parsed_val < 10) {
              $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "Enter a Minimum amount 10"});
              return false;
            }
          } else {

            euroTot = $("#"+ordertype+'_'+a+"_tot").val();
              parsed_Tot = parseInt(euroTot)
              if (parsed_Tot < 10) {
                $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "Enter a Minimum Total 10"});
                return false;
              } 
          }
        }

        var logincheck=check_user_login();
        if(logincheck)
        {
          if(ordertype=="limit") // limit
          { 
            var c     =   $('#'+ordertype+'_'+a+'_amount').val();
            var p = $("#"+ordertype+'_'+a+"_price").val();
            d = $("#"+ordertype+'_'+a+"_tot").val();
            if(isNaN(c) || isNaN(d))
            { 
              $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Please enter valid amount and price');?>"});
                return false;
            }
            else if(c=="" || d=="")
            { 
              $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Please enter valid amount and price');?>"});
                return false;
            }
            else if(c<=0 || d<=0)
            {
              $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Minimum trade amount is')?>"+ parseFloat(minimum_trade_amount)});
                return false;
            }
            if(p=="" || c=="")
            {
              $('#'+ordertype+'_'+a+'_amount').val(0);
              $("#"+ordertype+'_'+a+"_price").val(0);
              $("#"+ordertype+'_'+a+"_tot").val(0);
            }
            // $(".trade-loader").fadeOut("slow");
            return order_confirm(a,ordertype);
          }

          else if(ordertype=="instant") // market
          {
              var c     =   $('#'+ordertype+'_'+a+'_amount').val();
              d = $('#'+ordertype+'_'+a+'_tot').val(); 

              if(isNaN(c) || isNaN(d))
              {
                $(".trade-loader").fadeOut("slow");
                $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Please enter valid amount and price');?>"});
                  return false;
              }
              else if(c=="" || d=="")
              {
                $(".trade-loader").fadeOut("slow");
                $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Please enter valid amount and price');?>"});
                  return false;
              }
              else if(c<=0 || d<=0)
              {
                $(".trade-loader").fadeOut("slow");
                $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Minimum trade amount is')?>"+" "+ minimum_trade_amount});
                return false;
              }
              return order_confirm(a,ordertype);
          }
          else // Stop limit
          {
              var c     =   $('#'+ordertype+'_'+a+'_amount').val(); 
              d = $('#'+ordertype+'_'+a+'_tot').val(); 
              var pri = $("#"+ordertype+"_"+a+"_price").val();
              var limit_price = $("#"+ordertype+"_"+a+"_tprice").val();

              // console.log(ordertype+"_"+a+"_tprice")

              if(isNaN(c) || isNaN(d))
              {
                $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Please enter valid amount and price');?>"});
                 
                  return false;
              }
              else if(c=="" || d=="")
              {
                $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Please enter valid amount and price');?>"});
                  return false;
              }
              else if(c<=0 || d<=0)
              {
                $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Minimum trade amount is')?>"+ parseFloat(minimum_trade_amount)});
                return false;
              }
              else if((c!="" || c>=0 || d!="" || d>=0) && limit_price=="" || limit_price<=0)
              {
                $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Please enter limit price');?>"});
                return false;
              }
              return order_confirm(a,ordertype);
          }
        }   
    }

    function order_confirm(a,ordertype)
    {
       $("#"+a+"_btn").attr('disabled', true);
       $("#"+a+"_btn_loader").css('display','inline-block');
       // console.log(ordertype)
        if(ordertype=='limit') // limit
        {
          var c = $('#'+ordertype+'_'+a+'_amount').val();
          var d = $('#'+ordertype+'_'+a+'_price').val();
          var multiply  = parseFloat(c)*parseFloat(d);
          if(a=="buy")
          {
            var fees      = parseFloat(multiply)*maker_fee/100;
            if(multiply>0)
            {
              var tot = multiply+fees;
            }
            else
            {
              var tot = 0;
            }
          }
          else
          {
            var fees      = parseFloat(multiply)*taker_fee/100;
             if(multiply>0)
            {
              var tot = multiply-fees;
            }
            else
            {
              var tot = 0;
            } 
          }
          if(parseFloat(tot) < parseFloat(minimum_trade_amount)){
            $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Minimum trade amount is')?>"+ parseFloat(minimum_trade_amount)});
                return false;
          }
          var mul = parseFloat(tot);
          if(a=="buy")
          { 
             if(mul > to_currency)
              { 
                $(".trade-loader").fadeOut("slow");
                $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Insufficient balance');?>"});
                  return false;
              }
              else
              {
                return executeOrder('buy','limit');
              }
          }
          else
          {    
            if(from_currency < parseFloat(c))
            {
              $(".trade-loader").fadeOut("slow");
              $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Insufficient balance');?>"});
                return false;
            }
            else
            {
              return executeOrder('sell','limit');
            }
          }
        }
        else if(ordertype=='instant') // market
        {
          var c = $('#'+ordertype+'_'+a+'_amount').val();
          var d = $('#'+ordertype+'_'+a+'_price').val();
          
          if(a=="buy")
          {
            var fees      = parseFloat(multiply)*maker_fee/100;

            // var d = current_buy_price;
            var multiply  = parseFloat(c)*parseFloat(d);
            if(multiply>0)
            {
              var tot = multiply+fees;
            }
            else
            {
              var tot = 0;
            } 
          }
          else
          {
            // var d = current_sell_price;
            var multiply  = parseFloat(c)*parseFloat(d);
            var fees      = parseFloat(multiply)*taker_fee/100;
            if(multiply>0)
            {
              var tot = multiply-fees;
            }
            else
            {
              var tot = 0;
            } 
          }

          if(parseFloat(tot) < parseFloat(minimum_trade_amount)){
            $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Minimum trade amount is')?>"+ parseFloat(minimum_trade_amount)});

                setTimeout(function(){
                    $("#"+a+"_btn").attr('disabled', false);
                    $("#"+a+"_btn_loader").css('display','none');
                }, 3000);
                return false;
          }
          var mul = parseFloat(tot);
          if(a=="buy")
          { 
             if(mul > to_currency)
              { 
                $(".trade-loader").fadeOut("slow");
                $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Insufficient balance');?>"});
                  return false;
              }
              else
              {
                return executeOrder('buy','instant');
              }
          }
          else
          {    
            if(from_currency < parseFloat(c))
            { 
              $(".trade-loader").fadeOut("slow");
              $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Insufficient balance');?>"});  
                return false;
            }
            else
            {
              return executeOrder('sell','instant');
            }
          }
        }
        else // Stop limit
        { 
          var c = $('#'+ordertype+'_'+a+'_amount').val();
          var d = $('#'+ordertype+'_'+a+'_price').val();
          var  l = $("#"+a+"_limit").val();
          var multiply  = parseFloat(c)*parseFloat(d);
          if(a=="buy")
          {
            if(parseFloat(d)==parseFloat(current_buy_price))
            { 
             $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Stop price not same as market price');?>"});
                return false;
            }
            else if(parseFloat(d)!=parseFloat(current_buy_price)) 
            { 
            
               if(parseFloat(l)==parseFloat(current_buy_price))
              {
                $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Limit price not same as market price');?>"});
                return false;
              }
            
            }
            else
            { 
            var fees      = parseFloat(multiply)*maker_fee/100;
            if(multiply>0)
            {
              var tot = multiply+fees;
            }
            else
            {
              var tot = 0;
            }
            }
          }
          else
          {
            if(parseFloat(d)==parseFloat(current_buy_price))
            {
              $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Stop price not same as market price');?>"});
              return false;
            }
            else if(parseFloat(d)!=parseFloat(current_buy_price)) 
            {
               if(parseFloat(l)==parseFloat(current_buy_price))
              {
                $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Limit price not same as market price');?>"});
                return false;
              }
            
            }
            else
            {
            var fees = parseFloat(multiply)*taker_fee/100;
             if(multiply>0)
            {
              var tot = multiply-fees;
            }
            else
            {
              var tot = 0;
            }
            }
          }
          if(parseFloat(tot) < parseFloat(minimum_trade_amount)){

            $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Minimum trade amount is')?>"+ parseFloat(minimum_trade_amount)});
                setTimeout(function(){
                    $("#"+a+"_btn").attr('disabled', false);
                    $("#"+a+"_btn_loader").css('display','none');
                }, 3000);
                return false;
          }
          var mul = parseFloat(tot);
          if(a=="buy")
          {
             if(mul > to_currency)
              { 
                $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Insufficient balance');?>"});
                  setTimeout(function(){
                      $("#"+a+"_btn").attr('disabled', false);
                      $("#"+a+"_btn_loader").css('display','none');
                  }, 3000);
                  return false;
              }
              else
              {
                return executeOrder('buy','stop');
              }
          }
          else
          {    
            if(from_currency < parseFloat(c))
            { 
              $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Insufficient balance');?>"});
                setTimeout(function(){
                    $("#"+a+"_btn").attr('disabled', false);
                    $("#"+a+"_btn_loader").css('display','none');
                }, 3000);
                return false;
            }
            else
            {
              return executeOrder('sell','stop');
            }
          }
        }        
    }

    function executeOrder(a,ordertype)
    {
      exchange_type = $('#exchange_type').val();
      if(ordertype=='limit') // limit
      {
          var amount = $('#'+ordertype+'_'+a+'_amount').val();
          var price = $('#'+ordertype+'_'+a+'_price').val();
          var total = $('#'+ordertype+'_'+a+'_tot').val();
          if(a =='buy')
          {
            var fee=maker_fee;
          }
          else
          {
            var fee=taker_fee;
          }
          var loan_rate=0;  

          var param = {  
          path: "execute_order",
          amount: amount,
          price:price,
          limit_price:limit_price,
          total:total,
          fee:fee,
          ordertype:ordertype,
          pair:pair,
          pair_id:pair_id,
          type:a,
          loan_rate:loan_rate,
          pagetype:pagetype,
          user_id:'<?php echo $this->session->userdata('user_id');?>',
          exchange_type:exchange_type,
         };
         ws.send(JSON.stringify(param));
         //load_design();

         $('#'+ordertype+'_'+a+'_amount').val(0);
       $('#'+ordertype+'_'+a+'_price').val(0);
       $('#'+ordertype+'_'+a+'_tot').val(0);
      }
      else if(ordertype=='instant') // market
      {

          var amount = $('#'+ordertype+'_'+a+'_amount').val();
          var price = $('#'+ordertype+'_'+a+'_price').val();
          var total = $('#'+ordertype+'_'+a+'_tot').val();
          if(a =='buy')
          {
            // var price = current_buy_price;
            var fee=maker_fee;
          }
          else
          {
            // var price = current_sell_price;
            var fee=taker_fee;
          }

          sorting_type = $('#sorting_type').val();
        // console.log(amount);  
        // console.log(price);
        // console.log(total); 
        // console.log(order_type);   
        // return false;
          var limit_price =0;
          var loan_rate=0;
          var param = {  
          path: "execute_order",
          amount: amount,
          price:price,
          limit_price:limit_price,
          total:total,
          fee:fee,
          ordertype:ordertype,
          pair:pair,
          pair_id:pair_id,
          type:a,
          loan_rate:loan_rate,
          pagetype:pagetype,
          user_id:'<?php echo $this->session->userdata('user_id');?>',
          exchange_type:exchange_type,
          sorting_type:sorting_type,
         };
         ws.send(JSON.stringify(param));
        // $("#"+a+"_price").val(current_buy_price);

         $('#'+ordertype+'_'+a+'_amount').val(0);
       $('#'+ordertype+'_'+a+'_price').val(price);
       $('#'+ordertype+'_'+a+'_tot').val(0);
      }
      else // Stop limit
      { 
          var amount = $('#'+ordertype+'_'+a+'_amount').val();
          var price = $('#'+ordertype+'_'+a+'_price').val();
          var total = $('#'+ordertype+'_'+a+'_tot').val();
          var limit_price = $("#"+ordertype+"_"+a+"_tprice").val();
          if(a =='buy')
          {
            var fee=maker_fee;
          }
          else
          {
            var fee=taker_fee;
          }
          var loan_rate=0;
          var param = {  
          path: "execute_order",
          amount: amount,
          price:price,
          limit_price:limit_price,
          total:total,
          fee:fee,
          ordertype:ordertype,
          pair:pair,
          pair_id:pair_id,
          type:a,
          loan_rate:loan_rate,
          pagetype:pagetype,
          user_id:'<?php echo $this->session->userdata('user_id');?>',
          exchange_type:exchange_type,
         };
         ws.send(JSON.stringify(param));

         $('#'+ordertype+'_'+a+'_amount').val(0);
       $('#'+ordertype+'_'+a+'_price').val(0);
       $('#'+ordertype+'_'+a+'_tot').val(0);
      }

       
    }

    function cancel_order(tradeid,pair_id)
    {
        if(confirm("<?=$this->lang->line('Are you sure you want to cancel this order?');?>"))
        {          
           $(".trade-loader").fadeIn("slow");
           var param = {  
            path: "close_active_order",
            tradeid: tradeid,
            pair_id:pair_id,
            user_id:user_id
           };
           ws.send(JSON.stringify(param));
        }
    }

    function load_design(decimal)
    { 
        if(decimal==undefined)
        {
          decimal = 8;
        }
        else
        {
          decimal = decimal;
        }
        var decimalpoints=decimal;
        var decimal=decimal;         

        //Call WEB SOCKET
        var param = {  
        path: "trade_integration",
        pair_id: pair_id,
        user_id:user_id,
        pagetype:pagetype,
        pair:pair,
        //showorder:showorder
       };
       ws.send(JSON.stringify(param));     
    } 
    ws.onopen = function(event) 
    { 
        console.log("connected websocket....");             
        load_design();
    }
    ws.onmessage = function(event) 
    {
          var browsername=navigator ? navigator.userAgent.toLowerCase() : "other";
          var resp = browsername.split(" "); 
          var lengthbrowser=resp.length;
          var getname=resp[lengthbrowser-1];
          var res1 = getname.split("/"); 
          if(res1[1]!='safari')
          {
            console.API;
            if (typeof console._commandLineAPI !== 'undefined') {
            console.API = console._commandLineAPI; //chrome
            } else if (typeof console._inspectorCommandLineAPI !== 'undefined') {
            console.API = console._inspectorCommandLineAPI; //Safari
            } else if (typeof console.clear !== 'undefined') {
            console.API = console;
            }
          }
          
          var res = event.data;
          var designs=JSON.parse(res);
          // console.log( parseFloat(designs.to_currency).toFixed(8) );          
          // var from_balance = designs.from_currency;
          // var to_balance = designs.to_currency; 

          var from_balance = parseFloat(designs.from_currency).toFixed(8);
          var to_balance = parseFloat(designs.to_currency).toFixed(8); 

          // console.log( from_currency+'----' )
          var from_symbol = designs.from_symbol;
          var to_symbol = designs.to_symbol;
          var formt1 = formt;
          var pair_active = from_symbol+"/"+to_symbol;

          var lastPrice = designs.current_buy_price;

          $('.trade_price').html(lastPrice);
          var price_change = designs.change;
          var hign = designs.high;
          var low = designs.low;
          var volume = designs.volume;

          if(price_change>=0){
            var Price_change_percent = '<span class="text-green"><small>'+price_change+'%</small></span>';
          }
          else{
            var Price_change_percent = '<span class="text-red"><small>'+price_change+'%</small></span>';
          }

          $('#change').html(Price_change_percent);
          $('#high').html(hign);
          $('#low').html(low);
          $('#volume').html(volume);

          var userlogid = "<?php echo $user_id; ?>";
          $(".sell_bal").html(from_balance+" "+First_Currency);
          $(".buy_bal").html(to_balance+" "+Second_Currency);
          if (designs.web_trade == "1" && designs.web_trade != '') 
          {
              var decimalpoints = "<?php //echo $this->decimal_format; ?>";
              var decimal = "<?php //echo $this->decimal_format; ?>";
              var transactionhistory=designs.transactionhistory;
              var buyResult=designs.buyResult;
              var sellResult=designs.sellResult;
              var api_buyResult=designs.api_buyResult;
              var api_sellResult=designs.api_sellResult;
               var decimalpoints = 6;

              var pairs=designs.pairs;
              from_currency=designs.from_currency;
              to_currency=designs.to_currency;
              tenrealm_userid=designs.tenrealm_userid;
              current_buy_price=designs.current_buy_price;
              current_sell_price=designs.current_sell_price;
              lastmarketprice=designs.lastmarketprice;

              var market_trade = designs.market_trades;
              var market_api_trades = designs.market_api_trades;

              var from_bal = "<?php echo $from_cur;?>";
              var to_bal = "<?php echo $to_cur;?>";

              if(transactionhistory!=0&&transactionhistory.length>0)
              {
                  var transaction_length=transactionhistory.length;
                  var historys='';
                  var basic_historys=''; 
                  for(count = 0; count < transaction_length; count++)
                  {
                    if(transactionhistory[count].trade_id!='' && transactionhistory[count].trade_id)
                    {
                      var time3 = transactionhistory[count].tradetime;
                      var myuserID = transactionhistory[count].userId;

                      //var time3 = transactionhistory[count].datetime;
                      var type3 = (transactionhistory[count].Type).charAt(0).toUpperCase()+transactionhistory[count].Type.slice(1);
                      var price3 = transactionhistory[count].Price;
                      var amount3 = transactionhistory[count].Amount;
                      var fee3 = transactionhistory[count].Fee;
                      var total3  = transactionhistory[count].Total;
                      var pairy = transactionhistory[count].pair_symbol;
                      var status3 = transactionhistory[count].status.charAt(0).toUpperCase()+transactionhistory[count].status.slice(1);

                        var times3 = time3;
                        var hist_clr = "";
                        if(type3=="Buy")
                        {
                          hist_clr = "text-uppercase text-green";
                        }
                        else
                        {
                          hist_clr = "text-uppercase text-red";
                        }

                        var mycls = (myuserID==userlogid)?'myclass':'otherclass';
                        var coinAmt = parseFloat(amount3).toFixed(6);
                        var usdPrice = coinAmt*usd_price;
                        usdPrice = parseFloat(usdPrice).toFixed(2);

                    }
                    else
                    {    
                        var askAmount=transactionhistory[count].askAmount;
                        var buyer_trade_id=transactionhistory[count].buyer_trade_id;
                        var buy_userId = transactionhistory[count].buyerUserid;
                        var sell_userId = transactionhistory[count].sellerUserid;
                        var seller_trade_id=transactionhistory[count].seller_trade_id;
                        var filledAmount=transactionhistory[count].filledAmount;
                        var pairy = transactionhistory[count].pair_symbol;
                       // filledAmount=parseFloat(filledAmount).toFixed(decimalpoints);

                        if(buy_userId==user_id)
                        {
                          var type1="Buy";
                          var askPrice=transactionhistory[count].buyaskPrice;
                          //askPrice=parseFloat(askPrice).toFixed(decimalpoints);
                          var sellaskPrice=transactionhistory[count].sellaskPrice;
                          sellaskPrice=parseFloat(sellaskPrice).toFixed(decimalpoints);
                          var orderTime1=transactionhistory[count].buyertime;
                          var orderTime2=transactionhistory[count].sellertime;
                          var buyerfee = transactionhistory[count].buyerfee;
                          var sellerfee = transactionhistory[count].sellerfee;
                          var buyertotal = transactionhistory[count].buyertotal;
                          var sellertotal = transactionhistory[count].sellertotal;
                          var time1 = orderTime1;

                          // var datetime = transactionhistory[count].buyertime;
                          var datetime = transactionhistory[count].datetime;

                          var myuserID = transactionhistory[count].buyerUserid;
                          var mycls = (myuserID==userlogid)?'myclass':'otherclass';

                          var b_tot = parseFloat(askPrice * filledAmount);
                          var status = transactionhistory[count].status.charAt(0).toUpperCase()+transactionhistory[count].status.slice(1);

                          var coinAmt = parseFloat(filledAmount).toFixed(5);
                          var usdPrice = coinAmt*usd_price;
                          usdPrice = parseFloat(usdPrice).toFixed(2);

                          historys=historys+'<tr class="'+mycls+'"><td >'+datetime+'</td><td class="text-uppercase text-green">'+type1+'</td><td>'+pairy+'</td><td>'+parseFloat(filledAmount).toFixed(6)+'</td><td>'+parseFloat(askPrice).toFixed(5)+'</td><td>'+parseFloat(b_tot).toFixed(6)+'</td><td>'+status+'</td></tr>';   
                                                   
                        }
                        else if(sell_userId==user_id)
                        {
                          var type1="Sell";
                          var askPrice=transactionhistory[count].sellaskPrice;
                          //askPrice=parseFloat(askPrice).toFixed(decimalpoints);
                          var sellaskPrice=transactionhistory[count].buyaskPrice;
                          sellaskPrice=parseFloat(sellaskPrice).toFixed(decimalpoints);
                          var orderTime1=transactionhistory[count].buyertime;
                          var orderTime2=transactionhistory[count].sellertime;
                          var pairy = transactionhistory[count].pair_symbol;
                          var buyerfee = transactionhistory[count].buyerfee;
                          var sellerfee = transactionhistory[count].sellerfee;
                          var buyertotal = transactionhistory[count].buyertotal;
                          var sellertotal = transactionhistory[count].sellertotal;
                          var time2 = orderTime2;

                          var datetime = transactionhistory[count].datetime;
                          
                          var myuserID = transactionhistory[count].sellerUserid;
                          var mycls = (myuserID==userlogid)?'myclass':'otherclass';

                          var s_tot = parseFloat(askPrice * filledAmount);
                          var status = transactionhistory[count].status.charAt(0).toUpperCase()+transactionhistory[count].status.slice(1);

                          var coinAmt = parseFloat(filledAmount).toFixed(6);
                          var usdPrice = coinAmt*usd_price;
                          usdPrice = parseFloat(usdPrice).toFixed(2);

                        historys=historys+'<tr class="'+mycls+'"><td >'+datetime+'</td><td class="text-uppercase text-red">'+type1+'</td><td>'+pairy+'</td><td>'+parseFloat(filledAmount).toFixed(6)+'</td><td>'+parseFloat(askPrice).toFixed(5)+'</td><td>'+parseFloat(s_tot).toFixed(6)+'</td><td>'+status+'</td></tr>';
                        
                        }                    
                    }
                  }
                  $('.transactionhistory').html(historys);
              }
              else 
              {              
                $('.transactionhistory').html('<tr><td></td><td></td><td></td><td><?php echo "No Trade History";?></td><td></td><td></td></tr>');
              }   

              //Market Trade Start
              if(checkapi==0)
              {
                  if(market_trade.length>0)
                    var market_trade_length=market_trade.length;
                    var market_table='';
                    for(count = 0; count < market_trade_length; count++)
                    {
                      var market_price=market_trade[count].price;
                      var activefilledAmount=market_trade[count].totalamount;
                      var type=market_trade[count].ordertype;

                    var activeAmount  = market_trade[count].Amount;
                   /* if(activefilledAmount)
                    {
                      market_amount = activeAmount-activefilledAmount;
                    }
                    else
                    {
                      market_amount = activeAmount;
                    }*/

                    market_amount = activeAmount;

                      if(type=='buy'){
                        var disp_color = 'text-green';
                        var th_type = "'buy'";
                      }
                      else{
                        var disp_color = 'text-red';
                        var th_type = "'sell'";
                      }
                      
                      var click="return cancel_order('"+market_trade[count].trade_id+"')";
                      var decimal = 6;

                      var coinAmt = parseFloat(market_amount).toFixed(decimal);
                      var usdPrice = coinAmt*usd_price;
                      usdPrice = parseFloat(usdPrice).toFixed(2);

                      market_table+='<tr><td>'+parseFloat(market_price).toFixed(decimal)+'</td><td>'+parseFloat(market_amount).toFixed(decimal)+'</td><td class="'+disp_color+'">'+type+'</td></tr>';
                     }
              }
              else
              {
                var market_table='';
                if(market_api_trades.length>0)
                {

                  for(var counts=0; counts < market_api_trades.length; counts++)
                  {

                    var market_price=market_api_trades[counts].price;
                    var market_amount=market_api_trades[counts].quantity;
                    var type=market_api_trades[counts].ordertype;

                    var width1 ="";
                    var decimal = 6;
                    if(type=='Buy'){
                        var disp_color = 'text-green';
                        var th_type = "'buy'";
                      }
                      else{
                        var disp_color = 'text-red';
                        var th_type = "'sell'";
                      }

                      var coinAmt = parseFloat(market_amount).toFixed(decimal);
                      var usdPrice = coinAmt*usd_price;
                      usdPrice = parseFloat(usdPrice).toFixed(2);

                      market_table+='<tr><td>'+parseFloat(market_price).toFixed(decimal)+'</td><td>'+parseFloat(market_amount).toFixed(decimal)+'</td><td class="'+disp_color+'">'+type+'</td></tr>';
                  }
                }
                else
                {
                  market_table+='<tr><td colspan="4" style="text-align:center !important;"><?php echo "No Orders Found";?></td></tr>';
                }
              }
              $('.market_trade').html(market_table);
              //Market Trade End       

              var orders1=[];
              if(checkapi==0)
              { 
                  if(sellResult.length>0)
                  {
                    var sellres_length=sellResult.length;
                    var order_table='';
                    for(count = 0; count < sellres_length; count++)
                    {
                      var activefilledAmount=sellResult[count].totalamount;
                      var activePrice=sellResult[count].Price;
                      var Fee=sellResult[count].Fee;
                      activePrice = activePrice;
                      var activeAmount  = sellResult[count].Amount;
                      if(activefilledAmount)
                      {
                        activefilledAmount = activeAmount-activefilledAmount;
                      }
                      else
                      {
                        activefilledAmount = activeAmount;
                      }
                      activefilledAmount=activefilledAmount; 

                      var click="return cancel_order('"+sellResult[count].trade_id+"')";
                      var type="'buy'";
                      var decimal = 8;

                      var coinAmt = parseFloat(activefilledAmount).toFixed(decimal);
                      var usdPrice = coinAmt*usd_price;
                      usdPrice = parseFloat(usdPrice).toFixed(2);

                      var totalAmt = sellResult[count].Total; 
                      var ordtype = sellResult[count].ordertype; 
                      basic_pairId = ['4','7','8','9','10'];
                        
                      if((jQuery.inArray(sellResult[count].pair, basic_pairId) != -1)&&(ordtype=='instant')) {
                        var activeCalcTotal = parseFloat(totalAmt);
                        onclickFun = "placeorder_basic";
                      } else {
                        var activeCalcTotal=parseFloat(activefilledAmount*activePrice) - parseFloat(Fee);
                        activeCalcTotal=(parseFloat(activeCalcTotal)).toFixed(decimalpoints);    
                        onclickFun = "placeorder";
                      }

                      order_table+='<tr hh style="cursor:pointer;" onclick="'+onclickFun+'('+type+','+parseFloat(activePrice).toFixed(decimal)+','+parseFloat(activefilledAmount).toFixed(decimal)+','+parseFloat(activeCalcTotal).toFixed(8)+')"><td class="text-red">'+parseFloat(activePrice).toFixed(decimal)+'</td><td>'+parseFloat(activefilledAmount).toFixed(decimal)+'</td><td>'+parseFloat(activeCalcTotal).toFixed(decimal)+'</td></tr>';

                     }
                  }
                

              }
              else
              {
                var order_table='';
                if(api_sellResult.length>0)
                {
                  for(var counts=0; counts < api_sellResult.length; counts++)
                  {
                    var type="'buy'";
                    var width1 ="";
                    var decimal = 6;

                    var coinAmt = parseFloat(api_sellResult[counts]['quantity']).toFixed(decimal);
                    var usdPrice = coinAmt*usd_price;
                    usdPrice = parseFloat(usdPrice).toFixed(2);
                    
                    order_table+='<tr dd style="cursor:pointer;" onclick="placeorder('+type+','+parseFloat(api_sellResult[counts]['price']).toFixed(decimal)+','+parseFloat(api_sellResult[counts]['quantity']).toFixed(decimal)+')"><td class="text-red">'+parseFloat(api_sellResult[counts]['price']).toFixed(decimal)+'</td><td>'+parseFloat(api_sellResult[counts]['quantity']).toFixed(decimal)+'</td><td>'+(parseFloat(api_sellResult[counts]['quantity'])*parseFloat(api_sellResult[counts]['price'])).toFixed(decimal)+'</td></tr>';
                  }
                }
                else
                {
                  order_table+='<tr><td colspan="4" style="text-align:center !important;"><?php echo "No Orders Found";?></td></tr>';
                }
              }
              $('.sell_order').html(order_table);

              var orders=[];
              if(checkapi==0)
              {
                if(buyResult.length>0)
                {
                      var buyres_length=buyResult.length;
                      var order_table1='';
                      for(count = 0; count < buyres_length; count++)
                      {
                        var activefilledAmount=buyResult[count].totalamount;
                        var activePrice=buyResult[count].Price;
                        var Fee=buyResult[count].Fee;
                        activePrice=activePrice;
                        var activeAmount  = buyResult[count].Amount;
                        if(activefilledAmount)
                        {
                          activefilledAmount = activeAmount-activefilledAmount;
                        }
                        else
                        {
                          activefilledAmount = activeAmount;
                        }
                        activefilledAmount=activefilledAmount;         
                        
                        var click="return cancel_order('"+buyResult[count].trade_id+"')";
                        var type="'sell'";
                        var decimal = 8;

                        var coinAmt = parseFloat(activefilledAmount).toFixed(decimal);
                        var usdPrice = coinAmt*usd_price;
                        usdPrice = parseFloat(usdPrice).toFixed(2);

                        var totalAmt = buyResult[count].Total; 
                        var ordtype = buyResult[count].ordertype; 
                        basic_pairId = ['4','7','8','9','10'];
                          
                        if((jQuery.inArray(buyResult[count].pair, basic_pairId) != -1)&&(ordtype=='instant')) {
                          var activeCalcTotal = parseFloat(totalAmt);
                          onclickFun = "placeorder_basic";
                        } else {
                          var activeCalcTotal = parseFloat(activefilledAmount*activePrice) + parseFloat(Fee);
                          activeCalcTotal=activeCalcTotal;   
                          onclickFun = "placeorder";
                        }
                        order_table1+='<tr style="cursor:pointer;" onclick="'+onclickFun+'('+type+','+parseFloat(activePrice).toFixed(decimal)+','+parseFloat(activefilledAmount).toFixed(8)+','+parseFloat(activeCalcTotal).toFixed(8)+')"><td class="text-green">'+parseFloat(activePrice).toFixed(decimal)+'</td><td>'+parseFloat(activefilledAmount).toFixed(decimal)+'</td><td>'+parseFloat(activeCalcTotal).toFixed(decimal)+'</td></tr>';
                      }
                }
              }
              else
              { 
                var order_table1 ='';
                if(api_buyResult.length>0)
                {                 
                  for(var count = 0; count < api_buyResult.length; count++)
                  {                    
                    var type="'sell'";
                    var buy_totl = (parseFloat(api_buyResult[count]['quantity'])*parseFloat(api_buyResult[count]['price'])).toFixed(8)
                    var width = "";
                    var decimal = 6;
                    var coinAmt = parseFloat(api_buyResult[count]['quantity']).toFixed(decimal);
                    var usdPrice = coinAmt*usd_price;
                    usdPrice = parseFloat(usdPrice).toFixed(2);                    

                    order_table1+='<tr style="cursor:pointer;" onclick="placeorder('+type+','+parseFloat(api_buyResult[count]['price']).toFixed(decimal)+','+parseFloat(api_buyResult[count]['quantity']).toFixed(decimal)+')"><td class="text-green">'+parseFloat(api_buyResult[count]['price']).toFixed(decimal)+'</td><td>'+parseFloat(api_buyResult[count]['quantity']).toFixed(decimal)+'</td><td>'+(parseFloat(api_buyResult[count]['quantity'])*parseFloat(api_buyResult[count]['price'])).toFixed(decimal)+'</td></tr>';
                  } 
                }
                else
                {
                  order_table1+='<tr><td colspan="4" style="text-align:center !important;"><?php echo "No Orders Found";?></td></tr>';
                }
              }          
              $('.buy_order').html(order_table1);
              var open_orders=designs.open_orders;
              var cancel_orders=designs.cancel_orders;
              var limit_orders = designs.open_orders_limit;
              var market_orders = designs.open_orders_market;
              var stop_orders=designs.open_orders_stop;
              var decimalpoints = 8;
              if(open_orders!=0&&open_orders.length>0)
              { 
                  var open_length=open_orders.length;
                  var open_orders_text='';
                  var open_orders_basic='';
                  var active_market_orders='';
                  for(count = 0; count < open_length; count++)
                  {
                    var activefilledAmount=open_orders[count].totalamount;
                    var activePrice=open_orders[count].Price;
                    var Fee=parseFloat(open_orders[count].Fee).toFixed(decimalpoints);
                    activePrice=(parseFloat(activePrice)).toFixed(decimalpoints);
                    var activeAmount  = open_orders[count].Amount;
                    if(activefilledAmount)
                    {
                      activefilledAmount = activeAmount-activefilledAmount;
                    }
                    else
                    {
                      activefilledAmount = activeAmount;
                    }
                    activefilledAmount=(parseFloat(activefilledAmount)).toFixed(decimalpoints);
                    

                    var click="return cancel_order('"+open_orders[count].trade_id+"')";
                    var odr_type = open_orders[count].Type;
                    var odr_status = open_orders[count].status;
                    var odr_color = '';

                    var time = open_orders[count].trade_time;
                    var pair_symbol = open_orders[count].pair_symbol; 
                    var pairy  = open_orders[count].pair;               
                    var ordtypes = open_orders[count].ordertype;

                    var click="return cancel_order('"+open_orders[count].trade_id+"','"+pairy+"')";

                    if(ordtypes == 'limit') var ordtype = 'Limit';
                    else if(ordtypes == 'stop') var ordtype = 'Stop Order';
                    else if(ordtypes == 'instant') var ordtype = 'Market';
                    else var ordtype = '-';

                    if(pair_active==pair_symbol) var myclass = 'currentpair';
                    else var myclass = 'differpair';

                    var coinAmt = activefilledAmount;
                    var usdPrice = coinAmt*usd_price;
                    usdPrice = parseFloat(usdPrice).toFixed(2);
                    
                    if(odr_type=='buy')
                    {
                      odr_color = 'text-uppercase text-green';

                      basic_pairId = ['4','7','8','9','10'];                        
                      if((jQuery.inArray(open_orders[count].pair, basic_pairId) != -1)&&(ordtype=='Market')) {
                        var activeCalcTotal=parseFloat(open_orders[count].Total);
                      } else {
                        var activeCalcTotal=parseFloat(activefilledAmount*activePrice) - parseFloat(Fee);
                        activeCalcTotal=(parseFloat(activeCalcTotal)).toFixed(decimalpoints);    
                      }
                                              
                    }
                    else
                    {
                      odr_color = 'text-uppercase text-red';
                     
                      basic_pairId = ['4','7','8','9','10'];
                      if((jQuery.inArray(open_orders[count].pair, basic_pairId) != -1)&&(ordtype=='Market')) {
                        var activeCalcTotal=parseFloat(open_orders[count].Total);
                      } else {
                        var activeCalcTotal=parseFloat(activefilledAmount*activePrice) - parseFloat(Fee);
                        activeCalcTotal=(parseFloat(activeCalcTotal)).toFixed(decimalpoints);    
                      }
                    }
 
                    if(odr_status=="partially") {
                      var style_st = "display:none";
                    } else {
                      var style_st = "display:block";
                    }

                    exchange_type = open_orders[count].exchange_type;
                   
                    open_orders_text=open_orders_text+'<tr><td>'+time+'</td><td class="'+odr_color+'">'+odr_type+'</td><td>'+pair_symbol+'</td><td>'+ordtype+'</td><td>'+activefilledAmount+'</td><td>'+activePrice+'</td><td>'+activeCalcTotal+'</td><td><a onclick="'+click+'" class="text-red" href="javascript:void(0);">Cancel Order</a></td></tr>';

                    if(ordtype=='Market') {
                      
                      if(odr_type=='buy') {
                        market_type="'sell'";
                      } else {
                        market_type="'buy'";
                      } 
                    }
                  }
                  
                  $('.open_orders').html(open_orders_text);
                  // $('.open_orders_basic').html(open_orders_text);
              }
              else
              {             
                 $('.open_orders').html('<tr><td colspan="7" style="text-align: center;"><?php echo 'No Active Orders Found';?></td></tr>'); 
                 // $('.open_orders_basic').html('<tr><td colspan="7" style="text-align: center;"><?php echo 'No Active Orders Found';?></td></tr>');             
              }                                         
          }
          else if(designs.web_trade == "2" && designs.web_trade != '')
          {
              var reslts = res.replace(/(\r\n|\n|\r)/gm,"");
              var res1 = JSON.parse(reslts);
              if(res1.result==1)
              { 
              	  $(".trade-loader").fadeOut("slow");
                  $.growl.notice({location: "cc",size:"large", title: "Share Coin Exchange", message: "Your order has been cancelled successfully"});
                  if(res1.type=='buy')
                  {
                      var balamount_buy=parseFloat((res1.second_balance)).toFixed(8);
                      var tosymbol = res1.to_symbol;
                      $(".buy_bal").html(balamount_buy+" "+to_symbol);                      
                  }
                  else
                  {
                      var balamount_sell=parseFloat((res1.first_balance)).toFixed(8);
                      var fromsymbol = res1.from_symbol;
                      $(".sell_bal").html(balamount_sell+" "+fromsymbol);
                  }
              }
              else
              {
                  //Swal.fire('Something went wrong, Please try again later', '', 'error');
              } 
          }
          else 
          {
              // var reslts = res.replace(/(\r\n|\n|\r)/gm,"");
              // var res1 = JSON.parse(reslts);
              // var from_balance = res1.from_currency;
              // var to_balance = res1.to_currency; 
              // var from_symbol = res1.from_symbol;
              // var to_symbol = res1.to_symbol;
              // var ordertype = res1.ordertype;
              // $(".sell_bal").html(from_balance+" "+from_symbol);
              // $(".buy_bal").html(to_balance+" "+to_symbol);

              var reslts = res.replace(/(\r\n|\n|\r)/gm,"");
              var res1 = JSON.parse(reslts);
              var from_balance = res1.from_currency;
              var to_balance = res1.to_currency; 
              var from_symbol = res1.from_symbol;
              var to_symbol = res1.to_symbol;
              var ordertype = res1.ordertype;
              var from_currency_value = $('#from_currency_value').val();
              var to_currency_value = $('#to_currency_value').val();
              $(".sell_bal").html(from_currency_value+' '+ First_Currency);
              $(".buy_bal").html(to_currency_value+' '+ Second_Currency);


              var a = res1.type;
              $("#"+a+"_btn").attr('disabled', true);
              $("#"+a+"_btn_loader").css('display','inline-block');
              
              if(res1.status == "balance")
              { 
                $(".trade-loader").fadeOut("slow");
                $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Insufficient balance');?>"});
                return false;
              }
              else if(res1.status == "minimum_amount")
              {
                $(".trade-loader").fadeOut("slow");
                $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Minimum trade amount is')?>"+ parseFloat(minimum_trade_amount)});
                return false;
              }
              else if(res1.status == "login")
              { 
                location.reload();
                $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Login to your account');?>"});
                
              }
              else if(res1.status == "success")
              {     
              	$(".trade-loader").fadeOut("slow");
                $.growl.notice({location: "cc",size:"large", title: "Share Coin Exchange", message: "<?=$this->lang->line('Your order has been placed');?>"});
                  setTimeout(function(){
                  $("#"+a+"_btn").attr('disabled', false);
                  $("#"+a+"_btn_loader").css('display','none');
                  }, 3000);
              }
              else
              {
                setTimeout(function(){
                $("#"+a+"_btn").attr('disabled', false);
                $("#"+a+"_btn_loader").css('display','none');
                }, 3000);
              }

              $('#'+ordertype+'_'+a+'_amount').val('');
              if(a=='buy')
              {
                $('#'+ordertype+'_'+a+'_price').val(current_buy_price); 
              }
              if(a=='buy')
              {
                  $('#'+ordertype+'_'+a+'_price').val(current_buy_price); 
              }
            $('#'+ordertype+'_'+a+'_tot').val(0);

            $("#limit_"+a+"_amount").val('');
            $("#limit_"+a+"_price").val(''); 
            $("#stop_"+a+"_amount").val(''); 
            $("#stop_"+a+"_price").val('');
            $("#stop_"+a+"_tprice").val('');

            $("#limit_"+a+"_tot").val(0);
            $("#instant_"+a+"_tot").val(0);
            $("#stop_"+a+"_tot").val(0);
            $(".spinner-border-sm").css("display","none");
          }
          // document.getElementById("buy_btn").disabled = false;
          // document.getElementById("sell_btn").disabled = false;
          $(".se-pre-con").fadeOut("slow");

    };
    ws.onerror = function(event)
    {
        var Data = JSON.parse(event);
    };
    ws.onclose = function(event)
    {
        $("#loader").hide();
    };      
    setInterval(function () {
        var decimal_sel = 8; 
            load_design(decimal_sel);
    },3000);

    $('.coin_percent_select ul li a').click(function() {

        $('.coin_percent_select ul li a.active').removeClass('active');
        $(this).addClass('active');
    });


</script>
</body>

</html>