<?php 
    $settings = $site_common['site_settings']; 
    $home_content = $this->common_model->getTableData('static_content',array('slug'=>'home_content'))->row();
    $sitelan = $this->session->userdata('site_lang'); 
    $copy_right_text = $sitelan."_copy_right_text";
?>
<div class="cptyBtm">
        <?=$settings->$copy_right_text?>
</div>

<script src="<?=front_js()?>jquery.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?=front_js()?>bootstrap.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?=front_js()?>owl.carousel.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?=front_js()?>main.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script type="text/javascript" src="../chart_library/charting_library/charting_library.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script type="text/javascript" src="../chart_library/datafeeds/udf/dist/polyfills.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script type="text/javascript" src="../chart_library/datafeeds/udf/dist/bundle.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?=front_js()?>toastr.min.js?v=<?php echo date('Ymdhis'); ?>"></script> 
<script>
    toastr.options = { "closeButton": true, "timeOut": "34000", }
</script> 
<script>
    var newjson_pair = '<?php echo $First_Currency . $Second_Currency?>';
    var newjson_pairs = '<?php echo $First_Currency . "_" . $Second_Currency?>';
    TradingView.onready(function () {
        var trade_feed = new Datafeeds.UDFCompatibleDatafeed("<?php echo base_url(); ?>newget_chart_record/" + newjson_pairs, 60000);
        var interval = "5";
        var widget = window.tvWidget = new TradingView.widget({
            debug: false,
            fullscreen: true,
            toolbar_bg: "rgba(61, 255, 1, 1)",
            symbol: newjson_pair,
            interval: interval,
            timeframe: "3D",
            //range: "1D",
            width: 980,
            //height: 910,
            timezone: "Europe/Berlin",
            "theme": "Light",
            
            container_id: "tradingview_254d3",
            datafeed: trade_feed,
            library_path: "../chart_library/charting_library/",
            locale: "en",

            drawings_access: {type: 'black', tools: [{name: "Regression Trend"}]},
            disabled_features: ["use_localstorage_for_settings"],
            autosize: true,

            overrides: {
                "paneProperties.background": "#FFF",
                "paneProperties.vertGridProperties.color": "#f0f1f5",
                "paneProperties.horzGridProperties.color": "#f0f1f5",
                "symbolWatermarkProperties.transparency": 90,
                "scalesProperties.textColor": "#000",
                "mainSeriesProperties.style": 8,
                "mainSeriesProperties.candleStyle.wickUpColor": '#1e5530',
                "mainSeriesProperties.candleStyle.wickDownColor": '#772830',
                "mainSeriesProperties.candleStyle.upColor": "#52d321",
                "mainSeriesProperties.candleStyle.downColor": "#f1440b",
                "mainSeriesProperties.showCountdown": true,
            },
            exchanges: [{"value": "", "name": "All Exchanges", "desc": ""}, {
                "value": "POLONIEX",
                "name": "POLONIEX",
                "desc": "POLONIEX"
            }
            ],
        });
    });
</script>
 <script>
  function placeorder(type,price,amount,total)
  {  
     price = convert(price);
    // console.log("price",price);
      if(type =='buy'){ api_type ='buy'}
      else { api_type ='sell'}
      var ordertype ='';
      $("#pills-"+api_type+"-tab").trigger('click');
      if(ordertype==''||ordertype==null)
      {
        ordertype='limit';
      }
      //$("#"+api_type+"_order_type").val(ordertype);
      $("#"+api_type+"_amount").val(amount);
      $("#"+api_type+"_price").val(price);
      $("#"+api_type+"_price").trigger('change');
      if(api_type == 'buy') {
       var maker = maker_fee;
        var fee_val = parseFloat(maker) / 100;
        var fee_val1 = parseFloat(taker_fee) / 100;
        var step1 = (amount*price*fee_val);
        var step2 = (amount*price);
        var trade_fee = (amount*fee_val1);
        var show_fee = trade_fee;
     }
      else 
      { 
        var maker = taker_fee;
        var fee_val = parseFloat(maker) / 100;
        var fee_val1 = parseFloat(maker_fee) / 100;
        var step1 = (amount*price*fee_val);
        var step2 = (amount*price);
        var trade_fee = (amount*price*fee_val1);
        var show_fee = trade_fee;
      }
     
      if(api_type == 'buy') {
       var total_val = (step1+step2).toFixed(8);
     }
      else { 
        var total_val = (step2+step1).toFixed(8); 
      }
      $("#"+api_type+"_tot").val(total);
      $("#"+api_type+"_fee_tot").val(parseFloat(step1).toFixed(8));
      $("#m"+api_type+"_totfee").text(parseFloat(show_fee).toFixed(8));          
  }
</script>
<script>
      var user_id='<?php echo $this->user_id; ?>';
      var base_url='<?php echo base_url(); ?>';
      var front_url='<?php echo front_url(); ?>';
      var coinchairs_userid = "<?php echo $this->user_id; ?>";
      var from_currency = "<?php echo $from_cur; ?>";
      var to_currency = "<?php echo $to_cur; ?>";
      var maker_fee = "<?php echo $this->maker; ?>";
      var taker_fee = "<?php echo $this->taker; ?>";
      var pair = "<?php echo implode('_',$pair); ?>";
      var pair_id = "<?php echo $pair_details->id; ?>";
      var checkapi = "<?php echo checkapi($pair_details->id); ?>";
      var current_buy_price = "<?php echo trailingZeroes(numberFormatPrecision($this->marketprice)); ?>";
      var current_sell_price = "<?php echo trailingZeroes(numberFormatPrecision($this->marketprice)); ?>";
      var minimum_trade_amount = "<?php echo $this->minimum_trade_amount; ?>";
      var lastmarketprice = "<?php echo $this->lastmarketprice; ?>";
      var dummyimg='<?php echo dummyuserImg(); ?>';
      var pagetype='<?php echo $pagetype; ?>';
      var first_id              = "<?php echo isset($pair[0])?currency_id($pair[0]):''; ?>";
      var second_id              = "<?php echo isset($pair[1])?currency_id($pair[1]):''; ?>";
      var port                  = "<?php echo $port; ?>";
      var host                  = "<?php echo $host; ?>";
      var date                  = "<?php echo date('Y-m-d H:i:s') ?>";
      var First_Currency = "<?php echo $First_Currency;?>";
      var Second_Currency = "<?php echo $Second_Currency;?>";
      var from_id = "<?php echo $from_currency_id; ?>";
      var to_id = "<?php echo $to_currency_id; ?>";
      var formt = 8;
      var number_format = 8;
      if(Second_Currency=="USD" || Second_Currency=="USDT")
      {
       number_format = 6;
      }
      
      var wsurl = 'ws://127.0.0.1:5001/ws/';
      var ws = new WebSocket(wsurl);
      
      $(".market_prices").val(current_buy_price);
      $(".instant_price").val(current_buy_price);
      $(".instant_prices").val(current_sell_price);
      $(".sell_pricesm").val(current_sell_price);
      $("#sell_prices").val(current_sell_price);

      var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';
      $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
              if (options.type.toLowerCase() == 'post') {
                  options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
                  if (options.data.charAt(0) == '&') {
                      options.data = options.data.substr(1);
                  }
              }
          });

      $( document ).ajaxComplete(function( event, xhr, settings ) {
        if (settings.type.toLowerCase() == 'post') {
          $.ajax({
              url: front_url+"get_csrf_token", 
              type: "GET",
              cache: false,             
              processData: false,      
              success: function(data) {
                console.log("CSRF Token");
                console.log(data);
                $("input[name="+csrfName+"]").val(data);
              }
            });
          }
      }); 
    function check_user_login()
    {
        if(user_id==''||user_id==undefined||user_id==0)
        {
          window.location.href = base_url;
          return false;
        }
        return true;
    }

    function change_buytrade(thiss,orderrtype,percrens)
    {
       //alert(thiss);       
       var typre = thiss;
       //$('#'+orderrtype+'_order_type').val();

       if(typre == 'limit') { var a = ''; }
       else if(typre == 'instant') { var a = 's'; }
       else { var a = 'ss'; } 

       var marketprice = $("#buy_prices").val();
       var current_currency = $("#current_currency").val();
       if(current_currency == 'USD') { var format = 2;}
       else { var format = 8;}
       var balance = $("#currency_value").val();
       var total = ((percrens/100)*balance).toFixed(format);
       $("#buy_tot"+a).val(total); // APPEND TOTAL
       
       var amount_calc = total/marketprice;
       var trade_fee = maker_fee/100;
       var fee_calc = parseFloat(amount_calc * marketprice * trade_fee).toFixed(format);
       $("#buy_fee_tot"+a).val(fee_calc);
       $("#mbuy_totfee"+a).text(fee_calc); 
       var amount_calculation = parseFloat((total/marketprice)-trade_fee).toFixed(format);
       if(user_id==''||user_id==undefined||user_id==0 || balance=='' || balance==undefined || balance==0)
       {
         amount_calculation = 0;
         total = 0;
         trade_fee = 0;
       }
       //alert(marketprice);alert(amount_calculation); alert(typre);
       if(typre == 'limit')
       {
         $("#buy_price").val(marketprice); 
         $('#buy_amount').val(amount_calculation); // APPEND AMOUNT
       }
       else
       {
         $("#buy_price"+a).val(marketprice); 
         $('#buy_amount'+a).val(amount_calculation); // APPEND AMOUNT
       }
       
    }

    function change_selltrade(thiss,orderrtype,percrens)
    {
      //lert(taker_fee);
       var typre = thiss;
       //$('#'+orderrtype+'_order_type').val();
       if(typre == 'limit') { var a = ''; }
       else if(typre == 'instant') { var a = 's'; }
       else { var a = 'ss'; } 

       var marketprice = $("#sell_prices").val();
       var current_currency = $("#scurrent_currency").val();
       if(current_currency == 'USD') { var format = 2;}
       else { var format = 8;}
       var balance = $("#scurrency_value").val();
       var amount = ((percrens/100)*balance).toFixed(format);
       $('#sell_amount'+a).val(amount); // APPEND AMOUNT
       
       var trade_fee = taker_fee/100;
       var total_calc = amount*marketprice;
       var fee_calc = parseFloat(amount * trade_fee).toFixed(format);
       $("#sell_fee_tot"+a).val(fee_calc);
       $("#msell_totfee"+a).text(fee_calc); 
       var total_calculation = (total_calc).toFixed(format);
       if(user_id==''||user_id==undefined||user_id==0 || balance=='' || balance==undefined || balance==0)
       {
       total_calculation = 0;
       amount = 0;
       trade_fee = 0;
       }
       
       $("#sell_price"+a).val(marketprice);
       $("#sell_tot"+a).val(total_calculation); // APPEND TOTAL
       $("#msell_tot"+a).text(parseFloat(total_calculation).toFixed(format));
    }

    function calculation(a,ordertype)
    {    
        var order_type  = $('#'+a+'_order_'+ordertype).val();
        if(order_type=='instant') // market
        {
            var amount      = $("#"+a+"_amounts").val();
            var buy_price   = $('#buy_prices').val();
            // alert(buy_price);
            var sell_price  = $('#sell_prices').val();
            if(a=='buy')
            { 
                if(buy_price!='' && amount!='')
                {
                    var maker_fee = "<?php echo $this->maker; ?>";
                    var taker_fee = "<?php echo $this->taker; ?>";

                    var tot   = parseFloat(amount)*parseFloat(current_buy_price);
                    var fee_val = parseFloat(maker_fee) / 100;
                    var fee_val1 = parseFloat(taker_fee) / 100;

                    var fees  = tot * fee_val;
                    fees = parseFloat(fees).toFixed(8);

                    var trade_fees  = parseFloat(amount) * fee_val1;
                    trade_fees = parseFloat(trade_fees).toFixed(8);

                    var n = tot.toString();
                    var n1 = fees.toString();
                    if(tot>0)
                    {
                        var tot = parseFloat(tot).toFixed(8);
                    }
                    else
                    {
                        var tot = 0;
                    }
                    if(amount!="" && amount!=0 && !isNaN(amount)&&n.indexOf("e")==-1&&n1.indexOf("e")==-1)
                    {
                        $('#buy_tots').val(tot);  
                        $('#buy_fee_tots').val(fees);
                        $('#mbuy_tots').text(tot);  
                        $('#mbuy_totfees').text(trade_fees);
                    }
                    else
                    {
                        if(n.indexOf("e")>-1||n1.indexOf("e")>-1)
                        {
                            $('.alert_err_'+a).show();
                            $('.error_msg_'+a).html('<?php echo $this->lang->line("Please enter valid amount and price")?>');
                            setTimeout(function(){
                                $('.alert_err_'+a).hide();
                            }, 3000);
                            return false;
                        }
                        $('#buy_tots').val(0);
                        $('#buy_fee_tots').val(0);
                        $('#mbuy_tots').text(0);  
                        $('#mbuy_totfees').text(0);
                        //$('#buy_prices').val(current_buy_price);
                        $('#buy_amounts').val(0);
                    }
                }
                else
                {
                    // alert("dshgh");
                    $('#buy_tots').val(0);
                    $('#buy_fee_tots').val(0);
                    $('#mbuy_tots').text(0);  
                    $('#mbuy_totfees').text(0);
                }
            }   
            else
            {
                if(sell_price!='' && amount!='')
                {
                    var maker_fee = "<?php echo $this->maker; ?>";
                    var taker_fee = "<?php echo $this->taker; ?>";

                    var tot_fee   = parseFloat(amount);
                    var fee_val = parseFloat(taker_fee) / 100;
                    var fee_val1 = parseFloat(maker_fee) / 100;

                    var show_fees  = tot_fee * fee_val;
                    show_fees = parseFloat(show_fees).toFixed(8);

                    var tot = parseFloat(amount) * parseFloat(current_sell_price);

                    var fees  = tot_fee * fee_val;
                    fees = parseFloat(fees).toFixed(8);
                      
                    var trade_fees  = tot * fee_val1;
                    trade_fees = parseFloat(trade_fees).toFixed(8);

                    var n = tot.toString();
                    var n1 = fees.toString();
                    if(tot>0)
                    {
                        var tot = parseFloat(tot).toFixed(8);
                    }
                    else
                    {
                        var tot = 0;
                    }
                    if(amount!="" && amount!=0 && !isNaN(amount)&&n.indexOf("e")==-1&&n1.indexOf("e")==-1)
                    {
                        $('#sell_tots').val(tot); 
                        $('#sell_fee_tots').val(fees);
                        $('#msell_tots').text(tot);  
                        $('#msell_totfees').text(trade_fees);
                    }
                    else
                    {
                        if(n.indexOf("e")>-1||n1.indexOf("e")>-1)
                        {
                            $('.alert_err_'+a).show();
                            $('.error_msg_'+a).html('<?php echo $this->lang->line("Please enter valid amount and price")?>');
                            setTimeout(function(){
                                $('.alert_err_'+a).hide();
                            }, 3000);
                            return false;
                        }
                        $('#sell_tots').val(0);
                        $('#sell_fee_tots').val(0);
                        $('#msell_tots').text(0);  
                        $('#msell_totfees').text(0);
                    }
                }
                else
                {
                    $('#sell_tots').val(0);
                    $('#sell_fee_tots').val(0);
                    $('#msell_tots').text(tot);  
                    $('#msell_totfees').text(fees);
                }
            }
        }
        else if(order_type=='limit') // limit
        {
            var amount      = $("#"+a+"_amount").val();
            var buy_price   = $('#buy_price').val();
            var sell_price  = $('#sell_price').val();
            if(a=='buy')
            {
              if(buy_price!='' && amount!='')
              {
                    var maker_fee = "<?php echo $this->maker; ?>";
                    var taker_fee = "<?php echo $this->taker; ?>";

                    var tot   = parseFloat(amount)*parseFloat(buy_price);
                    var fee_val = parseFloat(maker_fee) / 100;

                    var fee_val1 = parseFloat(taker_fee) / 100;


                    var fees  = tot * fee_val;
                    fees = parseFloat(fees).toFixed(8);

                    var trade_fees  = parseFloat(amount) * fee_val1;
                    trade_fees = parseFloat(trade_fees).toFixed(8);

                    var n = tot.toString();
                    var n1 = fees.toString();
                    if(tot>0)
                    {
                        var tot = parseFloat(tot).toFixed(8);
                    }
                    else
                    {
                        var tot = 0;
                    }
                    
                    if(amount!="" && amount!=0 && !isNaN(amount)&&n.indexOf("e")==-1&&n1.indexOf("e")==-1)
                    {

                        $('#buy_tot').val(tot);  
                        $('#buy_fee_tot').val(fees);
                        $('#mbuy_tot').text(tot);  
                        $('#mbuy_totfee').text(trade_fees);
                    }
                    else
                    {
                        if(n.indexOf("e")>-1||n1.indexOf("e")>-1)
                        {
                            $('.alert_err_'+a).show();
                            $('.error_msg_'+a).html('<?php echo $this->lang->line("Please enter valid amount and price")?>');
                            setTimeout(function(){
                                $('.alert_err_'+a).hide();
                            }, 3000);
                            return false;

                        }
                        $('#buy_tot').val(0);
                        $('#buy_fee_tot').val(0);
                        $('#mbuy_tot').text(0);  
                        $('#mbuy_totfee').text(0);
                        $('#buy_price').val(0);
                        $('#buy_amount').val(0);
                    }
              }
              else
              {
                $('#buy_tot').val(0);
                $('#buy_fee_tot').val(0);
                $('#mbuy_tot').text(0);  
                $('#mbuy_totfee').text(0);
              }
            }
            else
            {
                if(sell_price!='' && amount!='')
                {
                    var maker_fee = "<?php echo $this->maker; ?>";
                    var taker_fee = "<?php echo $this->taker; ?>";

                    var tot_fee   = parseFloat(amount);
                    var fee_val = parseFloat(taker_fee) / 100;
                    var fee_val1 = parseFloat(maker_fee) / 100;

                    var show_fees  = tot_fee * fee_val;
                    show_fees = parseFloat(show_fees).toFixed(8);

                    var tot = parseFloat(amount) * parseFloat(sell_price);

                    var fees  = tot_fee * fee_val;
                    fees = parseFloat(fees).toFixed(8);

                     var trade_fees  = tot * fee_val1;
                    trade_fees = parseFloat(trade_fees).toFixed(8);
                      

                      var n = tot.toString();
                      var n1 = fees.toString();
                      if(tot>0)
                      {
                          var tot = parseFloat(tot).toFixed(8);
                      }
                      else
                      {
                          var tot = 0;
                      }
                      if(amount!="" && amount!=0 && !isNaN(amount)&&n.indexOf("e")==-1&&n1.indexOf("e")==-1)
                      {
                          $('#sell_tot').val(tot); 
                          $('#sell_fee_tot').val(fees);
                          $('#msell_tot').text(tot);  
                          $('#msell_totfee').text(trade_fees);
                      }
                      else
                      {
                          if(n.indexOf("e")>-1||n1.indexOf("e")>-1)
                          {
                              $('.alert_err_'+a).show();
                              $('.error_msg_'+a).html('<?php echo $this->lang->line("Please enter valid amount and price")?>');
                              setTimeout(function(){
                                  $('.alert_err_'+a).hide();
                              }, 3000);
                              return false;
                          }
                          $('#sell_tot').val(0);
                          $('#sell_fee_tot').val(0);
                          $('#msell_tot').text(0);  
                          $('#msell_totfee').text(0);
                      }
              }
              else
              {
                $('#sell_tot').val(0);
                $('#sell_fee_tot').val(0);
                $('#msell_tot').text(tot);  
                $('#msell_totfee').text(fees);
              }
            }
        }
        else // Stop limit
        { 
            var amount      = $("#"+a+"_amountss").val();
            var buy_price   = $('#buy_pricess').val();
            var sell_price  = $('#sell_pricess').val(); 
            if(a=='buy')
            { 
              if(buy_price!='' && amount!='' && buy_price!=0 && amount!=0 && !isNaN(buy_price) && !isNaN(amount))
              {
                    var maker_fee = "<?php echo $this->maker; ?>";
                    var taker_fee = "<?php echo $this->taker; ?>";
                    var tot   = parseFloat(amount)*parseFloat(buy_price);
                    var fee_val = parseFloat(maker_fee) / 100;
                    var fee_val1 = parseFloat(taker_fee) / 100;

                    var fees  = tot * fee_val;
                    fees = parseFloat(fees).toFixed(8);

                    var trade_fees  = parseFloat(amount) * fee_val1;
                    trade_fees = parseFloat(trade_fees).toFixed(8);

                    var n = tot.toString();
                    var n1 = fees.toString();
                    if(tot>0)
                    {
                        var tot = parseFloat(tot).toFixed(8);
                    }
                    else
                    {
                        var tot = 0;
                    }
                    if(amount!="" && buy_price!="" && amount!=0 && buy_price!=0&&!isNaN(amount)&&n.indexOf("e")==-1&&n1.indexOf("e")==-1)
                    {
                        $('#buy_totss').val(tot);  
                        $('#buy_fee_totss').val(fees);
                        $('#mbuy_totss').text(tot);  
                        $('#mbuy_totfeess').text(trade_fees);
                    }
                    else
                    {
                        if(n.indexOf("e")>-1||n1.indexOf("e")>-1)
                        {
                            $('.alert_err_'+a).show();
                            $('.error_msg_'+a).html('<?php echo $this->lang->line("Please enter valid amount and price")?>');
                            //$('.sellbutton,.buybutton').prop('disabled', true);
                            setTimeout(function(){
                                $('.alert_err_'+a).hide();
                            }, 3000);
                            return false;
                        }
                    }
                }
                else
                {
                    $('#buy_totss').val("");
                    $('#buy_fee_totss').val("");
                    $('#mbuy_totss').text(0);  
                    $('#mbuy_totfeess').text(0);
                }
            }
            else
            { 
                if(sell_price!='' && amount!='' && sell_price!=0 && amount!=0 && !isNaN(sell_price) && !isNaN(amount))
                { 
                    var maker_fee = "<?php echo $this->maker; ?>";
                    var taker_fee = "<?php echo $this->taker; ?>";

                    var tot_fee   = parseFloat(amount);
                    var fee_val = parseFloat(taker_fee) / 100;

                    var fee_val1 = parseFloat(maker_fee) / 100;

                    var show_fees  = tot_fee * fee_val;
                    show_fees = parseFloat(show_fees).toFixed(8);

                    var tot = parseFloat(amount) * parseFloat(sell_price);

                    var fees  = tot_fee * fee_val;
                    fees = parseFloat(fees).toFixed(8);

                    var trade_fees  = tot * fee_val1;
                    trade_fees = parseFloat(trade_fees).toFixed(8);

                    var n = tot.toString();
                    var n1 = fees.toString();
                    if(tot>0)
                    {
                        var tot = parseFloat(tot).toFixed(8);
                    }
                    else
                    {
                        var tot = 0;
                    }
                    if(amount!="" && sell_price!="" && amount!="" && sell_price!=""&&!isNaN(amount)&&n.indexOf("e")==-1&&n1.indexOf("e")==-1)
                    { 
                        $('#sell_totss').val(tot); 
                        $('#sell_fee_totss').val(fees);
                        $('#msell_totss').text(tot);  
                        $('#msell_totfeess').text(trade_fees);
                    }
                    else
                    { 
                        if(n.indexOf("e")>-1||n1.indexOf("e")>-1)
                        {
                            $('#alert_errss_'+a).show();
                            $('#error_msgss_'+a).html('<?php echo $this->lang->line("Please enter valid amount and price")?>');
                            setTimeout(function(){
                            $('#alert_errss_'+a).hide();
                        }, 3000);
                            return false;
                        }

                        $('#sell_totss').val(0);
                        $('#sell_fee_totss').val(0);
                        $('#msell_totss').text(0);  
                        $('#msell_totfeess').text(0);
                        $('#sell_pricess').val(0);
                        $('#sell_amountss').val(0);
                    }
                }
                else
                { 
                    $('#sell_totss').val("");
                    $('#sell_fee_totss').val("");
                    $('#msell_totss').text(0);  
                    $('#msell_totfeess').text(0);
                }
            }
        }
    }

    function order_placed(a,ordertype)
    {  
        var logincheck=check_user_login();
        if(logincheck)
        {
           // $("#"+a+"_btn").attr('disabled', true);
          if(ordertype=="limit") // limit
          { 
         
            $('.alert_err_'+a).hide();
            $('.alert_succ_'+a).hide();
            var c     =   $("#"+a+"_amount").val();
            var p = $("#"+a+"_price").val();
            d = $("#"+a+"_tot").val();
            if(isNaN(c) || isNaN(d))
            {

                $('.alert_err_'+a).show(); 
                $('.error_msg_'+a).html("<?php echo $this->lang->line('Please enter valid amount and price')?>");
                setTimeout(function(){
                $('.alert_err_'+a).hide();
                $("#"+a+"_btn").attr('disabled', false);
                }, 3000);
               
                return false;
            }
            else if(c=="" || d=="")
            {
                $('.alert_err_'+a).show();
                $('.error_msg_'+a).html("<?php echo $this->lang->line('Please enter valid amount and price')?>"); 
                $('.error_msg_'+a).show();

                setTimeout(function(){
                  $('.alert_err_'+a).hide();
                  $("#"+a+"_btn").attr('disabled', false);
                }, 3000);
                return false;
            }
            else if(c<=0 || d<=0)
            {
                $('.alert_err_'+a).show();
                $('.error_msg_'+a).html("<?php echo $this->lang->line('Minimum trade amount is')?> "+ parseFloat(minimum_trade_amount)); 
                $('.error_msg_'+a).show();

                setTimeout(function(){
                  $('.alert_err_'+a).hide();
                  $("#"+a+"_btn").attr('disabled', false);
                }, 3000);
          
                return false;
            }
            if(p=="" || c=="")
            {
              $("#"+a+"_amount").val("");
              $("#"+a+"_price").val("");
              $("#"+a+"_tot").val("");
            }
            return order_confirm(a,ordertype);
          }
          else if(ordertype=="instant") // market
          {

              $('#alert_errs_'+a).hide();
              $('#alert_succs_'+a).hide();

              var c     =   $("#"+a+"_amounts").val();
              d = $("#"+a+"_tots").val(); 
              if(isNaN(c) || isNaN(d))
              {
                  $('#alert_errs_'+a).show();
                  $('#error_msgs_'+a).html("<?php echo $this->lang->line('Please enter valid amount and price')?>"); 
                  setTimeout(function(){
                  $('#alert_errs_'+a).hide();
                  $("#"+a+"_btn").attr('disabled', false);
                  }, 3000);
                 
                  return false;
              }
              else if(c=="" || d=="")
              {
                  $('#alert_errs_'+a).show();
                  $('#error_msgs_'+a).html("<?php echo $this->lang->line('Please enter valid amount and price')?>"); 
                  $('#error_msgs_'+a).show();

                  setTimeout(function(){
                    $('#alert_errs_'+a).hide();
                    $("#"+a+"_btn").attr('disabled', false);
                  }, 3000);
                  return false;
              }
              else if(c<=0 || d<=0)
              {
                  $('#alert_errs_'+a).show();
                  $('#error_msgs_'+a).html("<?php echo $this->lang->line('Minimum trade amount is')?> "+ parseFloat(minimum_trade_amount)); 
                  $('#error_msgs_'+a).show();

                  setTimeout(function(){
                    $('#alert_errs_'+a).hide();
                    $("#"+a+"_btn").attr('disabled', false);
                  }, 3000);
                  return false;
              }
              return order_confirm(a,ordertype);
          }
          else // Stop limit
          {
              $('#alert_errss_'+a).hide();
              $('#alert_succss_'+a).hide();

              var c     =   $("#"+a+"_amountss").val(); 
              d = $("#"+a+"_totss").val(); 
              var pri = $("#"+a+"_pricess").val();
              var limit_price = $("#"+a+"_limit").val();
              if(isNaN(c) || isNaN(d))
              {
                  $('#alert_errss_'+a).show();
                  $('#error_msgss_'+a).html("<?php echo 'Please enter valid amount and price';?>");
                  setTimeout(function(){
                  $('#alert_errss_'+a).hide();
                  $("#"+a+"_btn").attr('disabled', false);
                  }, 3000);
                 
                  return false;
              }
              else if(c=="" || d=="")
              {
                  $('#alert_errss_'+a).show();
                  $('#error_msgss_'+a).html("<?php echo 'Please enter valid amount and price';?>");
                  $('#error_msgss_'+a).show();

                  setTimeout(function(){
                    $('#alert_errss_'+a).hide();
                    $("#"+a+"_btn").attr('disabled', false);
                  }, 3000);
                  return false;
              }
              else if(c<=0 || d<=0)
              {
                  $('#alert_errss_'+a).show();
                  $('#error_msgss_'+a).html("<?php echo 'Minimum trade amount is';?> "+ parseFloat(minimum_trade_amount));
                  $('#error_msgss_'+a).show();

                  setTimeout(function(){
                    $('#alert_errss_'+a).hide();
                    $("#"+a+"_btn").attr('disabled', false);
                  }, 3000);
                  return false;
              }
              else if((c!="" || c>=0 || d!="" || d>=0) && limit_price=="" || limit_price<=0)
              {
                  $('#alert_errss_'+a).show();
                  $('#error_msgss_'+a).html('<?php echo "Please enter limit price";?>'); 
                  $('#error_msgss_'+a).show();
                  setTimeout(function(){
                    $('#alert_errss_'+a).hide();
                    $("#"+a+"_btn").attr('disabled', false);
                  }, 3000);
                  return false;
              }
              return order_confirm(a,ordertype);
          }
        }   
    }

    function order_confirm(a,ordertype)
    {
       $("#"+a+"_btn").attr('disabled', true);
        if(ordertype=='limit') // limit
        {
          var c = $("#"+a+"_amount").val();
          var d = $("#"+a+"_price").val();
          var multiply  = parseFloat(c)*parseFloat(d);
          
          if(a=="buy")
          {
            var fee_val = parseFloat(maker_fee) / 100;

            var fees      = multiply * fee_val;
            if(multiply>0)
            {
              var tot = multiply;
            }
            else
            {
              var tot = 0;
            }
          }
          else
          {
            var fee_val = parseFloat(taker_fee) / 100;
            var s_amount = parseFloat(c);
            var fees      = s_amount * fee_val;

             if(multiply>0)
            {
              var tot = multiply;
            }
            else
            {
              var tot = 0;
            } 
          }
          if(parseFloat(tot) < parseFloat(minimum_trade_amount)){
            $('.alert_err_'+a).show();
                $('.error_msg_'+a).html("<?php echo 'Minimum trade amount is';?> "+ parseFloat(minimum_trade_amount));
                setTimeout(function(){
                    $('.alert_err_'+a).hide();
                     $("#"+a+"_btn").attr('disabled', false);
                }, 3000);
                return false;
          }
          var mul = parseFloat(tot);
          if(a=="buy")
          {
             if(mul > to_currency)
              { 
                  $('.alert_err_'+a).show();
                  $('.error_msg_'+a).html("<?php echo 'Insufficient balance';?>");
                  setTimeout(function(){
                      $('.alert_err_'+a).hide();
                      $("#"+a+"_btn").attr('disabled', false);
                  }, 3000);
                  return false;
              }
              else
              {
                return executeOrder('buy','limit');
              }
          }
          else
          {    
            if(from_currency < parseFloat(c))
            {
                $('.alert_err_'+a).show();
                $('.error_msg_'+a).html("<?php echo 'Insufficient balance';?>");
                setTimeout(function(){
                    $('.alert_err_'+a).hide();
                    $("#"+a+"_btn").attr('disabled', false);
                }, 3000);
                return false;
            }
            else
            {
              return executeOrder('sell','limit');
            }
          }

        }
        else if(ordertype=='instant') // market
        {
          var c = $("#"+a+"_amounts").val();
          var d = $("#"+a+"_prices").val();
          var multiply  = parseFloat(c)*parseFloat(d);
          if(a=="buy")
          {
            var fee_val = parseFloat(maker_fee) / 100;

            var fees      = multiply * fee_val;

            if(multiply>0)
            {
              var tot = multiply;
            }
            else
            {
              var tot = 0;
            }
          }
          else
          {
             var fee_val = parseFloat(taker_fee) / 100;
             var s_amount = parseFloat(c);
             var fees      = s_amount * fee_val;

             if(multiply>0)
            {
              var tot = multiply;
            }
            else
            {
              var tot = 0;
            } 
          }
          if(parseFloat(tot) < parseFloat(minimum_trade_amount)){
            $('.alert_err_'+a).show();
                $('.error_msg_'+a).html("<?php echo $this->lang->line('Minimum trade amount is')?> "+ parseFloat(minimum_trade_amount));
                setTimeout(function(){
                    $('.alert_err_'+a).hide();
                    $("#"+a+"_btn").attr('disabled', false);
                }, 3000);
                return false;
          }
          var mul = parseFloat(tot);
          if(a=="buy")
          {
             if(mul > to_currency)
              { 
                  $('.alert_err_'+a).show();
                  $('.error_msg_'+a).html("<?php echo $this->lang->line('Insufficient balance')?>");
                  setTimeout(function(){
                      $('.alert_err_'+a).hide();
                      $("#"+a+"_btn").attr('disabled', false);
                  }, 3000);
                  return false;
              }
              else
              {
                return executeOrder('buy','instant');
              }
          }
          else
          {    
            if(from_currency < parseFloat(c))
            {
                $('.alert_err_'+a).show();
                $('.error_msg_'+a).html("<?php echo $this->lang->line('Insufficient balance')?>");
                setTimeout(function(){
                    $('.alert_err_'+a).hide();
                    $("#"+a+"_btn").attr('disabled', false);
                }, 3000);
                return false;
            }
            else
            {
              return executeOrder('sell','instant');
            }
          }
        }
        else // Stop limit
        { 
          var c = $("#"+a+"_amountss").val();
          var d = $("#"+a+"_pricess").val();
          var  l = $("#"+a+"_limit").val();
         
          if(a=="buy")
          {
            if(parseFloat(d)==parseFloat(current_buy_price))
            { 
                $('#alert_errss_'+a).show();
                $('#error_msgss_'+a).html('<?php echo "Stop price not same as market price";?>');
                setTimeout(function(){
                $('#alert_errss_'+a).hide();
                $("#"+a+"_btn").attr('disabled', false);
                        }, 3000);
              
                return false;
            }
            else if(parseFloat(d)!=parseFloat(current_buy_price)) 
            { 
            
               if(parseFloat(l)==parseFloat(current_buy_price))
              {
                $('#alert_errss_'+a).show();
                $('#error_msgss_'+a).html('<?php echo "Limit price not same as market price";?>');
                setTimeout(function(){
                $('#alert_errss_'+a).hide();
                $("#"+a+"_btn").attr('disabled', false);
                        }, 3000);
              
                return false;
              }
            
            }
            else
            {
            var multiply  = parseFloat(c)*parseFloat(d);
            var fee_val = parseFloat(maker_fee) / 100;
            var fees      = multiply * fee_val;

            if(multiply>0)
            {
              var tot = multiply;
            }
            else
            {
              var tot = 0;
            }
            }
          }
          else
          {
            if(parseFloat(d)==parseFloat(current_buy_price))
            {
              $('#alert_errss_'+a).show();
                        $('#error_msgss_'+a).html('<?php echo "Stop price not same as market price";?>');
                        setTimeout(function(){
                        $('#alert_errss_'+a).hide();
                        $("#"+a+"_btn").attr('disabled', false);
                        }, 3000);
                       
                        return false;
            }
            else if(parseFloat(d)!=parseFloat(current_buy_price)) 
            {
               if(parseFloat(l)==parseFloat(current_buy_price))
              {
                $('#alert_errss_'+a).show();
                $('#error_msgss_'+a).html('<?php echo "Limit price not same as market price";?>');
                setTimeout(function(){
                $('#alert_errss_'+a).hide();
                $("#"+a+"_btn").attr('disabled', false);
                        }, 3000);
              
                return false;
              }
            
            }
            else
            {
            var multiply  = parseFloat(c)*parseFloat(d);
            var s_amount = parseFloat(c);
            var fee_val = parseFloat(taker_fee) / 100;
            var fees      = s_amount * fee_val;
             if(multiply>0)
            {
              var tot = multiply;
            }
            else
            {
              var tot = 0;
            }
            }
          }
          if(parseFloat(tot) < parseFloat(minimum_trade_amount)){
            $('.alert_err_'+a).show();
                $('.error_msg_'+a).html("<?php echo 'Minimum trade amount is';?> "+ parseFloat(minimum_trade_amount));
                setTimeout(function(){
                    $('alert_err_'+a).hide();
                    $("#"+a+"_btn").attr('disabled', false);
                }, 3000);
                return false;
          }
          var mul = parseFloat(tot);
          if(a=="buy")
          {
             if(mul > to_currency)
              { 
                  $('.alert_err_'+a).show();
                  $('.error_msg_'+a).html("<?php echo 'Insufficient balance';?>");
                  setTimeout(function(){
                      $('.alert_err_'+a).hide();
                      $("#"+a+"_btn").attr('disabled', false);
                  }, 3000);
                  return false;
              }
              else
              {
                return executeOrder('buy','stop');
              }
          }
          else
          {    
            if(from_currency < parseFloat(c))
            {
                $('.alert_err_'+a).show();
                $('.error_msg_'+a).html("<?php echo 'Insufficient balance';?>");
                setTimeout(function(){
                    $('.alert_err_'+a).hide();
                    $("#"+a+"_btn").attr('disabled', false);
                }, 3000);
                return false;
            }
            else
            {
              return executeOrder('sell','stop');
            }
          }
        }        
    }

    function executeOrder(a,ordertype)
    {
      
       
      if(ordertype=='limit') // limit
      {
          var amount = $("#"+a+"_amount").val();
          var price = $("#"+a+"_price").val();
          var total = $("#"+a+"_tot").val();
          if(a =='buy')
          {
            var fee=maker_fee;
          }
          else
          {
            var fee=taker_fee;
          }
          var loan_rate=0;                   
          var param = {  
          path: "execute_order",
          amount: amount,
          price:price,
          limit_price:limit_price,
          total:total,
          fee:fee,
          ordertype:ordertype,
          pair:pair,
          pair_id:pair_id,
          type:a,
          loan_rate:loan_rate,
          pagetype:pagetype,
          user_id:'<?php echo $this->session->userdata('user_id');?>'
         };
         ws.send(JSON.stringify(param));
      }
      else if(ordertype=='instant') // market
      {
          var amount = $("#"+a+"_amounts").val();
          var price = $("#"+a+"_prices").val();
          var total = $("#"+a+"_tots").val();
          if(a =='buy')
          {
            var fee=maker_fee;
          }
          else
          {
            var fee=taker_fee;
          }
          var loan_rate=0;
          var param = {  
          path: "execute_order",
          amount: amount,
          price:price,
          limit_price:limit_price,
          total:total,
          fee:fee,
          ordertype:ordertype,
          pair:pair,
          pair_id:pair_id,
          type:a,
          loan_rate:loan_rate,
          pagetype:pagetype,
          user_id:'<?php echo $this->session->userdata('user_id');?>'
         };
         ws.send(JSON.stringify(param));
      }
      else // Stop limit
      { 
          var amount = $("#"+a+"_amountss").val();
          var price = $("#"+a+"_pricess").val();
          var total = $("#"+a+"_totss").val();
          var limit_price = $("#"+a+"_limit").val();
          if(a =='buy')
          {
            var fee=maker_fee;
          }
          else
          {
            var fee=taker_fee;
          }
          var loan_rate=0;
          var param = {  
          path: "execute_order",
          amount: amount,
          price:price,
          limit_price:limit_price,
          total:total,
          fee:fee,
          ordertype:ordertype,
          pair:pair,
          pair_id:pair_id,
          type:a,
          loan_rate:loan_rate,
          pagetype:pagetype,
          user_id:'<?php echo $this->session->userdata('user_id');?>'
         };
         ws.send(JSON.stringify(param));
      }
    }

    function cancel_order(tradeid,pair_id)
    {
        if(confirm('<?php echo $this->lang->line("Are you sure you want to cancel this order?")?>'))
        {          
           var param = {  
            path: "close_active_order",
            tradeid: tradeid,
            pair_id:pair_id,
            user_id:user_id
           };
           ws.send(JSON.stringify(param));
        }
    }

    function cancelAll()
    {
        if(confirm("Are you sure you want to cancel these orders?"))
        {          
           var param = {  
            path: "close_all_order",
            pair_id:pair_id,
            user_id:user_id
           };
           ws.send(JSON.stringify(param));
        }
    }

    function load_design(decimal)
    { 
        if(decimal==undefined)
        {
          decimal = 8;
        }
        else
        {
          decimal = decimal;
        }
         var decimalpoints=decimal;
         var decimal=decimal;
         if($("#showme").prop("checked") == true){
           var showorder = 'check';
         }
         else
         {
            var showorder = 'uncheck';
         }
         //console.log("showorder",showorder);

        //Call WEB SOCKET
       var param = {  
        path: "trade_integration",
        pair_id: pair_id,
        user_id:user_id,
        pagetype:pagetype,
        pair:pair,
        showorder:showorder
       };
       ws.send(JSON.stringify(param));     
    } 
    ws.onopen = function(event) 
    { 
        console.log("connected");             
        load_design();
    }
    ws.onmessage = function(event) 
    {
         // $("#buy_btn").attr("disabled",true);
          var browsername=navigator ? navigator.userAgent.toLowerCase() : "other";
          var resp = browsername.split(" "); 
          var lengthbrowser=resp.length;
          var getname=resp[lengthbrowser-1];
          var res1 = getname.split("/"); 
          if(res1[1]!='safari')
          {
            console.API;
            if (typeof console._commandLineAPI !== 'undefined') {
            console.API = console._commandLineAPI; //chrome
            } else if (typeof console._inspectorCommandLineAPI !== 'undefined') {
            console.API = console._inspectorCommandLineAPI; //Safari
            } else if (typeof console.clear !== 'undefined') {
            console.API = console;
            }
            //  console.API.clear();
          }

          var res = event.data;
          var designs=JSON.parse(res);
         
          var from_balance = designs.from_currency;
          var to_balance = designs.to_currency; //console.log(to_balance);
          var from_symbol = designs.from_symbol;
          var to_symbol = designs.to_symbol;
          var formt1 = formt;
          var pair_active = from_symbol+"/"+to_symbol;
          var apibuyResult = designs.apibuyResult;
          var apisellResult = designs.apisellResult;
          //console.log(apibuyResult);
         // console.log(apisellResult);
            /** Update the balance from web socket response **/
          var userlogid = "<?php echo $this->user_id; ?>";
          $(".sell_bal").html(from_balance+" "+First_Currency);
          $(".buy_bal").html(to_balance+" "+Second_Currency);

          if (designs.web_trade == "1" && designs.web_trade != '') 
          {
              var decimalpoints = "<?php echo $this->decimal_format; ?>";
              var decimal = "<?php echo $this->decimal_format; ?>";
              var current_trade=designs.current_trade;
              var transactionhistory=designs.transactionhistory;
              //console.log(transactionhistory);
              var bot_history=designs.transactionhistory_bot;
              var buyResult=designs.buyResult;
              var sellResult=designs.sellResult;
              var api_buyResult=designs.api_buyResult;
              var api_sellResult=designs.api_sellResult;
              var decimalpoints = 6;

              from_currency=designs.from_currency;
              to_currency=designs.to_currency;
              current_buy_price=designs.current_buy_price;
              current_sell_price=designs.current_sell_price;
              var show_t = designs.showme;
              var trans_class = designs.trans_class;

              var market_trade = designs.market_trade;

              var from_bal = "<?php echo $from_cur;?>";
              var to_bal = "<?php echo $to_cur;?>";
              var type_array =  ["buy","sell"];
              var type_rand = getrandom(type_array);

              if(transactionhistory!=0&&transactionhistory.length>0)
              {
                var transaction_length=transactionhistory.length;
                var historys='';
                for(count = 0; count < transaction_length; count++)
                {
                  if(transactionhistory[count].trade_id!='' && transactionhistory[count].trade_id)
                  {
                    var time3 = transactionhistory[count].tradetime;

                    var myuserID = transactionhistory[count].userId;

                    //var time3 = transactionhistory[count].datetime;
                    var type3 = (transactionhistory[count].Type).charAt(0).toUpperCase()+transactionhistory[count].Type.slice(1);
                    var price3 = transactionhistory[count].Price;
                    var amount3 = transactionhistory[count].Amount;
                    var fee3 = transactionhistory[count].Fee;
                    var total3  = transactionhistory[count].Total;
                    var pairy = transactionhistory[count].pair_symbol;
                    var status3 = transactionhistory[count].status.charAt(0).toUpperCase()+transactionhistory[count].status.slice(1);

                      var times3 = time3;
                      var hist_clr = "";
                      if(type3=="Buy")
                      {
                        hist_clr = "text-uppercase text-green";
                      }
                      else
                      {
                        hist_clr = "text-uppercase text-red";
                      }
                      /*if(show_t=="check")
                      {
                        var mycls = 'myclass';
                      }
                      else
                      {
                        var mycls = 'otherclass';
                      }*/
                      var mycls = (myuserID==userlogid)?'myclass':'otherclass';

                      historys=historys+'<tr class="'+mycls+'"><td>'+time3+'</td><td class="'+hist_clr+'">'+type3+'</td><td>'+pairy+'</td><td>'+parseFloat(amount3).toFixed(number_format)+'</td><td>'+parseFloat(price3).toFixed(number_format)+'</td><td>'+parseFloat(total3).toFixed(number_format)+'</td><td class="t-red">'+status3+'</td></tr>';
                  }
                  else
                  {    
                      var askAmount=transactionhistory[count].askAmount;
                      var buyer_trade_id=transactionhistory[count].buyer_trade_id;
                      var buy_userId = transactionhistory[count].buyerUserid;
                      var sell_userId = transactionhistory[count].sellerUserid;
                      var seller_trade_id=transactionhistory[count].seller_trade_id;
                      var filledAmount=transactionhistory[count].filledAmount;
                      var pairy = transactionhistory[count].pair_symbol;
                     // filledAmount=parseFloat(filledAmount).toFixed(decimalpoints);
                      if(buy_userId==sell_userId)
                      {
                        
                         if(buyer_trade_id < seller_trade_id)
                      {
                        var type1="Buy";
                        var askPrice=transactionhistory[count].buyaskPrice;
                        //askPrice=parseFloat(askPrice).toFixed(decimalpoints);
                        var sellaskPrice=transactionhistory[count].sellaskPrice;
                        sellaskPrice=parseFloat(sellaskPrice).toFixed(decimalpoints);
                        var orderTime1=transactionhistory[count].buyertime;
                        var orderTime2=transactionhistory[count].sellertime;
                        var buyerfee = transactionhistory[count].buyerfee;
                        var sellerfee = transactionhistory[count].sellerfee;
                        var buyertotal = transactionhistory[count].buyertotal;
                        var sellertotal = transactionhistory[count].sellertotal;
                        var time1 = orderTime1;

                        var datetime = transactionhistory[count].datetime;
                        var myuserID = transactionhistory[count].buyerUserid;
                        var mycls = (myuserID==userlogid)?'myclass':'otherclass';

                        var b_tot = parseFloat(askPrice * filledAmount);
                         var status = transactionhistory[count].status.charAt(0).toUpperCase()+transactionhistory[count].status.slice(1);

                         historys=historys+'<tr class="'+mycls+'"><td>'+datetime+'</td><td class="text-uppercase text-green">'+type1+'</td><td>'+pairy+'</td><td>'+parseFloat(filledAmount).toFixed(number_format)+'</td><td>'+parseFloat(askPrice).toFixed(number_format)+'</td><td>'+parseFloat(b_tot).toFixed(number_format)+'</td><td>'+status+'</td></tr>';
                                                 
                      }
                      else
                      {
                        var type1="Sell";
                        var askPrice=transactionhistory[count].sellaskPrice;
                        //askPrice=parseFloat(askPrice).toFixed(decimalpoints);
                        var sellaskPrice=transactionhistory[count].buyaskPrice;
                        sellaskPrice=parseFloat(sellaskPrice).toFixed(decimalpoints);
                        var orderTime1=transactionhistory[count].buyertime;
                        var orderTime2=transactionhistory[count].sellertime;
                        var pairy = transactionhistory[count].pair_symbol;
                        var buyerfee = transactionhistory[count].buyerfee;
                        var sellerfee = transactionhistory[count].sellerfee;
                        var buyertotal = transactionhistory[count].buyertotal;
                        var sellertotal = transactionhistory[count].sellertotal;
                        var time2 = orderTime2;

                        var datetime = transactionhistory[count].datetime;

                        var myuserID = transactionhistory[count].sellerUserid;
                        var mycls = (myuserID==userlogid)?'myclass':'otherclass';

                        var s_tot = parseFloat(askPrice * filledAmount);
                        var status = transactionhistory[count].status.charAt(0).toUpperCase()+transactionhistory[count].status.slice(1);

                        historys=historys+'<tr class="'+mycls+'"><td>'+datetime+'</td><td class="text-uppercase text-red">'+type1+'</td><td>'+pairy+'</td><td>'+parseFloat(filledAmount).toFixed(number_format)+'</td><td>'+parseFloat(askPrice).toFixed(number_format)+'</td><td>'+parseFloat(s_tot).toFixed(number_format)+'</td><td>'+status+'</td></tr>';
                      } 

                      }
                      else
                      {
                        if(buy_userId==user_id)
                      {
                        var type1="Buy";
                        var askPrice=transactionhistory[count].buyaskPrice;
                        //askPrice=parseFloat(askPrice).toFixed(decimalpoints);
                        var sellaskPrice=transactionhistory[count].sellaskPrice;
                        sellaskPrice=parseFloat(sellaskPrice).toFixed(decimalpoints);
                        var orderTime1=transactionhistory[count].buyertime;
                        var orderTime2=transactionhistory[count].sellertime;
                        var buyerfee = transactionhistory[count].buyerfee;
                        var sellerfee = transactionhistory[count].sellerfee;
                        var buyertotal = transactionhistory[count].buyertotal;
                        var sellertotal = transactionhistory[count].sellertotal;
                        var time1 = orderTime1;

                        var datetime = transactionhistory[count].datetime;
                        var myuserID = transactionhistory[count].buyerUserid;
                        var mycls = (myuserID==userlogid)?'myclass':'otherclass';

                        var b_tot = parseFloat(askPrice * filledAmount);
                         var status = transactionhistory[count].status.charAt(0).toUpperCase()+transactionhistory[count].status.slice(1);

                         historys=historys+'<tr class="'+mycls+'"><td>'+datetime+'</td><td class="text-uppercase text-green">'+type1+'</td><td>'+pairy+'</td><td>'+parseFloat(filledAmount).toFixed(number_format)+'</td><td>'+parseFloat(askPrice).toFixed(number_format)+'</td><td>'+parseFloat(b_tot).toFixed(number_format)+'</td><td>'+status+'</td></tr>';
                                                 
                      }
                      else if(sell_userId==user_id)
                      {
                        var type1="Sell";
                        var askPrice=transactionhistory[count].sellaskPrice;
                        //askPrice=parseFloat(askPrice).toFixed(decimalpoints);
                        var sellaskPrice=transactionhistory[count].buyaskPrice;
                        sellaskPrice=parseFloat(sellaskPrice).toFixed(decimalpoints);
                        var orderTime1=transactionhistory[count].buyertime;
                        var orderTime2=transactionhistory[count].sellertime;
                        var pairy = transactionhistory[count].pair_symbol;
                        var buyerfee = transactionhistory[count].buyerfee;
                        var sellerfee = transactionhistory[count].sellerfee;
                        var buyertotal = transactionhistory[count].buyertotal;
                        var sellertotal = transactionhistory[count].sellertotal;
                        var time2 = orderTime2;

                        var datetime = transactionhistory[count].datetime;

                        var myuserID = transactionhistory[count].sellerUserid;
                        var mycls = (myuserID==userlogid)?'myclass':'otherclass';

                        var s_tot = parseFloat(askPrice * filledAmount);
                        var status = transactionhistory[count].status.charAt(0).toUpperCase()+transactionhistory[count].status.slice(1);

                        historys=historys+'<tr class="'+mycls+'"><td>'+datetime+'</td><td class="text-uppercase text-red">'+type1+'</td><td>'+pairy+'</td><td>'+parseFloat(filledAmount).toFixed(number_format)+'</td><td>'+parseFloat(askPrice).toFixed(number_format)+'</td><td>'+parseFloat(s_tot).toFixed(number_format)+'</td><td>'+status+'</td></tr>';
                      } 

                      }
                                         
                  }
                }
                $('.transactionhistory').html(historys);
              }
              else 
              {              
              
              $('.transactionhistory').html('<tr><td colspan="7" style="text-align: center;">No Trade History Found</td></tr>');
              }

              if(bot_history!=0&&bot_history.length>0)
              {
                var bot_length=bot_history.length;
                var bot_historys='';
                for(count = 0; count < bot_length; count++)
                {
                  if(bot_history[count].trade_id!='' && bot_history[count].trade_id)
                  {
                    var time3 = bot_history[count].tradetime;

                    var myuserID = bot_history[count].userId;
                    var type3 = (bot_history[count].Type).charAt(0).toUpperCase()+bot_history[count].Type.slice(1);
                    var price3 = bot_history[count].Price;
                    var amount3 = bot_history[count].Amount;
                    var fee3 = bot_history[count].Fee;
                    var total3  = bot_history[count].Total;
                    var pairy = bot_history[count].pair_symbol;
                    var status3 = bot_history[count].status.charAt(0).toUpperCase()+bot_history[count].status.slice(1);

                      var times3 = time3;
                      var hist_clr = "";
                      if(type3=="Buy")
                      {
                        hist_clr = "text-uppercase text-green";
                      }
                      else
                      {
                        hist_clr = "text-uppercase text-red";
                      }
                      var mycls = (myuserID==userlogid)?'myclass':'otherclass';

                      bot_historys=bot_historys+'<tr class="'+mycls+'"><td>'+time3+'</td><td class="'+hist_clr+'">'+type3+'</td><td>'+pairy+'</td><td>'+parseFloat(amount3).toFixed(number_format)+'</td><td>'+parseFloat(price3).toFixed(number_format)+'</td><td>'+parseFloat(total3).toFixed(number_format)+'</td><td>'+status3+'</td></tr>';
                  }
                  }
                  $('.bot_history').html(bot_historys);
              }
              else 
              {
              $('.bot_history').html('<tr><td colspan="7" style="text-align: center;">No Trade History Found</td></tr>');
              }           

              var orders1=[];
              if(checkapi==0)
              {
                  if(sellResult.length>0)
                  {var order_table = '';
                if (sellResult.length > 0) {
                    for (var count = 0; count < sellResult.length; count++) {
                        var price = "'" + sellResult[count]['Price'] + "'";
                        if (sellResult[count]['filledAmount']) {
                            var filledamount = parseFloat(sellResult[count]['filledAmount']);
                        } else {
                            var filledamount = 0;
                        }
                        if (orders1[price] != undefined) {
                            orders1[price] = parseFloat(orders1[price]) + parseFloat(sellResult[count]['Amount']) -
                                filledamount;
                        } else {
                            orders1[price] = parseFloat(sellResult[count]['Amount']) - filledamount;
                        }
                    }
                }
                var autoinc1 = 0;
                for (var i in orders1) {
                    var ret = i.replace("'", "");
          
                    if (autoinc1 == 0) {
                        current_buy_price = parseFloat(ret).toFixed(8);
                        autoinc1 = 1;
                    }
                    var type = "'buy'";

                    order_table+='<tr style="cursor:pointer;" onclick="placeorder(' + type + ',' + parseFloat(ret)
                        .toFixed(number_format)+','+parseFloat(orders1[i]).toFixed(number_format)+','+(parseFloat(orders1[i]) * parseFloat(ret))+')"><td class="text-red">'+parseFloat(ret).toFixed(number_format).replace(/\.?0+$/, '')+'</td><td>'+parseFloat(orders1[i])
                        .toFixed(number_format).replace(/\.?0+$/, '')+'</td><td>'+(parseFloat(orders1[i]) * parseFloat(ret))
                        .toFixed(number_format).replace(/\.?0+$/, '')+'</td></tr>';
                }
                  }
                else
                {
                  order_table+='<tr><td colspan="3" style="text-align:center !important;">No Orders Found</td></tr>';
                }

              }
              else
              {
                var order_table='';
                 if(apisellResult.length>0)
                 {
                  var order_table = '';
                  if (apisellResult.length > 0) {
                      for (var count = 0; count < apisellResult.length; count++) {
                          var price = "'" + apisellResult[count]['price'] + "'";

                          if (apisellResult[count]['filledAmount'] != null || apisellResult[count]['filledAmount'] != undefined || apisellResult[count]['filledAmount'] != 0) {
                              var filledamount = apisellResult[count]['filledAmount'];
                          } else {
                              var filledamount = 0;
                          }
                          if (orders1[price] != undefined) {
                            //console.log("here");
                              orders1[price] = parseFloat(orders1[price]) + parseFloat(apisellResult[count]['quantity']) -
                                  filledamount;
                                  //console.log(orders1[price]);
                          } else {
                           // console.log("here 1");
                              orders1[price] = parseFloat(apisellResult[count]['quantity'] - filledamount);
                             // console.log(orders1[price]);
                          }
                      }
                  }
                  var autoinc1 = 0;
                  for (var i in orders1) {
                      var ret = i.replace("'", "");
            
                      if (autoinc1 == 0) {
                          current_buy_price = parseFloat(ret).toFixed(8);
                          autoinc1 = 1;
                      }
                      var type = "'buy'";
                     // console.log(filledamount);
                     // console.log(orders1[i]);
                      order_table+='<tr style="cursor:pointer;" onclick="placeorder(' + type + ',' + parseFloat(ret)
                          .toFixed(number_format)+','+parseFloat(orders1[i]).toFixed(number_format)+','+parseFloat(parseFloat(orders1[i]) * parseFloat(ret)).toFixed(number_format)+')"><td class="text-red">'+parseFloat(ret).toFixed(number_format).replace(/\.?0+$/, '')+'</td><td>'+parseFloat(orders1[i])
                          .toFixed(number_format).replace(/\.?0+$/, '')+'</td><td>'+(parseFloat(orders1[i]) * parseFloat(ret))
                          .toFixed(number_format).replace(/\.?0+$/, '')+'</td></tr>';
                  }
                  }
                  else
                  {
                  order_table+='<tr><td colspan="3" style="text-align:center !important;">No Orders Found</td></tr>';
                }
              }
              $('.sell_order').html(order_table);

              var orders=[];
              if(checkapi==0)
              {
                if(buyResult.length>0)
              {

                if (buyResult.length > 0) {
                    for (var count = 0; count < buyResult.length; count++) {

                        var price = "'" + buyResult[count]['Price'] + "'";
                        if (buyResult[count]['filledAmount']) {
                            var filledamount = parseFloat(buyResult[count]['filledAmount']);
                        } else {
                            var filledamount = 0;
                        }

                        if (orders[price] != undefined) {
                            orders[price] = parseFloat(orders[price]) + parseFloat(buyResult[count]['Amount']) -
                                filledamount;
                        } else {
                            orders[price] = parseFloat(buyResult[count]['Amount']) - filledamount;
                        }

                    }
                }
                var autoinc = 0;
                var width = 0;
                for (var i in orders) {
                    var ret = i.replace("'", "");
                   
                    if (autoinc == 0) {
                        current_sell_price = parseFloat(ret).toFixed(decimalpoints);
                        autoinc = 1;
                    }
                    var type = "'sell'";

                    order_table1+='<tr style="cursor:pointer;" onclick="placeorder(' + type + ',' + parseFloat(ret)
                        .toFixed(number_format) + ',' + parseFloat(orders[i]).toFixed(number_format) +
                        ',' + (parseFloat(orders[i]) * parseFloat(ret))
                        .toFixed(8) + ')"><td class="text-green">' + parseFloat(ret).toFixed(number_format).replace(/\.?0+$/, '') +
                        '</td><td>' + parseFloat(orders[i])
                        .toFixed(number_format).replace(/\.?0+$/, '') + '</td><td>' + (parseFloat(orders[i]) * parseFloat(ret))
                        .toFixed(number_format).replace(/\.?0+$/, '') + '</td></tr>'; 

                }
              }
              else
              {
                order_table1+='<tr><td colspan="3" style="text-align:center !important;">No Orders Found</td></tr>';
              }

              }
              else
              { 
                var order_table1 ='';
                if(apibuyResult.length>0)
                  {

                    if (apibuyResult.length > 0) {
                        for (var count = 0; count < apibuyResult.length; count++) {

                            var price = "'" + apibuyResult[count]['price'] + "'";
                            if (apibuyResult[count]['filledAmount'] != null || apibuyResult[count]['filledAmount'] != undefined || apibuyResult[count]['filledAmount'] != 0) {
                                var filledamount = apibuyResult[count]['filledAmount'];
                            } else {
                                var filledamount = 0;
                            }

                            if (orders[price] != undefined) {
                                orders[price] = parseFloat(orders[price]) + parseFloat(apibuyResult[count]['quantity']) -
                                    filledamount;
                            } else {
                                orders[price] = parseFloat(apibuyResult[count]['quantity'] - filledamount);
                            }

                        }
                    }
                    var autoinc = 0;
                    var width = 0;
                    for (var i in orders) {
                        var ret = i.replace("'", "");
                       
                        if (autoinc == 0) {
                            current_sell_price = parseFloat(ret).toFixed(decimalpoints);
                            autoinc = 1;
                        }
                        var type = "'sell'";

                        order_table1+='<tr style="cursor:pointer;" onclick="placeorder(' + type + ',' + parseFloat(ret)
                            .toFixed(number_format) + ',' + parseFloat(orders[i]).toFixed(number_format) +
                            ',' + parseFloat(parseFloat(orders[i]) * parseFloat(ret))
                            .toFixed(number_format) + ')"><td class="text-green">' + parseFloat(ret).toFixed(number_format).replace(/\.?0+$/, '') +
                            '</td><td>' + parseFloat(orders[i])
                            .toFixed(number_format).replace(/\.?0+$/, '') + '</td><td>' + (parseFloat(orders[i]) * parseFloat(ret))
                            .toFixed(number_format).replace(/\.?0+$/, '') + '</td></tr>'; 

                    }
                  }
                  else
                  {
                    order_table1+='<tr><td colspan="3" style="text-align:center !important;">No Orders Found</td></tr>';
                  }
                
              }          
              $('.buy_order').html(order_table1);  


              var open_orders=designs.open_orders;
              
              var decimalpoints = 8;

              if(open_orders!=0&&open_orders.length>0)
              {
                  var open_length=open_orders.length;
                  var open_orders_text='';
                  for(count = 0; count < open_length; count++)
                  {
                    var activefilledAmount=open_orders[count].totalamount;
                    var activePrice=open_orders[count].Price;
                    var Fee=parseFloat(open_orders[count].Fee).toFixed(number_format);
                    activePrice=(parseFloat(activePrice)).toFixed(number_format);
                    var activeAmount  = open_orders[count].Amount;
                    if(activefilledAmount)
                    {
                      activefilledAmount = activeAmount-activefilledAmount;
                    }
                    else
                    {
                      activefilledAmount = activeAmount;
                    }
                    activefilledAmount=(parseFloat(activefilledAmount)).toFixed(number_format);
                    

                    var click="return cancel_order('"+open_orders[count].trade_id+"')";
                    var odr_type = open_orders[count].Type;
                    var odr_status = open_orders[count].status;
                    //alert(odr_type);
                    var odr_color = '';
                    if(odr_type=='buy')
                    {
                      odr_color = 'text-uppercase text-green t-green';
                      var activeCalcTotal = parseFloat(activefilledAmount*activePrice).toFixed(number_format).replace(/\.?0+$/, '');
                      //var activeCalcTotal=parseFloat(open_orders[count].Total).toFixed(8);
                    }
                    else
                    {
                      odr_color = 'text-uppercase text-red t-red';
                       var activeCalcTotal = parseFloat(activefilledAmount*activePrice).toFixed(number_format).replace(/\.?0+$/, '');
                      //var activeCalcTotal=parseFloat(open_orders[count].Total).toFixed(8);
                    }
                    if(odr_status=="partially")
                    {
                      var style_st = "display:block";
                    }
                    else
                    {
                      var style_st = "display:block";
                    }
                    var time = open_orders[count].datetime;
                    var pair_symbol = open_orders[count].pair_symbol; 
                    var pairy  = open_orders[count].pair;               
                    var ordtypes = open_orders[count].ordertype;

                    var click="return cancel_order('"+open_orders[count].trade_id+"','"+pairy+"')";

                    if(ordtypes == 'limit') var ordtype = 'Limit';
                    else if(ordtypes == 'stop') var ordtype = 'Stop Order';
                    else if(ordtypes == 'instant') var ordtype = 'Market';
                    else var ordtype = '-';

                    if(pair_active==pair_symbol) var myclass = 'currentpair';
                    else var myclass = 'differpair';
                    
                     open_orders_text=open_orders_text+'<tr><td>'+time+'</td><td class="'+odr_color+'">'+odr_type+'</td><td>'+ordtype+'</td><td>'+pair_symbol+'</td><td>'+activefilledAmount+'</td><td>'+activePrice+'</td><td>'+activeCalcTotal+'</td><td><a onclick="'+click+'" class="text-red" href="javascript:void(0);" style="'+style_st+'">Cancel Order</a></td></tr>';

                  }
                  $('.open_orders').html(open_orders_text);
              }
              else
              {             
                 $('.open_orders').html('<tr><td colspan="7" style="text-align: center;">No Active Orders Found</td></tr>');             
              }
              if(market_trade.length>0)
              {
                var markettrade_length=market_trade.length;
                var market_res='';
                for(count = 0; count < markettrade_length; count++)
                {
                  var from_symbol = market_trade[count].from_symbol;
                  var to_symbol = market_trade[count].to_symbol;
                  var pair_symbol = from_symbol+'/'+to_symbol;
                  var trading_price = market_trade[count].trading_price;
                  var percent_class = market_trade[count].percent_class;
                  var price_24hrs = market_trade[count].price_24hrs;
                  var change_24hrs = parseFloat(market_trade[count].change_24hrs).toFixed(2);
                  var volume = market_trade[count].volume;
                  var from_small = market_trade[count].from_symbol.toLowerCase();
                  var to_small = market_trade[count].to_symbol.toLowerCase();
                  var baseurl = "<?php echo base_url();?>";

                  
                  

                  market_res += '<li class="slide-link '+from_symbol+' '+to_symbol+' '+from_small+' '+to_small+'"><div class=""><a href="'+baseurl+'trade/'+from_symbol+'_'+to_symbol+'"><h6>'+pair_symbol+'</h6></a><h6>'+market_trade[count].trading_price+'</h6></div><div><p>24h Change</p><p><span class="'+percent_class+'">'+price_24hrs+'</span>  (<span class="'+percent_class+'">'+change_24hrs+'%</span>)</p></div><div><p>24h Volume</p><p>'+volume+' '+from_symbol+'</p></div></li>';

                 $(".pairres").html(market_res);

                 var myvalue = $("#mysearchs").val(); 
                if(myvalue=='')
                {
                    $(".coinPairsList li").removeClass('removeclass');
                    $(".coinPairsList li").removeClass('showclass');
                    $(".coinPairsList li").removeClass('overclass');
                    $("#coinPairsLists").hide();
                }
                else
                {
                  if($(".coinPairsList li").hasClass(myvalue))
                  {
                    $(".coinPairsList li").removeClass('removeclass');
                    $(".coinPairsList li").removeClass('showclass');
                    $(".coinPairsList li").removeClass('overclass');

                    $(".coinPairsList li").addClass('removeclass');
                    $('.'+myvalue).removeClass('removeclass').addClass('showclass');
                    $("#coinPairsLists").hide();
                  }
                  else
                  {
                     $(".coinPairsList li").removeClass('removeclass');
                     $(".coinPairsList li").removeClass('showclass');
                     $(".coinPairsList li").addClass("overclass");
                     $("#coinPairsLists").show();
                     $("#coinPairsLists").html("No results found..");

                  }
                }

                  
                 }
              }
              var current_trade = designs.current_trade;
               if(current_trade)
              {
               var tradeprice = current_trade.trading_price;
               var lowprice = current_trade.low_price;
               var highprice = current_trade.high_price;
               var volume = current_trade.volume;
               var volume_usd = current_trade.volume_usd;
               $(".trade_price").text(tradeprice);
               $(".trade_highprice").text(highprice);
               $(".trade_lowprice").text(lowprice);
               $(".trade_volume").text(volume);
               $(".trade_volume_usd").text(volume_usd);
              }

              /*if(market_trade_tab.length>0)
              {
                var markettradetab_length=market_trade_tab.length;
                var market_res='';
                for(count = 0; count < markettradetab_length; count++)
                {
                  var from_symbol = market_trade_tab[count].from_symbol;
                  var to_symbol = market_trade_tab[count].to_symbol;
                  var pair_symbol = from_symbol+'/'+to_symbol;
                  var trading_price = parseFloat(market_trade_tab[count].trading_price).toFixed(5);
                  var percent_class = market_trade_tab[count].percent_class;
                  var price_24hrs = parseFloat(market_trade_tab[count].price_24hrs).toFixed(4);
                  var change_24hrs = parseFloat(market_trade_tab[count].change_24hrs).toFixed(2);
                  var volume = parseFloat(market_trade_tab[count].volume).toFixed(5);
                  var from_small = from_symbol.toLowerCase();
                  var to_small = to_symbol.toLowerCase();
                  var baseurl = "<?php echo base_url();?>";

                  
                  
                  market_res += '<li class="slide-link '+from_symbol+' '+to_symbol+' '+from_small+' '+to_small+'"><div class=""><a href="'+baseurl+'trade/'+from_symbol+'_'+to_symbol+'"><h6>'+pair_symbol+'</h6></a><h6>'+trading_price+'</h6></div><div><p>24h Change</p><p><span class="'+percent_class+'">'+price_24hrs+'</span>  (<span class="'+percent_class+'">'+change_24hrs+'%</span>)</p></div><div><p>24h Volume</p><p>'+volume+' '+to_symbol+'</p></div></li>';

                 //$(".pairres_tab").html(market_res);

                  
                 }
              }*/                            
          }
          else if(designs.web_trade == "2" && designs.web_trade != '')
          {
              var reslts = res.replace(/(\r\n|\n|\r)/gm,"");
              var res1 = JSON.parse(reslts);
              if(res1.result==1)
              {
                  toastr.success("Your order has been cancelled successfully");
                  if(res1.type=='buy')
                  {
                      var balamount_buy=parseFloat((res1.second_balance)).toFixed(8);
                      var tosymbol = res1.to_symbol;
                      $(".buy_bal").html(balamount_buy+" "+to_symbol);
                      
                  }
                  else
                  {
                      var balamount_sell=parseFloat((res1.first_balance)).toFixed(8);
                      var fromsymbol = res1.from_symbol;
                      $(".sell_bal").html(balamount_sell+" "+fromsymbol);
                  }
                  var decimal_sel = 8;
                  load_design(decimal_sel);
              }
              else
              {
                  toastr.error("Something went wrong, Please try again later");
              } 
          }
          else if(designs.web_trade == "3" && designs.web_trade != '')
          {
              var reslts = res.replace(/(\r\n|\n|\r)/gm,"");
              var res1 = JSON.parse(reslts);
              if(res1.result==1)
              {
                  toastr.success("Your orders has been cancelled successfully");
                  if(res1.type=='buy')
                  {
                      var balamount_buy=parseFloat((res1.second_balance)).toFixed(8);
                      var tosymbol = res1.to_symbol;
                      $(".buy_bal").html(balamount_buy+" "+to_symbol);
                      
                  }
                  else
                  {
                      var balamount_sell=parseFloat((res1.first_balance)).toFixed(8);
                      var fromsymbol = res1.from_symbol;
                      $(".sell_bal").html(balamount_sell+" "+fromsymbol);
                  }
                  var decimal_sel = 8;
                  load_design(decimal_sel);
              }
              else
              {
                  toastr.error("Something went wrong, Please try again later");
              } 
          }
          else 
          {
              var reslts = res.replace(/(\r\n|\n|\r)/gm,"");
              var res1 = JSON.parse(reslts);

              var from_balance = res1.from_currency;
              var to_balance = res1.to_currency; //console.log(to_balance);
              var from_symbol = res1.from_symbol;
              var to_symbol = res1.to_symbol;
              $(".sell_bal").html(from_balance+" "+from_symbol);
              $(".buy_bal").html(to_balance+" "+to_symbol);

              var a = res1.type;
              $("#"+a+"_btn").attr('disabled', true);
              if(res1.status == "balance")
              { 
                $('.alert_err_'+a).show();
                $('.error_msg_'+a).html('<?php echo $this->lang->line("Insufficient balance")?>');
                $("#"+a+"_btn").attr('disabled', false);
                return false;
              }
              else if(res1.status == "minimum_amount")
              { 
                $('.alert_err_'+a).show();
                $('.error_msg_'+a).html("<?php echo $this->lang->line('Minimum trade amount is')?> "+ parseFloat(minimum_trade_amount));
                setTimeout(function(){
                    $('.alert_err_'+a).hide();
                    $("#"+a+"_btn").attr('disabled', false);
                }, 3000);
                return false;
              }
              else if(res1.status == "login")
              { 
                location.reload();
                $('.alert_err_'+a).show();
                $('.error_msg_'+a).html('<?php echo $this->lang->line("Login to your account")?>');
                setTimeout(function(){
                    $('.alert_err_'+a).hide();
                    $("#"+a+"_btn").attr('disabled', false);
                }, 3000);
              }
              else if(res1.status == "success")
              {                 
                  $('.alert_succ_'+a).show();
                  $('.success_msg_'+a).html('<?php echo $this->lang->line("Your order has been placed")?>');
                  setTimeout(function(){
                  $('.alert_succ_'+a).hide();
                  $('.success_msg'+a).html('');
                  $("#"+a+"_btn").attr('disabled', false);
                  }, 3000);
              }
              else
              {
                $('.alert_err_'+a).show();
                $('.error_msg_'+a).html(res);
                 setTimeout(function(){
                $('.alert_err_'+a).hide();
                $("#"+a+"_btn").attr('disabled', false);
                }, 3000);
              }
              $("#"+a+"_amount").val('');
              $("#"+a+"_amounts").val('');  $("#"+a+"_amountss").val('');
              $("#"+a+"_price").val('');  $("#"+a+"_pricess").val('');
              $("#"+a+"_tot").val(''); $("#"+a+"_tots").val(''); $("#"+a+"_totss").val('');
              $("#"+a+"_fee_tot").val(''); $("#"+a+"_fee_tots").val(''); $("#"+a+"_fee_totss").val('');
              $("#m"+a+"_totfee").text("0.00000000"); 
              $("#m"+a+"_totfees").text("0.00000000"); 
              $("#m"+a+"_totfeess").text("0.00000000");  
              $("#"+a+"_limit").val('');
              var decimal_sel = 8;
              load_design(decimal_sel);

          }
    }
    ws.onerror = function(event)
    {
        var Data = JSON.parse(event);
        //console.log("MANIMEGS => "+Data);
    };
    ws.onclose = function(event)
    {
        $("#loader").hide();
    };      
    setInterval(function () {
        var decimal_sel = 8;
             load_design(decimal_sel);
            // console.clear();
    },3000);
    </script>
    
    <script>
    $(document).ready(function(){
        $('#showme').click(function(){
            if($(this).prop("checked") == true){
              $(".otherclass").hide();
                $(".myclass").show();
            }
            else if($(this).prop("checked") == false){
               $(".myclass").show();
               $(".otherclass").show();
            }
        });
    });

    $("#mysearchs").keyup(function(){
      var myvalue = $(this).val(); 
      if(myvalue=='')
      {
          $(".coinPairsList li").removeClass('removeclass');
          $(".coinPairsList li").removeClass('showclass');
          $(".coinPairsList li").removeClass('overclass');
          $("#coinPairsLists").hide();
      }
      else
      {
        if($(".coinPairsList li").hasClass(myvalue))
        {
          $(".coinPairsList li").removeClass('removeclass');
          $(".coinPairsList li").removeClass('showclass');
          $(".coinPairsList li").removeClass('overclass');

          $(".coinPairsList li").addClass('removeclass');
          $('.'+myvalue).removeClass('removeclass').addClass('showclass');
          $("#coinPairsLists").hide();
        }
        else
        {
           $(".coinPairsList li").removeClass('removeclass');
           $(".coinPairsList li").removeClass('showclass');
           $(".coinPairsList li").addClass("overclass");
           $("#coinPairsLists").show();
           $("#coinPairsLists").html("No results found..");

        }
      }
    });

    function convert(n){
        var sign = +n < 0 ? "-" : "",
            toStr = n.toString();
        if (!/e/i.test(toStr)) {
            return n;
        }
        var [lead,decimal,pow] = n.toString()
            .replace(/^-/,"")
            .replace(/^([0-9]+)(e.*)/,"$1.$2")
            .split(/e|\./);
        return +pow < 0 
            ? sign + "0." + "0".repeat(Math.max(Math.abs(pow)-1 || 0, 0)) + lead + decimal
            : sign + lead + (+pow >= decimal.length ? (decimal + "0".repeat(Math.max(+pow-decimal.length || 0, 0))) : (decimal.slice(0,+pow)+"."+decimal.slice(+pow)))
    }

    function shuffle(array) {
  var currentIndex = array.length, temporaryValue, randomIndex;

  // While there remain elements to shuffle...
  while (0 !== currentIndex) {

    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;

    // And swap it with the current element.
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }

  return array;
}
function getrandom(list) {
  return list[Math.floor((Math.random()*list.length))];
} 
</script>


</body>

</html>
