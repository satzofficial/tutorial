<?php $settings = $site_common['site_settings'];
require 'webs/vendor/autoload.php';
require 'webs/includes/config.php';
$user_id = $this->session->userdata('user_id');
$site_common = site_common();
$site_name = $site_common['site_settings']->site_name;
$Logo = $site_common['site_settings']->site_logo;
$fav_icon = $site_common['site_settings']->site_favicon;

$pair_id = $pair_details->id;
$trading_price = tradeprice($pair_id);
$high_price = highprice($pair_id);
$low_price = lowprice($pair_id);
$price_24hr = pricechange($pair_id);
if($price_24hr>=0)
{
    $price_sym = "+";
}
$per_24hr = pricechangepercent($pair_id);
if($per_24hr >= 0)
{
   $per_sym = "+";
   $percent_class = 'text-green';
}
else
{
   $percent_class = 'text-red';
}
$volume = volume($pair_id);
$First_Currency = $pair[0];
$Second_Currency = $pair[1];
?>
<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?=$meta_content->title;?></title>
    <meta content="<?php echo $meta_content->meta_description; ?>" name="descriptison">
    <meta content="<?php echo $meta_content->meta_keywords;?>" name="keywords">
    <!-- Favicons -->
    <link href="<?=$settings->site_favicon?>" rel="icon">

    <!--bootstrap-->
   <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/front/inner/css/bootstrap.min.css" />

    <!--animation-->
    <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/front/inner/css/animate.min.css" />
    <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/front/inner/css/hover-min.css" />

    <!--carousel-->
    <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/front/inner/css/owl.carousel.min.css" />
    <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/front/inner/css/owl.theme.default.min.css" />
    <link href="<?=base_url();?>assets/front/vendor/icofont/icofont.min.css" rel="stylesheet">

    <!--font-icons-->
    <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/front/inner/css/fontawesome-all.css" />
    <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/front/inner/css/flag-icon.css" />

    <!--datatables-->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/w/bs4/dt-1.10.18/datatables.min.css" />

    <!--bootstrap-select-->
    <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/front/inner/css/bootstrap-select.css" />

    <!--sitefonts-->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Rajdhani:300,400,500,600,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">

    <!--styles-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/front/inner/css/style_trade.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/front/inner/css/responsive_trade.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/4.0.6/sweetalert2.min.css" />
</head>

<body class="trade_advance dark_mode" id="body">
    <header>
        <div class="container-fluid p-0">
            <div class="row align-items-center no-gutters">
                <div class="col-lg-3">
                    <div class="exchange_banner_left d-flex align-items-center">
                        <div class="trade_logo logo mr-auto">
                             <h1 class="text-light">
                           <a href="<?=base_url();?>"><img height="50" src="<?php echo $settings->site_logo;?>"></a>
                       </h1>
                        </div>
                        <ul>
                            <li><a href="<?php echo base_url()?>trade">Basic</a></li>
                            <li class="active"><a href="<?php echo base_url()?>trade/pro">Advance</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-9">
                    <div
                        class="currency_details d-flex justify-content-lg-end justify-content-center align-items-center">
                        <ul class="currency_status">
                            <li>
                                <h5>Last Price
                                    <span class="text-green"><?php echo number_format($trading_price,5); ?> <?php echo $Second_Currency;?></span></h5>
                            </li>
                            <li>
                                <h5>24h Change
                                    <span class="<?php echo $percent_class; ?>"><?php echo $price_sym.number_format($price_24hr,5);?> <small><?php echo $per_sym.number_format($per_24hr,2).'%';?></small></span></h5>
                            </li>
                            <li>
                                <h5>24h High
                                    <span><?php echo number_format($high_price,5);?></span></h5>
                            </li>
                            <li>
                                <h5>24h Low
                                    <span><?php echo number_format($low_price,5);?></span></h5>
                            </li>
                            <li>
                                <h5>24h Volume
                                    <span><?php echo number_format($volume,2);?> <?php echo $Second_Currency;?></span></h5>
                            </li>
                        </ul>
                        <select class="currency_select selectpicker" onchange="change_pair(this.value)">
                            <optgroup label="<?php echo $Second_Currency;?>">
                            <?php if(count($pair_currency)>0) { foreach($pair_currency as $pair) {  
                                     $from_currency_det = getcryptocurrencydetail($pair->from_symbol_id);
                                     $to_currency_det = getcryptocurrencydetail($pair->to_symbol_id);
                                     $curr_pair = $First_Currency.$Second_Currency;
                                     $pairname = $from_currency_det->currency_symbol.$to_currency_det->currency_symbol;
                                     if($from_currency_det->id==$pair->from_symbol_id && $to_currency_det->id==$pair->to_symbol_id) {
                                    ?>
                            <option value="<?php echo $from_currency_det->currency_symbol.'_'.$to_currency_det->currency_symbol;?>" 
                                <?php if($curr_pair==$pairname) { echo "selected"; } else { echo ""; } ?> ><?php echo $from_currency_det->currency_symbol.' / '.$to_currency_det->currency_symbol;?></option>
                            <?php } } } ?>
                            </optgroup>
                        </select>
                        <ul class="trade_top_links">
                    <?php
                    if(empty($user_id))
                    { ?><li><a href="<?=base_url();?>login"><i class="fa fa-sign-in-alt"></i>Signin</a></li>
                        <?php }else { ?><li><a href="<?=base_url();?>logout"><i class="fa fa-sign-out-alt"></i>Logout</a></li>
                            <?php } ?>
                            <?php
                    if(empty($user_id) && $settings->newuser_reg_status==1)
                    {
                    ?>
                    <li class="get-started"><a href="<?=base_url();?>signup">Signup</a></li>
                     <?php } else { ?>
                        <li><a href="<?=base_url();?>dashboard"><i class="fa fa-user"></i> Account</a></li>
                         <?php } ?>
                            
                            
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </header>