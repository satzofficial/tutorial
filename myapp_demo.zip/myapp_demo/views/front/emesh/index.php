<?php
// echo '<pre>';print_r($site_common['site_settings']);exit;
$favicon  =  ($site_common['site_settings']->site_favicon) ? $site_common['site_settings']->site_favicon :'';
$english_site_name  =  ($site_common['site_settings']->english_site_name) ? $site_common['site_settings']->english_site_name :'';
$sitelogo = ($site_common['site_settings']->site_logo) ? $site_common['site_settings']->site_logo :'';
$site_email = ($site_common['site_settings']->site_email) ? $site_common['site_settings']->site_email :'';
$assets_url_var = base_url('assets/front/');
$base_url_var = base_url();
$csrf_name = $this->security->get_csrf_token_name(); // for the name
$csrf_token = $this->security->get_csrf_hash();  // for the value
$class = $this->router->fetch_class();
$method = $this->router->fetch_method();
    ?>
    <!DOCTYPE html>
<html lang="en">

<!-- Mirrored from template.viserlab.com/casinous/demo/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 14 Dec 2022 15:27:21 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="<?php echo $csrf_name ?>" content="<?php echo $csrf_token; ?>">
      <title><?php echo $english_site_name; ?></title>
      
    <!--<link rel="icon" type="image/png" href="<?php echo base_url();?>css/assets/images/favicon.png" sizes="16x16">-->
    <!-- bootstrap 5  -->
    <link rel="stylesheet" href="<?php echo base_url();?>css/assets/css/lib/bootstrap.min.css">
    <!-- Icon Link  -->
    <link rel="stylesheet" href="<?php echo base_url();?>css/assets/css/all.min.css"> 
    <link rel="stylesheet" href="<?php echo base_url();?>css/assets/css/line-awesome.min.css"> 
    <link rel="stylesheet" href="<?php echo base_url();?>css/assets/css/lib/animate.css"> 

    <!-- Plugin Link -->
    <link rel="stylesheet" href="<?php echo base_url();?>css/assets/css/lib/slick.css">

    <!-- Main css -->
    <link rel="stylesheet" href="<?php echo base_url();?>css/assets/css/main.css">
</head>
    <body data-bs-spy="scroll" data-bs-offset="170" data-bs-target=".privacy-policy-sidebar-menu">

        <div class="overlay"></div>
        
        
        <style></style>
     
        <div class="preloader">
            <div class="scene" id="scene">
                <input type="checkbox" id="andicator" />
                   <span class="loader"></span>
                   <style>
                       .loader {
            width: 48px;
            height: 48px;
            position: relative;
            animation : rotate 4s linear infinite;
          }
          .loader:before,
          .loader:after {
            content:"";
            display: block;
            border: 24px solid;
            border-color: transparent transparent #fff  #fff;
            position: absolute;
            left: 0;
            top: 0;
            animation: mvx 1s infinite ease-in;
          }
          .loader:before {
            left: -1px;
            top: 1px;
            border-color:#FF3D00  #FF3D00 transparent transparent;
            animation-name:mvrx;
          }

          @keyframes rotate {
            100% {transform: rotate(360deg)}
          }
          @keyframes mvx {
            0% , 15% {transform: translate(0 , 0) rotate(0deg)}
            50% {transform: translate(-50% , 50%) rotate(180deg)}
            100% {transform: translate(0% , 0%) rotate(180deg)}
          }
          @keyframes mvrx {
            0% , 15%  {transform: translate(0 , 0) rotate(0deg)}
            50% {transform: translate(50% , -50%) rotate(180deg)}
            100% {transform: translate(0% , 0%) rotate(180deg)}
          }
    
                   </style>
             
            </div>
        </div>

    <div class="header">
    <div class="container">
        <div class="header-bottom">
            <div class="header-bottom-area align-items-center">
                <div class="logo"><a href="#"><img src="<?php echo base_url();?>css/assets/images/logos.png" alt="logo"></a></div>
                   <ul class="menu">
                    <li>
                        <a href="<?php echo base_url();?>">Home</a>
                    </li>
            <!--         <li>
                        <a href="about.html">About</a>
                    </li>
                    <li>
                        <a href="games.html">Games <span class="badge badge--sm badge--base text-dark">NEW</span></a>
                    </li>
                    <li>
                        <a href="faq.html">Faq</a>
                    </li> -->
                   <!--  <li>
                        <a href="#0">Pages</a>
                        <ul class="sub-menu">
                            <li>
                                <a href="dashboard.html">User Dashboard</a>
                            </li>
                            <li>
                                <a href="game-details.html">Game Details</a>
                            </li>
                            <li>
                                <a href="policy.html">Privacy Policy</a>
                            </li>
                            <li>
                                <a href="terms-conditions.html">Terms & Conditions</a>
                            </li>
                            <li>
                                <a href="sign-in.html">Sign In</a>
                            </li>
                            <li>
                                <a href="sign-up.html">Sign Up</a>
                            </li>
                        </ul>
                    </li> -->
                <!--     <li>
                        <a href="#0">Blog</a>
                        <ul class="sub-menu">
                            <li><a href="blog.html">Blog</a></li>
                            <li><a href="blog-details.html">Blog Details</a></li>
                        </ul>
                    </li> -->
                    <li>
                        <a href="<?php echo base_url();?>signup">Sign Up</a>
                    </li>
                     <li>
                        <a href="<?php echo base_url();?>signin">Sign In</a>
                    </li>


                    <button class="btn-close btn-close-white d-lg-none"></button>
                </ul>
                <div class="header-trigger-wrapper d-flex d-lg-none align-items-center">
                    <div class="header-trigger me-4">
                        <span></span>
                    </div>
                
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- Banner Section Starts Here -->
    <section class="banner-section bg_img overflow-hidden" style="background:url(<?php echo base_url();?>css/assets/images/banner/bg.png) center">
        <div class="container">
            <div class="banner-wrapper d-flex flex-wrap align-items-center">
                <div class="banner-content">
                    <h1 class="banner-content__title"><span style="color:red!important"; class="text--base">Blackchain</span><span style="color:#00dbff;">&nbsp; & &nbsp;</span> <span style="color:#2dff00;!important"; >Crypto Learning platform</span></h1>
                    <!--<p class="banner-content__subtitle">Get More Profits</p>-->
                    <div class="button-wrapper">
                     
                        <a href="<?php echo base_url();?>signup" class="cmn--btn btn--lg">Sign Up</a>
                          <a href="<?php echo base_url();?>signin" class="cmn--btn btn--lg">Sign In</a>
                    </div>
                    
                    <!--   <div class="button-wrapper">-->
                     
                      
                    <!--</div>-->
                    
                    <!--<img src="<?php echo base_url();?>css/assets/images/banner/card.png" alt="" class="shape1">-->
                </div>
                <div class="banner-thumb">
                    <img src="<?php echo base_url();?>css/assets/images/banner/btc.png" alt="banner">
                </div>
            </div>
        </div>
    </section>
    <!-- Banner Section Ends Here -->


    <!-- About Section Starts Here -->
    <!--<section class="about-section padding-top padding-bottom overflow-hidden">-->
    <!--    <div class="container">-->
    <!--        <div class="row align-items-center">-->
    <!--            <div class="col-lg-6">-->
    <!--                <div class="about-content">-->
    <!--                    <div class="section-header">-->
    <!--                        <h2 class="section-header__title">About The Casino</h2>-->
    <!--                        <p>A casino is a facility for certain types of gambling. Casinos are often built near or combined with hotels, resorts, restaurants, retail shopping, cruise ships, and other tourist attractions. Some casinos are also known for hosting live entertainment, such as stand-up comedy, concerts, and sports.</p>-->
    <!--                    </div>-->
    <!--                    <a href="about.html" class="cmn--btn active">Know More</a>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-lg-6">-->
    <!--                <div class="aobut-thumb section-thumb">-->
    <!--                    <img src="<?php echo base_url();?>css/assets/images/about/thumb.png" alt="about" class="ms-lg-5">-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--    <div class="shapes">-->
    <!--        <img src="<?php echo base_url();?>css/assets/images/about/shape.png" alt="about" class="shape shape1">-->
    <!--    </div>-->
    <!--</section>-->
    <!-- About Section Ends Here -->


    <!-- Game Section Starts Here -->
    <!--<section class="game-section padding-top padding-bottom bg_img" style="background: url(<?php echo base_url();?>css/assets/images/game/bg3.jpg);">-->
    <!--    <div class="container" style="display:none">-->
    <!--        <div class="row justify-content-center">-->
    <!--            <div class="col-lg-6 col-xl-5">-->
    <!--                <div class="section-header text-center">-->
    <!--                    <h2 class="section-header__title">Top Awesome Games</h2>-->
    <!--                    <p>A casino is a facility for certain types of gambling. Casinos are often built combined with hotels, resorts,.</p>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
            <!--<div class="row gy-4 justify-content-center">-->
            <!--    <div class="col-lg-4 col-xl-3 col-md-6 col-sm-6">-->
            <!--        <div class="game-item">-->
            <!--            <div class="game-inner">-->
            <!--                <div class="game-item__thumb">-->
            <!--                    <img src="<?php echo base_url();?>css/assets/images/game/item2.png" alt="game">-->
            <!--                </div>-->
            <!--                <div class="game-item__content">-->
            <!--                    <h4 class="title">Roulette</h4>-->
            <!--                    <p class="invest-info">Invest Limit</p>-->
            <!--                    <p class="invest-amount">$10.49 - $1,000</p>-->
            <!--                    <a href="#0" class="cmn--btn active btn--md radius-0">Play Now</a>-->
            <!--                </div>-->
            <!--            </div>-->
            <!--            <div class="ball"></div>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--    <div class="col-lg-4 col-xl-3 col-md-6 col-sm-6">-->
            <!--        <div class="game-item">-->
            <!--            <div class="game-inner">-->
            <!--                <div class="game-item__thumb">-->
            <!--                    <img src="<?php echo base_url();?>css/assets/images/game/item1.png" alt="game">-->
            <!--                </div>-->
            <!--                <div class="game-item__content">-->
            <!--                    <h4 class="title">Zero To Ninty</h4>-->
            <!--                    <p class="invest-info">Invest Limit</p>-->
            <!--                    <p class="invest-amount">$10.49 - $1,000</p>-->
            <!--                    <a href="#0" class="cmn--btn active btn--md radius-0">Play Now</a>-->
            <!--                </div>-->
            <!--            </div>-->
            <!--            <div class="ball"></div>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--    <div class="col-lg-4 col-xl-3 col-md-6 col-sm-6">-->
            <!--        <div class="game-item">-->
            <!--            <div class="game-inner">-->
            <!--                <div class="game-item__thumb">-->
            <!--                    <img src="<?php echo base_url();?>css/assets/images/game/item3.png" alt="game">-->
            <!--                </div>-->
            <!--                <div class="game-item__content">-->
            <!--                    <h4 class="title">Number Buy</h4>-->
            <!--                    <p class="invest-info">Invest Limit</p>-->
            <!--                    <p class="invest-amount">$10.49 - $1,000</p>-->
            <!--                    <a href="#0" class="cmn--btn active btn--md radius-0">Play Now</a>-->
            <!--                </div>-->
            <!--            </div>-->
            <!--            <div class="ball"></div>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--    <div class="col-lg-4 col-xl-3 col-md-6 col-sm-6">-->
            <!--        <div class="game-item">-->
            <!--            <div class="game-inner">-->
            <!--                <div class="game-item__thumb">-->
            <!--                    <img src="<?php echo base_url();?>css/assets/images/game/item4.png" alt="game">-->
            <!--                </div>-->
            <!--                <div class="game-item__content">-->
            <!--                    <h4 class="title">Roulette</h4>-->
            <!--                    <p class="invest-info">Invest Limit</p>-->
            <!--                    <p class="invest-amount">$10.49 - $1,000</p>-->
            <!--                    <a href="#0" class="cmn--btn active btn--md radius-0">Play Now</a>-->
            <!--                </div>-->
            <!--            </div>-->
            <!--            <div class="ball"></div>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--    <div class="col-lg-4 col-xl-3 col-md-6 col-sm-6">-->
            <!--        <div class="game-item">-->
            <!--            <div class="game-inner">-->
            <!--                <div class="game-item__thumb">-->
            <!--                    <img src="<?php echo base_url();?>css/assets/images/game/item5.png" alt="game">-->
            <!--                </div>-->
            <!--                <div class="game-item__content">-->
            <!--                    <h4 class="title">Card Game</h4>-->
            <!--                    <p class="invest-info">Invest Limit</p>-->
            <!--                    <p class="invest-amount">$10.49 - $1,000</p>-->
            <!--                    <a href="#0" class="cmn--btn active btn--md radius-0">Play Now</a>-->
            <!--                </div>-->
            <!--            </div>-->
            <!--            <div class="ball"></div>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--    <div class="col-lg-4 col-xl-3 col-md-6 col-sm-6">-->
            <!--        <div class="game-item">-->
            <!--            <div class="game-inner">-->
            <!--                <div class="game-item__thumb">-->
            <!--                    <img src="<?php echo base_url();?>css/assets/images/game/item6.png" alt="game">-->
            <!--                </div>-->
            <!--                <div class="game-item__content">-->
            <!--                    <h4 class="title">Dice Rolling</h4>-->
            <!--                    <p class="invest-info">Invest Limit</p>-->
            <!--                    <p class="invest-amount">$10.49 - $1,000</p>-->
            <!--                    <a href="#0" class="cmn--btn active btn--md radius-0">Play Now</a>-->
            <!--                </div>-->
            <!--            </div>-->
            <!--            <div class="ball"></div>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--    <div class="col-lg-4 col-xl-3 col-md-6 col-sm-6">-->
            <!--        <div class="game-item">-->
            <!--            <div class="game-inner">-->
            <!--                <div class="game-item__thumb">-->
            <!--                    <img src="<?php echo base_url();?>css/assets/images/game/item2.png" alt="game">-->
            <!--                </div>-->
            <!--                <div class="game-item__content">-->
            <!--                    <h4 class="title">Card Game</h4>-->
            <!--                    <p class="invest-info">Invest Limit</p>-->
            <!--                    <p class="invest-amount">$10.49 - $1,000</p>-->
            <!--                    <a href="#0" class="cmn--btn active btn--md radius-0">Play Now</a>-->
            <!--                </div>-->
            <!--            </div>-->
            <!--            <div class="ball"></div>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--    <div class="col-lg-4 col-xl-3 col-md-6 col-sm-6">-->
            <!--        <div class="game-item">-->
            <!--            <div class="game-inner">-->
            <!--                <div class="game-item__thumb">-->
            <!--                    <img src="<?php echo base_url();?>css/assets/images/game/item6.png" alt="game">-->
            <!--                </div>-->
            <!--                <div class="game-item__content">-->
            <!--                    <h4 class="title">Dice Rolling</h4>-->
            <!--                    <p class="invest-info">Invest Limit</p>-->
            <!--                    <p class="invest-amount">$10.49 - $1,000</p>-->
            <!--                    <a href="#0" class="cmn--btn active btn--md radius-0">Play Now</a>-->
            <!--                </div>-->
            <!--            </div>-->
            <!--            <div class="ball"></div>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--</div>-->
    <!--    </div>-->
    <!--</section>-->
    <!-- Game Section Ends Here -->


    <!-- Why Choose Us Section Starts Here -->
    <section class="why-section padding-top padding-bottom overflow-hidden">
        <div class="container">
            <div class="row justify-content-between gy-5">
                <div class="col-lg-12 col-xl-12">
                    <div class="section-header mb-4">
                        <h2 class="section-header__title">Why Choose Our Platform</h2>
                        <p>Emush is a crypto education platform in the area of life long learning  Economy foundation emush aims to create blockchain based network</p>
                    </div>
                    <h2 class="section-header__title">Secured Emush Platforms.</h2>
                    
                    <p>Emush is a platform Powered by the only secure and reliable blockchain System</p>
                    
                </div>
                <!--<div class="col-lg-7 col-xl-7">-->
                <!--    <div class="row gy-4 gy-md-5 gy-lg-4 gy-xl-5">-->
                <!--        <div class="col-lg-6 col-sm-6">-->
                <!--            <div class="why-item">-->
                <!--                <div class="why-item__thumb">-->
                <!--                    <i class="las la-shield-alt"></i>-->
                <!--                </div>-->
                <!--                <div class="why-item__content">-->
                <!--                    <h4 class="title">Secure Casino Games</h4>-->
                <!--                    <p>Games available in most casinos are commonly called casino games. In a casino game. you will found options.</p>-->
                <!--                </div>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--        <div class="col-lg-6 col-sm-6">-->
                <!--            <div class="why-item">-->
                <!--                <div class="why-item__thumb">-->
                <!--                    <i class="las la-dice-six"></i>-->
                <!--                </div>-->
                <!--                <div class="why-item__content">-->
                <!--                    <h4 class="title">Awesome Game State</h4>-->
                <!--                    <p>Games available in most casinos are commonly called casino games. In a casino game. you will found options.</p>-->
                <!--                </div>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--        <div class="col-lg-6 col-sm-6">-->
                <!--            <div class="why-item">-->
                <!--                <div class="why-item__thumb">-->
                <!--                    <i class="las la-trophy"></i>-->
                <!--                </div>-->
                <!--                <div class="why-item__content">-->
                <!--                    <h4 class="title">Higher Wining Chance</h4>-->
                <!--                    <p>Games available in most casinos are commonly called casino games. In a casino game. you will found options.</p>-->
                <!--                </div>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--        <div class="col-lg-6 col-sm-6">-->
                <!--            <div class="why-item">-->
                <!--                <div class="why-item__thumb">-->
                <!--                    <i class="las la-coins"></i>-->
                <!--                </div>-->
                <!--                <div class="why-item__content">-->
                <!--                    <h4 class="title">Invest Win And Earn</h4>-->
                <!--                    <p>Games available in most casinos are commonly called casino games. In a casino game. you will found options.</p>-->
                <!--                </div>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
            </div>
        </div>
        <div class="shapes">
        <!--    <img src="<?php echo base_url();?>css/assets/images/why/shape.png" alt="why" class="shape shape1">-->
        <!--</div>-->
    </section>
    <!-- Why Choose Us Section Ends Here -->


    <!-- How Section Starts Here -->
    <!--<section class="how-section padding-top padding-bottom bg_img" style="background: url(<?php echo base_url();?>css/assets/images/how/bg2.jpg);">-->
    <!--    <div class="container">-->
    <!--        <div class="row justify-content-center">-->
    <!--            <div class="col-lg-6">-->
    <!--                <div class="section-header text-center">-->
    <!--                    <h2 class="section-header__title">How to Play Game</h2>-->
    <!--                    <p>A casino is a facility for certain types of gambling. Casinos are often built combined with hotels, resorts.</p>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--        <div class="row gy-4 justify-content-center">-->
    <!--            <div class="col-sm-6 col-md-4 col-lg-4">-->
    <!--                <div class="how-item">-->
    <!--                    <div class="how-item__thumb">-->
    <!--                        <i class="las la-user-plus"></i>-->
    <!--                        <div class="badge badge--lg badge--round radius-50">01</div>-->
    <!--                    </div>-->
    <!--                    <div class="how-item__content">-->
    <!--                        <h4 class="title">Sign Up First & Login</h4>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-sm-6 col-md-4 col-lg-4">-->
    <!--                <div class="how-item">-->
    <!--                    <div class="how-item__thumb">-->
    <!--                        <i class="las la-id-card"></i>-->
    <!--                        <div class="badge badge--lg badge--round radius-50">02</div>-->
    <!--                    </div>-->
    <!--                    <div class="how-item__content">-->
    <!--                        <h4 class="title">Complete you Profile</h4>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-sm-6 col-md-4 col-lg-4">-->
    <!--                <div class="how-item">-->
    <!--                    <div class="how-item__thumb">-->
    <!--                        <i class="las la-dice"></i>-->
    <!--                        <div class="badge badge--lg badge--round radius-50">03</div>-->
    <!--                    </div>-->
    <!--                    <div class="how-item__content">-->
    <!--                        <h4 class="title">Choose a Game & Play</h4>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</section>-->
    <!-- How Section Ends Here -->


    <!-- Faq Section Starts Here -->
    <!--<section class="faq-section padding-top padding-bottom overflow-hidden">-->
    <!--    <div class="container">-->
    <!--        <div class="row justify-content-center">-->
    <!--            <div class="col-lg-7 col-xl-6">-->
    <!--                <div class="section-header text-center">-->
    <!--                    <h2 class="section-header__title">Frequently Asked Questions</h2>-->
    <!--                    <p>A casino is a facility for certain types of gambling. Casinos are often built combined with hotels, resorts.</p>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--        <div class="faq-wrapper row justify-content-between">-->
    <!--            <div class="col-lg-6">-->
    <!--                <div class="faq-item">-->
    <!--                    <div class="faq-item__title">-->
    <!--                        <h5 class="title">01. How do I create Casine Account ?</h5>-->
    <!--                    </div>-->
    <!--                    <div class="faq-item__content">-->
    <!--                        <p>Autem ut suscipit, quibusdam officia, perferendis odio neque eius similique quae ipsum dolor voluptas sequi recusandae dolorem assumenda asperiores deleniti numquam iste fugit eligendi voluptates aliquam voluptate. Quas, magni excepturi ab, dolore explicabo  .</p>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--                <div class="faq-item">-->
    <!--                    <div class="faq-item__title">-->
    <!--                        <h5 class="title">01. How do I create Casine Account ?</h5>-->
    <!--                    </div>-->
    <!--                    <div class="faq-item__content">-->
    <!--                        <p>Autem ut suscipit, quibusdam officia, perferendis odio neque eius similique quae ipsum dolor voluptas sequi recusandae dolorem assumenda asperiores deleniti numquam iste fugit eligendi voluptates aliquam voluptate. Quas, magni excepturi ab, dolore explicabo  .</p>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--                <div class="faq-item">-->
    <!--                    <div class="faq-item__title">-->
    <!--                        <h5 class="title">01. How do I create Casine Account ?</h5>-->
    <!--                    </div>-->
    <!--                    <div class="faq-item__content">-->
    <!--                        <p>Autem ut suscipit, quibusdam officia, perferendis odio neque eius similique quae ipsum dolor voluptas sequi recusandae dolorem assumenda asperiores deleniti numquam iste fugit eligendi voluptates aliquam voluptate. Quas, magni excepturi ab, dolore explicabo  .</p>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--                <div class="faq-item mb-2 mb-lg-0">-->
    <!--                    <div class="faq-item__title">-->
    <!--                        <h5 class="title">01. How do I create Casine Account ?</h5>-->
    <!--                    </div>-->
    <!--                    <div class="faq-item__content">-->
    <!--                        <p>Autem ut suscipit, quibusdam officia, perferendis odio neque eius similique quae ipsum dolor voluptas sequi recusandae dolorem assumenda asperiores deleniti numquam iste fugit eligendi voluptates aliquam voluptate. Quas, magni excepturi ab, dolore explicabo  .</p>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-lg-6">-->
    <!--                <div class="faq-item">-->
    <!--                    <div class="faq-item__title">-->
    <!--                        <h5 class="title">01. How do I create Casine Account ?</h5>-->
    <!--                    </div>-->
    <!--                    <div class="faq-item__content">-->
    <!--                        <p>Autem ut suscipit, quibusdam officia, perferendis odio neque eius similique quae ipsum dolor voluptas sequi recusandae dolorem assumenda asperiores deleniti numquam iste fugit eligendi voluptates aliquam voluptate. Quas, magni excepturi ab, dolore explicabo  .</p>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--                <div class="faq-item">-->
    <!--                    <div class="faq-item__title">-->
    <!--                        <h5 class="title">01. How do I create Casine Account ?</h5>-->
    <!--                    </div>-->
    <!--                    <div class="faq-item__content">-->
    <!--                        <p>Autem ut suscipit, quibusdam officia, perferendis odio neque eius similique quae ipsum dolor voluptas sequi recusandae dolorem assumenda asperiores deleniti numquam iste fugit eligendi voluptates aliquam voluptate. Quas, magni excepturi ab, dolore explicabo  .</p>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--                <div class="faq-item">-->
    <!--                    <div class="faq-item__title">-->
    <!--                        <h5 class="title">01. How do I create Casine Account ?</h5>-->
    <!--                    </div>-->
    <!--                    <div class="faq-item__content">-->
    <!--                        <p>Autem ut suscipit, quibusdam officia, perferendis odio neque eius similique quae ipsum dolor voluptas sequi recusandae dolorem assumenda asperiores deleniti numquam iste fugit eligendi voluptates aliquam voluptate. Quas, magni excepturi ab, dolore explicabo  .</p>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--                <div class="faq-item">-->
    <!--                    <div class="faq-item__title">-->
    <!--                        <h5 class="title">01. How do I create Casine Account ?</h5>-->
    <!--                    </div>-->
    <!--                    <div class="faq-item__content">-->
    <!--                        <p>Autem ut suscipit, quibusdam officia, perferendis odio neque eius similique quae ipsum dolor voluptas sequi recusandae dolorem assumenda asperiores deleniti numquam iste fugit eligendi voluptates aliquam voluptate. Quas, magni excepturi ab, dolore explicabo  .</p>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--    <div class="shapes">-->
    <!--        <img src="<?php echo base_url();?>css/assets/images/faq/shape.png" alt="faq" class="shape shape1">-->
    <!--    </div>-->
    <!--</section>-->
    <!-- Faq Section Ends Here -->


    <!-- Top Investor & Winner Section Starts Here -->
    <!--<section class="top-section padding-top padding-bottom bg_img" style="background:url(<?php// echo base_url();?>css/assets/images/top/bg.png) center">-->
    <!--    <div class="container">-->
    <!--        <div class="row align-items-center gy-5">-->
    <!--            <div class="col-lg-4">-->
    <!--                <h3 class="part-title mb-4">Latest Winner</h3>-->
    <!--                <div class="top-investor-slider">-->
    <!--                    <div class="investor-item">-->
    <!--                        <div class="investor-item__thumb">-->
    <!--                            <img src="<?php echo base_url();?>css/assets/images/top/item1.png" alt="top">-->
    <!--                            <p class="amount">$150</p>-->
    <!--                        </div>-->
    <!--                        <div class="investor-item__content">-->
    <!--                            <h6 class="name">Munna Ahmed</h6>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                    <div class="investor-item">-->
    <!--                        <div class="investor-item__thumb">-->
    <!--                            <img src="<?php echo base_url();?>css/assets/images/top/item2.png" alt="top">-->
    <!--                            <p class="amount">$270</p>-->
    <!--                        </div>-->
    <!--                        <div class="investor-item__content">-->
    <!--                            <h6 class="name">Fahad Bin</h6>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                    <div class="investor-item">-->
    <!--                        <div class="investor-item__thumb">-->
    <!--                            <img src="<?php echo base_url();?>css/assets/images/top/item3.png" alt="top">-->
    <!--                            <p class="amount">$52000</p>-->
    <!--                        </div>-->
    <!--                        <div class="investor-item__content">-->
    <!--                            <h6 class="name">Rafuj Raiha</h6>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                    <div class="investor-item">-->
    <!--                        <div class="investor-item__thumb">-->
    <!--                            <img src="<?php echo base_url();?>css/assets/images/top/item1.png" alt="top">-->
    <!--                            <p class="amount">$150</p>-->
    <!--                        </div>-->
    <!--                        <div class="investor-item__content">-->
    <!--                            <h6 class="name">Munna Ahmed</h6>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                    <div class="investor-item">-->
    <!--                        <div class="investor-item__thumb">-->
    <!--                            <img src="<?php echo base_url();?>css/assets/images/top/item3.png" alt="top">-->
    <!--                            <p class="amount">$50</p>-->
    <!--                        </div>-->
    <!--                        <div class="investor-item__content">-->
    <!--                            <h6 class="name">Rafuj Raihan</h6>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->
                <!--<div class="col-lg-4">-->
                <!--    <div class="cla-wrapper text-center">-->
                <!--        <h3 class="title mb-4">WIN !!! & <br> Get million dollars</h3>-->
                <!--        <a href="#0" class="cmn--btn active btn--md radius-0">Play Now</a>-->
                <!--        <div class="thumb">-->
                <!--            <img src="<?php echo base_url();?>css/assets/images/top/bg2.png" alt="top">-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <!--<div class="col-lg-4">-->
                <!--    <h3 class="part-title mb-4">Top Investor</h3>-->
                <!--    <div class="top-investor-slider">-->
                <!--        <div class="investor-item">-->
                <!--            <div class="investor-item__thumb">-->
                <!--                <img src="<?php echo base_url();?>css/assets/images/top/item1.png" alt="top">-->
                <!--                <p class="amount">$150</p>-->
                <!--            </div>-->
                <!--            <div class="investor-item__content">-->
                <!--                <h6 class="name">Munna Ahmed</h6>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--        <div class="investor-item">-->
                <!--            <div class="investor-item__thumb">-->
                <!--                <img src="<?php echo base_url();?>css/assets/images/top/item2.png" alt="top">-->
                <!--                <p class="amount">$270</p>-->
                <!--            </div>-->
                <!--            <div class="investor-item__content">-->
                <!--                <h6 class="name">Fahad Bin</h6>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--        <div class="investor-item">-->
                <!--            <div class="investor-item__thumb">-->
                <!--                <img src="<?php echo base_url();?>css/assets/images/top/item3.png" alt="top">-->
                <!--                <p class="amount">$52000</p>-->
                <!--            </div>-->
                <!--            <div class="investor-item__content">-->
                <!--                <h6 class="name">Rafuj Raiha</h6>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--        <div class="investor-item">-->
                <!--            <div class="investor-item__thumb">-->
                <!--                <img src="<?php echo base_url();?>css/assets/images/top/item1.png" alt="top">-->
                <!--                <p class="amount">$150</p>-->
                <!--            </div>-->
                <!--            <div class="investor-item__content">-->
                <!--                <h6 class="name">Munna Ahmed</h6>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--        <div class="investor-item">-->
                <!--            <div class="investor-item__thumb">-->
                <!--                <img src="<?php echo base_url();?>css/assets/images/top/item3.png" alt="top">-->
                <!--                <p class="amount">$50</p>-->
                <!--            </div>-->
                <!--            <div class="investor-item__content">-->
                <!--                <h6 class="name">Rafuj Raihan</h6>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</section>-->
    <!-- Top Investor & Winner Section Ends Here -->


    <!-- Testimonial Section Starts Here -->

    <!-- Testimonial Section Ends Here -->


    <!-- Footer Section Starts Here -->
<footer class="footer-section bg_img">
    <div class="footer-top">
        <div class="container">
            <div class="footer-wrapper d-flex flex-wrap align-items-center justify-content-md-between justify-content-center">
                <div class="logo mb-3 mb-md-0"><a href="index.html"><img src="<?php echo base_url();?>css/assets/images/logos.png" alt="logo"></a></div>
                <ul class="footer-links d-flex flex-wrap justify-content-center">
                  <li><a href="#"> <p><b>Support Mail</b>:support@emush.net</p></a></li>
                    <!--<li><a href="terms-conditions.html">Terms & Conditions</a></li>-->
                    <!--<li><a href="policy.html">Privacy Policy</a></li>-->
                </ul>
            </div>
        </div>
    </div>
 
  
  
   <div class="footer-bottom">
   <div class="container">
    <div class="footer-wrapper d-flex flex-wrap justify-content-center align-items-center text-center">
        <p class="copyright text-white"> © 2023 Emush.net All Rights Reserved.</p>
      <p> </p>
     
          </div>
      </div>
    </div>

</footer>
<!-- Footer Section Ends Here -->
    

<!-- jQuery library -->
<script src="<?php echo base_url();?>css/assets/js/lib/jquery-3.6.0.min.js"></script>
<!-- bootstrap 5 js -->
<script src="<?php echo base_url();?>css/assets/js/lib/bootstrap.min.js"></script>

<!-- Pluglin Link -->
<script src="<?php echo base_url();?>css/assets/js/lib/slick.min.js"></script>

<!-- main js -->
<script src="<?php echo base_url();?>css/assets/js/main.js"></script>  

</body>

<!-- Mirrored from template.viserlab.com/casinous/demo/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 14 Dec 2022 15:27:34 GMT -->
</html>