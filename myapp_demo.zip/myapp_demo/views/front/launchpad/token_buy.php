<?php $sitelan = $this->session->userdata('site_lang');
       $this->load->view('front/common/inner_header');
      $user_id=$this->session->userdata('user_id');
      $name = $sitelan."_name";
      $heading = $sitelan."_heading";
      $content = $sitelan."_content";
?>


    <div class="launch-sec-t">
        <div class="space"></div>
            <div class="space"></div>
        <?php
            /*$url = file_get_contents("https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=".$launchpad_detail->token_coin_fullname);
            $responseData = json_decode($url);*/
            $api_key = getSiteSettings('cryptocompare_apikey');
             $url = "https://min-api.cryptocompare.com/data/price?fsym=ETH&tsyms=USD&api_key=".$api_key;
              $chs = curl_init();
            curl_setopt($chs, CURLOPT_URL, $url);
            curl_setopt($chs, CURLOPT_RETURNTRANSFER, 1);
            $result1 = curl_exec($chs);
            $responseData = json_decode($result1);
            $usd_rate = $responseData->USD;
            $single_token_value = $launchpad_detail->single_token_value;
            $token_usd_rate = $usd_rate * $single_token_value;
        ?>
        
                                  <?php
                                            
                                            if(!empty(trim($launchpad_detail->token_logo)))
                                            {
                                                $img_url = $launchpad_detail->token_logo;
                                        ?>
                                                <style type="text/css">
                                                    .token-img {
                                                        width: 64px;
                                                         height: 64px;
                                                       }
                                                </style>
                                        <?php
                                            }
                                            else
                                            {
                                              $img_url = front_img()."progress-img.svg";
                                            }
                                        ?>


<section>
        <div class="container">
            <div class="row align-items-center" style="background: #fff;margin-right: -20px;margin-left: -20px;">
                <div class="col-lg-6">
                    <div class="launchpad-plate" style="margin-bottom: -60px;">
                        <img src="https://ixtoken.io/assets/front/img/IEO-background.png" class="img-fluid"><span> Listing confirmed</span><div class="token-img"> <img src="<?=$img_url?>"></div>
                    </div>
                </div>
                <div class="col-lg-6" >
                    <div class="launchpad-plate">
                         <div class="la-trmx-vrnce" ><?= $launchpad_detail->token_coin_fullname .'&nbsp'. '('.$launchpad_detail->token_coin_symbol. ')' ?></div>
                        <div class="la-text-trx"> <?=$launchpad_detail->description_token_coin?></div><div class="la-text-trxt">
              <div class="la-trmx-cc">
              
              
              
              <?php
                                            $attributes=array('id'=>'buy_tokenss',"autocomplete"=>"off",'name'=>"buy_tokenss");
                                            echo form_open_multipart($action,$attributes);
                                        ?>
                          <?php  ?>
                          
                          
                                          <select class="custom-select my-1 mr-sm-2 w-400" name="received_currency" id="received_currency" style="
    border-color: #bcbcbc;width: 100%;border-radius: 0;">
                                         <?php
                                            foreach($currency_list as $currency)
                                            {
                                        ?>
                                                <option value="<?php echo $currency->currency_symbol;?>" data-id="<?php echo $currency->id.'#'.$currency->type;?>" data-symbol="<?php echo $currency->currency_symbol;?>">
                                                        <?php echo $currency->currency_symbol;?>
                                                </option>
                                        <?php
                                            }
                                        ?>
                                        </select></div></div>
										
									   <div class="la-trmx-cc">
                                        <div class="ieo-pay-am">
                                        <div class="ieo-pay-am1">Amount</div>
                                        <div class="ieo-pay-am11"></div>
                                        <input type="text" placeholder="0" name="token_amount" id="token_amount" placeholder="0" class="ieo-pay-am2"> <!----><!---->
                                        <div class="ieo-pay-am3 "><?=$launchpad_detail->token_coin_symbol?></div></div>
                                        </div>



       <div class="la-trmx-cc">
         <div class="get-token-ieo">
         <div class="get-you">Spent</div>
         <div class="ieo-pay-am111"></div>
        <span id="launchValcalc"> 0.00</span> <!----><!---->
         <div id="token_amount"><span id="spent_currency">BTC</span></div></div></div>
                            <div class="ieo-purchase-btn" style=""><!----><!----><input type="hidden" name="currency_value" id="currency_value">
                            <input type="submit" name="buytokennn" class="btn progress-box-btn mx-auto" value="<?php echo $this->lang->line('Submit')?>" />
                            <?php echo form_close();?>
                            <!----></div>
							
                    <div class="valueInfoWrap"><!---->
                            <p class="est-value-ieo">Price for 1 <?=$launchpad_detail->token_coin_symbol?><!----><span id="valuettx"><?=number_format($token_usd_rate,2)?> USD</span></p>
                            <!----><!----> </div>
                            
                            

							
										
					</div>
                </div>
            </div>
        </div>
    </section>




      <div class="launchpad-ixtoken-buy-main">

        <h3 style="border-bottom: 1px solid #ededed;text-align: center;">Notice For Participants</h3>
         <ul>
            <li><span>Sale and purchase of <?= $launchpad_detail->token_coin_fullname?> take place between you and <?= $launchpad_detail->token_coin_fullname?> (the Issuer) and Ixtoken is neither a seller nor a party as any capacity in the sale of <?= $launchpad_detail->token_coin_fullname?></span></li>
            <li><span>Purchase of <?= $launchpad_detail->token_coin_fullname?> is final and there will be no refunds or cancellations</span></li>
            <li><span>The Participant can participate in IEO using their available ETH, BTC, BNB, TRON crypto assets at Ixtoken.io wallet</span></li>
            <li><span>Distribution will be implemented immediately after purchase of IEO token. </span></li>
            <li><span>From participant current crypto assets (ETH,BTC,BNB,TRON) wallet will be deducted appropriate assets and IEO tokens will be immediately transferred to the participant wallet at Ixtoken.io </span></li>
            <li><span>IEO tokens will be freezed and participant will be able to trade, withdraw after 3 days of IEO expiry.</span></li>
<!----></ul>

      </div>



 <div class="launchpad-ixtoken-buy">


<h3>DETAILS</h3>

<div class="launchpad-ixtoken-table">
<div class="launchpad-ixtoken-table-ins">
<div class="table-ins-desc">Token Name</div><div class="table-ins-desc-rg"><?= $launchpad_detail->token_coin_fullname?></div><!----><!----><!----><!----></div>
<div class="launchpad-ixtoken-table-ins">
<div class="table-ins-desc">Token Symbol</div><div class="table-ins-desc-rg"><?= $launchpad_detail->token_coin_symbol?></div><!----><!----><!----><!----></div>
<div class="launchpad-ixtoken-table-ins">
<div class="table-ins-desc">Start Date</div><!----><!----><div class="table-ins-desc-rg"><?=date("d-m-Y",strtotime($launchpad_detail->start_date))?></div><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----></div>
<div class="launchpad-ixtoken-table-ins">
<div class="table-ins-desc">Expiry Date</div><!----><!----><div class="table-ins-desc-rg"><?=date("d-m-Y",strtotime($launchpad_detail->expire_date))?></div><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----></div>
<div class="launchpad-ixtoken-table-ins">
<div class="table-ins-desc">Price</div><!----><!----><!----><!----><!----><!----><div class="table-ins-desc-rg">1 <?=$launchpad_detail->token_coin_symbol?> = <?=number_format($token_usd_rate,2)?> USD</div><!----><!----><!----><!----><!----><!----></div>
<div class="launchpad-ixtoken-table-ins">
<div class="table-ins-desc">Token Type</div><div class="table-ins-desc-rg">ERC-20</div><!----><!----><!----><!----></div>
<div class="launchpad-ixtoken-table-ins">
<div class="table-ins-desc">Softcap $</div><div class="table-ins-desc-rg"><?=$launchpad_detail->soft_cap?></div><!----><!----><!----><!----></div>
<div class="launchpad-ixtoken-table-ins">
<div class="table-ins-desc">Hardcap $</div><div class="table-ins-desc-rg"><?=$launchpad_detail->hard_cap?></div><!----><!----><!----><!----></div>
<div class="launchpad-ixtoken-table-ins">
<div class="table-ins-desc">Website</div><!----><div class="table-ins-desc-rg"><a rel="noopener noreferrer" target="_blank" class="ng" href="<?=$launchpad_detail->official_website?>"><?=$launchpad_detail->official_website?></a><!----></div><!----><!----><!----></div>
<div class="launchpad-ixtoken-table-ins">
<div class="table-ins-desc"><i class="fas fa-globe"></i>&nbsp;Whitepaper</div><!----><div class="table-ins-desc-rg"><a rel="noopener noreferrer" target="_blank" class="ng" href="<?=$launchpad_detail->whitepaper_link?>"> English </a><!----></div><!----><!----><!----></div>
<div class="launchpad-ixtoken-table-ins">
<div class="table-ins-desc">Session Supply</div><div class="table-ins-desc-rg"><?=$launchpad_detail->token_sale?></div><!----><!----><!----><!----></div>
<div class="launchpad-ixtoken-table-ins">
<div class="table-ins-desc">Total Supply</div><div class="table-ins-desc-rg"><?= $launchpad_detail->total_token_supply?></div><!----><!----><!----><!----></div>
<div class="launchpad-ixtoken-table-ins">
<div class="table-ins-desc">IEO Period</div><div class="table-ins-desc-rg"> <?php $diff =date_diff(date_create($launchpad_detail->start_date),date_create($launchpad_detail->expire_date)); echo $diff->format("%R%a Days");?></div><!----><!----><!----><!----></div>
<div class="launchpad-ixtoken-table-ins">
<div class="table-ins-desc">Social Links</div><div class="table-ins-desc-rg">

                   
                           <div class="launch_social_link">
                              <ul style="display: flex;padding-inline-start: 0px;padding: 0px;margin: 0;margin-top: -10px;">
                                    <?php
                                        if(!empty(trim($launchpad_detail->fb_link)))
                                        {
                                    ?>
                                 <li>
                                  <a href="<?=$launchpad_detail->fb_link?>"><img src="https://ixtoken.io/assets/front/img/facebook-circle.svg" alt="" class="img-fluid"></a>
                                    </li>
                                     <?php
                                        }
                                        if(!empty(trim($launchpad_detail->linkedin_link)))
                                        {
                                    ?>
                         <li>
                            <a href="<?=$launchpad_detail->linkedin_link?>"><img src="https://ixtoken.io/assets/front/img/linkedin-circle.svg" alt="" class="img-fluid"></a>
                                    </li>
                                     <?php
                                        }
                                        if(!empty(trim($launchpad_detail->telegram_link)))
                                        {
                                    ?>
                                    <li>
                                        <a href="<?=$launchpad_detail->telegram_link?>"><img src="https://ixtoken.io/assets/front/img/telegram-circle.svg" alt="" class="img-fluid"></a>
                                    </li>
                                     <?php
                                        }
                                        if(!empty(trim($launchpad_detail->twitter_link)))
                                        {
                                    ?>
                                    <li>
                                        <a href="<?=$launchpad_detail->twitter_link?>"><img src="https://ixtoken.io/assets/front/img/twitter-circle.svg" alt="" class="img-fluid"></a>
                                    </li>
                                     <?php
                                        }
                                        if(!empty(trim($launchpad_detail->youtube_link)))
                                        {
                                    ?>
                                    <li>
                                        <a href="<?=$launchpad_detail->youtube_link?>"><img src="https://ixtoken.io/assets/front/img/youtube.svg" alt="" class="img-fluid"></a>
                                    </li>
                                     <?php
                                        }
                                        if(!empty(trim($launchpad_detail->medium_link)))
                                        {
                                    ?>
                                    <li>
                                        <a href="<?=$launchpad_detail->medium_link?>"><img src="https://ixtoken.io/assets/front/img/medium.svg" alt="" class="img-fluid"></a>
                                    </li>
                                     <?php
                                        }
                                        if(!empty(trim($launchpad_detail->reddit_link)))
                                        {
                                    ?>
                                    <li>
                                        <a href="<?=$launchpad_detail->reddit_link?>"><img src="https://ixtoken.io/assets/front/img/reddit.svg" alt="" class="img-fluid"></a>
                                    </li>
                                     <?php
                                        }
                                        if(!empty(trim($launchpad_detail->github_link)))
                                        {
                                    ?>
                                    <li>
                                        <a href="<?=$launchpad_detail->github_link?>"><img src="https://ixtoken.io/assets/front/img/github.svg" alt="" class="img-fluid"></a>
                                    </li>
                                     <?php
                                        }
                                    ?>
                                </ul>
                            </div>

                            </div>

</div><!----><!----><!----><!----></div> 
       
      </div>

      <div class="launchpad-ixtoken-text">

        <h3>History</h3>
        <div class="launchpad-ixtoken-text-t"> <?= $launchpad_detail->history_project ?></div>
        <h3>Roadmap</h3>
        <div class="launchpad-ixtoken-text-t"> <?=$launchpad_detail->detail_roadmap_milestone?></div>
        <h3>Vision</h3>
        <div class="launchpad-ixtoken-text-t"> <?=$launchpad_detail->long_term_vision_project ?></div>
</div></div></div></div>

            <!--   <div class="row justify-content-center">
                    <div class="col-lg-4">
                        <div class="progress-box mobile-mar-b-15 text-center">
                            <span class="progress-label">In progress</span>
                            <div class="space"></div>
                            <div class="spaceTwenty"></div>
                            <div class="text-center">
                                <!-- <img src="img/progress-img.svg" class="img-fluid"> -->
                              </div>
                       <!--     <div class="spaceTwenty"></div>
                          <!--  <h3 class="text-center"><?= $launchpad_detail->token_coin_fullname .'&nbsp'. '('.$launchpad_detail->token_coin_symbol. ')' ?></h3>
                            <div class="spaceTwenty"></div>
                           <!--  <h5 class="text-center">Stake BNB, Earn ALPHA</h5> -->
                           <!--   <div class="spaceTwenty"></div>
                                 
                                  <div class="spaceTwenty"></div>
                                     <div class="form-group col-md-12">
                                        <label for="inputPassword4">Select Coin</label>
                                          <select class="custom-select my-1 mr-sm-2 w-400" name="received_currency" id="received_currency">
                                         <?php
                                            foreach($currency_list as $currency)
                                            {
                                        ?>
                                                <option value="<?php echo $currency->currency_symbol;?>" data-id="<?php echo $currency->id.'#'.$currency->type;?>" data-symbol="<?php echo $currency->currency_symbol;?>">
                                                        <?php echo $currency->currency_symbol;?>
                                                </option>
                                        <?php
                                            }
                                        ?>
                                        </select>
                                    </div>
                            <input type="text" class="form-control" placeholder="Enter token" name="token_amount" id="token_amount" >
                            <div class="spaceTwenty"></div>
                             <p class="text-center">Amount to Spent : <span id="launchValcalc"> 0.0000</span> <span id="spent_currency">BTC</span></p>
                             <div class="spaceTwenty"></div>
                             <input type="hidden" name="currency_value" id="currency_value">
                             <input type="submit" name="buytokennn" class="btn progress-box-btn mx-auto" value="<?php echo $this->lang->line('Submit')?>" />
                              <?php echo form_close();?>
                        </div>
                    </div>
                </div>
                <div class="spaceTwenty"></div>
            </div>   
        </section>
    </div> -->
    </div>
    
    
  <?php $this->load->view('front/common/footer'); ?>
 <?php $this->load->view('front/common/scripts'); ?>
  <script type="text/javascript">
      $('#buy_tokenss').validate({
      rules: {
        token_amount: {
          required: true,
          number: true,
        }
      },
      messages: {
        token_amount: {
          required: "Please Token Amount",
          number: "Only enter numbers as decimal or float"
        }
      },
    });
    $("#received_currency").change(function(){
        var from_currency = $("#received_currency").val();
        var token_amount = $("#token_amount").val();
        var launch_id = "<?php echo $launchpad_detail->launch_id; ?>";
        console.log($('#buy_tokenss').serialize());
        // return false;
         $.ajax({
            url: "<?php echo front_url(); ?>launch_currency",
            type: "POST",
            // data: $('#buy_tokenss').serialize() + "&launch_id=" + launch_id,
            data: {"from_currency":from_currency,"launch_id":launch_id,"token_amount":token_amount},
            beforeSend:function(data){
              $("#launchValcalc").html('<img height="1" width="1" src="<?php echo base_url(); ?>assets/front/img/loading.gif">');
              $("#spent_currency").html('');
            },
            success: function (data) {
                // alert(data);
                //console.log(data);
              
              $("#launchValcalc").html(data);
              $("#currency_value").val(data);
              $("#spent_currency").html(from_currency);
                // $("#depositModal").modal('show');
                     },
        });
    })
    $("#token_amount").keyup(function(){
        var from_currency = $("#received_currency").val();
        var token_amount = $("#token_amount").val();
        var launch_id = "<?php echo $launchpad_detail->launch_id; ?>";
         $.ajax({
            url: "<?php echo front_url(); ?>launch_currency",
            type: "POST",
            // data: $('#buy_tokenss').serialize() + "&launch_id=" + launch_id,
            data: {"from_currency":from_currency,"launch_id":launch_id,"token_amount":token_amount},
            beforeSend:function(data){
              $("#launchValcalc").html('<img height="1" width="1" src="<?php echo base_url(); ?>assets/front/img/loading.gif">');
              $("#spent_currency").html('');
            },
            success: function (data) {
                // alert(data);
                // console.log(data);
              $("#launchValcalc").html(data);
              $("#currency_value").val(data);
              $("#spent_currency").html(from_currency);
            },
        });
    })
  </script>
</body>
</html>