<div class="sidebar">
    <div class="menu">
      <ul>
        <li><a href="<?php echo base_url();?>profile" data-toggle="tooltip" data-placement="right" title="<?=$this->lang->line('Profile');?>"> <span><i class="icofont-user"></i></span> </a> </li>
        <li><a href="<?php echo base_url();?>wallet" data-toggle="tooltip" data-placement="right" title="<?=$this->lang->line('Wallet');?>"> <span><i class="icofont-wallet"></i></span> </a> </li>
        <li><a href="<?php echo base_url();?>trade" data-toggle="tooltip" data-placement="right" title="<?=$this->lang->line('Exchange Tab');?>"> <span><i class="icofont-exchange"></i></span> </a> </li>
        <li><a href="<?php echo base_url();?>settings_profile" data-toggle="tooltip" data-placement="right" title="<?=$this->lang->line('Profile Settings Tab');?>"> <span><i class="icofont-settings"></i></span> </a> </li>
        <li> <a href="<?php echo base_url();?>crypto_address" data-toggle="tooltip" data-placement="right" title="<?=$this->lang->line('Address Book');?>"> <span><i class="icofont-address-book"></i></span> </a> </li>

        <!-- <li> <a href="<?php echo base_url();?>settings" data-toggle="tooltip" data-placement="right" title="<?=$this->lang->line('KYC');?>"> <span><i class="icofont-attachment"></i></span> </a> </li>
        <li> <a href="<?php echo base_url();?>settings/account-change-password" data-toggle="tooltip" data-placement="right" title="<?=$this->lang->line('Change Password');?>"> <span><i class="icofont-ui-password"></i></span> </a> </li> -->
        
        <!-- <li class="logout"><a href="<?php echo base_url();?>logout" data-toggle="tooltip" data-placement="right" title="<?=$this->lang->line('Logout');?>"> <span><i class="icofont-power"></i></span> </a> </li> -->
      </ul>
      <!-- <p class="copyright"> &#169;<br/>
        <a href="<?php echo base_url();?>">Share Coin exchange</a> </p> -->
    </div>
  </div>