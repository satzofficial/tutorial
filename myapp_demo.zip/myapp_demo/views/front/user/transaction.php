<?php $this->load->view('front/common/header_in');
      $settings = $site_common['site_settings']; ?>
    <div class="wrapper">
        <nav id="sidebar">
            <div class="sidebar-header">
                 <a href="<?=base_url('home')?>"><img src="<?=$settings->site_logo?>" alt="logo" class="img-fluid"></a>
            </div>
            <div class="user_profile">
                <?php $img =  ($users->profile_picture)?$users->profile_picture:base_url().'assets/front/inner/img/user_img.svg';?>
                <span><img src="<?=$img?>" width="85px" alt="user_img" class="img-fluid"></span>
                <h5><?php echo ($users->ixtoken_username)?$users->ixtoken_username:'';?></h5>
            </div>
             <?php $this->load->view('front/common/sidebar'); ?>
        </nav>
        <div id="content">
            <header>
                <div class="row">
                    <div class="col-sm-8">
                        <div class="header_left">
                            <button type="button" id="sidebarCollapse" class="toggle_btn"><i
                                    class="fa fa-bars"></i></button>
                            <h4><?php echo $this->lang->line('Transactions')?></h4>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="header_right">
                            <ul>
                                <?php $this->load->view('front/common/top_navigation'); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </header>

            <div class="row">
                <div class="col-md-12">
                    <div class="tab_inner">
                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="tab" href="#Deposit"><?php echo $this->lang->line('Deposit')?></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#Withdraw"><?php echo $this->lang->line('Withdraw')?></a>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div id="Deposit" class="tab-pane active">
                                <div class="block p-3 mb-3">
                                    <h5 class="block_title mb-3"><?php echo $this->lang->line('Deposit')?></h5>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="deposit_right mb-2">
                                                <div class="mb-2">
                                                    <label class="label_inner"><?php echo $this->lang->line('Select Your Currency')?> :</label>
                                                    <select id="crypto_curr" onChange="change_address()" class="custom-select select_inner">
                                                        <?php if(count($all_currency)>0) { foreach($all_currency as $currency){ ?>
                                            <option value="<?php echo $currency->id;?>"><?php echo $currency->currency_name;?> (<?php echo strtolower($currency->currency_symbol);?>)</option>
                                            <?php } } ?>
                                                    </select>
                                                </div>
                                                <div class="your_balance">
                                                    <ul>
                                                        <li><?php echo $this->lang->line('Total Balance')?>: <span id="tot_balance"></span></li>
                                                        <!-- <li>In Order: <span>0.005400 CRC</span></li> 
                                                        <li>Available Balance: <span>0.005400 CRC</span></li>-->
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="deposit_left mb-2">
                                                <h5><?php echo $this->lang->line('Scan QR Code')?></h5>
                                                <div class="deposit_left_inner d-flex align-items-center">
                                                    <span>
                                                        <img src="<?=base_url();?>assets/front/inner/img/qr_code.svg" alt="qr_code" width="125px;" id="crypto_img" class="img-fluid">
                                                    </span>
                                                    <div class="qr_code_right">
                                                        <b><?php echo $this->lang->line('OR send funds to the below Address')?></b>
                                                        <label><?php echo $this->lang->line('Address')?> :</label>
                                                        <span id="crypto_address">763XJN2ISYQIGPSX763XJN2ISY</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <ul class="note">
                                                <span><?php echo $this->lang->line('Note')?> :</span>
                                                <li><?php echo $this->lang->line('Coins will be deposited after network confirmations')?></li>
                                                <li><?php echo $this->lang->line('After making a deposit, you can track its progress on the history page')?></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="block p-3">
                                    <h5 class="block_title mb-3"><?php echo $this->lang->line('Deposit History')?></h5>
                                    <div class="table_inner">
                                        <div class="table_responsive">
                                            <table id="deposit" class="display nowrap" style="width:100%">
                                                <thead>
                                                    <tr>
                                                        <th><?php echo $this->lang->line('S.no')?></th>
                                                        <th><?php echo $this->lang->line('Date & Time')?></th>
                                                        <th><?php echo $this->lang->line('Currency')?></th>
                                                        <th><?php echo $this->lang->line('Transaction ID')?></th>
                                                        <th><?php echo $this->lang->line('Deposit Amount')?></th>
                                                        <th><?php echo $this->lang->line('Address')?></th>
                                                        <th><?php echo $this->lang->line('Status')?></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                    <?php
                                        if(isset($deposit_history) && !empty($deposit_history))
                                        {
                                            $a=0;
                                           foreach($deposit_history as $deposit)
                                           {
                                            $a++;
                                            if($deposit->transaction_id == '')
                                            {
                                              $transaction_id = '-';
                                            }
                                            else
                                            {
                                              $transaction_id = $deposit->transaction_id;
                                            }     
                                            ?>
                                                    <tr>
                                            <td><?php echo $a;?></td>
                                            <td><?php echo date('d-m-Y h:i a',$deposit->datetime);?></td>
                                            <td><?php echo strtoupper(getcryptocurrency($deposit->currency_id));?></td>
                                            <td>#<?php echo $transaction_id;?></td>
                                            <td><?php echo number_format($deposit->amount,8);?></td>
                                            <td><?php echo $deposit->crypto_address;?></td>
                                            <?php if($deposit->status =='Completed')
                                            {
                                              $clr_class = 'text-green';

                                            }
                                            else
                                            {
                                              $clr_class = 'text-red';
                                            } ?>                   
                                             
                                            <td class="<?php echo $clr_class;?>"><?php echo $deposit->status;?></td>
                                        </tr>
                                                  <?php } } ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="Withdraw" class="tab-pane fade">
                                <div class="block p-3 mb-3">
                                    <h5 class="block_title mb-2"><?php echo $this->lang->line('Withdraw')?></h5>
                        <?php 
                        $attributes=array('id'=>'deposit_withdraw_coin');
                        $action1 = base_url().'transaction';
                        echo form_open($action1,$attributes);
                        ?>
                        <input type="hidden" name='ids' id="ids" value="">

                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="mb-3">
                                                <label class="label_inner"><?php echo $this->lang->line('Select Your Currency')?></label>
                                                <select class="custom-select select_inner" onChange="change_witaddress()" id="cryptos_curr">
                                     <?php
                                          foreach($all_currency as $currency){
                                            ?>
                                            <option value="<?php echo $currency->id;?>"><?php echo $currency->currency_name;?> (<?php echo strtolower($currency->currency_symbol);?>)</option>
                                            <?php
                                          }
                                          ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group form_inner mb-3">
                                                <label class="label_inner"><span id="withdraw_curr"></span> <?php echo $this->lang->line('Wallet Address')?></label>
                                                <input id="address" name="address" type="text" class="form-control" placeholder="<?php echo $this->lang->line('Enter Wallet Address')?>">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group form_inner mb-3">
                                                <label class="label_inner"><?php echo $this->lang->line('Amount of')?> <span id="withdraw_amt"></span> <?php echo $this->lang->line('to Wallet')?></label>
                                                <input type="text" class="form-control" id="amount" name="amount" placeholder="<?php echo $this->lang->line('Enter BTC Amount')?>">
                                            </div>
                                        </div>
                                        <div class="col-md-12">

                                            <div class="text-center mt-3 mb-4">
                                                <input type="submit" name="withdrawcoin" class="btn btn-primary" value="<?php echo $this->lang->line('Submit')?>" />
                                            </div>

                                        </div>

                                        <div class="col-md-6">
                                            <ul class="note mb-md-0 mb-2">
                                                <li><?php echo $this->lang->line('Transaction Fees')?>: <small id="withdraw_fee">0.0056</small></li>
                                                <li><?php echo $this->lang->line('You will Get')?>: <small id="withdraw_limit">0.0056 BTC</small></li>
                                            </ul>
                                        </div>
                                        <div class="col-md-6">
                                            <ul class="note">
                                                <span><?php echo $this->lang->line('Note')?> :</span>
                                                <li><?php echo $this->lang->line('Coins will be deposited after network confirmations')?></li>
                                                <li><?php echo $this->lang->line('After making a deposit, you can track its progress on the history page')?></li>
                                            </ul>
                                        </div>
                                    </div>
                                     <?php echo form_close();?>
                                </div>
                                <div class="block p-3">
                                    <h5 class="block_title mb-2"><?php echo $this->lang->line('Withdraw History')?></h5>
                                    <div class="table_inner">
                                        <div class="table_responsive">
                                            <table id="withdraw" class="display nowrap" style="width:100%">
                                                <thead>
                                                    <tr>
                                                        <th><?php echo $this->lang->line('S.no')?></th>
                                                        <th><?php echo $this->lang->line('Date & Time')?></th>
                                                        <th><?php echo $this->lang->line('Currency')?></th>
                                                        <th><?php echo $this->lang->line('Send Amount')?></th>
                                                        <th><?php echo $this->lang->line('Fees')?></th>
                                                        <th><?php echo $this->lang->line('Receive Amount')?></th>
                                                        <th><?php echo $this->lang->line('Status')?></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                     <?php
                                    if(isset($withdraw_history) && !empty($withdraw_history)){
                                    $b=0;
                                    foreach($withdraw_history as $withdraw){
                                    $b++;
                                    ?>
                                                   <tr>
                                            <td><?php echo $b;?></td>
                                            <td><?php echo date('d-M-Y H:i',$withdraw->datetime);?></td>
                                            <td><?php echo strtoupper(getcryptocurrency($withdraw->currency_id));?></td>
                                            <td><?php echo number_format($withdraw->amount,8);?></td>
                                            <td><?php echo number_format($withdraw->fee,8);?></td>
                                            <td><?php echo number_format($withdraw->transfer_amount,8);?></td>
                                             <?php 
                                              if($withdraw->status =='Completed')
                                              {
                                                $elmt_class = 'text-green';

                                              }
                                              else
                                              {
                                                $elmt_class = 'text-red';
                                              } ?> 
                                                <td class="<?php echo $elmt_class; ?>"><?php echo $withdraw->status;?></td>
                                          </tr>
                                                   <?php } } ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


           <?php $this->load->view('front/common/footer_in'); ?>
           <script>

 function change_address()
 {
   var currency_id = $("#crypto_curr option:selected").val();
    $.ajax({

                url: base_url+"change_address",
                type: "POST",
                data: "currency_id="+currency_id,
                success: function(data) {
                  var res = jQuery.parseJSON(data);
                  $('#crypto_address').html(res.address);
                  $("#crypto_img").attr("src",res.img);
                  $('#curr_name').html(res.currname);
                  $('#tot_balance').html(res.coin_balance+' '+res.coin_symbol);
                }
            });
  }

  function change_witaddress()
  {
   var currency_id = $("#cryptos_curr option:selected").val();
    $.ajax({

                url: base_url+"change_address",
                type: "POST",
                data: "currency_id="+currency_id,
                success: function(data) {
                  var res = jQuery.parseJSON(data);
                  $('#withdraw_curr').text(res.coin_symbol);
                  $('#withdraw_amount').text(res.coin_symbol);
                  $('#amount').attr("placeholder","Enter "+res.coin_symbol+" Amount");
                  $('#withdraw_fee').text(res.withdraw_fees);
                  $("#withdraw_limit").text(res.withdraw_limit+' '+res.coin_symbol);
                  
                }
            });
    $('#ids').val(currency_id);
  }


  $(document).ready(function(){
    change_address();
    change_witaddress();
   });

  var hash = window.location.hash;
  var cur_hash = hash.substr(1);
  if(cur_hash=="deposit")
  {
    $(".deposit_tab").trigger("click");
  }
  else if(cur_hash=="withdraw")
  {
    $(".withdraw_tab").trigger("click");
  }

  $(".deposit_tab").click(function(){
   var hash_char1='#deposit';
    $(location).attr('href','http://spiegeltech.site/cripyic/transaction'+hash_char1);
  });

  $(".withdraw_tab").click(function(){
   var hash_char2='#withdraw';
    $(location).attr('href','http://spiegeltech.site/cripyic/transaction'+hash_char2);
  });

</script>