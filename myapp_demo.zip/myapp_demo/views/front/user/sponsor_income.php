<?php include realpath(dirname(__DIR__) . '/common/inner_header.php'); 
$prefix = get_prefix();
$fname = $prefix.'fname';
$lname = $prefix.'lname';
?><div class="page-body">
  <div class="container-xl">
    <ol class="breadcrumb breadcrumb-arrows mb-3" aria-label="breadcrumbs">
      <li class="breadcrumb-item"><a href="#">Affiliate</a></li>
      <li class="breadcrumb-item active" aria-current="page">Sponsor Income</li>
    </ol>
    <div class="row row-cards">
      <?php 
      if($packages_arr){
        foreach ($packages_arr as $pakey => $package) {
          $package_id = ($package['id']) ? $package['id'] :'';
          $pkname = ($package['package_name']) ? $package['package_name'] :'';          
          $package_price = package_price($package_id);
          if($date_of_sposor_joing = sponsordateOfJoining2x($user_id, $package_id)){ 
           ?>
           <div class="col-sm-12">
            <div class="card shadow radius-20">
              <div class="card-body">
                <div class="row">
                  <div class="card card-md radius-20"> 

                    <!-- Premium Plan -->
                    <div class="row align-items-center top-0 align-top">
                      <div class="col-12 col-md-4 bg-light bg-blue-lt border-rgt radius-20 no-rd-rgt package-header-row">
                        <h4 class="pt-3 text-170 text-600 text-purple-d1 letter-spacing"><?php echo strtoupper($pkname); ?></h4>
                        <div class="text-secondary-d1 text-120">
                          <div class="display-5 my-3"><span class="ltr-spac-0"><?php echo ($package_price); ?></span><span class="small text-h4 pl-1">PYM</span></div>
                        </div>
                        <dl class="row">
                          <span class="row total2xcls">
                            <dt class="col-5">Total Earnings:</dt>
                            <dd class="col-7"><?php echo (totalSponsorEarning2x($user_id, $package_id)) ? number_format(totalSponsorEarning2x($user_id, $package_id),2) : 0.00; ?> PYM</dd>
                          </span>
                          <span class="row total4xcls" style="display: none;">
                            <dt class="col-5">Total Earnings:</dt>
                            <dd class="col-7"><?php echo (totalSponsorEarning4x($user_id, $package_id)) ? number_format(totalSponsorEarning4x($user_id, $package_id),2) : 0.00; ?> PYM</dd>
                          </span>
                          <dt class="col-5">Date Of Joining: </dt>
                          <dd class="col-7"><?php echo $date_of_sposor_joing; ?> UTC</dd>
                        </dl>
                        <ul class="nav nav-tabs nav-fill glob-tabs ml-2" data-bs-toggle="tabs">
                          <li class="nav-item"> <a href="#tabs-x2<?php echo $pakey; ?>" class="nav-link active two_matrix total-income-by-user-click" data-tabs="<?php echo $pakey; ?>" data-type="2" data-bs-toggle="tab">X2 <span class="badge bg-azure ml-2"><?php
                          // echo $overall = calcOverallRebirthLevel($user_id, $package_id);
                          echo $overall = 0;
                          ?></span></a> </li>
                          <li class="nav-item"> <a href="#tabs-x4<?php echo $pakey; ?>" class="nav-link total-income-by-user-click" data-bs-toggle="tab">X4 <span class="badge bg-azure ml-2"><?php
                           //echo $overall_4x = calc4xOverallRebirthLevel($user_id, $package_id); 
                          echo $overall_4x = 0;
                          ?></span></a> </li>
                           <li class="nav-item"> <a href="#tabs-x6<?php echo $pakey; ?>" data-package-no="<?php echo $pakey; ?>" class="nav-link total-income-by-user-x6-click"  data-type="6" data-bs-toggle="tab">∞2X<span class="badge bg-azure ml-2"><?php
                           // echo $overall_4x = calc4xOverallRebirthLevel($user_id, $package_id);
                           echo $overall_6x = 0;
                          ?></span></a> </li>
                        </ul>
                      </div>
                      <div class="col-12 col-md-8 text-left p-0">
                        <div class="row">
                          <div class="col-sm-12">
                            <div class="card-body p-0">
                              <div class="tab-content">


                                <div class="tab-pane active show" id="tabs-x2<?php echo $pakey; ?>">
                                  <div class="card none-card" style="height: calc(13.6rem + 10px)">
                                    <div class="card-body card-body-scrollable card-body-scrollable-shadow">

                                      <?php if($lev_arr = calcPackAchievedSponsorLevel($user_id, $package_id)){ ?>
                                        <div class="chat_container">
                                          <div class="job-box">
                                            <?php 
                                            $amount = 0;
                                            foreach ($lev_arr as $lkey => $lvalue) {
                                                // print_r($lvalue);exit;
                                                // twoPaymentPackageList($user_id, $package_id);
                                              $lkey = $lkey + 1;
                                              $id = $lvalue->id;
                                              $charts = $lvalue->chart_level;
                                              $package_id = $lvalue->package_id;
                                              $level = $lvalue->level;
                                              $amount += $lvalue->profit;
                                              $pack_activate = timestamp_UTC_conversion($lvalue->timestamp);
                                              ?>
                                              <div class="job-box-filter">
                                                <h4 class="">Achieved Lvl : <?php                                                
                                                $max_achieved = calcMaxPackAchievedSponsorLevel($user_id, $package_id, $charts);
                                                echo ($l = $max_achieved) ? $l : 0; ?></h4>
                                              </div>
                                              <div class="inbox-message">
                                                <ul>
                                                  <li class="bg-red-lt"> <a href="javascript:;" class="get_level_income"
                                                   data-level="1" 
                                                   data-list="<?php echo ($profit_id = encryptIt($id))? $profit_id : 0; ?>"
                                                   data-p="<?php echo ($package_id) ?>"
                                                   data-c="<?php echo ($package_id) ?>"
                                                   data-charts="<?php echo ($charts) ?>"
                                                   data-type="<?php echo ($m_type = ($lvalue->type))? $m_type : 0; ?>"
                                                   data-package-name="<?php echo ucfirst($pkname); ?>"
                                                   >
                                                   <div class="message-avatar"> <?php echo $lkey; ?> </div>
                                                   <div class="message-body">
                                                    <div class="message-body-heading">
                                                      <h5><span class="unread float-start mr-2 
                                                        <?php if($l >= ACHIEVED_LEVEL_2X){ echo "bg-danger"; }else{ echo "bg-success";} ?>
                                                        "><?php if($l >= ACHIEVED_LEVEL_2X){ echo 'Close'; }else{ echo 'Open';} ?>
                                                      </span> <?php echo $pack_activate; ?> UTC </h5>
                                                      <span class="float-end h1 mt-1"><?php echo ($p = calcMaxPackAchievedsponsor($user_id, $package_id, $charts)) ? $p : 0; ?> PYM</span> </div>
                                                    </div>
                                                  </a> </li>
                                                </ul>
                                              </div>
                                            <?php  }  ?>
                                            <?php                                                                                         
                                            if($overall >= count($lev_arr) ){ ?>
                                              <!-- <div class="job-box-filter">
                                                <h4 class="">Achieved Lvl :  0 </h4>
                                              </div>
                                              <div class="inbox-message">
                                                <ul>
                                                  <li class="bg-red-lt"> <a href="javascript:;" class="get_level_income"
                                                   data-level="1" 
                                                   data-list="<?php echo $profit_id =  0; ?>"
                                                   data-p="<?php echo 0 ?>"
                                                   data-c="<?php echo (0) ?>"
                                                   data-charts="<?php echo (0) ?>"
                                                   data-type="<?php echo $m_type =  0; ?>"
                                                   data-package-name="<?php echo ucfirst($pkname); ?>"
                                                   >
                                                   <div class="message-avatar"> <?php echo $lkey + 1; ?> </div>
                                                   <div class="message-body">
                                                    <div class="message-body-heading">
                                                      <h5><span class="unread float-start mr-2 
                                                        <?php if($l >= ACHIEVED_LEVEL_2X){ echo "bg-danger"; }else{ echo "bg-success";} ?>
                                                        "><?php if($l >= ACHIEVED_LEVEL_2X){ echo 'Close'; }else{ echo 'Open';} ?>
                                                      </span> <?php echo $pack_activate; ?> UTC </h5>
                                                      <span class="float-end h1 mt-1"><?php echo 0.00; ?> PYM</span> </div>
                                                    </div>
                                                  </a> </li>
                                                </ul>
                                              </div> -->
                                            <?php } ?>
                                          </div>
                                        </div>
                                      <?php } ?>
                                    </div>
                                  </div>
                                </div>

                                <div class="tab-pane" id="tabs-x4<?php echo $pakey; ?>">
                                  <div>
                                    <div class="card none-card" style="height: calc(13.6rem + 10px)">
                                      <div class="card-body card-body-scrollable card-body-scrollable-shadow">
                                        <?php
                                        if($lev_4x_arr = calc4xPackAchievedSponsorLevel($user_id, $package_id)){
                                          $amount = 0;                                            
                                          foreach ($lev_4x_arr as $lkey => $lvalue) {
                                            $lkey = $lkey + 1;
                                            $id = $lvalue->id;
                                            $package_id = $lvalue->package_id;
                                            $level = $lvalue->level;
                                            $charts = $lvalue->chart_level;
                                            $amount += ($lvalue->profit) ? $lvalue->profit : 0;
                                            $pack_4x_activate = timestamp_UTC_conversion($lvalue->timestamp);
                                            ?>
                                            <div class="chat_container">
                                              <div class="job-box">
                                                <div class="job-box-filter">
                                                  <h4 class="">Achieved Lvl : <?php
                                                  $max_achieved_4x = calcMax4xPackAchievedSponsorLevel($user_id, $package_id, $charts);
                                                  echo ($l = $max_achieved_4x) ? $l : 0; ?></h4>
                                                </div>
                                                <div class="inbox-message">
                                                  <ul>
                                                    <li class=" bg-green-lt">
                                                      <a href="javascript:;"  data-level="1" class="get_level_4x_income" 
                                                      data-list="<?php echo ($profit_id = encryptIt($id))? $profit_id : 0; ?>"
                                                      data-p="<?php echo ($package_id) ?>"
                                                      data-c="<?php echo ($package_id) ?>"
                                                      data-charts="<?php echo ($charts) ?>"
                                                      data-type="<?php echo ($mx_type = ($lvalue->matrix_type))? $mx_type : 0; ?>"
                                                      data-package-name="<?php echo ucfirst($pkname); ?>"
                                                      >
                                                      <div class="message-avatar">  <?php echo $lkey; ?> </div>
                                                      <div class="message-body">
                                                        <div class="message-body-heading">
                                                          <h5><span class="unread float-start mr-2 
                                                            <?php if($level == 10){ echo 'bg-danger'; }else{ echo 'bg-success';} ?>"><?php if($level == 10){ echo 'Close'; }else{ echo 'Open';} ?></span><?php echo $pack_4x_activate; ?> UTC </h5>
                                                            <span class="float-end h1 mt-1"> <?php echo ($p = calcMax4xPackAchievedSponsor($user_id, $package_id, $charts)) ? $p : 0; ?> PYM</span> </div>
                                                          </div>
                                                        </a> </li>
                                                      </ul>
                                                    </div>

                                                    <?php                                                                                         
                                                    if($overall_4x >= count($lev_4x_arr) ){ ?>
                                                     <!--  <div class="job-box-filter">
                                                        <h4 class="">Achieved Lvl :  0 </h4>
                                                      </div>
                                                      <div class="inbox-message">
                                                        <ul>
                                                          <li class="bg-red-lt"> <a href="javascript:;" class="get_level_income"
                                                           data-level="1" 
                                                           data-list="<?php echo $profit_id =  0; ?>"
                                                           data-p="<?php echo 0 ?>"
                                                           data-c="<?php echo (0) ?>"
                                                           data-charts="<?php echo (0) ?>"
                                                           data-type="<?php echo $mx_type =  0; ?>"
                                                           data-package-name="<?php echo ucfirst($pkname); ?>"
                                                           >
                                                           <div class="message-avatar"> <?php echo $lkey + 1; ?> </div>
                                                           <div class="message-body">
                                                            <div class="message-body-heading">
                                                              <h5><span class="unread float-start mr-2 
                                                                <?php if($l >= ACHIEVED_LEVEL_4X){ echo "bg-danger"; }else{ echo "bg-success";} ?>
                                                                "><?php if($l >= ACHIEVED_LEVEL_4X){ echo 'Close'; }else{ echo 'Open';} ?>
                                                              </span> <?php echo $pack_4x_activate; ?> UTC </h5>
                                                              <span class="float-end h1 mt-1"><?php echo 0.00; ?> PYM</span> </div>
                                                            </div>
                                                          </a> </li>
                                                        </ul>
                                                      </div> -->
                                                    <?php } ?>

                                                  </div>
                                                </div>
                                              <?php } } ?>

                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                      <div class="tab-pane" id="tabs-x6<?php echo $pakey; ?>">
                                      </div>

                                    </div>
                                  </div>

                                  
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

              <?php } } } ?>

            </div>
          </div>
        </div>




        <div class="modal modal-blur fade" id="modal-large" tabindex="-1" role="dialog" aria-hidden="true">
          <div class="modal-dialog modal-full-width modal-dialog-centered" role="document">
            <div class="modal-content shadow radius-20">
              <div class="modal-header">
                <h5 class="modal-title custom-package-title"></h5>
                <span class="float-end">                 
                </span>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <div class="table-responsive display-level-table">

                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn ms-auto float-right" data-bs-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>

        <?php include realpath(dirname(__DIR__) . '/common/inner_footer.php'); ?>

        <!-- tenrealm Core --> 
        <script type="text/javascript">
          var Xtype = '2';
          var currentRequest = null;

          function showDialog2() {
            $("#dialog1").removeClass("fade").modal("hide");
            $("#dialog2").addClass("fade").modal("show");
          }
          $(function () {
            $("#dialog1").modal("show");
            $("#dialog-ok").on("click", function () {
              showDialog2();
            });
          });


          $.fn.capitalizeFirstLetter = function(string) {
            return string.charAt(0).toLowerCase() + string.slice(1);
          }


          Object.defineProperty(String.prototype, 'capitalize', {
            value: function() {
              return this.charAt(0).toUpperCase() + this.slice(1);
            },
            enumerable: false
          });



          $.fn.displayData = function(result, packName){
          // var printMe = result.data.reverse();
          var printMe = $.fn.displayDecryptData(result.data);

          var titleObj = packName.capitalize() + ' Sponsor Farming Income Chart';
          $('.custom-package-title').html(titleObj);

          var table = '<table class="table table-vcenter card-table border-n text-center">\
          <thead>\
          <tr>\
          <th>Level</th>\
          <th>Sponsor Income</th>\
          </tr>\
          </thead>\
          <tbody>';


          $.each(printMe, function( index, value ) {  
            index = index + 1;
            if(value.matrix_type == 4){               
              var sponsor = Number(value.sponsor).toFixed(2);              

              if(index >= 1 && index <= 2){
                table +='<tr>\
                <td class="text-muted" > '+index+' </td>\
                <td> '+sponsor+' </td>\
                </tr>';
              }
              if(index >= 3){
                table +='<tr>\
                <td >'+index+'</td>\
                <td> '+sponsor+' </td>\
                </tr>';
              }

            }else{

              var sponsor = Number(value.sponsor).toFixed(2);            
              if(index >= 1 && index <= 10){
                table +='<tr>\
                <td class="text-muted" > '+index+' </td><td> '+sponsor+' </td></tr>';
              }

            }
          });
          table +='</tbody></table>';
          return table;
        }

        $(document).ready(function() {

          $(document).on('click', '.get_level_income', function(event) {
            event.preventDefault();
            /* Act on the event */
            var _this = $(this);
            var t = _this.data('type');
            var l = _this.data('p');
            var c = _this.data('list');
            var charts = _this.data('charts');
            var packName = _this.data('package-name');
            if ( typeof(t) !== "undefined" && t !== null ) {
              Xtype = t;
            }

            currentRequest = $.ajax({
              url: baseURL + 'display-sponsor-income',
              type: 'POST',
              dataType: 'json',
              data: { csrf_name: csrf_token, 'p': l, 't': Xtype,'c':c ,'charts' : charts},
              accepts: "application/json; charset=utf-8",
              beforeSend : function(){              
                if (typeof(currentRequest) != 'undefined' && currentRequest != null) {
                  currentRequest.abort();
                }
              },
              success:function(res){
                if(res.status == true){
                  $('#modal-large').modal('show');
                  $('.display-level-table').html($.fn.displayData(res, packName));  
                } 
              }
            });

          // .done(function() {
          //   console.log("success");
          // })
          // .fail(function(jqXHR, exception) {
          //    // Our error logic here
          //     var msg = '';
          //     if (jqXHR.status === 0) {
          //         msg = 'Not connect.\n Verify Network.';
          //     } else if (jqXHR.status == 404) {
          //         msg = 'Requested page not found. [404]';
          //     } else if (jqXHR.status == 500) {
          //         msg = 'Internal Server Error [500].';
          //     } else if (exception === 'parsererror') {
          //         msg = 'Requested JSON parse failed.';
          //     } else if (exception === 'timeout') {
          //         msg = 'Time out error.';
          //     } else if (exception === 'abort') {
          //         msg = 'Ajax request aborted.';
          //     } else {
          //         msg = 'Uncaught Error.\n' + jqXHR.responseText;
          //     }
          //   console.log("error", msg);
          // })
          // .always(function(res) {
          //   if(res.status == true){
          //     $('#modal-large').modal('show');
          //     $('.display-level-table').html($.fn.displayData(res));  
          //   }           
          // });



        });  


          $(document).on('click', '.get_level_4x_income', function(event) {
            event.preventDefault();
            /* Act on the event */

            var _this = $(this);
            var t = _this.data('type');
            var l = _this.data('p');
            var c = _this.data('list');
            // var list = _this.data('list');
            var charts = _this.data('charts');
            var packName = _this.data('package-name');
            if ( typeof(t) !== "undefined" && t !== null ) {
              Xtype = t;
            }

            currentRequest = $.ajax({
              url: baseURL + 'display-sponsor-4x-income',
              type: 'POST',
              dataType: 'json',
              data: { csrf_name: csrf_token, 'p': l, 't': Xtype,'c':c ,'charts' : charts},              
              accepts: "application/json; charset=utf-8",
              beforeSend : function(){              
                if (typeof(currentRequest) != 'undefined' && currentRequest != null) {
                  currentRequest.abort();
                }
              },
              success:function(res){
                if(res.status == true){
                  $('#modal-large').modal('show');
                  $('.display-level-table').html($.fn.displayData(res, packName));  
                } 
              }
            });
          });

          $(document).on('click', '.total-income-by-user-click', function(){
            var _this = $(this);
            var type = _this.data('type');
            if(type == 2){
              _this.closest('.package-header-row').find('.total2xcls').show();
              _this.closest('.package-header-row').find('.total4xcls').hide();
            }else{
              _this.closest('.package-header-row').find('.total4xcls').show();
              _this.closest('.package-header-row').find('.total2xcls').hide();
            }
          });        

        });
        
        
      </script>
    </body>
    </html>