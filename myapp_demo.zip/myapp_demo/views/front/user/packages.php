<?php include realpath(dirname(__DIR__) . '/common/inner_header.php'); ?>
  <style type="text/css">
    #qrcode-div {
      display: inline-block;
      vertical-align: middle;  
    }  
    .error{color:red;}   
    .require-inline {
      display: block;
      width: 100%;    
    }  
  </style>
<div class="page-body">
	<div class="container-xl">
		<ol class="breadcrumb breadcrumb-arrows mb-3" aria-label="breadcrumbs">
			<li class="breadcrumb-item"><a href="#">Wallet</a></li>
			<li class="breadcrumb-item active" aria-current="page">Activation</li>
		</ol>
		<div class="row row-cards">
			<div class="col-sm-12">
				<div class="row d-flex justify-content-center">
						<!-- <h2 class="text-center">Galaxy Pass</h2>  -->
						<?php
						if(isset($packages)){
						//Columns must be a factor of 12 (1,2,3,4,6,12)
            $sub_title = [
                        '<h2 class="text-center">Galaxy Pass</h2>',
                        '<h2 class="text-center">Universal Pass</h2>'
                        ];
            $s=0;
						$rows = $packages;
						$numOfCols = 3;
						$rowCount = 0;
						$bootstrapColWidth = 12 / $numOfCols;
						foreach ($packages as $key => $package){

							$package_id = ($package['id']) ? $package['id'] :'';
							$pkname = ($package['package_name']) ? $package['package_name'] :'';
              
              // $branch_income = global_branch_income($package_id);
              // $branch_income_total = 0;
              // // if($branch_income){
              //     $branch_income_total = $branch_income['income_l1'] +  $branch_income['income_l2'] + $branch_income['income_l3'] + $branch_income['income_l4'] + $branch_income['income_l5'] + $branch_income['income_l6'] + $branch_income['income_l7'] + $branch_income['income_l8'];  
              // // }
							// $income = ($package['income']) ? $package['income'] :0;
							// $farming_income = ($package['farming_income']) ? $package['farming_income'] :0;
							// $cultivation_income = ($package['cultivation_income']) ? $package['cultivation_income'] :0;
							// $system_income = ($package['system_income']) ? $package['system_income'] :0;

							// $package_price = $income + $farming_income + $cultivation_income + $system_income + $branch_income_total;
							$package_price  = package_price($package_id);

              if($rowCount % $numOfCols == 0) { ?>
                <h2 class="text-center"><?php echo ($sub_title[$s]) ? $sub_title[$s] : ''; $s++; ?></h2>
               <div class="row active-star-header"> <?php } 
						    $rowCount++; ?>		

					<div class="col-sm-6 col-lg-<?php echo $bootstrapColWidth; ?> mb-3">
						<div class="card card-md shadow radius-20 active-star-<?php echo $package_id; ?>">

							<?php 
							$valid = $this->common_model->get_row_counter('package_4x_payment',['package_id' => $package_id, 'user_id' => $user_id]);
							if($valid){ ?>
							<div class="ribbon ribbon-top ribbon-bookmark bg-green">								
								<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-filled" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
									<path stroke="none" d="M0 0h24v24H0z" fill="none"/>
									<path d="M12 17.75l-6.172 3.245l1.179 -6.873l-5 -4.867l6.9 -1l3.086 -6.253l3.086 6.253l6.9 1l-5 4.867l1.179 6.873z" />
								</svg>
							</div>
							<?php } ?>
							<div class="card-body text-center">
								<div class="text-uppercase text-muted font-weight-medium"><?php echo ucfirst($pkname)?></div>
								<div class="display-5 my-3">$ <?php echo $package_price; ?> EMD</div>
								<div class="text-center mt-4"> <a href="javascript:;" class="btn btn-light  w-100 selected_package_cls" data-selected_package="<?php echo $package_id; ?>" data-selected_package_amount="<?php echo $package_price; ?>" id="selected_package_cls_<?php echo $package_id; ?>">Activate</a> </div>
							</div>
						</div>
					</div>
						<?php if($rowCount % $numOfCols == 0 ) { ?> </div><?php } } } ?>
				</div>
			</div>			
		</div>
	</div>
</div>

<!-- Modal -->
<div class="modal modal-blur fade" id="modal-deposit" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
     <?php
       $action = base_url('is-activation');
       $attributes = array('id'=>'purchaseform','autocomplete'=>"off",'class'=>'purchaseform');
       echo form_open($action,$attributes);
       ?>
       <input type="hidden" value="" name="current_package" id="current_package" class="current_package" >
    <div class="modal-content shadow radius-20">
      <div class="modal-body">
        <div class="modal-title"> <span class="avatar avatar-xs mt-3 mr-2 avatar-rounded" style="background-image: url(<?php echo $sitelogo;?>)"></span>EMD</div>
        <div>
          <div class="input-group mb-2"> <span class="input-group-text"> User ID </span>
            <input type="text" maxlength="11" name="user_reference_id" id="user_reference_id" class="form-control required" placeholder="Enter User Id" value="<?php  echo user_id_to_unique_id($user_id); ?>" autocomplete="off">
          </div>
            <div class="input-group mb-2"> <span class="input-group-text"> User Details </span>
            <input type="text" readonly id="user_details" name="user_details" class="form-control" placeholder="" autocomplete="off" value="<?php echo user_id_to_name($user_id); ?>">
          </div>
          <div class="input-group mb-2"> <span class="input-group-text"> EMUSH </span>
            <input type="text" readonly id="purchase_amount" name="purchase_amount" class="form-control purchase_amount" value="" placeholder="Enter depoist value" autocomplete="off">
          </div>
        </div>
        <div class="alert alert-danger print-purchase-status-msg" id="print-purchase-status-msg" style="display: none;"></div>
        <p>Available Balance:<?php echo ($pym = number_format(get_pym_Balance($user_id),2) ?? 0.00);  ?></p>
        
        
        
      </div>
      <div class="modal-footer">
          
         
          <?php  $user_id = $this->session->userdata('user_id'); ?>
          <a class="btn btn-link link-secondary me-auto package_activation_cancel_btn"    href="<?php echo base_url();?>payment">Deposit</a>
      	
        <button type="button" class="btn btn-link link-secondary me-auto package_activation_cancel_btn" data-bs-dismiss="modal">Cancel</button>
        <!-- <button type="submit" class="btn btn-primary" name="btn-submit" value="package_purchasing">Activate</button> -->
        <input type="submit" class="btn btn-primary" name="btn-submit" value="Activate" id="package_activation_form_submit_btn" >
      </div>
    </div>
    	 <?php echo form_close(); ?>
  </div>
</div>



<div class="modal modal-blur fade" id="modal-qacode" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
      <?php
      $action = '';
      $attributes = array('id'=>'deposit_form','autocomplete'=>"off",'class'=>'deposit_form');
      echo form_open($action,$attributes);
      ?>
      <input type="hidden" name="user_deposit_amount_submit" value="" id="user_deposit_amount_submit" >
      <div class="modal-content shadow radius-20">
        <div class="modal-body pb-0">
          <div class="modal-title h1">
            <h2>Initializing</h2>
          </div>
          <div>
            <div class="row">
              
              <div class="col-md-6 col-xl-6"> <a id="copy3234" class="card card-link" href="javascript:;">
                <div class="card-body p-2">
                  <div class="row">
                    <div class="col-auto"> <span class="avatar rounded" style="background-image: url(<?php echo $assets_url_var; ?>static/Litecoin-LTC-icon.png)"></span> </div>
                    <div class="col" >
                      <div class="font-weight-medium coinprice" id="get_ltc_values"></div> <span>LTC</span>                      
                    </div>
                  </div>
                </div>
              </a>
              <span class="badge bg-green-lt mt-1 show_copied_to_clipboard"
               style="display: none;" id="show_copied_to_clipboard">Copied to clipboard!</span>
             </div>

              <div class="col-md-6 col-xl-6"> <a class="card card-link" href="#">
                <div class="card-body p-2">
                  <div class="row">
                    <div class="col">
                      <div class="font-weight-medium text-right">
                        <h1> <strong class="display-user-deposit-amount" id="display-user-deposit-amount"></strong> </h1>
                      </div>
                    </div>
                  </div>
                </div>
              </a> </div>
            </div>
            <div id="display_qr_code_as_true" >
            <p class="mt-3 mb-1">To complete your payment, please send <strong class="coinprice"> </strong> LTC or scan the QR code</p>
            <div class="card">
              <div class="card-body text-center">
                <div class="mb-3"> 
                  <div id="qrcode-div"></div>                  
                </div>
              </div>
              <!-- <form> -->
                <div class="input-group">
                  <input type="text" class="form-control" value="<?php echo md5(rand()); ?>" readonly placeholder="Some path" id="crypto_address" >
                  <span class="input-group-btn">
                    <button class="btn btn-default" type="button" id="copy-button" data-toggle="tooltip" data-placement="button" title="Copy to Clipboard" > Copy </button>
                    <span style="color:#66A81A;font-weight:bold;" id="copy_but" class="copy_but"></span>
                  </span>
                </div>

                  <div id="countdown">
                    <div id="tiles">
                      <span id="hours">00</span>
                      <span id="minutes">00</span>
                      <span  id="seconds">00</span></div>
                    <div class="labels">                   
                      <li>Hrs</li>
                      <li>Mins</li>
                      <li>Secs</li>
                    </div>
                  </div>
                  <div id="expire-countdown"></div>
                  <input type="hidden" value="" name="timer22" id="timer22" class="timer22" />
                <p class="text-center pb-0 mb-0">Gateway expires at <span class="badge bg-azure-lt" id="endDate"></span></p>
              </div>
            </div>
            <div id="display_qr_code_as_false"  style="display:none;">This deposit has expired. Please create a new transaction.</div>

            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-link link-secondary me-auto deposit_form_cancel" >Cancel</button>            
          </div>
        </div>
        <?php echo form_close(); ?>
      </div>
    </div>


<?php include realpath(dirname(__DIR__) . '/common/inner_footer.php'); ?>
<script src="<?php echo $assets_url_var;?>js/qrcode.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var;?>js/deposit.js?v=<?php echo date('Ymdhis'); ?>"></script>

<script type="text/javascript">
  var activeStar = '<div class="ribbon ribbon-top ribbon-bookmark bg-green">\
                      <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-filled" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">\
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>\
                        <path d="M12 17.75l-6.172 3.245l1.179 -6.873l-5 -4.867l6.9 -1l3.086 -6.253l3.086 6.253l6.9 1l-5 4.867l1.179 6.873z"></path>\
                      </svg>\
                    </div>';
	$(document).ready(function() {
		  var _print_ajax_status_cls = $("#print-purchase-status-msg");
      var purchaseform = $('#purchaseform');
      var depositForm = $('#deposit_form');
      var currentRequest = null;  
      var currentInput = $('input#user_details');
      var packageActivationFormSubmitBtn = $('#input#package_activation_form_submit_btn');
      var sameId = "<?php $p = $user_id; echo encryptIt($p); ?>";

		$('#modal-withdraw').modal({backdrop:'static', keyboard: false}); 

		$(document).on('click', '.selected_package_cls', function(e){
			e.preventDefault();
      purchaseform.find("input[type='submit']").prop("disabled", false);
      $('.print-purchase-status-msg').html('');
      $('.package_activation_cancel_btn').trigger('click');
      $('#current_package').val($.trim($(this).data('selected_package')));
      $('#purchase_amount').val($.trim($(this).data('selected_package_amount')));
			$('#modal-deposit').modal('show');
		});

		  


  		$.fn.successFn = function(data){        
        if (typeof(data.msg) == 'undefined' && data.msg == null) { return;}
        _print_ajax_status_cls.removeClass('alert-danger').addClass('alert-success').empty().show().html('').fadeIn().html(data.msg).fadeOut(5000);  
       }

       $.fn.errorFn = function(data){        
        if (typeof(data.msg) == 'undefined' && data.msg == null) { return;}        
       	_print_ajax_status_cls.removeClass('alert-success').addClass('alert-danger').empty().show().html('').fadeIn().html(data.msg).fadeOut(5000);	
       }

          
		    purchaseform.validate({
          errorClass: 'error require-inline',
          ignore: [],
		       rules: {
		          user_reference_id: {
		           required: {
		            depends:function(){
		             $(this).val($.trim($(this).val().replace(/\s+/g, '')));
		             return true;
		           }
		         },      
		         // number:true,
             remote: {
                  url: baseURL + 'is-user-details-available',
                  type: 'POST',  
                  cache: false,                                  
                  data: { csrf_name : csrf_token },
                  dataType: 'json',
                  beforeSend : function(){
                      currentInput.val('');
                      packageActivationFormSubmitBtn.prop("disabled", false);
                      _print_ajax_status_cls.hide().empty();
                      if (typeof(currentRequest) != 'undefined' && currentRequest != null) {                        
                          currentRequest.abort();
                      }
                  },
                  dataFilter: function (result) {
                      var result = $.parseJSON(result);                  
                      if(result.status==true){
                        currentInput.val(result.data.username);   
                         return true;                   
                      }else{
                        $.fn.errorFn(result);                        
                      }                      
                  }
              },
		       },
		    
		   },
		   submitHandler: function (form, event) {
		    event.preventDefault();        
        purchaseform.find("input[type='submit']").prop("disabled", true);        
		    purchaseform.find('.print-purchase-status-msg').empty().hide();	
        var currentPackage = $('#current_package').val();             
		    currentRequest = $.ajax({
		      url: $(form).attr('action'),
		      type: 'POST',
		      dataType: 'json',
		      data: $(form).serialize(),    
		      accepts: "application/json; charset=utf-8",
          cache: false,
          beforeSend : function(){                    
                    if (typeof(currentRequest) != 'undefined' && currentRequest != null) {
                        currentRequest.abort();
                    }
                },
		      success: function(data) {
                purchaseform.find("input[type='submit']").prop("disabled", false);                 
	              if(data.status == true){
	                $.fn.successFn(data); 
                  if (typeof(currentRequest) != 'undefined' && currentRequest != null && (sameId == data.same_id)) {                  
                    var selectorForActive = ".active-star-" + currentPackage;
                    $(selectorForActive).prepend(activeStar);
                  }
                  // setTimeout(function(){                    
                  //   $.fn.getDepositDetailsModal($('#purchase_amount').val());
                  // },5000)	                
	                return;
	              }else{
	                $.fn.errorFn(data); 
	              }                
	            },
	            error: jqueryErrorHandling,
	          });
          }
        });


	   // Reset of the package purchase modal 
      $(document).on('click', '.package_activation_cancel_btn', function(){          
        // alert('package sample2');
        purchaseform[0].reset();          
        // $('#user_reference_id').val('');
        $('#purchase_amount').val('');
        purchaseform.validate().resetForm();
        purchaseform.find('.error').removeClass('error');        
      });


	// Numeric only control handler
    $.fn.ForceNumericOnly = (function()
    {
      return this.each(function()
      {
        $(this).keydown(function(e)
        {
        //   var key = e.charCode || e.keyCode || 0;
        //       // allow backspace, tab, delete, enter, arrows, numbers and keypad numbers ONLY
        //       // home, end, period, and numpad decimal              
        //       return (                          
                
        //         key == 8 || 
        //         key == 9 ||
        //         key == 13 ||
        //         key == 46 ||
        //         key == 110 ||
        //         key == 190 ||
        //         (key >= 35 && key <= 40) ||
        //         (key >= 48 && key <= 57) ||
        //         (key >= 96 && key <= 105)

        //         );
       


            if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
        // Allow: Ctrl+A,Ctrl+C,Ctrl+V, Command+A
                ((e.keyCode == 65 || e.keyCode == 86 || e.keyCode == 67) && (e.ctrlKey === true || e.metaKey === true)) ||
                // Allow: home, end, left, right, down, up
                (e.keyCode >= 35 && e.keyCode <= 40)) {
                // let it happen, don't do anything
                return;
            }
            // Ensure that it is a number and stop the keypress
            if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                e.preventDefault();
            }
            //Ensure that bulk number pasted is numeric only
            let n = $(this).val()
            if (!isNaN(parseFloat(n)) && isFinite(n)) {
            } else {
                $(this).val("")
            }

            });
      });
    });

    // $("#user_reference_id").ForceNumericOnly();


	});
</script>
<?php include realpath(dirname(__DIR__) . '/common/js_error_notify.php'); ?>
</body>
</html>