<?php  
$user_id=$this->session->userdata('user_id');
$seg1 = $this->uri->segment(1);
$all_currency = $mycontroller['digital_currency'];
$btc_makerfee = $mycontroller['btc_makerfee'];
$btc_takerfee = $mycontroller['btc_takerfee'];
$tradepair_info = $mycontroller['tradepair_info'];

$from_cur = getBalance($user_id,$tradepair_info[0]->from_symbol_id);
$to_cur = getBalance($user_id,$tradepair_info[0]->to_symbol_id);



// $tradepair_info = $mycontroller['tradepair_info'];

//echo "<pre>";
// print_r($mycontroller['btc_makerfee']);
?>

<div class="navbar-expand-md">
  <div class="collapse navbar-collapse" id="navbar-menu">
    <div class="navbar navbar-light">
      <div class="container-xl">
        <ul class="navbar-nav">
          <li class="nav-item <?=($seg1=='basic-home')?'active':''?>"> <a class="nav-link" href="<?=base_url()?>basic-home"> <span class="nav-link-icon d-md-none d-lg-inline-block">
            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
              <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
              <polyline points="5 12 3 12 12 3 21 12 19 12" />
              <path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-7" />
              <path d="M9 21v-6a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v6" />
            </svg>
            </span> <span class="nav-link-title"> <?php echo $this->lang->line('Home');?> </span> </a> </li>
           
          <!-- <li class="nav-item "> <a class="nav-link" href="<?=base_url()?>basic-portfolio" > <span class="nav-link-icon d-md-none d-lg-inline-block">
            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
              <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
              <rect x="4" y="4" width="6" height="5" rx="2"></rect>
              <rect x="4" y="13" width="6" height="7" rx="2"></rect>
              <rect x="14" y="4" width="6" height="7" rx="2"></rect>
              <rect x="14" y="15" width="6" height="5" rx="2"></rect>
            </svg>
            </span> <span class="nav-link-title"> Portfoilo </span> </a> </li> -->
            <!-- <li class="nav-item <?=($seg1=='basic-pay')?'active':''?>"> <a class="nav-link" href="<?=base_url()?>basic-pay" > <span class="nav-link-icon d-md-none d-lg-inline-block">
            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
              <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
              <rect x="4" y="4" width="6" height="5" rx="2"></rect>
              <rect x="4" y="13" width="6" height="7" rx="2"></rect>
              <rect x="14" y="4" width="6" height="7" rx="2"></rect>
              <rect x="14" y="15" width="6" height="5" rx="2"></rect>
            </svg>
            </span> <span class="nav-link-title"> <?php echo $this->lang->line('Pay');?> </span> </a> </li>  -->
          <li class="nav-item <?=($seg1=='basic-trade')?'active':''?>"> <a class="nav-link" href="<?=base_url()?>basic-trade" > <span class="nav-link-icon d-md-none d-lg-inline-block">
            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
              <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
              <rect x="10" y="9" width="4" height="12" rx="1.105" />
              <rect x="17" y="3" width="4" height="18" rx="1.105" />
              <circle cx="5" cy="19" r="2" />
            </svg>
            </span> <span class="nav-link-title"> <?php echo $this->lang->line('Trade');?> </span> </a> </li>

          <!-- <li class="nav-item "> <a class="nav-link" href="<?=base_url()?>basic-notification" > <span class="nav-link-icon d-md-none d-lg-inline-block">
            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
              <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
              <path d="M10 6h-3a2 2 0 0 0 -2 2v9a2 2 0 0 0 2 2h9a2 2 0 0 0 2 -2v-3" />
              <circle cx="17" cy="7" r="3" />
            </svg>
            </span> <span class="nav-link-title"> Notification </span> </a> </li> -->
        </ul>
        <!-- <div class="my-2 my-md-0 flex-grow-1 flex-md-grow-0 order-first order-md-last">
      <form action="." method="get">
        <div class="input-icon"> <span class="input-icon-addon">
          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
            <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
            <circle cx="10" cy="10" r="7" />
            <line x1="21" y1="21" x2="15" y2="15" />
          </svg>
          </span>
          <a  href="#preview-trade" class="btn btn-primary ms-auto" data-toggle="modal"> 
      Buy / Sell
      </a>
        </div>
      </form>
    </div> -->
        
      </div>
    </div>
  </div>
</div>


</div>



