<?php $this->load->view('front/common/header_in');
      $settings = $site_common['site_settings']; ?>
    <div class="wrapper">
        <nav id="sidebar">
            <div class="sidebar-header">
               <a href="<?=base_url('home')?>"><img src="<?=$settings->site_logo?>" alt="logo" class="img-fluid"></a>
            </div>
            <div class="user_profile">
                <?php $img =  ($users->profile_picture)?$users->profile_picture:base_url().'assets/front/inner/img/user_img.svg';?>
                <span><img src="<?=$img?>" width="85px" alt="user_img" class="img-fluid"></span>
                <h5><?php echo ($users->ixtoken_username)?$users->ixtoken_username:'';?></h5>
            </div>
            <?php $this->load->view('front/common/sidebar'); ?>
            
        </nav>
        <div id="content">
            <header>
                <div class="row">
                    <div class="col-sm-8">
                        <div class="header_left">
                            <button type="button" id="sidebarCollapse" class="toggle_btn"><i
                                    class="fa fa-bars"></i></button>
                            <h4><?php echo $this->lang->line('KYC Verification')?></h4>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="header_right">
                            <ul>
                                 <?php $this->load->view('front/common/top_navigation'); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </header>
            <?php
                      $status1 = $users->photo_1_status;
                      $status2 = $users->photo_2_status;
                      $status3 = $users->photo_3_status;

                      $status_addr = ($status1==3)?'circle':'close';
                      $status_id = ($status2==3)?'circle':'close';
                      $status_photo = ($status3==3)?'circle':'close';

                      if($status1==0)
                      {
                        $sts1 = $this->lang->line('Not Uploaded');
                        $cls1 = 'verified_notup';
                        $clss1 ='text-info';
                        $sym1 = '';
                      }                       
                      elseif($status1==1)
                      {
                        $sts1= $this->lang->line('Pending');
                        $cls1 = 'verified_pend';
                        $clss1 ='text-primary';
                        $sym1 = 'fas fa-info-circle';
                      }                        
                      elseif($status1==2)
                      {
                        $sts1 = $this->lang->line('Rejected');
                        $cls1 = 'verified_not';
                        $clss1 ='text-red';
                        $sym1 = 'far fa-times-circle';
                      }                        
                      else
                      {                        
                        $sts1 = $this->lang->line('Verified');
                        $cls1 = 'verified';
                        $clss1 ='text-green';
                        $sym1 = 'far fa-check-circle';
                      }

                      if($status2==0)
                      {
                        $sts2 = $this->lang->line('Not Uploaded');
                        $cls2 = 'verified_notup';
                        $clss2 ='text-info';
                        $sym2 = '';
                      }                       
                      elseif($status2==1)
                      {
                        $sts2= $this->lang->line('Pending');
                        $cls2 = 'verified_pend';
                        $clss2 ='text-primary';
                        $sym2 = 'fas fa-info-circle';
                      }                        
                      elseif($status2==2)
                      {
                        $sts2 = $this->lang->line('Rejected');
                        $cls2 = 'verified_not';
                        $clss2 ='text-red';
                        $sym2 = 'far fa-times-circle';
                      }                        
                      else
                      {                        
                        $sts2 = $this->lang->line('Verified');
                        $cls2 = 'verified';
                        $clss2 ='text-green';
                        $sym2 = 'far fa-check-circle';
                      }

                      if($status3==0)
                      {
                        $sts3 = $this->lang->line('Not Uploaded');
                        $cls3 = 'verified_notup';
                        $clss3 ='text-info';
                        $sym3 = '';
                      }                       
                      elseif($status3==1)
                      {
                        $sts3= $this->lang->line('Pending');
                        $cls3 = 'verified_pend';
                        $clss3 ='text-primary';
                        $sym3 = 'fas fa-info-circle';
                      }                        
                      elseif($status3==2)
                      {
                        $sts3 = $this->lang->line('Rejected');
                        $cls3 = 'verified_not';
                        $clss3 ='text-red';
                        $sym3 = 'far fa-times-circle';
                      }                        
                      else
                      {                        
                        $sts3 = $this->lang->line('Verified');
                        $cls3 = 'verified';
                        $clss3 ='text-green';
                        $sym3 = 'far fa-check-circle';
                      }
            ?>
            <div class="block p-3">
                <div class="row">
                    <div class="col-md-4">
                        <div class="proofs">
                            <h5 class="block_title mb-3"><?php echo $this->lang->line('Address Proof')?></h5>
                            <div class="proof_shown <?=$cls1?>">
                                <h5><?php echo $this->lang->line('Address Proof')?> <span class="<?=$clss1?>"><?=$sts1?> <i
                                            class="<?=$sym1?>"></i></span></h5>
                            </div>
                            <?php
                                  $attributes=array('id'=>'verification_forms1'); 
                                  $action = front_url() . 'address_verification';
                                  echo form_open_multipart($action,$attributes);
                                  if($users->photo_1_status==3 && $users->photo_id_1!=""){ 
                                    $style = "display:none";
                                    
                                  }
                                  else
                                  {
                                    $style = "display:block";
                                  }
                                  if(($users->photo_1_status==1 && $users->photo_id_1 !='') || ($users->photo_1_status==3 && $users->photo_id_1 !='')){
                                    $img = $users->photo_id_1;
                                    $text = "";
                                  }
                                  else
                                  {
                                    $img = images_url().'upload-icon.png';
                                    $text = "img";
                                  }
                            ?>
                            <div class="avatar-upload proof-upload" style="<?php echo $style;?>">
                                <div class="avatar-edit">
                                    <input type='file' id="imageUpload1" name="photo_id_1" accept=".png, .jpg, .jpeg, .svg" />
                                    <label for="imageUpload1"></label>
                                </div>
                                <input type="hidden" id="addr_proof" value="<?php echo $users->photo_id_1;?>">
                                <div class="avatar-preview">
                                    <div id="imagePreview1" style="background-image: url(<?php echo $img;?>);">
                                    </div>
                                </div>
                            </div>
                            <?php echo form_close();?>
                            <h6><?php echo $this->lang->line('[Maximum File Size Should Be Below 2mb]')?></h6>
                            <sapn class="photo_error">
                                    <small style="padding-left: 85px;" class="error_msg photo_id_1_error error"></small>
                                </span>
                            <ul class="proof_btns" style="<?php echo $style;?>">
                                <li>
                                    <button type="submit" id="addr_submit" class="btn_small btn-primary"><?php echo $this->lang->line('Save')?></button>
                                </li>
                                <li class="ml-2">
                                    <button type="submit" id="addr_cancel" class="btn_small btn-secondary"><?php echo $this->lang->line('Cancel')?></button>
                                </li>
                            </ul>
                            <ul class="proof_content">
                                <span><?php echo $this->lang->line('Any One Address Proof Document Must Submit')?></span>
                                <li><?php echo $this->lang->line('Bank Debit / Credit Card Statement')?></li>
                                <li><?php echo $this->lang->line('Passport')?></li>
                                <li><?php echo $this->lang->line('Rental/ Property Agreement')?></li>
                                <li><?php echo $this->lang->line('Income Tax / Property Tax')?></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="proofs">
                            <h5 class="block_title mb-3"><?php echo $this->lang->line('ID Proof')?></h5>
                            <div class="proof_shown <?=$cls2?>">
                                <h5><?php echo $this->lang->line('ID Proof')?> <span class="<?=$clss2?>"><?=$sts2?> <i class="<?=$sym2?>"></i></span></h5>
                            </div>
                            <?php
                                  $attributes=array('id'=>'verification_forms2'); 
                                  $action = front_url() . 'id_verification';
                                  echo form_open_multipart($action,$attributes);
                                  if($users->photo_2_status==3 && $users->photo_id_2!=""){ 
                                    $style = "display:none";
                                    
                                  }
                                  else
                                  {
                                    $style = "display:block";
                                  }
                                  if(($users->photo_2_status==1 && $users->photo_id_2 !='') || ($users->photo_2_status==3 && $users->photo_id_2 !='')){
                                    $img = $users->photo_id_2;
                                    $text = "";
                                  }
                                  else
                                  {
                                    $img = images_url().'upload-icon.png';
                                    $text = "img";
                                  }
                            ?>
                            <div class="avatar-upload proof-upload" style="<?php echo $style;?>">
                                <div class="avatar-edit">
                                    <input type='file' name="photo_id_2" id="imageUpload2" accept=".png, .jpg, .jpeg, .svg" />
                                    <label for="imageUpload2"></label>
                                </div>
                                <input type="hidden" id="id_proof" value="<?php echo $users->photo_id_2;?>">
                                <div class="avatar-preview">
                                    <div id="imagePreview2" style="background-image: url(<?php echo $img;?>);">
                                    </div>
                                </div>
                            </div>
                            <?php echo form_close();?>
                            <h6><?php echo $this->lang->line('[Maximum File Size Should Be Below 2mb]')?></h6>
                            <span class="photo_error">
                                    <small style="padding-left: 85px;" class="error_msg photo_id_2_error error"></small>
                                </span>
                            <ul class="proof_btns" style="<?php echo $style;?>">
                                <li>
                                    <button type="submit" id="id_submit" class="btn_small btn-primary"><?php echo $this->lang->line('Save')?></button>
                                </li>
                                <li class="ml-2">
                                    <button id="id_cancel" type="submit" class="btn_small btn-secondary"><?php echo $this->lang->line('Cancel')?></button>
                                </li>
                            </ul>
                            <ul class="proof_content">
                                <span><?php echo $this->lang->line('Any ID Address Proof Document Must Submit')?></span>
                                <li><?php echo $this->lang->line('Driving License')?></li>
                                <li><?php echo $this->lang->line('Passport')?></li>
                                <li><?php echo $this->lang->line('Insurance Document')?></li>
                                <li><?php echo $this->lang->line('Debit / Credit Card With Photo And Name')?> </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="proofs">
                            <h5 class="block_title mb-3"><?php echo $this->lang->line('Photo Upload')?></h5>
                            <div class="proof_shown <?=$cls3?>">
                                <h5><?php echo $this->lang->line('Photo Proof')?> <span class="<?=$clss3?>"><?=$sts3?> <i
                                            class="<?=$sym3?>"></i></span></h5>
                            </div>
                            <?php
                                  $attributes=array('id'=>'verification_forms3'); 
                                  $action = front_url() . 'photo_verification';
                                  echo form_open_multipart($action,$attributes);
                                  if($users->photo_3_status==3 && $users->photo_id_3!="")
                                  { 
                                    $style = "display:none";
                                    
                                  }
                                  else
                                  {
                                    $style = "display:block";
                                  }
                                  if(($users->photo_3_status==1 && $users->photo_id_3 !='') || ($users->photo_3_status==3 && $users->photo_id_3 !='')){
                                    $img = $users->photo_id_3;
                                    $text = "";
                                  }
                                  else
                                  {
                                    $img = images_url().'upload-icon.png';
                                    $text = "img";
                                  }
                            ?>
                            <div class="avatar-upload proof-upload" style="<?php echo $style;?>">
                                <div class="avatar-edit">
                                    <input type='file' id="imageUpload3" name="photo_id_3" accept=".png, .jpg, .jpeg, .svg" />
                                    <label for="imageUpload3"></label>
                                </div>
                                <input type="hidden" id="photo_proof" value="<?php echo $users->photo_id_3;?>">
                                <div class="avatar-preview">
                                    <div id="imagePreview3" style="background-image: url(<?php echo $img;?>);">
                                    </div>
                                </div>
                            </div>
                            <?php echo form_close();?>
                            <h6><?php echo $this->lang->line('[Maximum File Size Should Be Below 2mb]')?></h6>
                            <span class="photo_error">
                                    <small style="padding-left: 85px;" class="error_msg photo_id_3_error error"></small>
                                </span>
                            <ul class="proof_btns" style="<?php echo $style;?>">
                                <li>
                                    <button type="submit" id="photo_submit" class="btn_small btn-primary"><?php echo $this->lang->line('Save')?></button>
                                </li>
                                <li class="ml-2">
                                    <button id="photo_cancel" type="submit" class="btn_small btn-secondary"><?php echo $this->lang->line('Cancel')?></button>
                                </li>
                            </ul>
                            <ul class="proof_content">
                                <span><?php echo $this->lang->line('Following Proof Document Must Submit')?></span>
                                <li><?php echo $this->lang->line('Close Head Photo')?></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <?php $this->load->view('front/common/footer_in'); ?>
