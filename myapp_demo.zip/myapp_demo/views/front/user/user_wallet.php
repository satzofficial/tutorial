<?php $this->load->view('front/common/header_in');
      $settings = $site_common['site_settings']; ?>
    <div class="wrapper">
        <nav id="sidebar">
            <div class="sidebar-header">
               <a href="<?=base_url('home')?>"><img src="<?=$settings->site_logo?>" alt="logo" class="img-fluid"></a>
            </div>
            <div class="user_profile">
                 <?php $img =  ($users->profile_picture)?$users->profile_picture:base_url().'assets/front/inner/img/user_img.svg';?>
                <span><img src="<?=$img?>" width="85px" alt="user_img" class="img-fluid"></span>
                <h5><?php echo ($users->ixtoken_username)?$users->ixtoken_username:'';?></h5>
            </div>
            <?php $this->load->view('front/common/sidebar'); ?>
        </nav>
        <div id="content">
            <header>
                <div class="row">
                    <div class="col-sm-8">
                        <div class="header_left">
                            <button type="button" id="sidebarCollapse" class="toggle_btn"><i
                                    class="fa fa-bars"></i></button>
                            <h4><?php echo $this->lang->line('Balances')?></h4>

                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="header_right">
                            <ul>
                                 <?php $this->load->view('front/common/top_navigation'); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </header>
            <div class="row">
                <div class="col-md-12">
                    <div class="block p-3">
                        <div class="table_inner">
                            <div class="table_responsive">
                                <table id="balances" class="display nowrap" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th><?php echo $this->lang->line('Coin Name')?></th>
                                            <th><?php echo $this->lang->line('Total balance')?></th>
                                            <th style="display: none"><?php echo $this->lang->line('Sort order')?></th>
                                            <!-- <th><?php echo $this->lang->line('In order')?></th> -->
                                            <th><?php echo $this->lang->line('BTC Value')?></th>
                                            <th><?php echo $this->lang->line('Actions')?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                        <?php
                            if(count($dig_currency) >0)
                            {
                                foreach ($dig_currency as $digital) 
                                {
                                    if($digital->type=="fiat")
                                    {
                                        $format = 2;
                                    }
                                    elseif($digital->currency_symbol=="ZCHIP")
                                    {
                                        $format = 6;
                                    }
                                    elseif($digital->currency_symbol=="USDT")
                                    {
                                        $format = 6;
                                    }
                                    else
                                    {
                                        $format = 6;
                                    }
                                    $coin_price_val = to_decimal($wallet['Exchange AND Trading'][$digital->id], $format);
                                    $coin_price = $coin_price_val * $digital->online_usdprice;
                        ?>
                                        <tr>
                                            <td><img src="<?php echo $digital->image;?>" width="30px" alt="coin" class="img-fluid">
                                                <?php echo $digital->currency_name;?></td>
                                            <td><?php echo $coin_price_val; ?></td>
                                            <td style="display: none"><?php echo $digital->sort_order;?></td>
                                            <!-- <td>5.765544323</td> -->
                                            <td><?php echo $coin_price; ?></td>
                                            <td>
                                                <a href="<?php echo base_url();?>transaction#deposit" class="table_links">Deposit</a>
                                                <a href="<?php echo base_url();?>transaction#Withdraw" class="table_links">Withdraw</a>
                                                <a href="<?php echo base_url();?>trade" class="table_links">Trade</a>
                                               
                                            </td>
                                        </tr>
                                        <?php } } ?>
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php $this->load->view('front/common/footer_in'); ?>