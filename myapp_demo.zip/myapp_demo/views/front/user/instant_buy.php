<?php $sitelan = $this->session->userdata('site_lang'); 
       $this->load->view('front/common/inner_header'); 
      $user_id=$this->session->userdata('user_id');

      $name = $sitelan."_name";
      $heading = $sitelan."_heading";
      $content = $sitelan."_content";
      $site_settings = site_common();
      $stripe_public_key = $site_settings['site_settings']->stripeapi_public_key;
?>

<style type="text/css">
    .loader_img{
        height:50px;
        background-color: #F3F3F3;        
    }

    .stripe-button-el { display: none; }
</style>


   <div class="inner-body">
        <div class="container">
            <div class="inner-card-box max-650">
                <div class="inner-card-head">
                    <span>Buy Crypto with VISA card in USD</span>
                </div>
            <div class="inner-card-head">
                    <span>Coming soon</span>
                    </div>
 <!--               <div class="row">
                    <div class="col-lg-12">
                        <div class="inner-box-body">
                           <?php
                                    $user_id    = $this->session->userdata('user_id');
                                    $action     = front_url()."instant_buy";
                                    $attributes = array('id'=>'instant'); 
                                    echo form_open($action,$attributes); 
                                ?>
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="inputEmail4">Amount</label>
                                        <input type="text" class="form-control" id="send_amount" name="send_amount">
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="inputPassword4">Select Currency</label>
                                        <select class="form-control" id="fiatcurrency_symbol" name="fiatcurrency_symbol">
                                        	   <?php
                                            foreach($fiat_currency as $fiatcurrency)
                                            {
                                        ?>
                                              <option value="<?php echo $fiatcurrency->currency_symbol;?>" data-id="<?php echo $fiatcurrency->id.'#'.$fiatcurrency->type;?>" data-symbol="<?php echo $fiatcurrency->currency_symbol;?>">
                                                        <?php echo $fiatcurrency->currency_symbol;?>
                                                </option>
                                        <?php
                                            }
                                        ?>
                                          </select>
                                    </div>
                                </div>
                                <div class="form-row">

                                    <div class="form-group col-md-12">
                                        <label for="inputPassword4">Select Coin</label>
                                          <select class="custom-select my-1 mr-sm-2 w-400" name="received_currency" id="received_currency">
                                         <?php
                                            foreach($currency_list as $currency)
                                            {
                                        ?>
                                                <option value="<?php echo $currency->currency_symbol;?>" data-id="<?php echo $currency->id.'#'.$currency->type;?>" data-symbol="<?php echo $currency->currency_symbol;?>">
                                                        <?php echo $currency->currency_symbol;?>
                                                </option>
                                        <?php
                                            }
                                        ?>
                                        </select>
                                    </div>
                                </div>

                                Esitimated Cryptos: <div id="cntryValcalc">
                       
                           
                        </div>


                             <!--    <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="inputEmail4">Paywith</label>
                                        <input type="text" class="form-control" id="inputEmail4" placeholder="Visa Credit/Debit Card">
                                    </div>
                                </div> -->
<!--                                 <p id="processingbutton" style="font-size: 16px; color: #0CA7B2;"></p>
                                <div class="text-center mt-3" >
                                    <a class="transfer_mode form-btn" data-pay="stripe" href="javascript:void(0);">Buy Crypto</a>
                                </div>
-->
                            <?php 
                                    echo form_close();
                                ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $this->load->view('front/common/footer'); ?>
 <?php $this->load->view('front/common/scripts'); ?>


 
        <?php
         
            $action     = front_url()."stripe_success";
            $attributes = array('id'=>'instantttt'); 
            echo form_open($action,$attributes); 
        ?>

<input type="hidden" name="userId" id="userID" value="<?php echo $this->session->userdata('user_id');?>"/>
<input type="hidden" name="orderID" id="orderID" value=""/>
<input type="hidden" name="crypto_amnt" id="crypto_amnt" value="<?=$total?>"/>
<input type="hidden" name="send_currency" id="send_currency" value=""/>
<input type="hidden" name="receive_currency" id="receive_currency" value=""/>
<input type="hidden" name="fiat_amount" id="fiat_amount" value=""/>
<input type="hidden" name="prod_details" id="prod_details" value="Instant Buy"/>
<script src="https://checkout.stripe.com/checkout.js" class="stripe-button" data-key="<?=$stripe_public_key?>" data-amount="<?=$total?>" data-name="<?=getSiteName()?>" data-description="Ready to buy" data-image="" data-locale="auto" data-zip-code="false">
</script>
    
<?php  echo form_close(); ?>
 <script type="text/javascript">

   $("#send_amount").keyup(function(event) {
      

        var send_amount = $(this).val();
        var fiatcurrency_symbol = $("#fiatcurrency_symbol").val();
        var received_currency = $("#received_currency").val();
         $.ajax({
            url: "<?php echo front_url(); ?>currency_calculation",
            type: "POST",
            data: {"currency_symbol":fiatcurrency_symbol,"send_amount":send_amount,"received_currency":received_currency},
            beforeSend:function(data){
                $("#processingbutton").html('Loading...');
                $(".transfer_mode").hide();


            },
            success: function (data) {
                // console.log(data);
                $("#cntryValcalc").html(data);
                $("#processingbutton").html('');
                $(".transfer_mode").show();
                     },
                     });

    });

   $("#received_currency").change(function(event) {
      

        var received_currency = $(this).val();
        var send_amount = $("#send_amount").val();
        var fiatcurrency_symbol = $("#fiatcurrency_symbol").val();
        
         $.ajax({
            url: "<?php echo front_url(); ?>currency_calculation",
            type: "POST",
            data: {"currency_symbol":fiatcurrency_symbol,"send_amount":send_amount,"received_currency":received_currency},
            beforeSend:function(data){
               $("#processingbutton").html('Loading...');
                $(".transfer_mode").hide();
            },
            success: function (data) {
                // console.log(data);
                $("#cntryValcalc").html(data);
                 $("#processingbutton").html('');
                 $(".transfer_mode").show();
                     },
                     });

    });


   
</script>


  <script>

        $(".transfer_mode").on('click',function(){
            
            var crypto_amnt = $("#cntryValcalc").html();
            var fiatcurrency_symbol = $("#fiatcurrency_symbol").val();
            var send_amount = $("#send_amount").val();
            var received_currency = $("#received_currency").val();
            
           /* alert(crypto_amnt+"=== crypto_amnt"+fiatcurrency_symbol+"== fiatcurrency_symbol"+send_amount+"  === send_amount"+received_currency+"  == received_currency");;

            return false;*/

            $("#crypto_amnt").val(crypto_amnt.replace(/,(?=\d{3})/g, ''));      
            $("#receive_currency").val(received_currency);
            $("#send_currency").val(fiatcurrency_symbol);      
            $("#fiat_amount").val(send_amount);   

            // alert($("#crypto_amnt").val());
            $(".stripe-button-el").trigger('click');
      
            /*if(modes == 'paypal')
            {
                //alert(modes);
                var usd_balance = $(".currency_usd").val();
                var amounts = $(".set_total").val();
                var total_amounts = $("#to_currency").val();
                $("#currency_name").val('INR');
                $("#amount").val(amounts);
                $(".btn.main-btn-blue").css("display","none");
                $("#usd_form_submit").trigger('click');
            }*/
        });
    </script>