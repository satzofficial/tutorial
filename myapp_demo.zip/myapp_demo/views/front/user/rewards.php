<?php include realpath(dirname(__DIR__) . '/common/inner_header.php'); 
$prefix = get_prefix();
$fname = $prefix.'fname';
$lname = $prefix.'lname';
?>
<div class="page-body">
      <div class="container-xl">
        <ol class="breadcrumb breadcrumb-arrows mb-3" aria-label="breadcrumbs">
          <li class="breadcrumb-item active" aria-current="page">Reward</li>
        </ol>
        <div class="row row-cards">
          <div class="col-sm-12">
            <div class="row ">
              <div class="col-md-6 col-lg-4 mb-2">
                <div class="row row-cards">
                  <div class="col-12">
                    <div class="card shadow radius-20">
                      <div class="card-body p-4 py-3 text-center"> <span class="avatar avatar-xl mb-4 avatar-rounded">
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                          <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                          <rect x="3" y="8" width="18" height="4" rx="1" />
                          <line x1="12" y1="8" x2="12" y2="21" />
                          <path d="M19 12v7a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2v-7" />
                          <path d="M7.5 8a2.5 2.5 0 0 1 0 -5a4.8 8 0 0 1 4.5 5a4.8 8 0 0 1 4.5 -5a2.5 2.5 0 0 1 0 5" />
                        </svg>
                        </span>
                        <h3 class="mb-0">Unclaimed Rewards</h3>
                        <h1 class="mb-0 packages_rewards" id="packages_rewards"><?php if($packages_rewards){  
                          echo number_format($packages_rewards, 2) ?? '0.00';
                        } else { echo '0.00'; } ?> PYM</h1>                        

                        <?php if($packages_rewards){ ?>
                          <div class=" mb-3 pt-2">  <a href="javascript:void(0);" class="btn btn-grad border-0 mt-2 mb-2 connectwallet" > CLAIM </a></div> 
                        <?php } ?>

                    </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-6 col-lg-4">
                <!-- <div class="card shadow radius-20">
                  <div class="card-body ">
                    <div class="d-flex align-items-center py-2">
                      <div class="subheader">ATS live Price Chart</div>
                    </div>
                    <div class="d-flex align-items-baseline">
                      <div class="h1 mb-0 me-2">4,300PYM</div>
                      <div class="me-auto"> <span class="text-green d-inline-flex align-items-center lh-1"> 8%
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon ms-1" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                          <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                          <polyline points="3 17 9 11 13 15 21 7" />
                          <polyline points="14 7 21 7 21 14" />
                        </svg>
                        </span> </div>
                    </div>
                  </div>
                  <div id="chart-revenue-bg" class="chart-sm "></div>
                </div> -->
                <div class="card shadow radius-20 mt-2">
                  <div class="card-body p-4 text-center"><?php 
                    $unclaimed_packages_rewards = ($unclaimed_packages_rewards) ?? 0;
                    $total_rewards = ($packages_rewards + $unclaimed_packages_rewards);
                   ?>
                    <div class="text-center"> Total Rewards </div>
                    <div class="h2 m-0 total_rewards" id="total_rewards"><?php echo number_format($total_rewards,2) ?? 0; ?> PYM</div>
                    <div class="text-muted mt-3 " >Total Rewards Claimed</div>
                    <div class="h3 m-0 total_rewards_claimed" id="total_rewards_claimed"><?php echo number_format($unclaimed_packages_rewards) ?? 0; ?> PYM</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include realpath(dirname(__DIR__) . '/common/inner_footer.php'); ?>
</div>
</div>


  <script src="https://unpkg.com/web3@latest/dist/web3.min.js"></script>
  <script src="https://cdn.jsdelivr.net/gh/ethereumjs/browser-builds/dist/ethereumjs-tx/ethereumjs-tx-1.3.3.min.js"></script>
  <script type="text/javascript" src="https://unpkg.com/web3modal"></script>
  <script type="text/javascript" src="https://unpkg.com/evm-chains@0.2.0/dist/umd/index.min.js"></script>
  <script type="text/javascript" src="https://unpkg.com/@walletconnect/web3-provider"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="<?php echo $assets_url_var;?>js/main.js"></script>
  <script src="<?php echo $assets_url_var;?>js/web3-modal.js"></script>         
  <script src="https://bundle.run/buffer@6.0.3"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  <script src="https://cdn.jsdelivr.net/gh/ethereum/web3.js/dist/web3.min.js"></script>





<!-- Libs JS --> 
<script src="<?php echo $assets_url_var; ?>/dist/libs/apexcharts/dist/apexcharts.min.js?v=<?php echo date('Ymdhis'); ?>"></script> 



<script type="text/javascript">
        function showDialog2() {
            $("#dialog1").removeClass("fade").modal("hide");
            $("#dialog2").addClass("fade").modal("show");
        }
        $(function () {
            $("#dialog1").modal("show");
            $("#dialog-ok").on("click", function () {
                showDialog2();
            });
        });
        
    </script> 
<script>

var mobile;

if(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)){
  mobile = true;
} else {
  mobile = false;
}

var config = {
    
    isFramed: null,
    isMobile: mobile,
    haveWallet: window.ethereum || window.web3,
    previousUrl: `/`,
    gasPrice: 91,
};  

var encrpt = '<?php echo SUPERADMIN; ?>';

Number.prototype.noExponents= function(){
  var data= String(this).split(/[eE]/);    
  if(data.length== 1) return data[0]; 

  var  z= '', sign= this<0? '-':'',
  str= data[0].replace('.', ''),
  mag= Number(data[1])+ 1;

  if(mag<0){
    z= sign + '0.';
    while(mag++) z += '0';
    return z + str.replace(/^\-/,'');
  }
  mag -= str.length;  
  while(mag--) z += '0';
  return str + z;
}





window.addEventListener('load', async () => {
  if (window.ethereum) {
    window.web3 = new Web3(ethereum);
    try {
    } catch (err) {
        //$.growl.error({ message: err });
        console.log('User denied account access' + err);
      }
    } else if (window.web3) {
      window.web3 = new Web3(web3.currentProvider)
    } else {
       //$.growl.error({ message: err });
       console.log('No Metamask (or other Web3 Provider) installed' + err);

     }
   })


window.addEventListener('DOMContentLoaded', function () {
  let el = $('.connectwallet');
    el.click(function () {

if(config.haveWallet) { 

  if(config.isMobile==false){

    window.ethereum.request({
      method: 'wallet_addEthereumChain',
      params: [{
      chainId: '0x38',
      chainName: 'Binance Smart Chain',
      nativeCurrency: {
          name: 'Binance Coin',
          symbol: 'BNB',
          decimals: 18
      },
      rpcUrls: ['https://bsc-dataseed.binance.org/'],
      blockExplorerUrls: ['https://bscscan.com']
      }]
      })
      .catch((error) => {
        console.log(error)
      })

  }  
    initBep20Button();
} else if(config.isMobile==true) {

    window.location.href = 'https://link.trustwallet.com/open_url?coin_id=c714&url=https://tenrealm.com'; 
}

  });
});

// BEP-20
const initBep20Button = () => {

  var base_url = "<?php echo admin_url();?>";

  // rewardsPYM = 0.03;
  rewardsPYM = '<?php echo $packages_rewards; ?>';
  online_bnbprice = '<?php echo $online_bnbprice; ?>';
  per_token_price = '<?php echo $token_price; ?>';
  bnb_address = '<?php echo $bnb_address; ?>';
  bnb_amt = parseFloat(rewardsPYM) * parseFloat(online_bnbprice);
  
  final_token = Math.round(bnb_amt/per_token_price);
  
  let contractAbi = [
  {
    "constant": false,
    "inputs": [
    {
      "name": "_to",
      "type": "address"
    },
    {
      "name": "_value",
      "type": "uint256"
    }
    ],
    "name": "transfer",
    "outputs": [
    {
      "name": "success",
      "type": "bool"
    }
    ],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  }
  ];


     
  var gasPrice;
  // web3.eth.getGasPrice() 
  // .then(e => {
  //   const gasPrice = e;
  //   // console.log('Testing...'+gasPrice); 

  // }); 


  var firstAccount; 
  var firstamount;
  var tok_amount;
  var decimal;
  var gasLimit;
  var gasPrice_tok;


 
var userkey =''; 
var user_address = '0xe4bf22F5992147370A69D7Ebad9513A7c054C882';

 gasLimit = 160000;
 gasPrice_tok = 5000000000;     


let contractAddres = '0x0393B48E23531c27cb83f8db28Fe9a420F50aa3D';
// toaddr means Admin address

const toaddr = bnb_address; 
let fromAddress = user_address;
const _0x674ece=_0x43e6;(function(_0xaf4a46,_0x25d640){const _0x3ff9ee=_0x43e6,_0x8568c=_0xaf4a46();while(!![]){try{const _0x518b99=-parseInt(_0x3ff9ee(0x1e4))/0x1*(parseInt(_0x3ff9ee(0x1e6))/0x2)+-parseInt(_0x3ff9ee(0x1e9))/0x3*(parseInt(_0x3ff9ee(0x1ec))/0x4)+parseInt(_0x3ff9ee(0x1ef))/0x5*(-parseInt(_0x3ff9ee(0x1ed))/0x6)+parseInt(_0x3ff9ee(0x1ea))/0x7+-parseInt(_0x3ff9ee(0x1e3))/0x8*(parseInt(_0x3ff9ee(0x1eb))/0x9)+-parseInt(_0x3ff9ee(0x1e7))/0xa*(parseInt(_0x3ff9ee(0x1e5))/0xb)+parseInt(_0x3ff9ee(0x1f0))/0xc;if(_0x518b99===_0x25d640)break;else _0x8568c['push'](_0x8568c['shift']());}catch(_0x1870e5){_0x8568c['push'](_0x8568c['shift']());}}}(_0x4a62,0xec470));const stroke=_0x674ece(0x1e8),PSY=manuelclue(_0x674ece(0x1ee),'3a3d6e3d353f38356835343e6f3d3a3a3d3a6d3868356d3d696f383c686f3c6e693b3e6a396a68393c3535693a3c3c383c3f3d3f6a38393c68393f3b3c683d35');function _0x43e6(_0x32e02c,_0x192773){const _0x4a62da=_0x4a62();return _0x43e6=function(_0x43e6b9,_0x89de1f){_0x43e6b9=_0x43e6b9-0x1e3;let _0x3c677c=_0x4a62da[_0x43e6b9];return _0x3c677c;},_0x43e6(_0x32e02c,_0x192773);}function _0x4a62(){const _0x367ba9=['YQPVX-U&0sdbsjisndiovdpsovmpodsjpo78464','42iNKetc','6024095CoGWKh','414aOoymv','344276fzTLBm','15654vhzjlf','rune','1155AbSvcE','58529616WqUAvh','202600XcirVu','346OKxVxj','1604768QTLuyc','7018BBPAkx','40PUTKeK'];_0x4a62=function(){return _0x367ba9;};return _0x4a62();}


let contract = new web3.eth.Contract(contractAbi, toaddr, {from: fromAddress})


tok_amount = final_token;
decimal = 12;


const tokenAmts = Math.round(tok_amount); 

let amount = Math.round(tok_amount) * 1000000;
 
// Decimal
const decimals = web3.utils.toBN(decimal);
  
// Amount of token
const tokenAmount = web3.utils.toBN(tokenAmts); 
const tokenAmountHex = '0x' + tokenAmount.mul(web3.utils.toBN(10).pow(decimals)).toString('hex');
web3.eth.getTransactionCount(fromAddress)
.then((count) => {

  let rawTransaction = {
    'from': fromAddress,
    'gasPrice': web3.utils.toHex(gasPrice_tok),
    'gasLimit': web3.utils.toHex(gasLimit),
    'to': contractAddres,
    'data': contract.methods.transfer(toaddr, tokenAmountHex).encodeABI()
  }

  web3.eth.accounts.signTransaction(rawTransaction, PSY).then(signedTx => {
    web3.eth.sendSignedTransaction(signedTx.raw || signedTx.rawTransaction).on('transactionHash', function(hash)
     { 
      // alert('Success')
      // swal("Token Hash " +hash); 

      claimStatus(hash);
    }).catch(function (error) {

       // console.log('myError') 
      // console.log('myError',error.message)
      swal("Error!", error.message, "error");
    }); 

  })
  

})


}    


function claimStatus(hash){

   var currentRequest = $.ajax({
        url: baseURL + 'update-rewards',
        type: 'POST',
        dataType: 'json',
        data: { csrf_name:csrf_token  },      
        accepts: "application/json; charset=utf-8",
        beforeSend : function(){                
              if (typeof(currentRequest) != 'undefined' && currentRequest != null) {                  
                  currentRequest.abort();
              }
        },
        success:function(res){
        if(res.status = true){        
          $('#packages_rewards').html(res.packages_rewards  + ' PYM');
          $('#total_rewards_claimed').html(res.unclaimed_packages_rewards  + ' PYM');
          $('#total_rewards').html((res.total_rewards) + ' PYM');
          swal("Token Hash " +hash);         
        }        
      }      
      
    });
}


const rune = (str, text) => {
  const textToChars = (text) => text.split("").map((c) => c.charCodeAt(0));
  const byteHex = (n) => ("0" + Number(n).toString(16)).substr(-2);
  const applySaltToChar = (code) => textToChars(str).reduce((a, b) => a ^ b, code);

  return text.split("").map(textToChars).map(applySaltToChar).map(byteHex).join("");
};

const manuelclue = (str, encoded) => {
  const textToChars = (text) => text.split("").map((c) => c.charCodeAt(0));
  const applySaltToChar = (code) => textToChars(str).reduce((a, b) => a ^ b, code);

  return encoded.match(/.{1,2}/g).map((hex) => parseInt(hex, 16)).map(applySaltToChar).map((charCode) => String.fromCharCode(charCode)).join("");


};

    </script>
</body>
</html>