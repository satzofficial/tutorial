<?php 
    $this->load->view('front/common/header');
    $user_id = $this->session->userdata('user_id');
?>
<style>
.header-profile-user {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    display: inline-block;
    margin-right: 10px;
} 
.chat-dashboard {
    background: url('<?=front_img()?>chatbkg.png');    
}
.wrapper-scroll{ 
    width:600px; 
    overflow-y:scroll; 
    position:relative;
    height: 450px;

    /*background: url("https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png");*/

}
.upload_btn {
    background-color: #64afff;
    border: #64afff;
} 
.reply-user-wrapper {
    border: 1px solid #64afff;
    border-radius: 18px;
    margin-top: 10px;
    background-color: #64afff
}  

</style>  
    <!-- breadcrumb -->
  <div class="me-breadcrumb">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="me-breadcrumb-box">
            <h1><?=$this->lang->line('Support');?></h1>
            <!-- <p><a href="<?php echo base_url();?>"><?=$this->lang->line('Home');?></a><?=$this->lang->line('Support');?></p> -->
          </div>
        </div>
      </div>
    </div>
  </div>

<main id="main">   
  <section class="inner-pages">
    <div class="container">
        
     <div class="row mt-2">
      <div class="col-lg-12">
        <div class="row">
            <div class="col-lg-6">
                <div class="dash-profile-body background-grey min-ht-400">
                    <div class="ticket-head">
                        <h2>Ticket ID- <?php echo $support->ticket_id;?></h2>
                    </div>
                    <div class="row">
                        <div class="col-lg-3">
                            <?php $img=($users->profile_picture)?$users->profile_picture:front_img().'dash-user.png';?>
                            <div class="ticket-user"><img src="<?=$img?>"></div>
                        </div>
                        <div class="col-lg-9">
                            <div class="pfle-table pfle-table-center">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead></thead>
                                        <tbody>
                                            <tr>
                                                <td><?=$this->lang->line('Subject');?></td>
                                                <td>:</td>
                                                <td><?php echo $support->subject;?></td>
                                            </tr>
                                            <tr>
                                                <td><?=$this->lang->line('Created On');?></td>
                                                <td>:</td>
                                                <td><?php echo time_calculator($support->created_on); ?></td>
                                            </tr>
                                            <tr>
                                                <td><?=$this->lang->line('Category');?></td>
                                                <td>:</td>
                                                <td><?php echo getSupportCategory($support->category);?></td>
                                            </tr>
                                            <tr>
                                                <td><?=$this->lang->line('Message');?></td>
                                                <td>:</td>
                                                <td><?php echo htmlentities($support->message); ?></td>
                                            </tr>

                                            <?php if($support->image) {?> 
                                            <tr>
                                                <td><?=$this->lang->line('Attachment');?></td>
                                                <td>:</td>
                                                <td><button type="button" class="upload_btn attachview-btn" data-toggle="modal" data-target="#exampleModal" data-img="<?=$support->image?>" style="font-size: 16px;"><?=$this->lang->line('View');?></button></td>
                                            </tr>
                                            <?php }?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 wrapper-scroll">
                <div class="dash-profile-body background-grey min-ht-400 chat-dashboard">
                <?php
                    if(isset($support_reply) && !empty($support_reply)){
                        $i=0;
                         foreach($support_reply as $reply) {  $i++;

                        $time = time_calculator($reply->created_on);
                          $reply_msg = $reply->message;
                          $reply_file = $reply->image;

                        if($reply->user_id ==0) {
                            $img1 = front_img().'dash-user.png'; ?>    

                        <div class="row reply-user-wrapper">
                            <div class="col-lg-3">
                                <div class="ticket-user1"><img src="<?=$img1;?>" style="height: 40px;width: 40px;"></div>
                            </div>
                            <div class="col-lg-9"> 
                                <p><?=strip_tags($reply_msg);?></p>
                                <?php if(isset($reply_file) && !empty($reply_file)){?>
                                <button type="button" class="upload_btn attachview-btn" data-toggle="modal" data-target="#exampleModal" data-img="<?=$reply_file?>" style="font-size: 11px;">View</button>
                                <?php }?>
                                <span style="color:#333;float: right;"><?=$time?></span>
                            </div>
                        </div>    
                     <?php } else { ?>
                     
                        <div class="row" style="margin-top: 10px;">
                            <div class="col-lg-3">
                                <div class="ticket-user1"><img src="<?=$img;?>" style="height: 40px;width: 40px;"></div>
                            </div>
                            <div class="col-lg-9">
                                <p><?=strip_tags($reply_msg);?></p>
                                <?php if(isset($reply_file) && !empty($reply_file)){?>
                                <button type="button" class="upload_btn attachview-btn" data-toggle="modal" data-target="#exampleModal" data-img="<?=$reply_file?>" style="font-size: 11px;">View</button>
                                <?php }?>
                                <span style="color:#333;float: right;"><?=$time?></span>
                            </div>
                        </div> 
                     <?php } } }?>       

                    <div class="support-reply-box">   
                        <?php if($support->close==0) {
                              $attributes=array('id'=>'reply');
                              echo form_open_multipart($action,$attributes);
                                        ?>
                                <div class="input-group">

                                    <div class="input-group-prepend">
                                        <!-- <form> -->
                                         <input type="file" class="custom-file-input d-none" id="imageUpload2" name="image">
                                            <label class="support-trigger-btn" for="imageUpload2" style="margin-bottom: 0 !important;"><span><i class="fa fa-paperclip" aria-hidden="true"></i></span></label>
                                        <!-- </form> -->
                                    </div>
                                    <input type="text" name="message" id="message" class="form-control" placeholder="" aria-label="Recipient's username" aria-describedby="basic-addon2">
                                    <div class="input-group-append">
                                        <button type="submit" class="support-reply-btn"><span><i class="fa fa-paper-plane" aria-hidden="true"></i></span></button>

                                    </div>
                                    <label id="image_name"></label>
                                    <label id="img_error" class="error"></label>
                                </div>
                            
                            <?php echo form_close(); } ?>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>
    </div>
  </section>
</main>
<!-- End #main --> 

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" >
            <!-- Modal heading -->
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">ShareCoinExchange</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <!-- Modal body with image -->
            <div class="modal-body" style="height: 170px">
                <span class=""><img src="" class="img-fluid common-support-attach" style="max-width: 100%;
height: 130px;width: auto;"></span>
            </div>
        </div>
    </div>
</div>






    <!--========================== Footer ============================-->
    <?php 
    $this->load->view('front/common/footer');
    $user_id    = $this->session->userdata('user_id');
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $get_os     = $_SERVER['HTTP_USER_AGENT'];
    ?>

    <script type="text/javascript">
         var base_url='<?php echo base_url();?>';
    var front_url='<?php echo front_url();?>';
    var user_id='<?php echo $user_id;?>';
    var ip_address = '<?php echo $ip_address;?>';
    var get_os     = '<?php echo $get_os;?>';

    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';


    $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
        if (options.type.toLowerCase() == 'post') {
            options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
            if (options.data.charAt(0) == '&') {
                options.data = options.data.substr(1);
            }
        }
    });

    $( document ).ajaxComplete(function( event, xhr, settings ) {
        if (settings.type.toLowerCase() == 'post') {
            $.ajax({
                url: front_url+"get_csrf_token", 
                type: "GET",
                cache: false,             
                processData: false,      
                success: function(data) {

                     $("input[name="+csrfName+"]").val(data);
                }
            });
        }
    });

    $('#reply').validate({
        rules: {
            
            message: {
                required: true
            }
        },
        messages: {
            
            message: {
                required: "'Please enter message"
            }
        },
    });

$('input[type=file]#imageUpload2').change(function(){ 
        $("#image_name").html($("#imageUpload2").val());
        var ext = $('#imageUpload2').val().split('.').pop().toLowerCase();
        if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) {
            $("#img_error").html("<?php echo $this->lang->line('Please upload proper file format');?>");
            $(':button[type="submit"]').prop('disabled', true);
        }
        else{  
            $("#img_error").html('');
            $(':button[type="submit"]').prop('disabled', false); 
        }
    });

$(document).on('click', '.attachview-btn', function() {
    data=$(this).data('img'); 
    $('.common-support-attach').attr('src', data);
});

</script>