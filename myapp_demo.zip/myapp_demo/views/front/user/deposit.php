<?php 
$this->load->view('front/common/header');
$user_id = $this->session->userdata('user_id');
$url1=$_SERVER['REQUEST_URI'];
$min = min_to_sec(1);
header("Refresh: $min; URL=$url1");
?>
<!--========================== Banner Section ============================-->
<style type="text/css">

  .bs-tabs .nav-tabs { margin-bottom: 2px;
    background: #f4f4f4; }
    .bs-tabs .nav-tabs > li.active > a, .nav-tabs > li.active > a:focus, .nav-tabs > li.active > a:hover { border-width: 0; }
    .bs-tabs .nav-tabs > li > a { border: none; color: #000;padding: 10px 30px;       display: block;  background: #f4f4f4;}
    .bs-tabs .nav-tabs > li.active > a, .bs-tabs .nav-tabs > li > a:hover { border: none;  color: #000 !important; }
    .bs-tabs .nav-tabs > li > a::after { content: ""; height: 2px; position: absolute; width: 100%; left: 0px; bottom: -1px; transition: all 250ms ease 0s; transform: scale(0); }
    .bs-tabs .nav-tabs > li.active > a::after, .bs-tabs .nav-tabs > li:hover > a::after { transform: scale(1);  }
    .bs-tabs .tab-nav > li > a::after {  color: #fff; }
    .bs-tabs .tab-pane { padding: 15px 0; }
    .bs-tabs .tab-content{padding:20px;     background: #f4f4f4;}
    .bs-tabs .nav-tabs > li  {    /* width: 20%; */
      text-align: center;
      color: #000;

      margin-right: 2px;}
      .bs-tabs .nav-tabs > li a.active  {
        background: #4699F2; color:#FFF !important;
      }

      @media all and (max-width:724px){
        .bs-tabs .nav-tabs > li > a > span {display:none;}   
        .bs-tabs .nav-tabs > li > a {padding: 5px 5px;}
      }

      #chart-area, #widget-container, .tv-main-panel {background: #000;}
      .chart-page .chart-container {border: black solid 0;}

      .modal-content1 {
        position: relative;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        -ms-flex-direction: column;
        flex-direction: column;
        width: 100%;
        pointer-events: auto;
        background-color: #fff;
        background-clip: padding-box;
        border: 1px solid rgba(0, 0, 0, 0.2);
        border-radius: 0.3rem;
        outline: 0;
        height: 770px;
      }

      label.upload_btn1 {
        border: 1px solid #282F44;
        border-radius: 20px;
        padding: 2px 10px;
        font-size: 11px;
        letter-spacing: 0;
        color: #333;
        background: #e7d5a2;
        width: 100px;
        text-align: center;
        margin: 10px;
        margin-left: 34px;
      }

    </style>

    <!-- breadcrumb -->
    <div class="me-breadcrumb">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="me-breadcrumb-box">
              <h1><?php echo $this->lang->line('Deposit');?></h1>             
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="me-service-single me-padder-top me-padder-bottom">
     <?php $this->load->view('front/user/sidebar_sticky');?>
     <div class="content-body">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="deposit-main-box"> 
              <div class="row align-items-center">
                <div class="col-lg-6">
                  <div class="deposit-form bottom-border" style="height:356px;">
                    <form>
                      <div class="form-group">
                        <select class="form-control custom-select" onChange="change_address(this)">
                          <?php
                          if(count($all_currency) > 0) {
                            foreach ($all_currency as $currency) { ?>
                              <option value="<?php echo $currency->id.'#'.$currency->type;?>" <?php echo ($sel_currency->id == $currency->id)?'selected':''?>>
                                <?php echo $currency->currency_symbol?>
                              </option>
                            <?php }} ?>

                          </select>
                        </div>
                        <p class="amount-wrap">
                          <span><?php echo $this->lang->line('Available Balance');?></span>
                          <span><?php echo number_format($currency_balance,5)?></span>
                        </p>
                      </form>
                      <div class="grey-box">
                        <?php $sitelan = $this->session->userdata('site_lang'); 
                        if($sitelan=='english') {?>
                          <h4>TRANSFER PROCESS</h4> 
                          <ul>
                            <li><span><i class="fas fa-check"></i>Enter only <span class="currency-txt-sym"><?php echo $sel_currency->currency_symbol?></span> addresses</li>
                            <li><span><i class="fas fa-check"></i> The transfer is irrevocable</span></li>
                            <?php if($sel_currency->crypto_type=='eth') {?>
                              <li class="ethereum_coin"><span><i class="fas fa-check"></i> The Gas cost will be charged to the sender address</span></li>
                            <?php } ?> 
                          </ul>
                        <?php } elseif($sitelan=='italian') {?>   
                          <h4>PROCESSO DI TRASFERIMENTO</h4> 
                          <ul>
                            <li><span><i class="fas fa-check"></i> Inserire solo indirizzi <span class="currency-txt-sym"><?php echo $sel_currency->currency_symbol?></span></li>
                            <li><span><i class="fas fa-check"></i> Il trasferimento è irrevocabile</span></li>
                            <?php if($sel_currency->crypto_type=='eth') {?>
                              <li class="ethereum_coin"><span><i class="fas fa-check"></i> Il costo Gas sarà addebitato al mittente per l'ammontare mostrato</span></li>  
                            <?php } ?>
                          </ul>
                        <?php }?>  
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="deposit-address" style="height:350px;">
                      <?php if($sel_currency->id == 5){ 
                        $style = "display: none";  
                      } else {
                        $style = "display: block";  
                      }?>
                      <div class="input-group mb-3 cryp_add1" >
                        <input readonly style="<?php echo $style?>" type="text" class="form-control cryp_add" placeholder="Copy Address" aria-describedby="basic-addon2" value="<?php echo $crypto_address;?>" id="crypto_address">
                        <div style="<?php echo $style?>" class="input-group-append cryp_add">
                          <span class="input-group-text" id="basic-addon2"><a href="javascript:void(0)" onclick="copy_function('<?php echo $this->lang->line('COPIED')?>')"><?php echo $this->lang->line('Copy');?></a></span>
                          <span style="color:#66A81A;font-weight:bold;" class="copy_but"></span>  
                        </div>

                      </div>
                      <div class="form-group det_tag" <?php if($sel_currency->id == 6){ echo 'style="display: block;"'; } else{ echo 'style="display: none;"'; } ?>>
                        <label for="exampleInputEmail1"><?php echo $this->lang->line('Destination Tag');?></label>
                        <input type="text" class="form-control" value="<?php echo $destination_tag;?>" id="destination_tag">
                      </div>
                      <div class="text-center mt-4 cryp_add" <?php if($sel_currency->id==5){?> style="display: none;" <?php }?>>
                        <img src="<?php echo $First_coin_image;?>" alt="QR Code" id="crypto_img" class="img-fluid w-140 qr-code">
                      </div>
                      <div class="text-center mt-4 cryp_add" <?php if($sel_currency->id==5){?> style="display: none;" <?php }?>>
                        <a id="downloadpdf_btn" href="<?php echo base_url('download_pdf/'.$sel_currency->currency_symbol.'/'.base64_encode($crypto_address));?>" class="wallet-table-btn">Download PDF</a>
                      </div>

                      <?php if(trim($user->verify_level2_status)=='Completed') { ?>
                        <div class="text-center mt-4 fiat_deposit" <?php if($sel_currency->id!=5){?> style="display: none;" <?php } ?>>
                          <?php
                          if(getSiteSettings('paypeaks_bank')==1){
                            ?>
                            <button class="auth_btn" style="padding: 5px 28px !important;" data-toggle="modal" data-target="#mobile_wallet"><?php echo $this->lang->line('Bank Wire');?></button>
                          <?php }
                          if(getSiteSettings('paypeaks_mobile')==1){
                            ?>
                            <button class="auth_btn" style="padding: 5px 28px !important;" data-toggle="modal" data-target="#mobile_wallet"><?php echo $this->lang->line('Mobile Money');?></button>
                          <?php }
                          if(getSiteSettings('paypeaks_card')==1){
                            ?>
                            <button class="auth_btn" style="padding: 5px 28px !important;"data-toggle="modal" data-target="#card_processing"><?php echo $this->lang->line('Debit/Credit Card');?></button>
                          <?php }?>

                        </div> 
                      <?php } else {?> 
                        <div class="form-group deposit-address fiat_deposit" <?php if($sel_currency->id != 5){?>style="display: none;" <?php } ?>> 

                          <?php echo $this->lang->line('Please Complete KYC');?><a style="color: #4699F2;" href="<?php echo base_url();?>settings"> <?php echo $this->lang->line('Click here');?></a> 

                        </div> 
                      <?php }?>

                    </div>
                  </div>

                </div>
              </div>
            </div>
          </div>

        </div>     
      </div>
    </div>




    <!--Mobile Wallet modal start-->
    <div class="modal fade right" id="mobile_wallet" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
    aria-hidden="true"> 

    <!-- Add class .modal-full-height and then add class .modal-right (or other classes from list above) to set a position to the modal -->
    <div class="modal-dialog modal-full-height modal-right iks-popup" role="document">
      <div class="modal-content1">
        <div class="modal-header">
          <h4 class="modal-title w-100 text-center" id="myModalLabel"><?php echo $this->lang->line('Bank Wire');?></h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
        </div>
        <div class="modal-body">
          <div class="col-sm-12">
            <div class="row">
              <div class="col-sm-12 deposit-address bank_wire">
                <?php
                $action = front_url()."deposit/EUR";
                $attributes = array('id'=>'deposit_bank','autocomplete'=>"off",'enctype'=>"multipart/form-data"); 
                echo form_open($action,$attributes); 

                $country = get_countryname($bankwire->bank_country);
                    // $bank_det = get_admin_bank_details(1);
                    // $currency=$this->common_model->getTableData('currency',array('id'=>$bank_det->currency))->row();
                      // echo "<pre>";print_r($bank_det);
                ?>
                <!-- <input type="hidden" name="currency" class="currency" value="<?php echo $sel_currency->id;?>" > -->
                <h4 class="modal-title w-100 text-center" style="margin-top:10px"><?php echo $this->lang->line('Account Details');?></h4>
                <div class="form-row text-center" style="margin-top:20px;">
                  <div class="col-12">
                    <div class="mb-3">
                      <div class="form-row">
                        <div class="col-lg-6">
                          <label for="basic-url"><?php echo $this->lang->line('Bank Name');?></label>     
                        </div>
                        <div class="col-lg-6">
                          <label for="basic-url"><?php echo $bankwire->bank_name?></label>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-12">
                    <div class="mb-3">
                      <div class="form-row">
                        <div class="col-lg-6">
                          <label for="basic-url"><?php echo $this->lang->line('Account Number');?></label>     
                        </div>
                        <div class="col-lg-6">
                          <label for="basic-url"><?php echo $bankwire->bank_account_number?></label>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-12">
                    <div class="mb-3">
                      <div class="form-row">
                        <div class="col-lg-6">
                          <label for="basic-url"><?php echo $this->lang->line('Account Holder Name');?></label>     
                        </div>
                        <div class="col-lg-6">
                          <label for="basic-url"><?php echo $bankwire->bank_account_name?></label>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-12">
                    <div class="mb-3">
                      <div class="form-row">
                        <div class="col-lg-6">
                          <label for="basic-url"><?php echo $this->lang->line('Swift/BIC Code');?></label>
                        </div>
                        <div class="col-lg-6">
                          <label for="basic-url"><?php echo $bankwire->bank_swift?></label>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-12">
                    <div class="mb-3">
                      <div class="form-row">
                        <div class="col-lg-6">
                          <label for="basic-url"><?php echo $this->lang->line('Bank Country');?></label>
                        </div>
                        <div class="col-lg-6">
                          <label for="basic-url"><?php echo $country?></label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>


                <p><?php echo $this->lang->line('After making the transfer, fill in the fields below and upload a payment receipt in .pdf format (the maximum file size must be less than 2 MB)')?></p>


                <div class="form-row">
                  <div class="col-8 col-md-8">
                    <div class="row">
                      <div class="col-12 col-md-12">
                        <label for="basic-url"><?php echo $this->lang->line('Coin Name');?></label>
                        <div class="mb-3">
                          <input type="text" readonly class="form-control input_anim" aria-label="Small" aria-describedby="inputGroup-sizing-sm" name="coin_name" value="<?php echo $sel_currency->currency_symbol?>">
                          <input type="hidden" name="currency" value="<?php echo $sel_currency->id?>">
                        </div>
                      </div>
                    </div>
                    
                    <div class="row">
                      <div class="col-12 col-md-12">
                        <label for="basic-url"><?php echo $this->lang->line('Enter Amount');?></label>
                        <div class="mb-3">
                          <input type="text" class="form-control input_anim" aria-label="Small" aria-describedby="inputGroup-sizing-sm" name="amount">
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-4 col-md-4">
                    <div class="row">
                      <img style="max-width:160px;" src="<?php echo front_img();?>pdf-icon.png">
                      <label for="imgInp1" class="upload_btn1"><?php echo $this->lang->line('Upload pdf');?></label>
                      <input type="file" name="upload_pdf_deposit" id="imgInp1" class="imgInp upload_pdf" accept="application/pdf">
                      <span id="upload_pdf_name" style="font-weight: bold;"></span>
                      <span id="upload_pdf_error" style="margin-top: 10px;color: #ff0000;"></span>
                    </div>
                  </div>


                    <!-- <div class="col-8 col-md-8">
                      <div class="row">
                        <div class="col-12 col-md-12">
                          <label for="basic-url"><?php echo $this->lang->line('Reference Number');?></label>
                          <div class="mb-3">
                            <input type="text" class="form-control input_anim" aria-label="Small" aria-describedby="inputGroup-sizing-sm" name="ref_no">
                          </div>
                        </div>
                      </div>
                    </div> -->
                    <div class="col-12 col-md-12">
                      <div class="row">
                        <div class="col-12 col-md-12">
                          <input type="hidden" name="payment_types" id="payment_types" value="bank">
                          <input type="hidden" name="account_number" value="<?php echo $bankwire->bank_account_number?>">
                          <input type="hidden" name="account_name" value="<?php echo $bankwire->bank_account_name?>">
                          <input type="hidden" name="bank_name" value="<?php echo $bankwire->bank_name?>">
                          <input type="hidden" name="bank_swift" value="<?php echo $bankwire->bank_swift?>">
                          <input type="hidden" name="bank_country" value="<?php echo $bankwire->bank_country?>">
                          <input type="hidden" name="bank_city" value="<?php echo $bankwire->bank_city?>">
                          <input type="hidden" name="bank_address" value="<?php echo $bankwire->bank_address?>">
                          <input type="hidden" name="bank_postalcode" value="<?php echo $bankwire->bank_postalcode?>">
                          <div class="profile-flex border-0 pt-4 kyc-confirm-btn">
                            <div class="text-center">
                              <button name="deposit_bank" class="auth_btn deposit_bank" type="submit"><?php echo $this->lang->line('Deposit');?> </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>



                  <?php echo form_close();?> </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
      <!--Mobile Wallet modal end-->



      <!--Card Processing modal start-->
      <div class="modal fade right" id="card_processing" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
      aria-hidden="true"> 

      <!-- Add class .modal-full-height and then add class .modal-right (or other classes from list above) to set a position to the modal -->
      <div class="modal-dialog modal-full-height modal-right iks-popup" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title w-100" id="myModalLabel">Card Processing</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
          </div>
          <div class="modal-body">
            <div class="col-sm-12">
              <div class="row">
                <div class="col-sm-12 paypal_form mr-auto">
                  <?php
                  $action = front_url()."deposit/GHS";
                  $attributes = array('id'=>'deposit_card','autocomplete'=>"off"); 
                  echo form_open($action,$attributes); 
                  ?>
                  <input type="hidden" name="currency" class="currency" value="<?php echo $sel_currency->id;?>"/>


                  <div class="col-8 col-md-8">
                    <div class="row">
                      <div class="col-12 col-md-12">
                        <label for="basic-url">Enter amount</label>
                        <div class="mb-3">
                          <input type="number" class="form-control input_anim" aria-label="Small" aria-describedby="inputGroup-sizing-sm" name="amount">
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="col-8 col-md-8">
                    <div class="row">
                      <div class="col-12 col-md-12">
                        <label for="basic-url">Product</label>
                        <div class="mb-3">
                          <select name="productcode" class="form-control ">
                            <?php
                              // $Products = Get_Paypeaks_Products('CARD','CARD');
                              // foreach($Products as $Lists){
                            ?>
                            <!-- <option value='<?php echo $Lists->product_code;?>'><?php echo $Lists->product_name;?></option> -->
                            <?php
                              // }
                            ?>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>


                  <div class="col-8 col-md-8">
                    <div class="row">
                      <div class="col-12 col-md-12">
                        <label for="basic-url">Card Number</label>
                        <div class="mb-3">
                          <input type="text" class="form-control input_anim" aria-label="Small" aria-describedby="inputGroup-sizing-sm" name="card_number">
                          <i class="fa fa-cc-visa" aria-hidden="true"></i>
                          <i class="fa fa-cc-mastercard" aria-hidden="true"></i>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="col-8 col-md-8">
                    <div class="row">
                      <div class="col-12 col-md-12">
                        <label for="basic-url">Card Type</label>
                        <div class="mb-3">
                          <select name="card_type" class="form-control ">
                            <option value='Visa'>Visa</option>
                            <option value='Master Card'>Master Card</option>
                            <option value='Discover'>Discover</option>
                            <option value="Diner's Club">Diner's Club</option>
                            <option value='American Express'>American Express</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>



                  <div class="col-12 col-md-12">
                    <div class="row">
                      <div class="col-4 col-md-4">
                        <label for="basic-url">Expiration Date</label>
                        <div class="mb-3">
                          <div class="form-row">
                            <div class="col-lg-6">
                              <input type="text" placeholder="MM" name="ex_date"  maxlength="2" class="form-control" required>
                            </div>
                            <div class="col-lg-6">
                              <input type="text" placeholder="YY" name="ex_year" maxlength="2" class="form-control" required>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div class="col-4 col-md-4">
                        <label data-toggle="tooltip" title="Three digit CV code on the back of your card" for="basic-url">CVV <i class="fa fa-question-circle d-inline"></i></label>
                        <div class="mb-3">
                          <div class="form-row">
                            <div class="col-lg-6">
                              <input type="password" required class="form-control" name="card_ver_num">
                            </div>
                          </div>
                        </div>
                      </div>

                    </div>
                  </div>


                  <input type="hidden" name="payment_types" id="payment_types" value="card_processing">
                  <div class="text-center mb-2">
                    <button name="deposit_card" class="auth_btn">Deposit</button>
                  </div>
                  <?php echo form_close();?> </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
      <!--Card Processing modal end-->

      <!--========================== Footer ============================-->
      <?php
      $this->load->view('front/common/footer');
      ?>
      <script src="http://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>
      <script type="text/javascript">

       var base_url='<?php echo base_url();?>';
       var front_url='<?php echo front_url();?>';

       var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';


       $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
        if (options.type.toLowerCase() == 'post') {
          options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
          if (options.data.charAt(0) == '&') {
            options.data = options.data.substr(1);
          }
        }
      });

       $( document ).ajaxComplete(function( event, xhr, settings ) {
        if (settings.type.toLowerCase() == 'post') {
          $.ajax({
            url: front_url+"get_csrf_token", 
            type: "GET",
            cache: false,             
            processData: false,      
            success: function(data) {
              var dataaa = $.trim(data);
              $("input[name="+csrfName+"]").val(dataaa);
            }
          });
        }
      });
       function copy_function(lang) 
       {
        $(".copy_but").css('display','block');
        var copyText = document.getElementById("crypto_address");
        copyText.select();
        document.execCommand("COPY");
        $('.copy_but').html(lang);
        $('.copy_but').delay(1000).fadeOut('slow');
      }

      function change_address(sel)
      {
        var arr1 = sel.value;
        var arr = arr1.split('#');
        var currency_id = arr[0];
        var type = arr[1];

        var selectedText = ($(sel).find("option:selected").text()).trim();
        if(selectedText=='BTC') selCoin = 'Bitcoin'; 
        else if(selectedText=='ETH') selCoin = 'Ethereum';
        else if(selectedText=='BCH') selCoin = 'BitcoinCash';
        else if(selectedText=='XRP') selCoin = 'Ripple';
        else if(selectedText=='EUR') selCoin = 'EURO';
        else if(selectedText=='BNB') selCoin = 'BinanceCoin';
        else if(selectedText=='USDT') selCoin = 'Tether';  
        else if(selectedText=='LIR') selCoin = 'eLira';  

        currency_txt = selCoin+'('+selectedText+')';

        $('.currency-txt').html(currency_txt);
        if((selectedText=='ETH')||(selectedText=='LIR')||(selectedText=='USDT')) {
          $('.ethereum_coin').show();
        } else {
          $('.ethereum_coin').hide();
        }
        $('.currency-txt-sym').html(selectedText);

        if(type=='fiat')
        {
                //alert(arr[0]);
                // $(".grey-box").css('display','none');
                $(".cryp_add").css('display','none');
                $(".dig_button").css('display','none');
                $(".fiat_div").css('display','block');
                $(".fiat_deposit").css('display','block');
                $('.det_tag').css('display','none');
                $.ajax({
                  url: base_url+"change_address",
                  type: "POST",
                  data: "currency_id="+currency_id,
                  success: function(data) {
                    var res = jQuery.parseJSON(data);
                    if(currency_id==7){
                      var sym = 'GHS';
                    }
                    $('#minimum_deposit').html(res.minimum_deposit+' '+sym);
                  }
                });
                $("#currency").val(currency_id);
                $(".currency").val(currency_id);
              }
              else
              { 
                $(".grey-box").css('display','block');
                $(".fiat_div").css('display','none');
                $(".cryp_add").css('display','block');
                $(".fiat_deposit").css('display','none');
                $('.bank_wire').css('display','none');
                $('.paypal_form').css('display','none');
                $(".dig_button").css('display','block');
                $("#wallet_deposit").css('display','none');

                $.ajax({
                  url: base_url+"change_address",
                  type: "POST",
                  data: "currency_id="+currency_id,
                  success: function(data) {
                    var res = jQuery.parseJSON(data);
                    $('#crypto_address').val(res.address);
                    $("#crypto_img").attr("src",res.img);
                    $('.det_tag').css('display','none');
                    $('#minimum_withdrawal').html(res.minimum_deposit);
                    $('.syname').html(res.coin_name);
                    $('.sym').html(res.coin_symbol);

                    pdf_url = '<?php echo base_url()?>download_pdf/'+res.coin_symbol+'/'+btoa(res.address);
                    $('#downloadpdf_btn').attr('href',pdf_url);
                        // console.log( btoa(res.address) )
                        if(currency_id==6){
                          $('.det_tag').css('display','block');
                          $('#destination_tag').val(res.destination_tag);
                        }

                      }
                    });
              }
            }


            function show_paypal(){
              $(".bank_wire").css("display","none");
              $('.paypal_form').css('display','');
            }

            function payment_status(id){

              $.ajax({
                url: base_url+"payment_status",
                type: "POST",
                data: "id="+id,
                success: function(data) {
                  var res = jQuery.parseJSON(data);

                  var msg = res.msg;
                  var status = res.status;
                  if(status=='Pending'){
                    $.growl.error({title: "Ixtokens", message: msg });
                  }
                  else if(status=='Completed'){
                    $.growl.notice({title: "Ixtokens", message: msg });
                    $('#dep'+id).html('<span class="green">Completed</span>');
                  }
                  else{
                    $.growl.error({title: "Ixtokens", message: msg });
                    $('#dep'+id).html('<span class="red">Cancelled</span>');
                  }

                }
              });
            }
            $('#deposit_mobile').validate(
            {
              rules: {
                mobile_number:{
                  required: true,
                  number: true
                },
                pay_name:{
                  required: true
                },
                amount: {
                  required: true,
                  number: true,
                },
                narration: {
                  required: true
                }
              },
              messages: {
                mobile_number:{
                  required:'Please enter mobile number',
                  number:'Please enter valid number'
                },
                pay_name:{
                  required: 'Please enter name',
                },
                amount: {
                  required: "Please enter amount",
                  number: "Only enter numbers as decimal or float"
                },
                narration: {
                  required: "Please enter Narration"          
                }
              },
              invalidHandler: function(form, validator) {
                if (!validator.numberOfInvalids())
                {
                  return;
                }
                else
                {
                  var error_element=validator.errorList[0].element;
                  error_element.focus();
                }
              },
              highlight: function (element) {
                //$(element).parent().addClass('error')
              },
              unhighlight: function (element) {
                $(element).parent().removeClass('error')
              },
              submitHandler: function(form) 
              { 
                form.submit();
              }
            });
            $.validator.addMethod("uploadPDF", function(value,element) {


            }, "Please upload the bankwire receipt pdf and try again!!!");

            $('#deposit_bank').validate(
            {
              rules: {
                amount: {
                  required: true,
                  number: true,
                },
                upload_pdf_deposit: {
                  required: true,
                  uploadPDF: true
                }
              },
              messages: {
                amount: {
                  required: "Please enter amount",
                  number: "Only enter numbers as decimal or float"
                },
                upload_pdf_deposit: {
                  required: "Please Upload PDF",
                  uploadPDF:"Please upload the bankwire receipt pdf and try again!!!"          
                }
              },
              invalidHandler: function(form, validator) {
                if (!validator.numberOfInvalids())
                {
                  return;
                }
                else
                {
                  var error_element=validator.errorList[0].element;
                  error_element.focus();
                }
              },
              highlight: function (element) {
                //$(element).parent().addClass('error')
              },
              unhighlight: function (element) {
                $(element).parent().removeClass('error')
              },
              submitHandler: function(form) 
              { 
                form.submit();
              }
            });

            $('#deposit_card').validate({
              rules: {
                amount: {
                  required: true,
                  number: true
                },           
                card_number: {
                  required: true,
                  number: true,
                  minlength: 16,
                  maxlength: 16
                },
                ex_date: {
                  required: true,
                  number: true,
                  max: 12
                },
                ex_year: {
                  required: true,
                  number: true,
                  min: 21
                },
                card_ver_num: {
                  required: true,
                  number: true
                }
              },
              messages: {
                holder_name: {
                  required: 'Please enter Holder Name',
                },
                amount_paypal: {
                  required: 'Please enter amount',
                  number: 'Please enter valid amount',
                },
                card_num: {
                  required: 'Please enter Card Number',
                  number: 'Please enter valid Card Number',
                  minlength: 'Please enter valid Card Number',
                  maxlength: 'Please enter valid Card Number'
                },
                ex_date: {
                  required: 'Please enter Expiry Date',
                  number: 'Please enter valid Expiry Date',
                  max: 'Please enter valid Expiry Date'
                },
                ex_year: {
                  required: 'Please enter Expiry Year',
                  number: 'Please enter valid Expiry Year',
                  min: 'Please enter valid Expiry Year'
                },
                card_ver_num: {
                  required: 'Please enter CVV',
                  number: 'Please enter valid CVV'
                }
              }
            });

            $('.upload_pdf').change(function() {
              filename = $('.upload_pdf').val();
              if(filename!='' && this.files[0].size < 2000000) {
                $('#upload_pdf_name').html(this.files[0].name);
                $('#upload_pdf_error').html("");
                $(".kyc-confirm-btn").css("display", "block");
              }
              else{
                $('#upload_pdf_name').html(this.files[0].name);
                $('#upload_pdf_error').html("Please upload file less than 2MB.");
                $(".kyc-confirm-btn").css("display", "none");
              }  

            });


          </script>


