<?php 
    $this->load->view('front/common/header');
    $user_id = $this->session->userdata('user_id');
    $segment = $this->uri->segment(2)

?>
<!--========================== Banner Section ============================-->
<link rel="stylesheet" href="<?php echo front_css();?>jquery.dataTables.min.css">
<style type="text/css">
    
.bs-tabs .nav-tabs { margin-bottom: 2px;
    background: #f4f4f4; }
    .bs-tabs .nav-tabs > li.active > a, .nav-tabs > li.active > a:focus, .nav-tabs > li.active > a:hover { border-width: 0; }
    .bs-tabs .nav-tabs > li > a { border: none; color: #000;padding: 10px 30px;       display: block;  background: #f4f4f4;}
        .bs-tabs .nav-tabs > li.active > a, .bs-tabs .nav-tabs > li > a:hover { border: none;  color: #000 !important; }
        .bs-tabs .nav-tabs > li > a::after { content: ""; height: 2px; position: absolute; width: 100%; left: 0px; bottom: -1px; transition: all 250ms ease 0s; transform: scale(0); }
    .bs-tabs .nav-tabs > li.active > a::after, .bs-tabs .nav-tabs > li:hover > a::after { transform: scale(1);  }
.bs-tabs .tab-nav > li > a::after {  color: #fff; }
.bs-tabs .tab-pane { padding: 15px 0; }
.bs-tabs .tab-content{padding:20px;     background: #f4f4f4;}
.bs-tabs .nav-tabs > li  {    /* width: 20%; */
    text-align: center;
    color: #000;

    margin-right: 2px;}
.bs-tabs .nav-tabs > li a.active  {
    background: #4699F2; color:#FFF !important;
}

@media all and (max-width:724px){
.bs-tabs .nav-tabs > li > a > span {display:none;}   
.bs-tabs .nav-tabs > li > a {padding: 5px 5px;}
}

#chart-area, #widget-container, .tv-main-panel {background: #000;}
.chart-page .chart-container {border: black solid 0;}

.u-sheet:not(.u-image):not(.u-video) > * {
pointer-events: auto;
pointer-events: initial;
}
.u-section-1 .u-image-1 {
width: 38px;
height: 60px;
margin: -38px 151px 0 auto;
}
img.u-image, .u-video-poster {
overflow: hidden;
}
.u-overlap.u-overlap-transparent .u-header, .u-image, .u-gradient {
color: #111111;
}
.u-image, .u-background-effect-image, .u-video-poster {
object-fit: cover;
display: block;
vertical-align: middle;
background-size: cover;
background-position: 50% 50%;
background-repeat: no-repeat;
}
.wrapper-scroll{ 
    overflow-y:scroll; 
    position:relative;
    height: 500px;
}
.wallet-table-btn {
  margin-left:1000px;
}
img.u-image.u-image-SQUARE.u-image-1 {
  width: 50px;
  height: 50px;
}
.transaction-img {
  width: 50px;
  height: 50px; 
}
.trans-table li a.active {
	box-shadow: 4px 4px 10px rgb(39 94 121 / 30%);
	padding: 15px;
	color: #fff;
	background: #4699F2;
	border-radius: 5px;
}
.marketslinqs {
	margin-top: 5px;
}
.trans-table {
	padding-bottom: 20px;
}
</style>
<!-- breadcrumb -->
<div class="me-breadcrumb">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <div class="me-breadcrumb-box">
          <h1><?=$this->lang->line('Transactions');?></h1>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="me-investment-single me-padder-top">
    <div class="container">
      <?php $this->load->view('front/user/sidebar_sticky');?>
      <div class="row">

  <div class="col-lg-12">
    <ul class="nav nav-tabs trans-table" role="tablist">
      <li class="">
          <a href="#tab-table1" class="active show" data-toggle="tab"><?=$this->lang->line('Wallet Transactions')?> </a>
      </li>
      <li style="margin-left:30px;">
          <a href="#tab-table2" data-toggle="tab"><?=$this->lang->line('Exchange Buy/Sell Transactions')?></a>
      </li>
    </ul>
     <div class="table-responsive mb-5">

      <div class="tab-content">
          <div class="tab-pane active" id="tab-table1">

       <table id="marketCms" class="display w-100 table wallet-table">
          <thead>
             <tr>
                  <th class="text-center"><?=$this->lang->line('QR code');?></th>
                  <th class="text-center"><?=$this->lang->line('Date & Time');?></th>
                  <th class="text-center"><?=$this->lang->line('Address of sender / receipient');?></th>
                  <th class="text-center"><?=$this->lang->line('Amount');?></th>
                  <th class="text-center"><?=$this->lang->line('Status');?></th>
                  <th class="text-center"><?=$this->lang->line('Send / Receive');?></th>
             </tr>
          </thead>
          <tbody class="price_table">
             <?php if(isset($history) && !empty($history)){ 
                foreach($history as $info){ 
                  
                  if($info->status=='Completed') $statusClr = 'green';
                  else $statusClr = 'red'; ?>  
              <tr>
                  <td class="text-center">
                    <?php if($info->crypto_address!='') {
                    $First_coin_image = 'https://chart.googleapis.com/chart?cht=qr&chs=280x280&chl='.$info->crypto_address.'&choe=UTF-8&chld=L';
                    ?>
                    <a href="javascript:;" onclick="call_qrcode(<?=$info->trans_id?>)"><img class="u-image u-image-SQUARE u-image-1" src="<?=$First_coin_image?>" alt="" data-image-width="400" data-image-height="265"></a>
                  <?php } else {?>
                    <p class="u-image u-image-SQUARE u-image-1">-</p>
                  <?php }?>
                  </td>
                  <td class="text-center"><?=date("d-m-Y H:i a", $info->datetime)?></td> 
                  <td class="text-center"><?=$info->crypto_address?></td>
                  <td class="text-center"><?=number_format($info->amount,8)?></td>
                  <td class="text-center" style="color: <?=$statusClr?>"><?=$info->status?></td>
                  <td class="text-center"><?php if($info->type=='Deposit') {
                    $trans = 'Received';
                    ?>
                    <img class="transaction-img" src="<?=front_img()?>receiver.png">
                  <?php } elseif($info->type=='Withdraw') {
                    $trans = 'Sent';
                  ?>
                    <img class="transaction-img" src="<?=front_img()?>sender.png">
                  <?php } ?>
                  </td>

                  <div class="modal fade" id="exampleModal<?=$info->trans_id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content" >
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">QR Code</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                            <div class="modal-body" style="padding:100px;height:550px">
                                <span class="">
                                  <img style="max-width: 100%; height: 300px;width: auto;" class="u-image u-image-SQUARE u-image-1" src="<?=$First_coin_image?>" alt="" >
                                  </span>
                            </div>
                        </div>
                    </div>
                </div>
                </tr>
            <?php } }?>     
          </tbody>
       </table>
      </div>
      <div class="tab-pane " id="tab-table2"> 
        <table id="myTable2" class="display w-100 table wallet-table">
          <thead>
              <tr>
                  <th class="text-left">S.No</th>
                  <th class="text-left"><?=$this->lang->line('Date & Time');?></th>
                  <th class="text-left">Pair</th>
                  <th class="text-left"><?=$this->lang->line('Amount');?></th>
                  <th class="text-left">Price</th>
                  <th class="text-left">Fee</th>
                  <th class="text-left">Total</th>
                  <th class="text-left">Trade</th>
                  <th class="text-left">Type</th>
                  <th class="text-left">Status</th>
              </tr>
          </thead>
          <tbody></tbody>
        </table> 
    
        </div>
    </div>

          </div>
          </div>
      </div>
    </div>
  </div>



<!--========================== Footer ============================-->
<?php
$this->load->view('front/common/footer');
    ?>
<script type="text/javascript" src="<?php echo front_js();?>dataTables.min.js"></script>
<script type="text/javascript" src="<?php echo front_js();?>datatables.bootstrap4.min.js"></script>

<script>
$(document).ready(function() {
  $('a[data-toggle="tab"]').on( 'shown.bs.tab', function (e) {
      $.fn.dataTable.tables( {visible: true, api: true} ).columns.adjust();
  });
});  

cid = '<?=$history[0]->currency_id?>';
export_btn = 'Export PDF'; 
search_coin_name = 'Search';   
next = '<?=$this->lang->line('Next');?>';   
previous = '<?=$this->lang->line('Previous');?>'; 
no_data = '<?=$this->lang->line('No data available in table');?>';   
no_entry = '<?=$this->lang->line('Showing 0 to 0 of 0 entries');?>';   
show_entry = '<?=$this->lang->line('Showing _START_ to _END_ of _TOTAL_ entries Transaction');?>';   
filtered = '<?=$this->lang->line('(filtered from _MAX_ total entries)');?>'; 

 var marketCmsTable = $('#marketCms').DataTable( {
     // "order": [[ 5, "desc" ]],
     "pageLength": 10,
     "lengthChange": false,
     language: { 
         search: '<i class="fa fa-search"></i>',
         searchPlaceholder: search_coin_name,
         'paginate': {
          'previous': previous,
          'next': next,
        },
     },
     oLanguage: {
        "sEmptyTable": no_data,
        "infoEmpty": no_entry,
        "info": show_entry,
        "infoFiltered": filtered
     },
     'aoColumnDefs': [{
         'bSortable': false,  
         'aTargets': [-1] 
     }],
 });

var base_url='<?=base_url(); ?>';
var seg = '<?=$segment?>';
  var tradeTable = $('#myTable2').DataTable( {
     // "pageLength": 10,
     "lengthChange": false,
     language: { 
         search: '<i class="fa fa-search"></i>',
         searchPlaceholder: search_coin_name,
         'paginate': {
          'previous': previous,
          'next': next,
        },
     },
     oLanguage: {
        "sEmptyTable": no_data,
        "infoEmpty": no_entry,
        "info": show_entry,
        "infoFiltered": filtered
     },
     'aoColumnDefs': [{
         'bSortable': false,  
         'aTargets': [-1] 
     }],
     'responsive' : true,
      "processing" : true,
      "pageLength" : 10,
      "serverSide": true,
      "order": [[0, "asc" ]],
      "searching": true,
      "ajax": base_url+"trade_ajax/"+seg
 });
 
if(cid!='') {
  $('#marketCms_wrapper > .row:first-child > div:first-child').append('<ul class="marketslinqs d-flex" id="marketCms"><li><a class="btn me-AddressBook" href="<?=base_url()?>transaction_history_pdf/'+cid+'">'+export_btn+'</a></li></ul>');  
}         



function call_qrcode(trans_id) {
  $('#exampleModal'+trans_id).modal('show');
}
    
  
</script>


