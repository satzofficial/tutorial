<?php 
    $sitelan = $this->session->userdata('site_lang'); 
    $this->load->view('front/common/inner_header'); 
    $user_id=$this->session->userdata('user_id');
    $name = $sitelan."_name";
    $heading = $sitelan."_heading";
    $content = $sitelan."_content";
?>
    <section class="main-inner-pages">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="inner-page-header">
                        <h2>User History <span><img src="<?=front_img()?>line.png"></span></h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <ul class="nav nav-pills custom_pills" id="settings_tab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <a class="nav-link active" id="openOrders-tab" data-toggle="tab" href="#Deposit" role="tab" aria-controls="openOrders" aria-selected="true">Deposit History</a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" id="Withdraw-tab" data-toggle="tab" href="#Withdraw" role="tab" aria-controls="Withdraw" aria-selected="false">Withdraw HISTORY</a>
                        </li>
                         <li class="nav-item" role="presentation">
                            <a class="nav-link" id="Login-tab" data-toggle="tab" href="#Login" role="tab" aria-controls="Login" aria-selected="false">Login History</a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" id="Instant-tab" data-toggle="tab" href="#Instant" role="tab" aria-controls="Instant" aria-selected="false">InstantBuy History</a>
                        </li>
                    </ul>
                    <div class="dash-profile-body background-grey">                      
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="Deposit" role="tabpanel" aria-labelledby="openOrders-tab">
                                <div class="navTabsTbl openOdrsTbl table-responsive">
                                    <table class="table mb-0 table-borderless">
                                        <thead>
                                            <tr>
                                                <th><?php echo $this->lang->line('S.no')?></th>
                                                <th><?php echo $this->lang->line('Date & Time')?></th>
                                                <th><?php echo $this->lang->line('Currency')?></th>
                                                <th>Transaction ID</th>
                                                <th>Amount</th>
                                               <!--  <th>Address</th> -->
                                                <th><?php echo $this->lang->line('Status')?></th>
                                            </tr>
                                        </thead>
                                        <tbody class="opnOdrTblScroll">
                                            <?php
                                                if(isset($deposit_history) && !empty($deposit_history))
                                                {
                                                    $a=0;
                                                    foreach($deposit_history as $deposit)
                                                    {
                                                        $a++;
                                                        if($deposit->transaction_id == '')
                                                        {
                                                          $transaction_id = '-';
                                                        }
                                                        else
                                                        {
                                                          $transaction_id = $deposit->transaction_id;
                                                        }     
                                            ?>
                                                        <tr>
                                                            <td><?php echo $a;?></td>
                                                            <td><?php echo date('d-M-Y H:i',$deposit->datetime);?></td>
                                                            <td><?php echo strtoupper(getcryptocurrency($deposit->currency_id));?></td>
                                                            <td>#<?php echo $transaction_id;?></td>
                                                            <td><?php echo number_format($deposit->amount,8);?></td>
                                                            
                                                            
                                                            <!-- <td><?php echo $deposit->crypto_address;?></td> -->
                                                            <?php if($deposit->status =='Completed')
                                                            {
                                                                $clr_class = 'text-green';
                                                            }
                                                            else
                                                            {
                                                                $clr_class = 'text-red';
                                                            } ?>                   

                                                            <td class="<?php echo $clr_class;?>"><?php echo $deposit->status;?></td>
                                                        </tr>
                                            <?php 
                                                    }
                                                }   
                                                else
                                                { 
                                            ?>
                                                    <tr>
                                                        <td colspan="7">
                                                            <div class="alert alert-danger text-center">No records found !!!</div>
                                                        </td>
                                                    </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="Withdraw" role="tabpanel" aria-labelledby="Withdraw-tab">
                                <div class="navTabsTbl openOdrsTbl tradeHisTbl table-responsive">
                                    <table class="table mb-0 table-borderless">
                                        <thead>
                                            <tr>
                                                <th><?php echo $this->lang->line('S.no')?></th>
                                                <th><?php echo $this->lang->line('Date & Time')?></th>
                                                <th><?php echo $this->lang->line('Currency')?></th>
                                                <th><?php echo $this->lang->line('Sent Amount')?></th>
                                                <th><?php echo $this->lang->line('Fees')?></th>
                                                <th><?php echo $this->lang->line('Receive Amount')?></th>
                                                <th><?php echo $this->lang->line('Status')?></th>
                                            </tr>
                                        </thead>
                                        <tbody class="tradeHistoryTblScroll">
                                            <?php
                                                if(isset($withdraw_history) && !empty($withdraw_history))
                                                {
                                                    $b=0;
                                                    foreach($withdraw_history as $withdraw)
                                                    {
                                                        $b++;
                                            ?>
                                                        <tr>
                                                            <td><?php echo $b;?></td>
                                                            <td><?php echo date('d-M-Y H:i',$withdraw->datetime);?></td>
                                                            <td><?php echo strtoupper(getcryptocurrency($withdraw->currency_id));?></td>
                                                            <td><?php echo number_format($withdraw->amount,8);?></td>
                                                            <td><?php echo number_format($withdraw->fee,8);?></td>
                                                            <td><?php echo number_format($withdraw->transfer_amount,8);?></td>
                                                            <?php 
                                                                if($withdraw->status =='Completed')
                                                                {
                                                                    $elmt_class = 'text-green';

                                                                }
                                                                else
                                                                {
                                                                    $elmt_class = 'text-red';
                                                                } 
                                                            ?> 
                                                            <td class="<?php echo $elmt_class; ?>"><?php echo $withdraw->status;?></td>
                                                        </tr>
                                            <?php 
                                                    } 
                                                }
                                                else
                                                { 
                                            ?>
                                                    <tr>
                                                        <td colspan="7"><div class="alert alert-danger text-center">No records found !!!</div></td>
                                                    </tr>
                                            <?php 
                                                } 
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="Login" role="tabpanel" aria-labelledby="Login-tab">
                                <div class="navTabsTbl openOdrsTbl table-responsive">
                                    <table class="table mb-0 table-borderless">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th><?php echo $this->lang->line('Date & Time');?></th>
                                                <th><?php echo $this->lang->line('IP Address');?> </th>
                                                <th><?php echo $this->lang->line('Browser');?></th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody class="opnOdrTblScroll">
                                            <?php
                                                if(isset($login_history) && !empty($login_history)){
                                                    $d=0;
                                                    foreach($login_history as $login){
                                                        $d++;
                                            ?>

                                                        <tr>
                                                            <td><?php echo $d;?></td>
                                                            <td><?php echo date('d-m-Y h:i a',$login->date);?></td>
                                                            <td><?php echo $login->ip_address;?></td>
                                                            <td><?php echo $login->browser_name?><?php //echo $login->browser_name;?></td>
                                                          
                                                             <td><?php echo $this->lang->line($login->activity);?></td>
                                                        </tr>  
                                            <?php
                                                    }
                                                } else {
                                            ?>
                                                <tr>
                                                    <td colspan="7"><div class="alert alert-danger text-center">No records found !!!</div></td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="Instant" role="tabpanel" aria-labelledby="Instant-tab">
                                <div class="navTabsTbl openOdrsTbl table-responsive">
                                       <table class="table mb-0 table-borderless">
                                        <thead>
                                            <tr>
                                                <th><?php echo $this->lang->line('S.no')?></th>
                                                <th><?php echo $this->lang->line('Date & Time')?></th>
                                                <th><?php echo $this->lang->line('Currency')?></th>
                                                <th><?php echo $this->lang->line('Sent Amount')?></th>
                                                <!-- <th><?php echo $this->lang->line('Fees')?></th> -->
                                                <th><?php echo $this->lang->line('Receive Amount')?></th>
                                                <th><?php echo $this->lang->line('Status')?></th>
                                            </tr>
                                        </thead>
                                        <tbody class="tradeHistoryTblScroll">
                                            <?php
                                                if(isset($instantbuy_history) && !empty($instantbuy_history)){
                                                    $c=0;
                                                    foreach($instantbuy_history as $instant_buy){
                                                        $c++;
                                            ?>
                                                        <tr>
                                                            <td><?php echo $c;?></td>
                                                            <td><?php echo date('d-M-Y H:i',strtotime($instant_buy->datetime));?></td>
                                                            <td><?php echo strtoupper(getcryptocurrency($instant_buy->currency_id));?></td>
                                                            <td><?php echo number_format($instant_buy->amount,8);?></td>
                                                            <!-- <td><?php echo number_format($instant_buy->fee,8);?></td> -->
                                                            <td><?php echo number_format($instant_buy->transfer_amount,8);?></td>
                                                            <?php 
                                                                if($instant_buy->status =='Completed')
                                                                {
                                                                    $elmt_class = 'text-green';

                                                                }
                                                                else
                                                                {
                                                                    $elmt_class = 'text-red';
                                                                } 
                                                            ?> 
                                                            <td class="<?php echo $elmt_class; ?>"><?php echo $instant_buy->status;?></td>
                                                        </tr>
                                            <?php 
                                                    } 
                                                }else{ 
                                            ?>
                                                    <tr>
                                                        <td colspan="7"><div class="alert alert-danger text-center">No records found !!!</div></td>
                                                    </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $this->load->view('front/common/footer'); ?>
<?php $this->load->view('front/common/scripts'); ?>