<?php 
    $this->load->view('front/common/header');
    $user_id = $this->session->userdata('user_id');
?>
<style>
.table_panel_body thead tr th.datetime, tbody.table_scroll tr td.datetime {
    width: 315px;
}    
</style> 
<!-- breadcrumb -->
<div class="me-breadcrumb">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="me-breadcrumb-box">
            <h1><?=$this->lang->line('Support');?></h1>
            <!-- <p><a href="<?php echo base_url();?>"><?=$this->lang->line('Home');?></a><?=$this->lang->line('Support');?></p> -->
          </div>
        </div>
      </div>
    </div>
</div>


<main id="main"> 
  <section class="inner-pages">
    <div class="container">
        <?php if($this->session->userdata('user_id')!='') {
            $this->load->view('front/user/sidebar_sticky');  
          }?>
            <div class="row mt-2">
                <div class="col-lg-12">
                    <div class="dash-profile-body background-grey">
                        <div class="support-sec">
                            <div class="support-head">
                                <h2><?=$this->lang->line('Create your ticket');?></h2>
                            </div>
                            <?php $attributes=array('id'=>'support_form','class'=>'deposit_form profile-edit-sec'); echo form_open_multipart($action,$attributes); ?>     
                                <div class="form-group">
                                    <label for="formGroupExampleInput" class="col-form-label"><?=$this->lang->line('Subject');?></label>
                                    <input type="text" class="form-control" name="subject" id="subject" placeholder="">
                                </div>
                                <div class="form-group">
                                    <label for="formGroupExampleInput" class="col-form-label"><?=$this->lang->line('Category');?></label>
                                    <select class="custom-select" name="category" id="category">
                                        <?php foreach ($category as $category_value) { ?>
                                            <option value="<?php echo $category_value->id; ?>"><?php echo $category_value->name; ?></option>             
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="formGroupExampleInput" class="col-form-label"><?=$this->lang->line('Message');?></label>
                                    <textarea class="form-control" id="message" name="message" rows="3" placeholder=""></textarea>
                                </div>
                                <div class="support-upload-btn">
                                    <div class="input-group mb-3">
                                        <div class="custom-file">
                                            <input type="file" class="custom-file-input" name="image" id="image">
                                            <label class="custom-file-label" id="preview_imgname" for="inputGroupFile02"><?=$this->lang->line('Browse files');?></label>
                                        </div>
                                        <div class="input-group-append">
                                            <span class="input-group-text" id=""><?=$this->lang->line('Upload');?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="profile-edit-sec">
                                    <div class="row">
                                        <div class="col-lg-4"></div>
                                        <div class="text-left mt-3 mb-2 col-lg-8"><button name="submit_tick" class="auth_btn"><?=$this->lang->line('Submit');?></button></div>
                                    </div>

                                </div>

                            <?php echo form_close();?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="table_panel">
                        <div class="table_panel_heading d-flex justify-content-between align-items-center">
                            <h2><?=$this->lang->line('Support History');?></h2>
                            <input type="text" class="form-control search_input" id="search" placeholder="Search">
                        </div>
                        <div class="table_panel_body">
                            <div class="table-responsive">
                                <table class="table table-borderless">
                                    <thead>
                                        <tr>
                                            <th class="address"><?=$this->lang->line('Ticket ID');?></th>
                                            <th class="datetime"><?=$this->lang->line('Date & Time');?></th>
                                            <!-- <th><?=$this->lang->line('User Name');?></th> -->
                                            <th><?=$this->lang->line('Subject');?></th>
                                            <th><?=$this->lang->line('Status');?></th>
                                        </tr>
                                    </thead>
                                    <tbody class="table_scroll">
                                        <?php
                                        if(isset($support) && !empty($support)) { $a=0;
                                            $username = UserName($this->session->userdata('user_id'), $prefix.'username');

                                            foreach(array_reverse($support) as $support_list) { $a++;
                                                if($support_list->close==0){
                                                    $ticket_type = "open-black";
                                                }else{
                                                    $ticket_type = "close-red";
                                                }?>
                                        <tr>
                                            <td class="address"><?=$support_list->ticket_id?></td>
                                            <td class="datetime"><?=date("m/d/Y h:i a",$support_list->created_on)?></td>
                                            <!-- <td><?=$username?></td> -->
                                            <td><?=$support_list->subject?></td>
                                            <td >
                                                <?php if($support_list->close==0){
                                                    echo '<a class="'.$ticket_type.'" href='.base_url().'support_reply/'.$support_list->ticket_id.'>'.$this->lang->line('Open').'</a>';
                                                  } else{
                                                    echo '<a class="'.$ticket_type.'" href='.base_url().'support_reply/'.$support_list->ticket_id.'>'.$this->lang->line('Closed').'</a>';
                                                  }?>
                                            </td>

                                        </tr>
                                        
                                        <?php }} else { ?>
                                         <tr>
                                            <td colspan="5">
                                                <div class="alert alert-danger text-center"><?=$this->lang->line('No records found !!!');?></div>
                                            </td>
                                         </tr>
                                        <?php } ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

    </div>
  </section>
</main>
<!-- End #main --> 


  


    <!--========================== Footer ============================-->
   <?php 
    $this->load->view('front/common/footer');
    $user_id    = $this->session->userdata('user_id');
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $get_os     = $_SERVER['HTTP_USER_AGENT'];
    ?>

    <script type="text/javascript">
         var base_url='<?php echo base_url();?>';
    var front_url='<?php echo front_url();?>';
    var user_id='<?php echo $user_id;?>';
    var ip_address = '<?php echo $ip_address;?>';
    var get_os     = '<?php echo $get_os;?>';

    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';


    $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
        if (options.type.toLowerCase() == 'post') {
            options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
            if (options.data.charAt(0) == '&') {
                options.data = options.data.substr(1);
            }
        }
    });

    $( document ).ajaxComplete(function( event, xhr, settings ) {
        if (settings.type.toLowerCase() == 'post') {
            $.ajax({
                url: front_url+"get_csrf_token", 
                type: "GET",
                cache: false,             
                processData: false,      
                success: function(data) {

                     $("input[name="+csrfName+"]").val(data);
                }
            });
        }
    });

     $('#support_form').validate({
        rules: {
            subject: {
                required: true
            },
            message: {
                required: true
            }
        },
        messages: {
            subject: {
                required: "Please enter subject"
            },
            message: {
                required: "Please enter message"
            }
        }
    });
 $('input[type=file]#image').change(function(){ 
    var file_name = $("#image").val();
    $('#image_name').html(file_name);
    var ext = $('#image').val().split('.').pop().toLowerCase();
    if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) {
        $("#img_error").html("Please upload proper file format");
        $(':button[type="submit"]').prop('disabled', true);
    }
    else{  
     $("#img_error").html('');
     $(':button[type="submit"]').prop('disabled', false); 
    }
  });

 $('#image').change(function() {
    var filename = $('#image').val();
    if (filename.substring(3,11) == 'fakepath') {
        filename = filename.substring(12);
    } 
    $("label[for='inputGroupFile02']").html(filename);
    
});
</script>