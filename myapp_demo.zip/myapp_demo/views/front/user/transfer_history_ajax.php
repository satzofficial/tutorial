<?php
$dummy_user = dummyuserImg();
if($peer_peer_trans_history_obj){
  $user_id = $this->session->userdata('user_id');
  $prefix=get_prefix();
  $prefix = get_prefix();
  $fname = $prefix.'fname';
  $lname = $prefix.'lname';
  $red_icon = '<svg xmlns="http://www.w3.org/2000/svg" class="icon send-icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
        <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
        <line x1="21" y1="17" x2="3" y2="17"></line>
        <path d="M18 4l3 3l-3 3"></path>
        <path d="M18 20l3 -3l-3 -3"></path>
        <line x1="21" y1="7" x2="3" y2="7"></line>
      </svg>';
  $green_icon = '<svg xmlns="http://www.w3.org/2000/svg" class="icon recived-icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="#2fb344" stroke-linecap="round" stroke-linejoin="round">
        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
        <line x1="3" y1="7" x2="21" y2="7" />
        <path d="M6 20l-3 -3l3 -3" />
        <path d="M6 4l-3 3l3 3" />
        <line x1="3" y1="17" x2="21" y2="17" />
      </svg>';
foreach($peer_peer_trans_history_obj as $history_value){
$sender_id = $history_value->sender_id;
$receiver_id = $history_value->receiver_id;
$local_transaction_id = $history_value->local_transaction_id;

// if($sender_id == $user_id && $history_value->type == 'send'){
if($sender_id == $user_id){
  if($history_value->type == 'send'){
    $statement = 'Transfer ';   
    $only_for = 0; 
  }else{
    $only_for = 1; 
    $statement = 'Requested ';
  }
  
  $at = 'to'; 
  $color = 'red';
  $cc = 'danger';
  $dot = 'bg-soft-danger';
  $image = user_id_to_unique_id($receiver_id, true);  
  $to_user_id_name  = ($history_value->receive_fname) ? $history_value->receive_fname :''; 
  $date_ago = time_calculator($history_value->timestamp);
  $date = timestamp_UTC_conversion($history_value->timestamp);  
  $pp_status = ($image['profile_picture']) ? $image['profile_picture'] : false;
  // $pp_status = is_image($image['profile_picture']) ? $image['profile_picture'] : false;
  $img = ($image['profile_picture']) ? $image['profile_picture'] : false;
  $a = ($history_value->amount) ? my_number_format($history_value->amount) : 0.00;
  $unique_id = user_id_to_unique_id($receiver_id);
  $icon = $red_icon;
}else{

  if($history_value->type == 'send'){
    $statement = 'Transfer ';  
    $only_for = 0; 
  }else{
    $only_for = 1; 
    $statement = 'Requested ';
  }
  
  $icon = $green_icon;
  $at = 'from';  
  $color = 'green';
  $dot = 'bg-lime-lt';
  $cc = 'success';  
  $image = user_id_to_unique_id($sender_id, true);   
  $to_user_id_name  = ($history_value->send_fname) ? $history_value->send_fname :'';   
  // $to_user_id_name  = ($history_value->receiver_id) ? $history_value->receiver_id :'';
  $date_ago = time_calculator($history_value->timestamp);
  $date = timestamp_UTC_conversion($history_value->timestamp);  
  // $pp_status = is_image($image['profile_picture']) ? $image['profile_picture'] : false;
  $pp_status = ($image['profile_picture']) ? $image['profile_picture'] : false;
  $img = ($image['profile_picture']) ? $image['profile_picture'] : false;
  $a = ($history_value->amount) ? my_number_format($history_value->amount) : 0.00;
  $unique_id = user_id_to_unique_id($sender_id);
  
}
?>
  <tr class="<?php if($only_for == 1){ echo 'user-request-callover'; }?> bg-<?php echo $color; ?>-lt" <?php if($only_for == 1){ ?>  data-id="<?php echo ($unique_id)??''; ?>"  data-amt=<?php echo $a;?> <?php } ?>>    
    <td><div class="widget-26-job-title"> <a href="#"><?php echo '#'.$local_transaction_id; ?>  <?php echo $statement; ?> <?php echo $at; ?> <span class="avatar" <?php if($pp_status){ ?>style="background-image: url('<?php echo $img; ?>')" <?php }else{  ?> 
      style="background-image: url('<?php echo $dummy_user; ?>')" <?php  } ?> > </span> <?php echo $to_user_id_name; ?>
      <span class="req-unique-id" data-id="<?php echo ($unique_id) ? '( '. $unique_id .' )' : ''; ?>">
        <?php echo ($unique_id) ? '( '. $unique_id .' )' : ''; ?></span> </a>
      <p class="m-0"><?php echo $date;?> <span class="time">UTC <?php echo $date_ago; ?></span></p>
    </div></td>
    <td><div class="widget-26-job-category <?php echo $dot; ?>"> <i class="indicator bg-<?php echo $cc; ?>"></i> <span><?php echo $a;?> EMD</span> </div></td>
    <td><div class="widget-26-job-starred"> <a href="#">
      <?php echo $icon; ?>
    </a></div></td>    
  </tr>
<?php } }else{ 
echo '<tr><td align="center">';
echo '<label style="text-align:center;">There are no user\'s transactions<label>';
echo '</td></tr>';
}  ?>