<?php include realpath(dirname(__DIR__) . '/common/inner_header.php'); ?>
<?php
$unique_id = ($users->unique_id) ? $users->unique_id :'';
$wlink = base_url()."register?ref=".$unique_id;
?>
<div class="page-body">
  <div class="container-xl">
    <div class="row row-deck row-cards">
      <div class="col-md-12">
        <div class="card shadow radius-20">
          <div class="card-body">
            <div class="row g-2 align-items-center">
              <div class="col-lg-4">
                <div class="row g-2 align-items-center">
                  <div class="col-auto text-center w-100"> <span class="avatar avatar-lg" style="border-radius:100%; background-image: url('<?php echo $pp; ?>')"></span> </div>
                  <div class="col-12">
                    <div class="card-body p-0 ">
                      <div class=" text-center">
                        
                        <?php 
                        if($current_package_payment){                                       
                          ?>

                          <div class="subheader">ID: <span id="get_unique_id_values"><?php echo preg_replace('/(?<=\d)(?=(\d{4})+$)/', ' ', $unique_id); ?></span>
                            <?php if($users->tenrealm_phone){ ?>
                            <a target="_blank" href="https://wa.me/<?php echo ($users->tenrealm_phone) ?? ''; ?>?text=Hi, My reference link is <?php echo $wlink; ?>">
                              <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                <path d="M3 21l1.65 -3.8a9 9 0 1 1 3.4 2.9l-5.05 .9" />
                                <path d="M9 10a0.5 .5 0 0 0 1 0v-1a0.5 .5 0 0 0 -1 0v1a5 5 0 0 0 5 5h1a0.5 .5 0 0 0 0 -1h-1a0.5 .5 0 0 0 0 1" />
                              </svg>
                            </a>
                            <?php } ?>
                            <a href="javascript:;" id="copy32343534" class="copy32343534">
                              <input type="hidden" value="<?php echo $wlink; ?>" name="hlink" id="hlink" class="hlink">
                              <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                <path d="M10 14a3.5 3.5 0 0 0 5 0l4 -4a3.5 3.5 0 0 0 -5 -5l-.5 .5" />
                                <path d="M14 10a3.5 3.5 0 0 0 -5 0l-4 4a3.5 3.5 0 0 0 5 5l.5 -.5" />
                              </svg>
                            </a>
                            <div id="show_copied_to_clipboard" style="display: none;color:green;">Copied</div>
                          </div>
                        <?php } ?>

                        <div class="small mt-1"> Last Activity : <span><strong><?php echo (isset($login_history['date'])) ? timestamp_UTC_conversion($login_history['date'], 'jS F Y, H:i') : '';?></strong></span></div>
                        <div class="small mt-1"> Total Earning</div>
                        <div class="h1 mb-0 font-weight-bold"><?php echo ($pym = get_pym_Balance($user_id)) ? number_format($pym,2) : 0  ?><span class="small text-h4">PYM</span></div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6 mt-3">
                    <div class="card card-sm bg-azure-lt border-0"  >
                      <div class="card-body">
                        <div class="row align-items-center">
                          <div class="col-auto p-0 "> <span class="text-blue avatar bg-none">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                              <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                              <line x1="12" y1="5" x2="12" y2="19" />
                              <line x1="18" y1="13" x2="12" y2="19" />
                              <line x1="6" y1="13" x2="12" y2="19" />
                            </svg>
                          </span> </div>
                          <div class="col">
                            <div class="font-weight-bold h5 m-0"><?php echo ($pym = get_pym_Balance($user_id)) ? number_format($pym,2) : 0  ?><span class="small text-h6"> PYM</span></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <a href="#" class="btn btn-azure w-100 mt-2 btn-grad custome-btn"> Available Balance </a> </div>
                    <div class="col-sm-6 mt-3">
                      <div class="card card-sm  bg-azure-lt border-0">
                        <div class="card-body">
                          <div class="row align-items-center">
                            <div class="col-auto p-0"> <span class="text-blue avatar bg-none">
                              <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                <line x1="12" y1="5" x2="12" y2="19" />
                                <line x1="18" y1="11" x2="12" y2="5" />
                                <line x1="6" y1="11" x2="12" y2="5" />
                              </svg>
                            </span> </div>
                            <div class="col">
                              <div class="font-weight-bold h5 m-0"> 228,022.00<span class="small text-h6"> PYM</span></div>
                              <!--   <div class="text-muted"> Income </div>--> 
                            </div>
                          </div>
                        </div>
                      </div>
                      <a href="#" class="btn btn-indigo w-100 mt-2 btn-grad cmn-btn"> Total Withdraw </a> </div>
                    </div>
                  </div>
                  <div class="col-lg-4">
                    <div class="row g-2 align-items-center">
                      <div class="col">
                        <div class="card-body tencardd p-0 text-center ">
                          <h3 class="card-title">Current Package</h3>
                          <div class="vh-40 position-relative w-100" style="background: 
                          url(<?php echo $assets_url_var; ?>static/emty-card.png);background-size: contain;background-repeat: no-repeat;">
                          <div class="col-12 w-90 text-right text-white"  >
                            <h1 class="plan-no" ><?php 
                            if($packages){
                              $package_name='';
                              foreach ($packages as $pkey => $package) { 
                                if(in_array($package['id'], $user_package_arr)){
                                  $package_id = $package['id'];
                                  $package_name = $this->db->select('package_name')->get_where('package', ['id' => $package_id])->row('package_name');
                                }
                              }
                              echo $package_name;
                            }

                            ?></h1>
                          </div>
                          <div class="col-12 text-white"  >
                            <h1 class="card-no" ><?php echo preg_replace('/(?<=\d)(?=(\d{4})+$)/', ' ', $unique_id); ?></h1>
                          </div>
                          <div class="col-12 text-white"  >
                            <h1 class="amt-no" ><?php 
                            if($current_package_payment){  
                              if($package_id){
                                $price = package_price($package_id);
                                $pp = ($p = ($price)) ? $p : 0;
                                echo $pp ."\t" . 'PYM';
                              }              
                            }
                            ?></h1>
                          </div>                        
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-4">
                  <div class="row g-2 align-items-center">
                    <div class="col">
                      <div class="card-body p-0 ">
                        <div class="card border-0 shadow-n" style="height: calc(16rem + 10px)">
                          <div class="card-body card-body-scrollable card-body-scrollable-shadow">
                            <div class="divide-y">
                              <?php 
                              if($packages){
                                foreach ($packages as $pkey => $package) {           

                                  if(in_array($package['id'], $user_package_arr)){
                                    $avatar = 'avatar bg-green-lt';
                                    $badge = 'badge bg-green';
                                  }else{
                                    $avatar = 'avatar bg-red-lt';
                                    $badge = 'badge bg-red'; 
                                  }
                                  ?>
                                  <div class="atv-mlm">
                                    <div class="row ">
                                      <div class="col-auto"> <span class="<?php echo $avatar; ?>">                                       
                                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                          <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                          <circle cx="12" cy="7" r="4" />
                                          <path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2" />
                                        </svg>
                                      </span> </div>
                                      <div class="col">
                                        <div class="text-truncate"> <strong><?php echo ucfirst(($package['package_name'])?$package['package_name']:''); ?></strong> </div>
                                      </div>
                                      <div class="col-auto align-self-center">
                                        <div class="<?php echo $badge; ?>"></div>
                                      </div>
                                    </div>
                                  </div>
                                <?php } } ?>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-12 col-lg-8">
            <div class="card card-sm  shadow radius-20">
              <div class="card-header">
                <h3 class="card-title"> Wallets </h3>
                  </div>
                  <div class="card-body">
                    <div class="row p-2">
                      <div class="col-sm-6 col-lg-3 mb-2">
                        <div class="card with-radial-gradient">
                          <div class="empty p-2">
                            <div class="empty-img"><img src="<?php echo $assets_url_var; ?>static/illustrations/undraw_quitting_time_dm8t.svg" height="128"  alt=""> </div>
                            <h4 class="">MAIN BALANCE</h4>
                            <div class="text-muted "><span class="main-balance-amount-status"> <?php $main_balance=($sum_user_level_income + $sum_user_global_income + $sum_user_sponsor_income);
                              echo ($main_balance) ? number_format($main_balance, 2) : 0;
                             ?> </span> <span class="small text-h6"> PYM</span> </div>            
                          </div>
                        </div>
                      </div>
                      <div class="col-sm-6 col-lg-3 mb-2">
                        <div class="card with-radial-gradient">
                          <div class="empty p-2">
                            <div class="empty-img"><img src="<?php echo $assets_url_var; ?>static/illustrations/undraw_quitting_time_dm8t.svg" height="128"  alt=""> </div>
                            <h4 class="">LEVEL INCOME</h4>
                            <div class="text-muted"><span class="claim-amount-status"> <?php echo (!empty($sum_user_level_income))? number_format($sum_user_level_income, 2) : 0 ?></span> <span class="small text-h6"> PYM</span> </div>
                            <div class="empty-action"><div class="claim-status" ></div> <a href="javascript:;" class="btn btn-grad border-0 level-income-claim" data-type="level"> CLAIM </a> </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-sm-6 col-lg-3 mb-2">
                        <div class="card with-radial-gradient">
                          <div class="empty p-2">
                            <div class="empty-img"><img src="<?php echo $assets_url_var; ?>static/illustrations/undraw_quitting_time_dm8t.svg" height="128"  alt=""> </div>
                            <h3 class="">GLOBAL INCOME</h3>
                            <div class="text-muted"><span class="claim-amount-status"> <?php echo (!empty($sum_user_global_income)) ? number_format($sum_user_global_income, 2) : 0 ?></span> <span class="small text-h6"> PYM</span> </div>
                            <div class="empty-action"> <div class="claim-status" ></div> <a href="javascript:;" class="btn btn-grad border-0 global-income-claim" data-type="global"> CLAIM </a> </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-sm-6 col-lg-3 mb-2">
                        <div class="card with-radial-gradient">
                          <div class="empty p-2">
                            <div class="empty-img"><img src="<?php echo $assets_url_var; ?>static/illustrations/undraw_quitting_time_dm8t.svg" height="128"  alt=""> </div>
                            <h4 class="">SPONSOR INCOME</h4>
                            <div class="text-muted"><span class="claim-amount-status"><?php echo (!empty($sum_user_sponsor_income))? number_format($sum_user_sponsor_income, 2) : 0 ?></span><span class="small text-h6"> PYM</span> </div>
                            <div class="empty-action"> <div class="claim-status" ></div> <a href="javascript:;" class="btn btn-grad border-0 sponsor-income-claim" data-type="sponsor"> CLAIM </a> </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-sm-12 col-lg-4">
                <div class="card shadow radius-20">
                  <div class="card-header">
                    <h4 class="card-title"> Income Statistics </h4>
                    
        <!-- <div class="card-actions"> <a href="#"> View More
          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
            <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
            <polyline points="7 7 12 12 7 17" />
            <polyline points="13 7 18 12 13 17" />
        </svg>
      </a> </div> -->

    </div>
    <div class="card-body pt-1">
      <div class="card card-sm mt-1">
        <div class="card-body p-2">
          <div class="row align-items-center">
            <div class="col-auto"> <span class="avatar bg-azure-lt"><!-- Download SVG icon from http://tenrealm-icons.io/i/currency-dollar --> 
              <!-- Download SVG icon from http://tabler-icons.io/i/chart-line -->
              <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                <line x1="4" y1="19" x2="20" y2="19" />
                <polyline points="4 15 8 9 12 11 16 6 20 10" />
              </svg>
            </span> </div>
            <div class="col">
              <div class="h3 mb-0">100%</div>
              <div class="subheader">MAIN BALANCE</div>
              <div class="progress progress-sm mt-1">
                <div class="progress-bar bg-blue" style="width: 100%" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"> <span class="visually-hidden"> 100% Complete</span> </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="card card-sm mt-2">
        <div class="card-body p-2">
          <div class="row align-items-center">
            <div class="col-auto"> <span class="avatar bg-azure-lt"><!-- Download SVG icon from http://tenrealm-icons.io/i/currency-dollar --> 
              <!-- Download SVG icon from http://tabler-icons.io/i/chart-line -->
              <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                <line x1="4" y1="19" x2="20" y2="19" />
                <polyline points="4 15 8 9 12 11 16 6 20 10" />
              </svg>
            </span> </div>
            <div class="col">
              <?php 
                $level_per = 0;
                if($sum_user_level_income){
                  $level_per = ($sum_user_level_income * 100 ) / $main_balance;
                  $level_per = ($level_per) ? $level_per : 0;
                }
              ?>
              <div class="h3 mb-0"><?php echo ($level_per) ? number_format($level_per, 2):0; ?>%</div>
              <div class="subheader">LEVEL INCOME</div>
              <div class="progress progress-sm mt-1">
                <div class="progress-bar bg-orange" style="width: <?php echo $level_per; ?>%" role="progressbar" aria-valuenow="<?php echo $level_per; ?>" aria-valuemin="0" aria-valuemax="100"> <span class="visually-hidden"><?php echo ($level_per) ? number_format($level_per, 2):0; ?>% Complete</span> </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="card card-sm mt-2">
        <div class="card-body p-2">
          <div class="row align-items-center">
            <div class="col-auto"> <span class="avatar bg-azure-lt"><!-- Download SVG icon from http://tenrealm-icons.io/i/currency-dollar --> 
              <!-- Download SVG icon from http://tabler-icons.io/i/chart-line -->
              <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                <line x1="4" y1="19" x2="20" y2="19" />
                <polyline points="4 15 8 9 12 11 16 6 20 10" />
              </svg>
            </span> </div>
            <div class="col">
               <?php 
               $global_per = 0;
                if($sum_user_global_income){
                  $global_per = ($sum_user_global_income * 100 ) / $main_balance;
                  $global_per = ($global_per) ? $global_per : 0;
                }
              ?>
              <div class="h3 mb-0"><?php echo ($global_per) ? number_format($global_per,2) : 0; ?>%</div>
              <div class="subheader">GLOBAL INCOME</div>
              <div class="progress progress-sm mt-1">
                <div class="progress-bar bg-green" style="width: <?php echo $global_per; ?>%" role="progressbar" aria-valuenow="<?php echo $global_per; ?>" aria-valuemin="0" aria-valuemax="100"> <span class="visually-hidden"><?php echo ($global_per) ? number_format($global_per,2) : 0; ?>% Complete</span> </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="card card-sm mt-2">
        <div class="card-body p-2">
          <div class="row align-items-center">
            <div class="col-auto"> <span class="avatar bg-azure-lt">
              <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                <line x1="4" y1="19" x2="20" y2="19" />
                <polyline points="4 15 8 9 12 11 16 6 20 10" />
              </svg>
            </span> </div>
            <div class="col">
               <?php 
               $sponsor_per = 0;
                if($sum_user_sponsor_income){
                  $sponsor_per = ($sum_user_sponsor_income * 100 ) / $main_balance;
                  $sponsor_per = ($sponsor_per) ? $sponsor_per : 0;
                }
              ?>
              <div class="h3 mb-0"><?php echo ($sponsor_per) ? number_format($sponsor_per,2) : 0; ?>%</div>
              <div class="subheader">SPONSOR INCOME</div>
              <div class="progress progress-sm mt-1">
                <div class="progress-bar bg-red" style="width: <?php echo $sponsor_per; ?>%" role="progressbar" aria-valuenow="<?php echo $sponsor_per; ?>" aria-valuemin="0" aria-valuemax="100"> <span class="visually-hidden"><?php echo ($sponsor_per) ? number_format($sponsor_per,2) : 0; ?>% Complete</span> </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
</div>
</div>



<?php include realpath(dirname(__DIR__) . '/common/inner_footer.php'); ?>

<div id="income-confirmation-dialog" title="Confirmation Required">
  Are you sure about this?
</div>
<script>   
  
  if (document.querySelector('.copy32343534') !== null) {
    document.getElementById("copy32343534").addEventListener("click", copy_password);
  }
  
  function copy_password(e) {
    e.preventDefault();
    var text = document.getElementById('hlink').value;
    var elem = document.createElement("textarea");
    document.body.appendChild(elem);
    elem.value = text;
    elem.select();
    document.execCommand("copy");
    document.body.removeChild(elem);



    document.getElementById("show_copied_to_clipboard").style.display = "block";
    setTimeout(function() {
      var loader = document.getElementById("show_copied_to_clipboard");
    // loader.style.opacity = '1';
    loader.style.transition = '.5s';
    // loader.style.opacity = '0';
    // loader.style.visibility = 'none';
    loader.style.display = 'none';
  }, 1250);

  }
</script>


<?php if(isset($remaining_period_timestamp)){ ?>
  <script type="text/javascript">
   var countDownDate = <?php echo $remaining_period_timestamp; ?> * 1000;
   var now = <?php echo time() ?> * 1000;

// Update the count down every 1 second
var x = setInterval(function() {
  now = now + 1000;
// Find the distance between now an the count down date
var distance = countDownDate - now;
// Time calculations for days, hours, minutes and seconds
var days = Math.floor(distance / (1000 * 60 * 60 * 24));
var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
var seconds = Math.floor((distance % (1000 * 60)) / 1000);
// Output the result in an element with id="demo"
document.getElementById("package-remainder").innerHTML = days + "d " + hours + "h " + minutes + "m " + seconds + "s ";
// If the count down is over, write some text 
if (distance < 0) {
  clearInterval(x);
  document.getElementById("package-remainder").innerHTML = "EXPIRED";
}

}, 1000);

</script>
<?php } ?>


<script type="text/javascript">
  $(document).ready(function() {
    var confirmDialogId = $('#income-confirmation-dialog');

    $(confirmDialogId).dialog({
      autoOpen: false,
      modal: true,
      dialogClass:'transparent'
    });

    $.fn.confirmation = function(_this){
      var remainingBal = '0.00';
      var myDialog = $(confirmDialogId).dialog({
        buttons : {
          "Confirm" : function() {
                  var _claim_parent = _this.closest('.with-radial-gradient');
                  var Type = _this.data('type');
                  $.ajax({
                    url: baseURL + 'claim',
                    type: 'POST',
                    dataType: 'json',
                    data: {type : Type},
                    success: function(res) {
                      if(res.status == true){
                        $('.main-balance-amount-status').html(remainingBal);
                        _claim_parent.find('span.claim-amount-status').html(remainingBal);
                        _claim_parent.find('.claim-status').html(res.msg).show().delay(4000).fadeOut();
                      }
                      myDialog.dialog('close');
                    }
                  });            
          },
          "Cancel" : function() {
            $(this).dialog("close");
          }
        }
      });

      $(confirmDialogId).dialog("open");
    }


    $(document).on('click', '.level-income-claim, .global-income-claim, .sponsor-income-claim', function(event) {
      event.preventDefault();
      /* Act on the event */
      var _this = $(this);
      $.fn.confirmation(_this);      
    });


  });
</script>
</body>
</html>