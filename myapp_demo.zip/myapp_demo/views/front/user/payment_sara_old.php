<?php include realpath(dirname(__DIR__) . '/common/inner_header.php'); ?>
<style type="text/css">
  #qrcode-div {
    display: inline-block;
    vertical-align: middle;  
  } 
  .error{color:red;}   
  .require-inline {
    display: block;
    width: 100%;
    /*margin-top: 10px;*/
  }
</style>
<div class="page-body">
  <div class="container-xl">
    <ol class="breadcrumb breadcrumb-arrows mb-3" aria-label="breadcrumbs">
      <li class="breadcrumb-item"><a href="#">Wallet</a></li>
      <li class="breadcrumb-item active" aria-current="page">Payment Gateway</li>
    </ol>
    <div class="row row-cards">
     <?php $this->load->view('front/common/flashmessage'); ?>
     <div class="col-sm-12">
      <div class="row ">
        <div class="col-md-12">
          <div class="card shadow radius-20">
            <div class="card-body p-4 pb-0 text-center">
              <?php                     
              if($usd_24h_change >= 0){
                $text_class = 'text-green';
                $usd_24h_change = sprintf('%0.1f', $usd_24h_change);
              }else{
                $text_class = 'text-red';
                $usd_24h_change = sprintf('%0.1f', $usd_24h_change);
              }
              ?>
              <div class="text-end <?php echo $text_class; ?> position-absolute pull-right"> 
               <!--  <span class="<?php //echo $text_class; ?> d-inline-flex align-items-center lh-1">  <?php //echo $usd_24h_change; ?> % 
                <svg xmlns="http://www.w3.org/2000/svg" class="icon ms-1" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                  <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                  <polyline points="3 17 9 11 13 15 21 7"></polyline>
                  <polyline points="14 7 21 7 21 14"></polyline>
                </svg>
              </span> -->
               </div>
              <!-- <span class="avatar avatar-xl mb-3 avatar-rounded" style="background-image: url(<?php echo $assets_url_var; ?>static/Litecoin-LTC-icon.png)"></span> -->
              <h3 class="m-0 mb-1"><a href="#">EMD</a></h3>
            </div>
          <!--   <dl class="row p-3">
              <dt class="col-5">Current Price:</dt>
              <dd class="col-7"><span>$ </span><?php echo number_format($usd,2) ?? 0.00; ?></dd>
              <dt class="col-5">Market Cap:</dt>
              <dd class="col-7"><span>$ </span><?php echo ($usd_market_cap) ? $usd_market_cap:''; ?></dd>
              <dt class="col-5">24Hr Vol:</dt>
              <dd class="col-7"><span>$ </span><?php echo ($usd_24h_vol) ? $usd_24h_vol:''; ?></dd>
            </dl> -->
            <div class="d-flex"> <a href="#" class="card-btn modal-deposit-clear"  data-bs-toggle="modal" data-bs-target="#modal-deposit"> Deposit</a>
             <!-- <a href="javascript:;" <?php if(checkAvailableChildren($user_id)){ ?> class="card-btn user-withdraw-model-active" data-bs-toggle="modal" data-bs-target="#modal-withdraw" <?php }else{ echo 'class="card-btn not-eligible" title="You are not eligiable for withdraw i:e You must have 4 children "'; } ?>  > Withdraw</a> -->

             <a href="javascript:;" class="card-btn user-withdraw-model-active" data-bs-toggle="modal" data-bs-target="#modal-withdraw" > Withdraw</a>

           </div>
         </div>
       </div>
     </div>
   </div>
 </div>
</div>
</div>



<div class="modal modal-blur fade" id="modal-deposit" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
    <?php
      // $action = '';
      // $attributes = array('id'=>'pre_deposit_form','autocomplete'=>"off",'class'=>'pre_deposit_form');
      // echo form_open($action,$attributes);
    ?>
    <input type="hidden" name="deposit_amount_with_admin_fee" id="deposit_amount_with_admin_fee" value="">
    <div class="modal-content shadow radius-20">
      <div class="modal-body">
        <div class="modal-title"><span class="avatar avatar-xs mt-3 mr-2 avatar-rounded" style="background-image: url(<?php echo base_url();?>css/assets/images/logos.png)"></span>Please Select Your Deposit Crypto</div>
<!-- 
<form action="<?php echo base_url();?>deposit_page" Method="POST">
  <input type="hidden" name="currency_name" value="BTC"/> -->
  <!-- <button type="button" class="btn btn-outline-primary">BTC</button> -->
 <!--  <input type="submit" name="submit" class="btn btn-outline-primary" value="BTC"/>
 </form> -->
<!-- <a href="<?php echo base_url('deposit_page/BNB') ?>" class="btn btn-outline-secondary"></a>        
<button type="button" class="btn btn-outline-secondary">BNB</button>
<button type="button" class="btn btn-outline-success">LTC</button>
<button type="button" class="btn btn-outline-danger">TRON</button>
<button type="button" class="btn btn-outline-warning">ETH</button>
<button type="button" class="btn btn-outline-info">XRP</button> -->

<a href="<?php echo base_url('deposit_page/USDT') ?>" class="btn btn-outline-secondary">USDT</a> 
<a href="<?php echo base_url('deposit_page/BUSD') ?>" class="btn btn-outline-secondary">BUSD</a> 
  <a href="<?php echo base_url('dashboard') ?>" style="color:red" class="btn btn-outline-secondary">Cancel</a> 
<!--<a href="<?php echo base_url('deposit_page/LTC') ?>" class="btn btn-outline-secondary">LTC</a> -->
<!--<a href="<?php echo base_url('deposit_page/TRON') ?>" class="btn btn-outline-secondary">TRON</a> -->
<!--<a href="<?php echo base_url('deposit_page/ETH') ?>" class="btn btn-outline-secondary">ETH</a> -->
<!--<a href="<?php echo base_url('deposit_page/XRP') ?>" class="btn btn-outline-secondary">XRP</a> -->


<div>
          <!-- <div class="input-group mb-2"> <span class="input-group-text"> PYM </span>
            <input type="text" class="form-control" autofocus name="user_deposit_amount" min="0" id="user_deposit_amount" placeholder="Enter deposit value" autocomplete="off">
          </div> -->
          <?php 
          $admin_fees = 0;
          $deposit = $this->com_m->get_row_val('currency',[ 'currency_symbol' => 'LTC' ]); 
          if($admin_fees = $deposit['deposit_fees']){
            $admin_fees = $deposit['deposit_fees'];
            ($deposit['deposit_fees']) ?? '';
          }
          ?> 
<!--           <p class="mt-3 mb-1">Admin fee : <strong class="coinprice-admin-fee"> <?php 
          // $admin_fees = 0;
          // $deposit = $this->com_m->get_row_val('currency',[ 'currency_symbol' => 'LTC' ]);
          // if($admin_fees = $deposit['deposit_fees']){
          //   echo ($deposit['deposit_fees']) ?? '';
          // }
           ?> </strong> PYM <span class="error">*</span>
           <div id="pop-up-pym-values" style="display: none;"><h2> Received Amount : <span id="added-admin-fees"></span> PYM </h2> </div>
         </p>  -->         
       </div>
       <div class="form-error-display d-none"></div>
     </div>
   <!--    <div class="modal-footer">        
        <button type="button" class="btn btn-link link-secondary me-auto pre_deposit_cancel_btn" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-primary float-right submit-btn pre-modal-deposit-submit-btn" id="pre-modal-deposit-submit-btn" >Deposit</button>
      </div> -->
    </div>
    <?php echo form_close(); ?>
  </div>
</div>


<div class="modal modal-blur fade" id="modal-qacode" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
    <?php
    $action = '';
    $attributes = array('id'=>'deposit_form','autocomplete'=>"off",'class'=>'deposit_form');
    echo form_open($action,$attributes);
    ?>
    <input type="hidden" name="user_deposit_amount_submit" value="" id="user_deposit_amount_submit" >
    <input type="hidden" name="user_deposit_ltc_amount" value="" id="user_deposit_ltc_amount" >
    <input type="hidden" name="user_deposit_ltc_percentage" value="" id="user_deposit_ltc_percentage" >
    <div class="modal-content shadow radius-20">
      <div class="modal-body pb-0">
        <div class="modal-title h1">
          <h2>Initializing</h2>
        </div>
        <div>
          <div class="row">

            <div class="col-md-6 col-xl-6"> <a id="copy3234" class="card card-link" href="javascript:;">
              <div class="card-body p-2">
                <div class="row">
                  <div class="col-auto"><span class="avatar rounded" style="background-image: url(<?php echo $assets_url_var; ?>static/Litecoin-LTC-icon.png)"></span></div>
                  <div class="col" >
                    <span class="font-weight-medium coinprice copy-coinprice" title="Copied to clipboard" id="get_ltc_values"></span> <span>LTC</span>                      
                  </div>
                </div>
              </div>
            </a>
            <span class="badge bg-green-lt mt-1 show_copied_to_clipboard"  style="display: none;" id="show_copied_to_clipboard">Copied to clipboard!</span>
          </div>

          <div class="col-md-6 col-xl-6"> <a class="card card-link" href="#">
            <div class="card-body p-2">
              <div class="row">
                <div class="col">
                  <div class="font-weight-medium text-right">
                    <h1 style="font-size: 17px; margin-bottom:0px"> <strong class="display-user-deposit-amount" id="display-user-deposit-amount"></strong> </h1>
                  </div>
                </div>
              </div>
            </div>
          </a> </div>
        </div>
        <div id="display_qr_code_as_true" >

          <p class="mt-3 mb-1">To complete your payment, please send <strong class="coinprice"> </strong> LTC or scan the QR code</p>
          <div class="card">
            <div class="card-body text-center">
              <div class="mb-3"> 
                <div id="qrcode-div"></div>                  
              </div>
            </div>
            <!-- <form> -->
              <div class="input-group">
                <input type="text" class="form-control" value="<?php echo md5(rand()); ?>" readonly placeholder="Some path" id="crypto_address" >
                <span class="input-group-btn">
                  <button class="btn btn-default" type="button" id="copy-button" data-toggle="tooltip" data-placement="button" title="Copy to Clipboard" > Copy </button>
                  <span style="color:#66A81A;font-weight:bold;" id="copy_but" class="copy_but"></span>
                </span>
              </div>

              <div id="countdown">
                <div id="tiles">
                  <span id="hours">00</span>
                  <span id="minutes">00</span>
                  <span  id="seconds">00</span></div>
                  <div class="labels">                   
                    <li>Hrs</li>
                    <li>Mins</li>
                    <li>Secs</li>
                  </div>
                </div>
                <div id="expire-countdown"></div>
                <input type="hidden" value="" name="timer22" id="timer22" class="timer22" />
                <p class="text-center pb-0 mb-0">Gateway expires at <span class="badge bg-azure-lt" id="endDate"></span></p>
              </div>
            </div>
            <div id="display_qr_code_as_false"  style="display:none;">This deposit has expired. Please create a new transaction.</div>

          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-link link-secondary me-auto deposit_form_cancel" >Cancel</button>            
        </div>
      </div>
      <?php echo form_close(); ?>
    </div>
  </div>



  <div class="modal modal-blur fade" id="modal-timeout" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">     
      <div class="modal-content shadow radius-20">
        <div class="modal-body pb-0">
          <div class="modal-title h1">
            <h2 id="timeout-header">Time over</h2>
          </div>
          <div>
            <div class="row">              
              <div id="display_qr_code_as_false" class="timeout-body-msg" >This deposit has expired. Please create a new transaction.</div>
            </div>          
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-link link-secondary me-auto deposit_form_close" >Close</button>            
        </div>
      </div>

    </div>
  </div>


  <div class="modal modal-blur fade" id="modal-withdraw" tabindex="-1" role="dialog" aria-hidden="true">
     <!--  <div class="modal-dialog modal-sm modal-dialog-centered" role="document">      
       <?php
       $action = '';
       $attributes = array('id'=>'withdrawcoinForm','autocomplete'=>"off",'class'=>'withdraw_form');
       echo form_open($action,$attributes);
       ?>
       <input type="hidden" name="withdrawcoin" value="1242342">
       <input type="hidden" name="user_withdraw_ltc_percentage_hidden" id="user_withdraw_ltc_percentage_hidden" value="">
       <input type="hidden" name="widthdraw_admin_pym_amount_hidden" id="widthdraw_admin_pym_amount_hidden" value="">
       <div class="modal-content shadow radius-20">
        <div class="modal-body">
          <div class="modal-title"> <span class="avatar avatar-xs mt-3 mr-2 avatar-rounded" style="background-image: url(<?php echo $assets_url_var; ?>static/Litecoin-LTC-icon.png)"></span>LITECOIN</div>
          <div>
            <label for="inp" class="inp">
              <input type="text" id="amount" name="amount" class="form-control" placeholder=" ">
              <span class="label">Withdraw Amount</span> <span class="focus-bg"></span> </label>
              <label for="inp" class="inp">
                <input type="text" id="address" name="address" class="form-control" placeholder=" ">
                <span class="label">Payment Address</span> <span class="focus-bg"></span> </label>
                <?php 
                  $withdraw_admin_fee = 0;
                  $withdraw = $this->com_m->get_row_val('currency',[ 'currency_symbol' => 'LTC' ]);
                  if($withdraw_admin_fee = $withdraw['withdraw_fees']){
                    $withdraw_admin_fee = $withdraw['withdraw_fees'];
                    ($withdraw['withdraw_fees']) ?? '';
                  }
                ?>
              </div>
              <!-- <p class="mt-3 mb-1">Admin fee :  <strong> <?php 
                  // $withdraw_admin_fee = 0;
                  // $withdraw = $this->com_m->get_row_val('currency',[ 'currency_symbol' => 'LTC' ]);
                  // if($withdraw_admin_fee = $withdraw['withdraw_fees']){
                  //   echo ($withdraw['withdraw_fees']) ?? '';
                  // }
              ?> </strong> PYM <span class="error">*</span></p> -->
              <!-- <div class="widthdraw_admin_amount_div" id="widthdraw_admin_amount_div" style="display:none" >
                Received Amount : <strong class="widthdraw_admin_amount" id="widthdraw_admin_amount"  ></strong> PYM 
              </div> -->
            <!-- </div>
            <div class="alert alert-danger print-status-msg" style="display:none"></div>
            <div id="withdraw-load" style="display:none;text-align:center;"> 
                Please wait... <img src="//s.svgbox.net/loaders.svg?fill=maroon&ic=tail-spin" 
                     style="width:24px">
            </div>
            <div class="modal-footer">            
              <button type="button" class="btn btn-link link-secondary me-auto cancel_btn" >Cancel</button>
              <input type="submit" name="withdrawcoin" class="btn btn-primary float-right"  id="withdraw-btn" value="Yes, Withdraw" >
            </div>
          </div>
          <?php echo form_close(); ?>  
        </div> -->

        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
          <?php
      // $action = '';
      // $attributes = array('id'=>'pre_deposit_form','autocomplete'=>"off",'class'=>'pre_deposit_form');
      // echo form_open($action,$attributes);
          ?>
          <input type="hidden" name="deposit_amount_with_admin_fee" id="deposit_amount_with_admin_fee" value="">
          <div class="modal-content shadow radius-20">
            <div class="modal-body">
              <div class="modal-title"><span class="avatar avatar-xs mt-3 mr-2 avatar-rounded" style="background-image: url(<?php echo base_url();?>css/assets/images/logos.png)"></span>Please Select Your Withdrawal Crypto</div>

              <a href="<?php echo base_url('withdraw_page/USDT') ?>" class="btn btn-outline-secondary">USDT</a> 
              <a href="<?php echo base_url('withdraw_page/BUSD') ?>" class="btn btn-outline-secondary">BUSD</a> 
              <a href="<?php echo base_url('dashboard') ?>" style="color:red" class="btn btn-outline-secondary">Cancel</a> 
              <!--<a href="<?php echo base_url('withdraw_page/TRON') ?>" class="btn btn-outline-secondary">TRON</a> -->
              <!--<a href="<?php echo base_url('withdraw_page/ETH') ?>" class="btn btn-outline-secondary">ETH</a> -->
              <!--<a href="<?php echo base_url('withdraw_page/XRP') ?>" class="btn btn-outline-secondary">XRP</a> -->
              <div>

                <?php 
                $admin_fees = 0;
                $deposit = $this->com_m->get_row_val('currency',[ 'currency_symbol' => 'LTC' ]); 
                if($admin_fees = $deposit['deposit_fees']){
                  $admin_fees = $deposit['deposit_fees'];
                  ($deposit['deposit_fees']) ?? '';
                }
                ?> 
              </div>
              <div class="form-error-display d-none"></div>
            </div>
          </div>
          <?php echo form_close(); ?>
        </div>
      </div>

      <?php include realpath(dirname(__DIR__) . '/common/inner_footer.php'); ?>
      <script src="<?php echo $assets_url_var;?>js/qrcode.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
      <script src="<?php echo $assets_url_var;?>js/deposit.js?v=<?php echo date('Ymdhis'); ?>"></script>
      <script type="text/javascript">
        var _print_ajax_status_cls = $(".print-status-msg");
        var _error_div_amount_class = $(".print-error-msg>div.amount_err");
        var _error_div_address_class = $(".print-error-msg>div.address_err");

        var withdrawForm = $('#withdrawcoinForm');


        function showDialog2() {
          $("#dialog1").removeClass("fade").modal("hide");
          $("#dialog2").addClass("fade").modal("show");
        }
        $(function () {
          $("#dialog1").modal("show");
          $("#dialog-ok").on("click", function () {
            showDialog2();
          });
        });
      </script>
      <script>
        $(document).ready(function() {
  // Initialize the tooltip.
  $('#copy-button').tooltip();

  $( '.not-eligible, .copy-coinprice' ).tooltip();
  
});
</script> 
<script>



// SATZ JS settings
$(document).ready(function () {

  $('#modal-withdraw').modal({backdrop:'static', keyboard: false}); 
  $('#modal-deposit').modal({backdrop:'static', keyboard: false});
  $('#modal-qacode').modal({backdrop:'static', keyboard: false});

  var currentRequest = null;  

  var userWithdrawBtn = $('#withdraw-btn');

  $(document).on('click', '.user-withdraw-model-active', function(){
    withdrawForm.find(_print_ajax_status_cls).empty().hide();
    $('.cancel_btn').trigger('click');
  })

      withdrawForm.validate({ // initialize the plugin
        rules: {
          amount: {
           required: {
            depends:function(){
             $(this).val($.trim($(this).val()));
             return true;
           }
         },      
         number:true,
       },
       address: {
        required: {
          depends:function(){
           $(this).val($.trim($(this).val()));
           return true;
         }
       },
       minlength: 5,

     }
   },
   submitHandler: function (form, event) {
    event.preventDefault();
    withdrawForm.find(_print_ajax_status_cls).empty().hide(); 

    var amount = $('#amount').val();
    var address = $('#address').val();
    var admin_percentage = $('#user_withdraw_ltc_percentage_hidden').val();
    var admin_pym = $('#widthdraw_admin_pym_amount_hidden').val();
    userWithdrawBtn.prop("disabled", true);
    currentRequest = $.ajax({
      url: baseURL + "withdraw-validation",
      type: 'POST',
      dataType: 'json',
      data: {  csrf_name:csrf_token, address:address , amount : amount, percentage: admin_percentage, admin_pym : admin_pym},
      accepts: "application/json; charset=utf-8",
      beforeSend : function(){              
        if (typeof(currentRequest) != 'undefined' && currentRequest != null) {
          currentRequest.abort();
        }
      },
      success: function(data) {  
        userWithdrawBtn.prop("disabled", false);              
        if($.isEmptyObject(data.error)){
          $.fn.errorFn(data); 
          $.fn.successFormSubmitFn(form); 
          
          return;
        }else{
          $.fn.successFn(data,1);   
          $('#widthdraw_admin_amount_div').hide();                
        }                
      },
      // error: jqueryErrorHandling,
    });
  }
});


      $.fn.successFormSubmitFn = (function(form){        
        var url = baseURL + 'withdraw/LTC';
        $.ajax({
          url: url,
          type: 'POST',
          dataType: 'json',
          data : withdrawForm.serialize(),
          beforeSend : function(){              
            $('#withdraw-load').show();
          },
          success:function(data){
            $('#withdraw-load').hide();
            // console.log(data); return false;
            if(data.status != true){
              $.fn.errorFn(data);                
              return;
            }else{
              _print_ajax_status_cls.removeClass('alert-danger').addClass('alert-success').show().html('').fadeIn().html(data.msg).fadeOut(5000);
              withdrawForm[0].reset();
              $('#amount').val('');
              $('#address').val('');
              withdrawForm.validate().resetForm();                
              return true;                
            }            
          },
           // error: jqueryErrorHandling,
         });


      })


      $.fn.errorFn = (function(data){          
        if($.isEmptyObject(data.error)){                    
          _print_ajax_status_cls.fadeIn().html('').css('display','none').fadeOut(5000);  
        }
        return true;
      })

      $.fn.successFn = (function(data){            
        _print_ajax_status_cls.css('display','block');                    
        if(_error_div_amount_class.length == 0){              
          _print_ajax_status_cls.html(data.error);
          return true;
        }else{
          return true;              
        }     
      })



      $(document).on('click','.modal-deposit-clear',function(){
        $('#pop-up-pym-values').hide();
      });
      

      // Reset of the modal 
      $(document).on('click', '.cancel_btn', function(){          
        // alert('Widthraw sample2');
        withdrawForm[0].reset();          
        $('#user_deposit_amount').val('');
        withdrawForm.validate().resetForm();
        withdrawForm.find('.error').removeClass('error');
        withdrawForm.find('.print-error-msg').empty().hide();
        $('#modal-withdraw').modal('hide');        
      })


      $(document).on('keyup', '#user_deposit_amount', function(){
        var _this = $(this);
        
        var depositAmt = _this.val();
        if(depositAmt.length > 0){
          if (!isNaN(depositAmt)) {
            $('#pop-up-pym-values').show();
            var adminFee = "<?php echo (sprintf('%0.8f', $admin_fees)); ?>";
            var percentage = (depositAmt * adminFee) / 100;
            $('#user_deposit_ltc_percentage').val(percentage);
            
            var finalAmt = toMYFixed((parseFloat(depositAmt) + parseFloat(percentage)), 8);
            $('#deposit_amount_with_admin_fee').val(toMYFixed(finalAmt,8));
            $('#added-admin-fees').html(toMYFixed(finalAmt,8));            
          }
        }else{
          // $('#pop-up-pym-values').hide();
        }
      })
      

      

      $(document).on('keyup', '#amount', function(){
        var _this = $(this);
        
        var depositAmt = _this.val();
        if(depositAmt.length > 0 ){
          if (!isNaN(depositAmt)) {
            $('#widthdraw_admin_amount_div').show();
            var adminFee = "<?php echo (sprintf('%0.8f', $withdraw_admin_fee)); ?>";
            var percentage = (depositAmt * adminFee) / 100;
            $('#user_withdraw_ltc_percentage_hidden').val(percentage);
            var finalAmt = toMYFixed((parseFloat(depositAmt) - parseFloat(percentage)), 8);
            $('#widthdraw_admin_pym_amount_hidden').val(toMYFixed(finalAmt,8));
            $('#widthdraw_admin_amount').html(toMYFixed(finalAmt,8));            
          }
        }else{
          // $('#widthdraw_admin_amount_div').hide();
        }
      })



    });


function toMYFixed(num, fixed) {
  var re = new RegExp('^-?\\d+(?:\.\\d{0,' + (fixed || -1) + '})?');
  return num.toString().match(re)[0];
}




    // Numeric only control handler
    $.fn.ForceNumericOnly = (function()
    {
      return this.each(function()
      {
        $(this).keydown(function(e)
        {
          var key = e.charCode || e.keyCode || 0;
              // allow backspace, tab, delete, enter, arrows, numbers and keypad numbers ONLY
              // home, end, period, and numpad decimal
              return (                          
                key == 8 || 
                key == 9 ||
                key == 13 ||
                key == 46 ||
                key == 110 ||
                key == 190 ||
                (key >= 35 && key <= 40) ||
                (key >= 48 && key <= 57) ||
                (key >= 96 && key <= 105)
                );
            });
      });
    });

    // $("#amount").ForceNumericOnly();
    // $("#user_deposit_amount").ForceNumericOnly();

  </script>
  <?php include realpath(dirname(__DIR__) . '/common/js_error_notify.php'); ?>
</body>
</html>