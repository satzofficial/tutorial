<?php include realpath(dirname(__DIR__) . '/common/header.php'); ?>
<link rel="stylesheet" href="<?php echo $assets_url_var; ?>css/select2.min.css?v=<?php echo date('Ymdhis'); ?>">
<style>
    .sel_bx_set{}
    .sel_bx_set .select2-container .select2-selection--single .select2-selection__rendered{padding-left: 0px;}
    .sel_bx_set .select2-container--default .select2-selection--single .select2-selection__arrow {
        height: 26px;
        position: absolute;
        top: 12px;
        right: 15px;
        width: 20px;

    }
    .sel_bx_set .selection{width:100%;}
    .sel_bx_set .select2.select2-container.select2-container--default {
        width: 100% !important;
    }
    .sel_bx_set .select2-selection.select2-selection--single {
        background-color: #f5faff !important;
        border: 1px solid #EEF1FF !important;
        width: 100% !important;
        padding: 10px 20px !important;
        color: #1E266D !important;
        font-family: var(--body-font) !important;
        height: 50px !important;
    }
.pas_set{
    position: relative;
}
.pas_ico{
    position: absolute;
    top:43px;
    right:15px;
}    

.ui-datepicker select.ui-datepicker-month, .ui-datepicker select.ui-datepicker-year {
    width: 50%;
}

.terms_and_condition{
 width: 10%;
 padding: 2px 3px;   
}
</style>
<!-- Register In start -->
<section class="sign-in-up register">
    <div class="overlay pt-120 pb-120">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="form-content">
                        <div class="section-header">
                            <h5 class="sub-title">The Power of Financial Freedom</h5>
                            <h2 class="title">Let’s Get Started!</h2>
                            <p>Please Enter your Email Address to Start your Voyage</p>
                        </div>                        
                        <?php $this->load->view('front/common/flashmessage'); ?>
                        <?php
                        if(validation_errors()){
                          $error =  validation_errors();
                          echo '<div class="note note-danger">
                          <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$error.'</div>';
                      }
                      $attributes=array('class'=>'form-horizontal','id'=>'subForm', 'autocomplete' => "off" );
                      echo form_open($action,$attributes);                                         
                      ?>
                      <div class="row">
                        <div class="col-12">
                            <div class="single-input">
                                <label for="referral">Introducer Id</label>
                                <input type="text" name="parent" value="<?php 
                                if($this->input->get('ref')){
                                    echo $this->input->get('ref');
                                }
                                ?>" id="referral" placeholder="Enter the referral code" readonly class="required" required>

                                <?php 
                                if($this->input->get('ref')){
                                    $ref = $this->input->get('ref');
                                        // echo '<a href=""><span style="color: #1a4dbe;">'.$ref.'</span></a>';
                                }else{
                                        // echo  '<p>Don\'t Have Sponser ID? ';
                                        // echo '<a href="javascript:;" class="click_here_cls"><span style="color: #1a4dbe;">Click Here</span></a>';
                                        // echo '</p>';
                                }?>

                            </div>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <div class="single-input">
                                <label for="firstname">First Name</label>
                                <input type="text" name="first_name" id="firstname" class="inp1_uppercase" placeholder="First Name">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="single-input">
                                <label for="lastname">Last Name</label>
                                <input type="text" name="last_name" id="lastname"  class="inp2_uppercase" placeholder="Last Name">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="single-input">
                                <label for="email">Enter Your Email ID</label>
                                <input type="text" name="tenrealm_email" id="tenrealm_email" placeholder="Your email ID here">
                            </div>
                        </div>
                        <div class="row">
                             <div class="col-6">
                                <div class="single-input pas_set">
                                    <label for="Password">Mobile</label>
                                    <input type="text" class="phoneInput" autocomplete="off" name="phone" id="phone" placeholder="1234567890"> 
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="single-input pas_set">
                                    <label for="cnfm-password">DOB</label>
                                    <input type="text" class="dobInput" autocomplete="off" name="dob" id="datepicker" placeholder="mm-dd-yy">
                              </div>
                            </div>
                            <div class="col-6">
                                <div class="single-input pas_set">
                                    <label for="Password">Password</label>
                                    <input type="password" class="passInput" autocomplete="off" name="tenrealm_password" id="tenrealm_password" placeholder="********">
                                    <img class="showPass password_on pas_ico" src="<?php echo $assets_url_var; ?>images/icon/show-hide.png" alt="icon">                                               
                                    <img class="showPass password_off pas_ico" style="display:none;" src="<?php echo $assets_url_var; ?>images/vision.png" alt="icon"> 
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="single-input pas_set">
                                    <label for="cnfm-password">Confirm Password</label>
                                    <input type="password" class="CpassInput" autocomplete="off" name="cnfm_password" id="cnfm_password" placeholder="********">
                                    <img class="CshowPass Cpassword_on pas_ico" src="<?php echo $assets_url_var; ?>images/icon/show-hide.png" alt="icon">                                               
                                    <img class="CshowPass Cpassword_off pas_ico"  style="display:none;" src="<?php echo $assets_url_var; ?>images/vision.png" alt="icon"> 
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="single-input">
                                    <label style=" font-family:'open sans';color: black;">Select Country</label>
                                    <div class="input-group sel_bx_set">
                                        <select id="country_select" name="country" class="js-states sel_bx">
                                            <?php 
                                            foreach ($countries as $ckey => $cvalue) {                          
                                                $c_id = $cvalue->id;
                                                    if( $c_id == '230'){
                                                        $cname = $cvalue->country_name;
                                                        echo '<option selected value="'.$c_id.'">'.$cname.'</option>';
                                                    }else{
                                                        $cname = $cvalue->country_name;
                                                        echo '<option value="'.$c_id.'">'.$cname.'</option>';
                                                    }
                                                }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="col-6">
                                <div class="single-input">
                                    <label for="beb_address">Enter Your BEP 20 Address</label>
                                    <input type="text" name="beb_address" id="beb_address" placeholder="Your BEP20 Address here">
                                </div>
                            </div>
                            <div class="col-6">
                                <label id="ebcaptchatext"></label>
                                <input type="hidden" name="number1" id="number1" value="">
                                <input type="hidden" name="number2" id="number2" value="">
                                <input type="text" name="ebcaptchainput" class="textbox" id="ebcaptchainput"/>
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="single-input">
                                <input type="checkbox" name="terms_and_condition" class="terms_and_condition" id="terms_and_condition" value="1" checked="checked">
                                <p>By clicking submit, you agree to <span>Emush Terms of Use, Privacy Policy</span></p>
                            </div>
                        </div>
                    </div>
                    <div class="btn-area">
                        <button type="submit" name="btnsubmit" class="cmn-btn" value="submit">Submit Now</button>
                    </div>                            
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
</section>
<!-- Register In end -->

<?php include realpath(dirname(__DIR__) . '/common/footer.php'); ?>
<script src="<?php echo $assets_url_var; ?>js/select2.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script>
    var baseURL = "<?php echo base_url(); ?>";
var csrf_name = "<?php  echo $this->security->get_csrf_token_name(); ?>"; // for the name
var csrf_token = "<?php  echo $this->security->get_csrf_hash(); ?>";  // for the value    

$(function(){
  $('#subForm').ebcaptcha();
});

(function($){

    $(".sel_bx").select2();

     $( function() {
        // $( "#datepicker" ).datepicker();
        $('#datepicker').datepicker({changeYear: true, buttonImageOnly: true, yearRange: "-50:+0", changeMonth: true, dateFormat: 'mm-dd-yy'});
    });

    jQuery.fn.ebcaptcha = function(options){

        var element = this;
        var input = this.find('#ebcaptchainput');
        var label = this.find('#ebcaptchatext');

        var randomNr1 = 0;
        var randomNr2 = 0;
        var totalNr = 0;

        randomNr1 = Math.floor(Math.random()*10);
        randomNr2 = Math.floor(Math.random()*10);
        
        $('#number1').val(randomNr1);
        $('#number2').val(randomNr2);

        totalNr = randomNr1 + randomNr2;
        var texti = "What is "+randomNr1+" + "+randomNr2;
        $(label).text(texti);
    };

})(jQuery);


$(document).ready(function () {


    var _inpname1 = $('.inp1_uppercase');
    _inpname1.keypress(function () {
        var _val = _inpname1.val();
        var _txt = _val.charAt(0).toUpperCase() + _val.slice(1);
        _inpname1.val(_txt);
    })


    var _inpname2 = $('.inp2_uppercase');
    _inpname2.keypress(function () {
        var _val = _inpname2.val();
        var _txt = _val.charAt(0).toUpperCase() + _val.slice(1);
        _inpname2.val(_txt);
    })

    $.validator.addMethod('totalCheck', function(value, element, params) {
        var field_1 = $('#number1').val(),
        field_2 = $('#number2').val();
        return parseInt(value) === (parseInt(field_1) + parseInt(field_2));
    }, "Enter the valid number");


    $.validator.addMethod("strong_password", function (value, element) {
        let password = value;
        if (!(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[@#$%&])(.{8,20}$)/.test(password))) {
            return false;
        }
        return true;
    }, function (value, element) {
        let password = $(element).val();
        if (!(/^(.{8,20}$)/.test(password))) {
            return 'Password must be between 8 to 20 characters long.';
        }
        else if (!(/^(?=.*[A-Z])/.test(password))) {
            return 'Password must contain at least one uppercase.';
        }
        else if (!(/^(?=.*[a-z])/.test(password))) {
            return 'Password must contain at least one lowercase.';
        }
        else if (!(/^(?=.*[0-9])/.test(password))) {
            return 'Password must contain at least one digit.';
        }
        else if (!(/^(?=.*[@#$%&])/.test(password))) {
            return "Password must contain special characters from @#$%&.";
        }
        return false;
    });

        $('#subForm').validate({ // initialize the plugin
            rules: {

                parent: {
                    required: {
                        depends:function(){
                            $(this).val($.trim($(this).val()));
                            return true;
                        }
                    },
                    // remote: baseURL + "is-ref-exist"           
                },
                first_name: {
                    required: {
                        depends:function(){
                            $(this).val($.trim($(this).val()));
                            return true;
                        }
                    },           
                },
                last_name: {
                    required: {
                        depends:function(){
                            $(this).val($.trim($(this).val()));
                            return true;
                        }
                    },
                },
                tenrealm_email: {
                    required: {
                        depends:function(){
                            $(this).val($.trim($(this).val()));
                            return true;
                        }
                    },
                    email: true,                     
                    remote: baseURL + "is-email-exist"
                },
                tenrealm_password: {
                    required: true,
                    minlength: 5,
                    strong_password:true
                },
                cnfm_password: {
                    required: true,
                    minlength: 5,
                    equalTo: "#tenrealm_password"
                },
                ebcaptchainput: {
                    required: {
                        depends:function(){
                            $(this).val($.trim($(this).val()));
                            return true;
                        }
                    },
                    totalCheck: true
                },
                beb_address: {
                    required: {
                            depends:function(){
                            $(this).val($.trim($(this).val()));
                            return true;
                        }    
                    },
                    remote: baseURL + "is-beb-exist"
                },                
            },
            messages:{
             tenrealm_email: {                
                remote: jQuery.validator.format("This {0} is already exists!.")
            },
            parent: {                
                remote: jQuery.validator.format("This {0} is not valid referral!.")
            },
            beb_address: {                
                remote: jQuery.validator.format("This {0} is already exists!.")
            },

        }
    });


        // $(document).on('click', '.click_here_cls', function(event) {
        //     event.preventDefault();
            /* Act on the event */
            // $('#referral').val("<?php //echo (REGISTER_VAR) ? REGISTER_VAR :''; ?>");
        // });

    });

</script>
</body>
</html>