<?php include realpath(dirname(__DIR__) . '/common/inner_header.php'); ?>
<?php
$unique_id = ($users->unique_id) ? $users->unique_id :'';
$wlink = base_url()."signup?ref=".$unique_id;
$main_balance_centum = 24471955;
$level_income_centum = 24072544;
$global_income_centum = 381136;
$sponsor_income_centum = 18275;
?>

<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css">
  .ui-dialog-titlebar-close {
    visibility: hidden;
}

.disableClick{
    pointer-events: none;
}
.modal-confirm {    
  color: #636363;
  width: 400px;
}
.modal-confirm .modal-content {
  padding: 20px;
  border-radius: 5px;
  border: none;
  text-align: center;
  font-size: 14px;
}
.modal-confirm .modal-header {
  border-bottom: none;   
  position: relative;
}
.modal-confirm h4 {
  text-align: center;
  font-size: 26px;
  margin: 30px 0 -10px;
}
.modal-confirm .close {
  position: absolute;
  top: -5px;
  right: -2px;
}
.modal-confirm .modal-body {
  color: #999;
}
.modal-confirm .modal-footer {
  border: none;
  text-align: center;   
  border-radius: 5px;
  font-size: 13px;
  padding: 10px 15px 25px;
}
.modal-confirm .modal-footer a {
  color: #999;
}   
.modal-confirm .icon-box {
  width: 80px;
  height: 80px;
  margin: 0 auto;
  border-radius: 50%;
  z-index: 9;
  text-align: center;
  border: 3px solid #3fc3ee;
}
.modal-confirm .icon-box i {
  color: #3fc3ee;
  font-size: 46px;
  display: inline-block;
  margin-top: 13px;
}
.modal-confirm .btn, .modal-confirm .btn:active {
  color: #fff;
  border-radius: 4px;
  background: #60c7c1;
  text-decoration: none;
  transition: all 0.4s;
  line-height: normal;
  min-width: 120px;
  border: none;
  min-height: 40px;
  border-radius: 3px;
  margin: 0 5px;
}
.modal-confirm .btn-secondary {
  background: #c1c1c1;
}
.modal-confirm .btn-secondary:hover, .modal-confirm .btn-secondary:focus {
  background: #a8a8a8;
}
.modal-confirm .btn-danger {
  background: #f15e5e;
}
.modal-confirm .btn-danger:hover, .modal-confirm .btn-danger:focus {
  background: #ee3535;
  position:absolute;
    top : 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: black;
    content:"";
    pointer-events: none;
    z-index:100;
    opacity: .5
}
.trigger-btn {
  display: inline-block;
  margin: 100px auto;
}

body.modal-open .container{
/*    -webkit-filter: blur(4px);
    -moz-filter: blur(4px);
    -o-filter: blur(4px);
    -ms-filter: blur(4px);
    filter: blur(4px);
    filter: url("https://gist.githubusercontent.com/amitabhaghosh197/b7865b409e835b5a43b5/raw/1a255b551091924971e7dee8935fd38a7fdf7311/blur".svg#blur);
    filter:progid:DXImageTransform.Microsoft.Blur(PixelRadius='4');*/



}
/*
body:before{
    position:absolute;
    top : 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: black;
    content:"";
    pointer-events: none;
    z-index:100;
    opacity: .5

}*/
</style> 
<div class="page-body" style="background-color:#350b2d">
  <div class="container-xl">
    <div class="row row-deck row-cards">
      <div class="col-md-12 p-1">
        <div class="card shadow radius-20">
          <div class="card-body">
            <div class="row g-2 align-items-center">
              <div class="col-lg-12">
                <div class="row g-2 align-items-center">
                  <div class="col-auto text-center w-100"> <span class="avatar avatar-lg" style="border-radius:100%; background-image: url('<?php echo ($pp)? $pp:$dummy_user; ?>')"></span> </div>
                  <div class="col-12">
                    <div class="card-body p-0 ">
                      <div class=" text-center">
                        <div class="small mt-1"> USER NAME:<strong> <?php echo user_id_to_name($user_id);?></strong></div>
                        <?php 
                       if($current_package_payment){                                       
                          ?>

                          <div class="subheader"> UNIQUE ID: <span id="get_unique_id_values"><?php echo preg_replace('/(?<=\d)(?=(\d{4})+$)/', ' ', $unique_id); ?></span>
                        
                            <a data-toggle="tooltip" data-placement="button" title="Copy to Clipboard" href="javascript:;" id="copy32343534" class="copy32343534">
                              <input type="hidden" value="<?php echo $wlink; ?>" name="hlink" id="hlink" class="hlink">
                              <!-- <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                <path d="M10 14a3.5 3.5 0 0 0 5 0l4 -4a3.5 3.5 0 0 0 -5 -5l-.5 .5" />
                                <path d="M14 10a3.5 3.5 0 0 0 -5 0l-4 4a3.5 3.5 0 0 0 5 5l.5 -.5" />
                              </svg> -->

                              <i id="referral_link" class="fa fa-link fa-6 referral_link" aria-hidden="true" style="font-size:12px;"></i>
                            </a>

                            <!-- <i id="referral_link" class="fa fa-check fa-lg" aria-hidden="true" style="display:none;color:green;"></i> -->
                            <div id="show_copied_to_clipboard" style="display: none;color:green;">Copied</div>
                          </div>
                        <?php  } ?>
                        <div class="small mt-1"> Last Activity : <span><strong><?php echo (isset($login_history['date'])) ? timestamp_UTC_conversion($login_history['date'], 'jS F Y, H:i') : '';?> UTC</strong></span></div>
                        <div class="small mt-1"> Total Earnings</div>
                        <div class="h1 mb-0 font-weight-bold"><?php echo $total_earning; ?><span class="small text-h4"> EMD</span></div>
                      </div>
                    </div>
                  </div>
                </div>
                
                
                <div class="row">
                  <div class="col-sm-6 mt-3">
                    <div class="card card-sm bg-azure-lt border-0"  >
                      <a style="background-color:red;color:white"  href="<?php echo base_url();?>user-transfer" class="btn btn-azure w-100 mt-2 btn-grad custome-btn">Transfer</a>
                    </div>
                    <a   style="background-color:#df00ff;color:white"   href="<?php echo base_url();?>transactions" class="btn btn-azure w-100 mt-2 btn-grad custome-btn">Transactions</a> </div>
                    <div class="col-sm-6 mt-3">
                    <div class="card card-sm bg-azure-lt border-0"  >
                      <a   style="background-color:#00ffa9;color:white" href="<?php echo base_url();?>activation" class="btn btn-azure w-100 mt-2 btn-grad custome-btn">Activation</a>
                    </div>
                    <a   style="background-color:#00ffff;color:white"  href="<?php echo base_url();?>payment" class="btn btn-azure w-100 mt-2 btn-grad custome-btn">Deposit/Withdraw</a></div>
                    </div>
                
                
                <div class="row">
                  <div class="col-sm-4 mt-3">
                    <div class="card card-sm bg-azure-lt border-0"  >
                      <div class="card-body">
                        <div class="row align-items-center">
                          <div class="col-auto p-0 "> <span class="text-blue avatar bg-none">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="44" height="44" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                              <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                              <line x1="12" y1="5" x2="12" y2="19" />
                              <line x1="18" y1="13" x2="12" y2="19" />
                              <line x1="6" y1="13" x2="12" y2="19" />
                            </svg>
                          </span> </div>
                          <div class="col">
                            <div class="font-weight-bold h5 m-0"><?php echo ($pym = number_format(get_pym_Balance_only($user_id),2) ?? 0.00);  ?><span class="small text-h6"> EMD</span></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <a href="javascript:;"  style="background-color:#ba9b35;color:white"   class="btn btn-azure w-100 mt-2 btn-grad custome-btn"> Available Balance </a>
                  </div>


                    <div class="col-sm-4 mt-3">
                      <div class="card card-sm  bg-azure-lt border-0">
                        <div class="card-body">
                          <div class="row align-items-center">
                            <div class="col-auto p-0"> <span class="text-blue avatar bg-none">
                              <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                <line x1="12" y1="5" x2="12" y2="19" />
                                <line x1="18" y1="11" x2="12" y2="5" />
                                <line x1="6" y1="11" x2="12" y2="5" />
                              </svg>
                            </span> </div>
                            <div class="col">
                              <div class="font-weight-bold h5 m-0">
                                <?php
                              $transfer_balance = get_transfer_Balance($user_id);
                        echo ($transfer_balance) ? number_format($transfer_balance, 2) : 0;
                         ?><span class="small text-h6"> EMD</span></div>                              
                            </div>
                          </div>
                        </div>
                      </div>
                      <a href="#"  style="background-color:#ffdf00;color:white"    class="btn btn-indigo w-100 mt-2 btn-grad cmn-btn"> Transfer </a> 
                    </div>

                    <div class="col-sm-4 mt-3">
                      <div class="card card-sm  bg-azure-lt border-0">
                        <div class="card-body">
                          <div class="row align-items-center">
                            <div class="col-auto p-0"> <span class="text-blue avatar bg-none">
                              <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                <line x1="12" y1="5" x2="12" y2="19" />
                                <line x1="18" y1="11" x2="12" y2="5" />
                                <line x1="6" y1="11" x2="12" y2="5" />
                              </svg>
                            </span> </div>
                            <div class="col">
                              <div class="font-weight-bold h5 m-0"> <?php echo number_format($withdraw_package_payment,2) ?? 0.00; ?><span class="small text-h6"> EMD</span></div>                              
                            </div>
                          </div>
                        </div>
                      </div>
                      <a href="#" style="background-color:#656d77;color:white"    class="btn btn-indigo w-100 mt-2 btn-grad cmn-btn"> Total Withdraw </a> 
                    </div>

                    </div>
                  </div>
                  <!--<div class="col-lg-4">-->
                  <!--  <div class="row g-2 align-items-center">-->
                  <!--    <div class="col">-->
                  <!--      <div class="card-body tencardd p-0 text-center ">-->
                  <!--        <h3 class="card-title">Current Package</h3>-->
                  <!--        <div class="vh-40 position-relative w-100" style="display:none"-->
                      
                  <!--        <div class="col-12 w-90 text-right text-white"  >-->
                  <!--          <h1 class="plan-no" >
                  
                       -->
                  <!--          }-->
                  <!--          ?></h1>-->
                  <!--        </div>                        -->
                  <!--      </div>-->
                  <!--    </div>-->
                  <!--  </div>-->
                  <!--</div>-->
                
                <div class="col-lg-12 mt-3">
                  <div class="row g-2 align-items-center">
                    <div class="col-lg-6">
                      <div class="card-body p-0 ">
                        <div class="card border-0 shadow-n" style="height: calc(16rem + 10px)">
                          <div class="card-body card-body-scrollable card-body-scrollable-shadow">
                            <div class="divide-y">
                              <?php 
                              if($packages){
                                foreach ($packages as $pkey => $package) {           

                                  if(in_array($package['id'], $user_package_arr)){
                                    $avatar = 'avatar bg-green-lt';
                                    $badge = 'badge bg-green';
                                  }else{
                                    $avatar = 'avatar bg-red-lt';
                                    $badge = 'badge bg-red'; 
                                  }
                                  ?>
                                  <div class="atv-mlm">
                                    <div class="row ">
                                      <div class="col-auto"> <span class="<?php echo $avatar; ?>">                                       
                                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                          <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                          <circle cx="12" cy="7" r="4" />
                                          <path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2" />
                                        </svg>
                                      </span> </div>
                                      <div class="col">
                                        <div class="text-truncate"> <strong><?php echo ucfirst(($package['package_name'])?$package['package_name']:''); ?></strong> </div>
                                      </div>
                                      <div class="col-auto align-self-center">
                                        <div class="<?php echo $badge; ?>"></div>
                                      </div>
                                    </div>
                                  </div>
                                <?php } } ?>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col">
                      <div class="card-body p-0 ">
                        <div class="card border-0 shadow-n" style="height: calc(16rem + 10px)">
                          <div class="card-body card-body-scrollable card-body-scrollable-shadow">
                            <div class="divide-y">
                              <?php 
                              if($packages){
                                foreach ($packages as $pkey => $package) {           

                                  if(in_array($package['id'], $user_package_arr)){
                                    $avatar = 'avatar bg-green-lt';
                                    $badge = 'badge bg-green';
                                  }else{
                                    $avatar = 'avatar bg-red-lt';
                                    $badge = 'badge bg-red'; 
                                  }
                                  ?>
                                  <div class="atv-mlm">
                                    <div class="row ">
                                      <div class="col-auto"> <span class="<?php echo $avatar; ?>">                                       
                                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                          <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                          <circle cx="12" cy="7" r="4" />
                                          <path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2" />
                                        </svg>
                                      </span> </div>
                                      <div class="col">
                                        <div class="text-truncate"> <strong><?php //echo 'Remaining User'; ?>
                                          <?php
                                          // $user_id = 4;
                                          $package_id = 3;
                                          $levels = $rememing = 0;
                                          // $tree1 =  downline_4x_earning_tester(3, 1, 1, 1);
                                          // $tree2 =  downline_4x_earning_tester(3, $user_id, 1, 1);
                                          // $rem = downline_remainder($package_id, $user_id, $increment=1, $chart_level=1);
                                                                                    

                                          //   // Zero level user calc
                                          //   for ($i=1; $i <= count($tree1[0]); $i++) {
                                          //     $last_level = $i;
                                          //     $tree_pointer_end_arr = (($tree1[0][$i]));  
                                          //     $tree_pointer_end_count = (count($tree1[0][$i]));  
                                          //   }

                                          //   $current_count = 0;
                                          //   foreach ($tree_pointer_end_arr as $key => $value) {
                                          //     if($value['user_id'] == $user_id){
                                          //       $current_count = $key+1;
                                          //     }
                                          //   }
                                          //   echo $last_level;
                                          //   echo $current_count_place = ($current_count + pow(4, $last_level)) - $tree_pointer_end_count;
                                          //   exit;
                                          //   echo $tree_pointer_id = $tree_pointer_end['id'];
                                          //   $find_position = multi_array_search($tree1[0], array('id' => $tree_pointer_id));
                                          //   echo 'Remaining-->'.$rememing = (pow(4, $find_position[0]) - $find_position[1]) + $find_position[1]  * 4;
                                          // // print_r($tree1);
                                          // exit;
 
                                          // echo '-SATZ343- <br>';
                                          // $levels = 1;
                                          // $find_position = multi_array_search($tree1[0], array('user_id' => $user_id));
                                          // $rememing = (pow(4, $find_position[0]) - $find_position[1]) + $find_position[1]  * 4;
                                          // print_r((count($rem)));
                                          // print_r((($tree2) && count($rem) > 0));
                                          // print_r($tree2);
                                          // print_r($rem);exit;
                                          // if(($tree2) && count($rem) > 0){
                                          //   foreach(range(1, count($rem)) as $ke => $val){
                                          //     if($rem[$val]==0){
                                          //         echo "-SATZ1-";
                                          //         print_r(count($tree1));

                                          //       }else{
                                          //         echo "-SATZ2-";
                                          //         $levels = count($rem);
                                          //         $rememing = $rem[$val];
                                          //       }
                                          //   }
                                          // }else{

                                          //   echo '-SATZ3-';
                                          //   $levels = 1;
                                          //    // Zero level user calc
                                          //   for ($i=1; $i <= count($tree1[0]); $i++) {
                                          //     $last_level = $i;
                                          //     $tree_pointer_end = (end($tree1[0][$i]));
                                          //     $tree_pointer_end_arr = (($tree1[0][$i]));  
                                          //     $tree_pointer_end_count = (count($tree1[0][$i]));  
                                          //   }

                                          //   $current_count = 0;
                                          //   foreach ($tree_pointer_end_arr as $key => $value) {
                                          //     if($value['user_id'] == $user_id){                                                
                                          //       $current_count = $key+1;
                                          //     }
                                          //   }
                                            
                                          //   // echo $current_levels;
                                          //   // exit;

                                          //   $is_last_record = $tree_pointer_end_count - $current_count;
                                          //   if($is_last_record == 0){
                                          //     // Allow only last record calc
                                          //     $rememing = $current_count_place = (pow(4, $last_level) - $tree_pointer_end_count) + $current_count * 4;
                                          //   }else{
                                          //     // Before last record calc
                                          //     // echo $tree_pointer_id = $tree_pointer_end['id'];
                                          //     // $find_position = multi_array_search($tree1[0], array('id' => $tree_pointer_id));
                                          //     // echo 'Remaining-->'.$rememing = (pow(4, $find_position[0]) - $find_position[1]) + $find_position[1]  * 4;
                                          //     echo 'current' . $current_count;
                                          //     echo 'Power Only<br>'. (pow(4, $last_level));
                                          //     echo 'Power <br>'. (pow(4, $last_level) - $tree_pointer_end_count);

                                          //     $rememing = $current_count_place = (pow(4, $last_level) - $tree_pointer_end_count) + $current_count * 4;
                                          //   }
                                          // }


                                          // // Total four scenario
                                          // // 1. Last record of the user package activated-Done
                                          // // 2. Last before record user - Done
                                          // // 3. First user package activated-Done
                                          // // 4. Zero level package activated-Pending


                                          // echo "For \t". $levels ." level";
                                          // echo " rememing \t".($rememing);
                                          $rememing_arr = $this->db->get_where('remaining_user', [ 'user_id' => $user_id])->result_array();
                                          // echo $this->db->last_query();exit;
                                          if($rememing_arr){
                                            // print_r($rememing_arr);exit;
                                            foreach(range(1, 4) as $fkey => $val){
                                              $fkey = $fkey + 1;
                                              $in = 'l'.$fkey;
                                              if($rememing_arr[0][$in] == 0){
                                                echo 'The users have finished the rememing of level '. $fkey ."<br>";  
                                              }else{
                                                echo 'Remaining level '. $fkey . ' user'. $rememing_arr[0][$in]."<br>";
                                              }
                                              
                                            }
                                          }
                                          ?>
                                        </strong> </div>
                                      </div>
                                      <div class="col-auto align-self-center">
                                        <div class="<?php echo $badge; ?>"></div>
                                      </div>
                                    </div>
                                  </div>
                                <?php } } ?>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-12 p-1">
            <div class="card card-sm  shadow radius-20">
              <div class="card-header">
                <h3 class="card-title"> Wallets </h3>
              </div>
              <div class="card-body">
                <div class="row p-2">
                  <div  style="display:none"  class="col-sm-6 col-lg-3 mb-2">
                    <div class="card with-radial-gradient">
                      <div class="empty p-2">
                        <div class="empty-img"><img src="<?php echo $assets_url_var; ?>static/illustrations/undraw_quitting_time_dm8t.svg" height="128"  alt=""> </div>
                        <h4 class="">TOTAL SEGMENT</h4>
                        <div class="text-muted "><span class="main-balance-amount-status"> <?php $calc_main_balance = $main_balance=($sum_user_level_income + $sum_user_direct_income + $sum_user_team_income);
                        echo ($main_balance) ? number_format($main_balance, 2) : 0;
                        ?> </span> <span class="small text-h6"> EMD</span> </div>            
                      </div>
                    </div>
                  </div>

                       <div class="col-sm-4 mb-2">
                    <div class="card with-radial-gradient">
                      <div class="empty p-2">
                        <div class="empty-img"><img src="<?php echo $assets_url_var; ?>static/illustrations/undraw_quitting_time_dm8t.svg" height="128"  alt=""> </div>
                        <h3 class="">DIRECT LEVEL SEGMENT</h3>
                        <div class="text-muted"><span class="claim-amount-status"> <?php echo (!empty($sum_user_direct_income)) ? number_format($sum_user_direct_income, 2) : 0.00 ?></span> <span class="small text-h6"> EMD</span> </div>
                        <div class="empty-action"> <div class="claim-status" ></div> <a href="javascript:;" class="btn btn-grad border-0 global-income-claim" data-type="global"> CLAIM </a> </div>
                      </div>
                    </div>
                  </div>

                  <div class="col-sm-4  mb-2">
                    <div class="card with-radial-gradient">
                      <div class="empty p-2">
                        <div class="empty-img"><img src="<?php echo $assets_url_var; ?>static/illustrations/undraw_quitting_time_dm8t.svg" height="128"  alt=""> </div>
                        <h4 class="">AUTOFILLED LEVEL SEGMENT</h4>
                        <div class="text-muted"><span class="claim-amount-status"> <?php echo (!empty($sum_user_level_income))? number_format($sum_user_level_income, 2) : 0.00 ?> <?php //echo checkAvailableUserChildren($user_id) ? '' : 'disabled'; ?> </span> <span class="small text-h6"> EMD</span> </div>
                        <div style="display: flex;">
                          <?php
                          $my_profit_level1 = $this->db->select('*')->get_where('global_4x_profit', ['receiver_user_id' => $user_id, 'level' => '1'])->row();
                          if($my_profit_level1){
                        $status1 = $my_profit_level1->status;
                        $db_level1 = $my_profit_level1->level;
                        $style = $status1 ==0 ? "style='background:red';" : '';
                        $is_already_claimed = $status1 ==0 ? "7" : '0';
                         ?>
                        <div class="empty-action"><div class="claim-status" ></div> <a href="javascript:;" class="btn btn-grad border-0 level-income-claim" data-position="1" <?php echo $style;?> data-type="level" data-require_user="<?php echo $is_already_claimed; ?>"> CLAIM 1 </a> </div>
                        <?php 
                        }
                        // current position
                        $lev = 0; $k=1;
                        foreach (range(2, 4) as $key => $value) {
                        
                        $lev +=$k++;
                        $my_profit_level = $this->db->select('*')->get_where('global_4x_profit', ['receiver_user_id' => $user_id, 'level' => $value])->row();
                        if($my_profit_level && $my_profit_level->status != 0){
                        $status = $my_profit_level->status;
                        $db_level = $my_profit_level->level;
                        // echo my_last_query();
                        if($db_level == $value){
                        // $user_id=1;
                         $required_user =  $this->db->select("count('id') as cid")->get_where('package_4x_payment', ['direct_parent' => $user_id ])->row('cid');
                         // echo $this->db->last_query()."\n";
                         $r = $required_user ? $required_user : 0;
                         // echo 'Lev'.$lev.'rr'.$r. "\t" . $key; var_dump($r !=0 && $r >= $value && $lev <= $value);
                         // echo "R-->".Fibonacci($r)."\n";
                         $rlev[2] = 1;
                         $rlev[3] = 3;
                         $rlev[4] = 6;

                         if($r !=0 && $r >= $value && $lev <= $value){
                          $rememing = 0;
                         }else{
                          $r = $r < 6 ? $r : 6;
                          $rememing = $rlev[$value] - $r;
                         }
                         $style = $status ==0 ? "style='background:red';" : '';
                         
                         if($value == 2 && $db_level == 2){ 
                         //echo '->'.$rememing; 
                          $rememing = ($rememing<=1) ? $rememing : '1';
                          ?>
                        <div class="empty-action"><div class="claim-status" ></div> <a href="javascript:;" class="btn btn-grad border-0 level-income-claim" <?php echo $style; ?>   data-type="level" data-require_user="<?php echo $rememing; ?>" data-position="<?php echo $value; ?>"> CLAIM <?php echo $value; ?></a> </div>
                        <?php } 

                        if($value == 3 && $db_level == 3){
                        //echo '->'.$rememing;
                          $rememing = ($rememing<=2) ? $rememing : '2';
                           ?>
                        <div class="empty-action"><div class="claim-status" ></div> <a href="javascript:;" class="btn btn-grad border-0 level-income-claim" <?php echo $style; ?>   data-type="level" data-require_user="<?php echo $rememing; ?>" data-position="<?php echo $value; ?>"> CLAIM <?php echo $value; ?></a> </div>
                        <?php } 

                         if($value == 4 && $db_level == 4){ 
                          //echo '->'.$rememing;
                          $rememing = ($rememing<=3) ? $rememing : '3';
                           ?>
                        <div class="empty-action"><div class="claim-status" ></div> <a href="javascript:;" class="btn btn-grad border-0 level-income-claim" <?php echo $style; ?>  data-type="level" data-require_user="<?php echo $rememing; ?>" data-position="<?php echo $value; ?>"> CLAIM <?php echo $value; ?></a> </div>
                        <?php } 
                         } }else if($my_profit_level && $my_profit_level->status == 0){
                          $status = $my_profit_level->status;
                          
                          
                        $status = $my_profit_level->status;
                        $db_level = $my_profit_level->level;
                        // echo my_last_query();
                        if($db_level == $value){
                        // $user_id=1;
                         $required_user =  $this->db->select("count('id') as cid")->get_where('package_4x_payment', ['direct_parent' => $user_id ])->row('cid');
                         // echo $this->db->last_query()."\n";
                         $r = $required_user ? $required_user : 0;
                         // echo 'Lev'.$lev.'rr'.$r. "\t" . $key; var_dump($r !=0 && $r >= $value && $lev <= $value);
                         // echo "R-->".Fibonacci($r)."\n";
                         $rlev[2] = 1;
                         $rlev[3] = 3;
                         $rlev[4] = 6;

                         if($r !=0 && $r >= $value && $lev <= $value){
                          $rememing = 0;
                         }else{
                          $r = $r < 6 ? $r : 6;
                          $rememing = $rlev[$value] - $r;
                         }
                         $style = $status ==0 ? "style='background:red';" : '';
                         
                         if($value == 2 && $db_level == 2){ 
                         //echo '->'.$rememing; 
                          $rememing = ($rememing<=1) ?  $status==0 ? 7 : $rememing : '1';
                          ?>
                        <div class="empty-action"><div class="claim-status" ></div> <a href="javascript:;" class="btn btn-grad border-0 level-income-claim" <?php echo $style; ?>   data-type="level" data-require_user="<?php echo $rememing; ?>" data-position="<?php echo $value; ?>"> CLAIM <?php echo $value; ?></a> </div>
                        <?php } 

                        if($value == 3 && $db_level == 3){
                        //echo '->'.$rememing;
                          $rememing = ($rememing<=2) ? $status==0 ? 7 : $rememing : '2';
                           ?>
                        <div class="empty-action"><div class="claim-status" ></div> <a href="javascript:;" class="btn btn-grad border-0 level-income-claim" <?php echo $style; ?>   data-type="level" data-require_user="<?php echo $rememing; ?>" data-position="<?php echo $value; ?>"> CLAIM <?php echo $value; ?></a> </div>
                        <?php } 

                         if($value == 4 && $db_level == 4){ 
                          //echo '->'.$rememing;
                          $rememing = ($rememing<=3) ? $status==0 ? 7 : $rememing : '3';
                           ?>
                        <div class="empty-action"><div class="claim-status" ></div> <a href="javascript:;" class="btn btn-grad border-0 level-income-claim" <?php echo $style; ?>  data-type="level" data-require_user="<?php echo $rememing; ?>" data-position="<?php echo $value; ?>"> CLAIM <?php echo $value; ?></a> </div>
                        <?php } 
                         } 
                         }
                      }?>
                        </div>
                      </div>
                    </div>
                  </div>
             
                  <div class="col-sm-4  mb-2">
                    <div class="card with-radial-gradient">
                      <div class="empty p-2">
                        <div class="empty-img"><img src="<?php echo $assets_url_var; ?>static/illustrations/undraw_quitting_time_dm8t.svg" height="128"  alt=""> </div>
                        <h4 class="">TEAM LEVEL SEGMENT</h4>
                        <div class="text-muted"><span class="claim-amount-status"><?php echo (!empty($sum_user_team_income))? number_format($sum_user_team_income, 2) : 0.00 ?></span><span class="small text-h6"> EMD</span> </div>
                        <div class="empty-action"> <div class="claim-status" ></div> <a href="javascript:;" class="btn btn-grad border-0 sponsor-income-claim" data-type="sponsor"> CLAIM </a> </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
       
    </div>
  </div>
</div>

<?php include realpath(dirname(__DIR__) . '/common/inner_footer.php'); ?>

<div id="income-confirmation-dialog" title="Confirmation Required">
  Are you sure about this?
</div>
<script>   

$(document).ready(function() {

    $('#modal-claim').modal({backdrop:'static', keyboard: false}); 
    $( '.copy32343534, .whatsapp_cls' ).tooltip();
   
})


  if (document.querySelector('.copy32343534') !== null) {
    document.getElementById("copy32343534").addEventListener("click", copy_password);
  }
  
  function copy_password(e) {
    e.preventDefault();
    var text = document.getElementById('hlink').value;
    var elem = document.createElement("textarea");
    document.body.appendChild(elem);
    elem.value = text;
    elem.select();
    document.execCommand("copy");
    document.body.removeChild(elem);

    $('.referral_link').removeClass('fa-link').addClass('fa-check');
    $('.referral_link').delay(1000).fadeOut('slow');
    
    $("#copy32343534").load(location.href + " #copy32343534>*", "");

  }

</script>


<?php if(isset($remaining_period_timestamp)){ ?>
  <script type="text/javascript">
//    var countDownDate = <?php echo $remaining_period_timestamp; ?> * 1000;
//    var now = <?php echo time() ?> * 1000;

// // Update the count down every 1 second
// var x = setInterval(function() {
//   now = now + 1000;
// // Find the distance between now an the count down date
// var distance = countDownDate - now;
// // Time calculations for days, hours, minutes and seconds
// var days = Math.floor(distance / (1000 * 60 * 60 * 24));
// var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
// var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
// var seconds = Math.floor((distance % (1000 * 60)) / 1000);
// // Output the result in an element with id="demo"
// document.getElementById("package-remainder").innerHTML = days + "d " + hours + "h " + minutes + "m " + seconds + "s ";
// // If the count down is over, write some text 
// if (distance < 0) {
//   clearInterval(x);
//   document.getElementById("package-remainder").innerHTML = "EXPIRED";
// }

// }, 1000);

</script>
<?php } ?>


<script type="text/javascript">
  
  $(document).ready(function() {
    var confirmDialogId = $('#income-confirmation-dialog');

    $(confirmDialogId).dialog({
      autoOpen: false,
      modal: true,
      dialogClass:'transparent'
    });

    $.fn.confirmation = function(_this, dialogTitle=''){
      var remainingBal = '0.00';
      var myDialog = $(confirmDialogId).dialog({
        closeOnEscape: false,
        // width: 'auto',
        width: 'auto',
        bgiframe:true,
        resizable: true,
        autoOpen: false,
        title: dialogTitle || 'Confirm',
        modal: true,
        open: function(event, ui) {
            $(".ui-dialog-titlebar-close", ui.dialog || ui).hide();
        },
        buttons : {
          "Confirm" : function() {
            var _claim_parent = _this.closest('.with-radial-gradient');
            var Type = _this.data('type');
            let require_user = _this.data('require_user');
            let position = _this.data('position');
            $.ajax({
              url: baseURL + 'claim',
              type: 'POST',
              dataType: 'json',
              data: {type : Type, require_user:require_user, position:position},
              success: function(res) {
                if(res.status == true){
                  $('.main-balance-amount-status').html(res.main_balance.toString(2));
                   
                    remainingBal = res.remaining;
                   
                  _claim_parent.find('span.claim-amount-status').html(remainingBal);
                  _claim_parent.find('.claim-status').html(res.msg).show().delay(4000).fadeOut();
                }
                myDialog.dialog('close');
              }
            });            
          },
          "Cancel" : function() {
            $(this).dialog("close");
          }
        }
      });

      $(confirmDialogId).dialog("open");
       // $('#modal-claim').modal('show'); 

        
    }


    $(document).on('click', '.level-income-claim, .global-income-claim, .sponsor-income-claim', function(event) {
      event.preventDefault();
      /* Act on the event */
      var _this = $(this);
      let _type = $(this).data('type');
      if(_type == 'level'){
        let require_user = _this.data('require_user');
        if(require_user == 7){
          alert("Already you have claimed!.");
          return;
        }else if(require_user != 0){
          alert("Need reference "+ require_user +" user");
          return;
        }         
      }
      $.fn.confirmation(_this);
      
        // $('#type').val($(this).data('type'));
        // $('#modal-claim').modal('show');   
    });


  });


// $(document).on('click', '.close-modal', function() {

//   $("#modal-claim").modal("hide"); 
// });




// function confirm_levelincome(_this) {
    
//     console.log(_this);
//     return;
    
//     var remainingBal = '0.00';
//     var Type = $('#type').val();
//     var _claim_parent = _this.closest('.with-radial-gradient');
//     var Type = _this.data('type');



//     $.ajax({
//       url: baseURL + 'claim',
//       type: 'POST',
//       dataType: 'json',
//       data: {type : Type},
//       success: function(res) {
//         if(res.status == true){
//           $('.main-balance-amount-status').html(res.main_balance.toString(2));
//           _claim_parent.find('span.claim-amount-status').html(remainingBal);
//           _claim_parent.find('.claim-status').html(res.msg).show().delay(4000).fadeOut();
//         }
//         // myDialog.dialog('close');
//       }
//     }); 
// }


</script>
</body>
</html>