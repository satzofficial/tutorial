<?php include realpath(dirname(__DIR__) . '/common/inner_header.php'); 

$sym = $dig_currency->currency_symbol;
$link="https://live.blockcypher.com/ltc/address/".$coin_address;
?>
  <div class="page-wrapper">
    <div class="page-body">
      <div class="container-xl">
        <ol class="breadcrumb breadcrumb-arrows mb-3" aria-label="breadcrumbs">
          <li class="breadcrumb-item"><a href="#">Wallet</a></li>
          <li class="breadcrumb-item active" aria-current="page">Activated</li>
        </ol>
        <div class="row row-cards">
          <div class="col-sm-8" style="margin: 0px auto;">
            <style>
              @media(max-width:600px){
                .s_dep_h1{
                  font-size: 26px !important;
                }
              }
              .s_dep_out{
                display: block;
                width:100%;
                background-color: #fff;
                padding: 30px;
                border-top:10px solid #2b6bfa;
                border-radius: 10px;
              }
              .s_dep_h1{
                display: block;
                font-size: 34px;
                text-align: center;
                margin-bottom: 30px;
              }
              .s_dep_h2{
                display: block;
                width: 100%;
                padding: 20px 0px;
              border-top:1px solid rgba(0,0,0,0.1);
              border-bottom:1px solid rgba(0,0,0,0.1);
           
              }
              .s_dep_h3st{
                display: block;
                width: 100%;
                padding: 20px 0px;
              border-top:1px solid rgba(0,0,0,0.1);
              border-bottom:1px solid rgba(0,0,0,0.1);
              }
              .s_dep_h4st{
                display: block;
                width: 100%;
                padding: 20px 0px;
            
              }
              .s_dep_h3hd{
                display: block;
                line-height: 1.6;
                font-size: 16px;
                font-weight: 400;
                color:#666;
                text-align: center;
                margin-bottom: 20px;
              }
              .s_dep_h3li{
                display: block;
                position: relative;
                width: 100%;
                font-size: 14px;
                line-height: 1.6;
                color:#666;text-align: right;
                margin-bottom: 10px;
              }
              .s_dep_h3li span:before{
                content:":";
                display: block;
                line-height: 1.6;
                position: absolute;
                left: 8px;
                color:#777;
                font-size: 14px;top:0px;
              }
              .s_dep_h3li span{
                display: inline-block;
                width: 50%;
                text-align: left;
                padding-left: 20px;
                color:#000;
                position: relative;
                font-weight: 600;
              }
              .s_dep_h4li{
                display: block;
                position: relative;
                width: 100%;
                font-size: 12px;
                line-height: 1.6;
                color:#666;
                margin-bottom: 10px;
              }
            
              .s_dep_h4li span{
                display: block;
                width: 100%;
                text-align: left;
                font-size: 14px;
                color:#000;
                position: relative;
                font-weight: 600;
                word-break: break-all;
              }
              .s_dep_h2{
                display: block;
                font-size: 16px;
                font-weight: 400;
                color:#000;
              }
              .s_dep_h2 span{
                display: block;
                font-size: 20px;
                font-weight: 600;
                color:#666;
                float: right;
                line-height: 1;
                
              }
              .s_dep_h2 img{
                display: inline-block;
                width: 20px;
                margin-right: 10px;
              }
              .s_dep_img{
                display: block;
                width: 100%;
                object-fit: contain;
                height: 100px;
                padding: 10px 0px;
              }
            </style>
          <div class="s_dep_out">
          <div class="s_dep_h1"><?php echo $transaction->type?> Successful </div>
          <div class="s_dep_h2"><?php echo $transaction->transfer_amount?> <b><?php echo $sym?></b> <span>$<?php echo $transaction->fiat_amount?></span></div>
          <img src="<?php echo front_img()?>check-tick.jpg" class="s_dep_img">
       
          <div class="s_dep_h3st">
          <div class="s_dep_h3hd"><?php echo $transaction->type?> Details</div>
          <div class="s_dep_h3li">Total Amount <span><?php echo $transaction->transfer_amount?> <?php echo $sym?></span></div>
          <div class="s_dep_h3li">Settled Amount <span><?php echo $transaction->transfer_amount?> <?php echo $sym?></span></div>

      <?php if($transaction->type=='Deposit') {?>

          <div class="s_dep_h3li">Requested Sum <span><?php echo $transaction->fiat_amount?> USD</span></div>
          <div class="s_dep_h3li">Settled Sum <span><?php echo $transaction->amount?> USD</span></div>
      <?php } else {?>
          <div class="s_dep_h3li">Requested Sum <span><?php echo $transaction->amount?> USD</span></div>
          <div class="s_dep_h3li">Settled Sum <span><?php echo $transaction->fiat_amount?> USD</span></div>

      <?php } ?>

          
          


          <div class="s_dep_h3li">Transaction Ref ID <span><?php echo $transaction->local_transaction_id?></span></div>
          </div>
          <div class="s_dep_h4st">
            <div class="s_dep_h3hd">Block Details</div>
            <div class="s_dep_h4li">Address <span><?php echo $coin_address?></span></div>
            <div class="s_dep_h4li">Received (Litoshi)<span><?php echo $transaction->transfer_amount?></span></div>
            <div class="s_dep_h4li">Transactions Hash <span><?php echo $transaction->information?></span></div>
            <div class="s_dep_h4li">Transactions Confirmations <span><?php echo $transaction->confirmations?></span></div>
           
  
  
  
            </div>

<a target="_blank" href="<?php echo $link?>">View more details in block</a>

          </div>
          </div>
        </div>
      </div>
    </div>
  </div>


<div class="modal modal-blur fade" id="modal-deposit" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-body">
        <div class="modal-title"> <span class="avatar avatar-xs mt-3 mr-2 avatar-rounded" style="background-image: url(./static/Litecoin-LTC-icon.png)"></span>LITECOIN</div>
        <div>
          <div class="input-group mb-2"> <span class="input-group-text"> UST </span>
            <input type="text" class="form-control" placeholder="Enter depoist value" autocomplete="off">
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-link link-secondary me-auto" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary" data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#modal-qacode">Yes, Deposit</button>
      </div>
    </div>
  </div>
</div>
<div class="modal modal-blur fade" id="modal-activeplan" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-body">
        <div class="modal-title"> <span class="avatar avatar-xs mt-3 mr-2 avatar-rounded" style="background-image: url(./static/Litecoin-LTC-icon.png)"></span>LITECOIN</div>
        <div>
          <div class="input-group mb-2"> <span class="input-group-text"> UST </span>
            <input type="text" class="form-control" placeholder="Enter depoist value" autocomplete="off">
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-link link-secondary me-auto" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary" data-bs-dismiss="modal" >Yes, Deposit</button>
      </div>
    </div>
  </div>
</div>
<div class="modal modal-blur fade" id="modal-qacode" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-body">
        <div class="modal-title h1">
          <h2>Initializing</h2>
        </div>
        <div>
          <div class="row">
            <div class="col-md-6 col-xl-6"> <a class="card card-link" href="#">
              <div class="card-body">
                <div class="row">
                  <div class="col-auto"> <span class="avatar rounded" style="background-image: url(./static/Litecoin-LTC-icon.png)"></span> </div>
                  <div class="col">
                    <div class="font-weight-medium"> <strong>0.00808983</strong> LTC</div>
                    <div class="text-muted">Civil Engineer</div>
                  </div>
                </div>
              </div>
              </a> <span class="badge bg-green-lt mt-1">Copied to clipboard!</span> </div>
            <div class="col-md-6 col-xl-6"> <a class="card card-link" href="#">
              <div class="card-body">
                <div class="row">
                  <div class="col">
                    <div class="font-weight-medium text-right">
                      <h1> <strong>6.4PYM</strong> </h1>
                    </div>
                  </div>
                </div>
              </div>
              </a> </div>
          </div>
          <p class="mt-3 mb-1">To complete your payment, please send <strong>0.00808983 LTC</strong> or scan the QR code</p>
          <div class="card">
            <div class="card-body text-center">
              <div class="mb-3"> <img src="static/download.png" alt=""> </div>
            </div>
            <form>
              <div class="input-group">
                <input type="text" class="form-control"
        value="/path/to/foo/bar" placeholder="Some path" id="copy-input">
                <span class="input-group-btn">
                <button class="btn btn-default" type="button" id="copy-button"
          data-toggle="tooltip" data-placement="button"
          title="Copy to Clipboard"> Copy </button>
                </span> </div>
            </form>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-link link-secondary me-auto" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Yes, Done</button>
      </div>
    </div>
  </div>
</div>
<div class="modal modal-blur fade" id="modal-withdraw" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-body">
        <div class="modal-title"> <span class="avatar avatar-xs mt-3 mr-2 avatar-rounded" style="background-image: url(./static/Litecoin-LTC-icon.png)"></span>LITECOIN</div>
        <div>
          <label for="inp" class="inp">
            <input type="text" id="inp" class="form-control" placeholder=" ">
            <span class="label">Withdraw Amount</span> <span class="focus-bg"></span> </label>
          <label for="inp" class="inp">
            <input type="text" id="inp" class="form-control" placeholder=" ">
            <span class="label">Payment Address</span> <span class="focus-bg"></span> </label>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-link link-secondary me-auto" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Yes, Withdr</button>
      </div>
    </div>
  </div>
</div>
<div class="modal modal-blur fade prfile-dir" id="modal-report" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Jeyabalan Profile</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="row g-2 align-items-center">
          <div class="col-auto"> <span class="avatar avatar-lg" style="background-image: url(./static/avatars/000m.jpg)"></span> </div>
          <div class="col">
            <h4 class="card-title m-0"> Jeyabalna </h4>
            <div class="text-muted"> Id: 1234567890 </div>
            <div class="text-muted"> Mailid: jeyabalan@sp.com </div>
            <div class="text-muted"> Joining Date/Time: July / 20222 : 22.30AM </div>
          </div>
        </div>
      </div>
      <div class="modal-body">
        <div class="form-selectgroup-boxes row mb-3 ">
          <div class="col-lg-6"> <span class="form-selectgroup-label d-flex align-items-center p-3 bg-green-lt mb-2"> <span class="form-selectgroup-label-content"> <span class="form-selectgroup-title strong mb-1">Modern Earth</span> <span class="d-block text-muted text-black ">Joining Date/Time: July / 20222 : 22.30AM</span> </span> </span>
            </label>
          </div>
          <div class="col-lg-6"> <span class="form-selectgroup-label d-flex align-items-center p-3 bg-blue-lt mb-2"> <span class="form-selectgroup-label-content"> <span class="form-selectgroup-title strong mb-1">Glorious Moon</span> <span class="d-block text-muted text-black "><a href="#"  data-bs-toggle="modal" data-bs-target="#modal-small">Activated</a></span> </span> </span>
            </label>
          </div>
          <div class="col-lg-6"> <span class="form-selectgroup-label d-flex align-items-center p-3 mb-2"> <span class="form-selectgroup-label-content"> <span class="form-selectgroup-title strong mb-1">Mysterious Mars</span> <span class="d-block text-muted text-black ">In Activated</span> </span> </span>
            </label>
          </div>
          <div class="col-lg-6"> <span class="form-selectgroup-label d-flex align-items-center p-3 mb-2"> <span class="form-selectgroup-label-content"> <span class="form-selectgroup-title strong mb-1">Modern Earth</span> <span class="d-block text-muted text-black ">In Activated</span> </span> </span>
            </label>
          </div>
          <div class="col-lg-6"> <span class="form-selectgroup-label d-flex align-items-center p-3 mb-2"> <span class="form-selectgroup-label-content"> <span class="form-selectgroup-title strong mb-1">Modern Earth</span> <span class="d-block text-muted text-black ">In Activated</span> </span> </span>
            </label>
          </div>
          <div class="col-lg-6"> <span class="form-selectgroup-label d-flex align-items-center p-3 mb-2"> <span class="form-selectgroup-label-content"> <span class="form-selectgroup-title strong mb-1">Modern Earth</span> <span class="d-block text-muted text-black ">In Activated</span> </span> </span>
            </label>
          </div>
        </div>
      </div>
      <div class="modal-footer"> <a href="#" class="btn btn-link link-secondary" data-bs-dismiss="modal"> Cancel </a> </div>
    </div>
  </div>
</div>
<div class="modal modal-blur fade" id="modal-small" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-body">
        <div class="row">
          <div class="col-sm-12">
            <div class="card1">
              <div class="empty">
                <div class="empty-img"><img src="./static/illustrations/undraw_quitting_time_dm8t.svg" height="128" alt=""> </div>
                <h4 class="empty-title">Modern Earth</h4>
                <h2 class="empty-subtitle text-muted"> 100PYM </h2>
                <div class="empty-action">
                  <input type="text" class="form-control" name="example-text-input" placeholder="Enter User Id">
                  Activation for <span class="badge bg-blue p-2 mt-2"> <span class="avatar" style="background-image: url(./static/avatars/005f.jpg)"></span> Dunn Slane </span> </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-link link-secondary me-auto" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-green" data-bs-dismiss="modal"  data-bs-toggle="modal" data-bs-target="#modal-success">Yes, Activated</button>
      </div>
    </div>
  </div>
</div>
<div class="modal modal-blur fade" id="modal-success" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
    <div class="modal-content">
      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      <div class="modal-status bg-success"></div>
      <div class="modal-body text-center py-4"> 
        <!-- Download SVG icon from http://tabler-icons.io/i/circle-check -->
        <svg xmlns="http://www.w3.org/2000/svg" class="icon mb-2 text-green icon-lg" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
          <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
          <circle cx="12" cy="12" r="9" />
          <path d="M9 12l2 2l4 -4" />
        </svg>
        <h3>Activated succedeed</h3>
        <div class="text-muted">Your payment of $290 has been successfully submitted. Your invoice has been sent to support@tabler.io.</div>
      </div>
      <div class="modal-footer">
        <div class="w-100">
          <div class="row">
            <div class="col"><a href="#" class="btn btn-white w-200" data-bs-dismiss="modal"> Go to dashboard </a></div>
            <div class="col"><a href="#" class="btn btn-success w-20 mr-5 text-center" data-bs-dismiss="modal"> 
              <!-- Download SVG icon from http://tabler-icons.io/i/download -->
              <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                <path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2 -2v-2" />
                <polyline points="7 11 12 16 17 11" />
                <line x1="12" y1="4" x2="12" y2="16" />
              </svg>
              </a><a href="#" class="btn btn-success w-20 mr-5 text-center" data-bs-dismiss="modal"> 
              <!-- Download SVG icon from http://tabler-icons.io/i/brand-whatsapp -->
              <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                <path d="M3 21l1.65 -3.8a9 9 0 1 1 3.4 2.9l-5.05 .9" />
                <path d="M9 10a0.5 .5 0 0 0 1 0v-1a0.5 .5 0 0 0 -1 0v1a5 5 0 0 0 5 5h1a0.5 .5 0 0 0 0 -1h-1a0.5 .5 0 0 0 0 1" />
              </svg>
              </a></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="modal modal-blur fade" id="modal-large" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-full-width modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Modern Earth Global Farming Income Chart </h5>
        <span class="float-end"><!-- Download SVG icon from http://tabler-icons.io/i/cloud-download -->
        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
          <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
          <path d="M19 18a3.5 3.5 0 0 0 0 -7h-1a5 4.5 0 0 0 -11 -2a4.6 4.4 0 0 0 -2.1 8.4" />
          <line x1="12" y1="13" x2="12" y2="22" />
          <polyline points="9 19 12 22 15 19" />
        </svg>
        </span>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="table-responsive">
          <table
		class="table table-vcenter card-table border-n">
            <thead>
              <tr>
                <th>Level</th>
                <th>Price</th>
                <th>Users</th>
                <th>Income</th>
                <th>Upgrade</th>
                <th>Regeneration</th>
                <th>To Sponsor</th>
                <th>Profit</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td >1</td>
                <td class="text-muted" > 1 </td>
                <td class="text-muted" >2</td>
                <td class="text-muted" > 2 </td>
                <td> NIL </td>
                <td> NIL </td>
                <td> 0.2 </td>
                <td> 1.80 </td>
              </tr>
              <tr>
                <td >2</td>
                <td class="text-muted" > 1 </td>
                <td class="text-muted" >4</td>
                <td class="text-muted" >4</td>
                <td> NIL </td>
                <td> NIL </td>
                <td> 0.2 </td>
                <td> 3.80 </td>
              </tr>
              <tr>
                <td >3</td>
                <td class="text-muted" > 1 </td>
                <td class="text-muted" >8</td>
                <td class="text-muted" >8</td>
                <td> NIL </td>
                <td> NIL </td>
                <td> 0.4 </td>
                <td> 7.60 </td>
              </tr>
              <tr>
                <td >4</td>
                <td class="text-muted" > 1 </td>
                <td class="text-muted" >16</td>
                <td class="text-muted" >16</td>
                <td> NIL </td>
                <td> NIL </td>
                <td> 0.8 </td>
                <td> 15.20 </td>
              </tr>
              <tr>
                <td >5</td>
                <td class="text-muted" > 1 </td>
                <td class="text-muted" >32</td>
                <td class="text-muted" >32</td>
                <td> NIL </td>
                <td> NIL </td>
                <td> 1.60 </td>
                <td> 30.40 </td>
              </tr>
              <tr>
                <td >6</td>
                <td class="text-muted" > 1 </td>
                <td class="text-muted" >64</td>
                <td class="text-muted" >64</td>
                <td> NIL </td>
                <td> NIL </td>
                <td> 3.20 </td>
                <td> 40.80 </td>
              </tr>
              <tr>
                <td >7</td>
                <td class="text-muted" > 1 </td>
                <td class="text-muted" >128</td>
                <td class="text-muted" >128</td>
                <td> NIL </td>
                <td> NIL </td>
                <td> 6.40 </td>
                <td> 1.60 </td>
              </tr>
              <tr>
                <td >8</td>
                <td class="text-muted" > 1 </td>
                <td class="text-muted" >256</td>
                <td class="text-muted" >256</td>
                <td> NIL </td>
                <td> NIL </td>
                <td> 12.80 </td>
                <td> 223.20 </td>
              </tr>
              <tr>
                <td >9</td>
                <td class="text-muted" > 1 </td>
                <td class="text-muted" >512</td>
                <td class="text-muted" >512</td>
                <td> NIL </td>
                <td> NIL </td>
                <td> 25.60 </td>
                <td> 466.40 </td>
              </tr>
              <tr>
                <td >10</td>
                <td class="text-muted" > 1 </td>
                <td class="text-muted" >1024</td>
                <td class="text-muted" >1024</td>
                <td> NIL </td>
                <td> NIL </td>
                <td> 51.20 </td>
                <td> 952.80 </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn me-auto" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<?php include realpath(dirname(__DIR__) . '/common/inner_footer.php'); ?>

