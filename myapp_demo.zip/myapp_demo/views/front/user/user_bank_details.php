<?php 
    $this->load->view('front/common/header');
    $user_id = $this->session->userdata('user_id');
?>
  <div class="me-breadcrumb">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="me-breadcrumb-box">
            <h1><?=$this->lang->line('Bank Details');?></h1>
          </div>
        </div>
      </div>
    </div>
  </div>


<main id="main"> 
  <section class="inner-pages">
    <div class="container">
    <?php if($this->session->userdata('user_id')!='') {
            $this->load->view('front/user/sidebar_sticky');  
          }?>    
     <div class="row mt-2">
        <div class="col-lg-12">
            <div class="dash-profile-body background-grey">
                <div class="support-sec">
                    <div class="support-head">
                        <h2><?=$this->lang->line('Bank Details');?></h2>
                    </div>
                    <?php $action = front_url() . 'update_bank_details';
                    $attributes=array('id'=>'update_bank_details','class'=>'auth_form1','autocomplete'=>"off");
                      echo form_open($action,$attributes); 
                      ?>
                        <div class="form-group">
                            <label for="formGroupExampleInput" class="col-form-label"><?=$this->lang->line('Currency');?></label>
                            
                            <select name="currency" id="currency" class="custom-select">
                                <option disabled="disabled" selected=""><?=$this->lang->line('Select Currency')?></option>
                              <?php foreach ($fiat_currency as $fiat) {?>
                              	<option <?=(($bankwire->currency==$fiat->id)?'selected':'')?> value="<?=$fiat->id?>"><?=$fiat->currency_symbol?></option>
                              <?php } ?>  
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput" class="col-form-label"><?=$this->lang->line('Bank Name');?></label>
                            <input type="text" class="form-control" name="bank_name" id="bank_name" value="<?=(($bankwire->bank_name)?$bankwire->bank_name:'')?>" >
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput" class="col-form-label"><?=$this->lang->line('Account Number');?></label>
                            <input type="text" class="form-control" name="bank_account_number" id="bank_account_number" value="<?=(($bankwire->bank_account_number)?$bankwire->bank_account_number:'')?>">
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput" class="col-form-label"><?=$this->lang->line('Account Holder Name');?></label>
                            <input type="text" class="form-control" name="bank_account_name" id="bank_account_name" value="<?=(($bankwire->bank_account_name)?$bankwire->bank_account_name:'')?>">
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput" class="col-form-label"><?=$this->lang->line('Swift/BIC Code');?></label>
                            <input type="text" class="form-control" name="bank_swift" id="bank_swift" value="<?=(($bankwire->bank_swift)?$bankwire->bank_swift:'')?>">
                        </div>
                        <!-- <div class="form-group">
                            <label for="formGroupExampleInput" class="col-form-label"><?=$this->lang->line('Bank Address');?></label>
                            <input type="text" class="form-control" name="bank_address" id="bank_address" value="<?=(($bankwire->bank_address)?$bankwire->bank_address:'')?>">
                        </div> -->
                        <!-- <div class="form-group">
                            <label for="formGroupExampleInput" class="col-form-label"><?=$this->lang->line('Bank City');?></label>
                            <input type="text" class="form-control" name="bank_city" id="bank_city" value="<?=(($bankwire->bank_city)?$bankwire->bank_city:'')?>">
                        </div> -->
                        <div class="form-group">
                            <label for="formGroupExampleInput" class="col-form-label"><?=$this->lang->line('Bank Country');?></label>
                            <select name="bank_country" id="bank_country" class="custom-select">
                                <option disabled="disabled" selected=""><?=$this->lang->line('Select Country')?></option>
                              <?php foreach ($countries as $country) {?>
                              	<option <?=(($bankwire->bank_country==$country->id)?'selected':'')?> value="<?=$country->id?>"><?=$country->country_name?></option>
                              <?php } ?>  
                            </select>
                        </div>
                        <!-- <div class="form-group">
                            <label for="formGroupExampleInput" class="col-form-label"><?=$this->lang->line('Bank Postal Code');?></label>
                            <input type="text" class="form-control" name="bank_postalcode" id="bank_postalcode" value="<?=(($bankwire->bank_postalcode)?$bankwire->bank_postalcode:'')?>">
                        </div> -->

                        

                        <div class="profile-edit-sec">
                            <div class="row">
                                <div class="col-lg-4"></div>
                                <div class="text-left mt-3 mb-2 col-lg-8"><button class="auth_btn"><?php echo $this->lang->line('Submit');?></button></div>
                            </div>

                        </div>

                    <?php echo form_close();
                    ?>
                </div>
            </div>
        </div>
        
    </div>





    </div>
  </section>
</main>







 <?php
$this->load->view('front/common/footer');
    ?>

 <script>
 $.validator.addMethod('ZipChecker', function() {
    }, 'Invalid zip code');

    $.validator.addMethod("lettersonly", function(value) {
        return (/^[a-zA-Z\s]*$/.test(value));
    });
    $('#update_bank_details').validate({
        rules: {
            currency: {
                required: true
            },
            bank_name: {
                required: true
            },
            bank_account_number: {
                required: true
            },
            bank_account_name: {
                required: true,
                lettersonly: true
            },
            bank_swift: {
                required: true
            },
            // bank_address: {
            //      required: true
            // },
            // bank_city: {
            //     required: true,
            //     lettersonly: true
            // },
            bank_country: {
                required: true,
               // lettersonly: true
            },
            // bank_postalcode: {
            //     required: true,
            //     number: true,
            //     maxlength: 7,
            //     ZipChecker: function(element) {
            //         values=$("#postal_code").val();
            //         if( values =="0" || values =="00" || values =="000" || values =="0000" || values =="00000"  || values =="000000"   || values =="0000000" )
            //         {
            //             return true;
            //         }
            //     }
            // }
        },
        messages: {
            bank_name: {
                required: "<?php echo $this->lang->line('Please enter Bank name');?>"
            },
            bank_account_number: {
                required: "<?php echo $this->lang->line('Please enter Account number');?>"
            },
            bank_account_name: {
                required: "<?php echo $this->lang->line('Please enter Account name');?>",
                lettersonly: "<?php echo $this->lang->line('Please enter letters only');?>"
            },
            bank_swift: {
                required: "<?php echo $this->lang->line('Please enter Swift Code');?>"
            },
            // bank_address: {
            //     required: "<?php echo $this->lang->line('Please enter Bank Address');?>"
            // },
            // bank_city: {
            //     required: "<?php echo $this->lang->line('Please enter Bank City');?>",
            //     lettersonly: "<?php echo $this->lang->line('Please enter letters only');?>"
            // },
            bank_country: {
                required: "<?php echo $this->lang->line('Please select Bank Country');?>"
            },
            // bank_postalcode: {
            //     required: "<?php echo $this->lang->line('Please enter Postal code');?>"
            // }
        }
    });    
 </script>   
