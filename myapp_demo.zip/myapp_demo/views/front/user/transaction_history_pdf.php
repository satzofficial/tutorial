<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Transaction History</h2>
  <div class="table-responsive" style="width: 100%">          
  <table class="table">
    <thead>
      <tr>
        <th width="10%">Coin</th>
        <th width="10%">Date & Time</th>
        <!-- <th>Transaction ID</th> -->
        <th width="10%">Type</th>
        <th width="18%">Amount</th>
        <th width="10%">Age</th>
        <th width="20%">Address of sender / receipient</th>
        <!-- <th width="18%">Status</th> -->
      </tr>
    </thead>
    <tbody>
      <?php
            if(isset($history) && !empty($history)){
              $b=0;
              foreach($history as $withdraw){
              $b++;
            ?>
            <tr>
              <td><?php echo strtoupper(getcryptocurrency($withdraw->currency_id));?></td>
              <td><?php 
              if($withdraw->payment_method=='crypto'){
                echo date('Y-m-d H:i A',$withdraw->datetime);
              } else {
                echo date('Y-m-d H:i A',$withdraw->datetime);
              }?></td>
              <?php if(empty($withdraw->transaction_id)) {
                  $transaction_id = '-';
                } else {
                  $transaction_id = $withdraw->transaction_id;
                }?>
              <!-- <td> <?php echo $transaction_id;?></td>   -->
              <td><?=$withdraw->type?></td>
              <td><?php echo number_format($withdraw->amount,8);?></td>
              <td><?=timeSince($withdraw->datetime)?></td>
              <td ><?=$withdraw->crypto_address?></td>
               <?php 
                if($withdraw->status =='Completed')
                {
                  $elmt_class = 'green';

                }
                else
                {
                  $elmt_class = 'red';
                } ?> 
              <!-- <td><span class="<?php echo $elmt_class; ?>"><?php echo $withdraw->status;?></span></td> -->
            </tr>
        <?php } }else{ ?>
                    <tr>
                  <td colspan="7" style="text-align: center;">No records found !!!</td>
              </tr>
               <?php } ?>
    </tbody>
  </table>
  </div>
</div>

</body>
</html>