<?php $sitelan = $this->session->userdata('site_lang'); 
       $this->load->view('front/common/inner_header'); 
      $user_id=$this->session->userdata('user_id');

      $name = $sitelan."_name";
      $heading = $sitelan."_heading";
      $content = $sitelan."_content";
?>
      <div class="inner-body">
        <div class="container">
            <div class="inner-card-box">
                <div class="d-flex justify-content-between flex-wrap align-items-center">
                    <div class="inner-card-head">
                        <span>Deposit</span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8">
                        <div class="deposit-form">
                            <div class="row align-items-center justify-content-center">
                                <div class="col-lg-6">
                                    <div class="add-copy-sec">
                                       <?php 
                                            $attributes=array('id'=>'fiat_deposit_coin',"autocomplete"=>"off","class"=>"mt-4"); 
                                              $action = front_url() . 'fiat_deposit/'.$fiat_currency->currency_symbol;
                                            echo form_open_multipart($action,$attributes); 
                                        ?>   
                                            <!-- div class="form-group">
                                                <label for="exampleInputEmail1">Currency</label>
                                                 <input class="form-control" id="currency" name="currency" placeholder="Amount Deposited" type="text" value="<?php echo $fiat_currency->currency_symbol; ?>">
                                            </div> -->                                            
                                            <input class="form-control" id="currency" name="currency" type="hidden" value="<?php echo $fiat_currency->currency_symbol; ?>">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Amount</label>
                                                 <input class="form-control" id="amount" name="amount" placeholder="Amount Deposited" type="text">
                                            </div>

                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Reference No</label>
                                               <input class="form-control" id="ref_no" name="ref_no" placeholder="<?php echo $this->lang->line('Important notice');?>Reference number" type="text">
                                            </div>

                                             <div class="form-group">
                                                <label for="exampleInputEmail1">Description</label>
                                              <textarea id="desc" name="desc" class="form-control" row="5s"></textarea>
                                            </div>
                                            <p class="with-query">
                                                Minimum Deposit Amount: <?php echo $fiat_currency->currency_symbol."  ".$fiat_currency->min_deposit_limit; ?> <br> Maximum Deposit Amount: <?php echo $fiat_currency->currency_symbol."  ".$fiat_currency->max_deposit_limit; ?> <br><!-- Commission : <?php echo $fiat_currency->currency_symbol."  ".$fiat_currency->withdraw_fees; ?> -->
                                            </p>
                                            <input type="submit" name="withdrawcoin" class="withdraw-btn mt-4 clr-white al-center" value="<?php echo $this->lang->line('Submit')?>" />
                                        <?php echo form_close();?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                      <div class="col-lg-4">
                        <div class="deposit-form">
                          <div class="row align-items-center justify-content-center">
                          
                                    <div class="add-copy-sec">
                                       <div class="form-group row">
                                <h2 class="col-sm-12 col-form-label">Admin Bank Details</h2>
                         <?php
                       /*  echo "<pre>";
                         print_r($admin_bankdetails);*/
                           if (count($admin_bankdetails) > 0) {
                                  $i=1;
                                 
                                    ?>
                                    <div class="admin_details">
                                      <table class="table">
                                        <tr>
                                       <td><input type="hidden" name="bank" value="<?php echo $bank_details->id;?>" <?php if($i==1){echo "checked";}?>>Account Name </td>
                                         <td>:</td>
                                          <td><?php echo $admin_bankdetails->bank_account_name;?></td>
                                        </tr>

                                         <tr>
                                        <td><?php echo 'Bank Name';?></td>
                                         <td>:</td>
                                          <td><?php echo $admin_bankdetails->bank_name;?></td>
                                        </tr>

                                        <tr>
                                        <td><?php echo 'Account No';?></td>
                                         <td>:</td>
                                          <td><?php echo $admin_bankdetails->bank_account_number;?></td>
                                        </tr>
                                        
                                         <tr>
                                        <td><?php echo 'Bank SWIFT / BIC / IFSC';?></td>
                                         <td>:</td>
                                          <td><?php echo $admin_bankdetails->bank_swift;?></td>
                                        </tr>

                                         <tr>
                                        <td><?php echo 'Bank Address';?></td>
                                         <td>:</td>
                                          <td><?php echo $admin_bankdetails->bank_address."<br/>".$admin_bankdetails->bank_city."<br/>".$admin_bankdetails->bank_postalcode;?></td>
                                        </tr>
                                      </table> 
                                    </div>
                                    <div class="clearfix mt-3"></div>
                                    <?php
                                 
                                  }
                                  ?>  
                                </div>
                              
                                </div>
                        </div>
                    </div>
                </div>

            </div>


        </div>
    </div>
   <?php //$this->load->view('front/common/inner_footer'); ?>
   <?php $this->load->view('front/common/footer'); ?>

  <?php $this->load->view('front/common/scripts'); ?>
  <script type="text/javascript">
      $('#fiat_deposit_coin').validate({
      rules: {
        amount: {
          required: true
        },
        ref_no: {
          required: true          
        }
      },
      messages: {
        amount: {
          required: "Please enter Amount"
        },
        ref_no: {
          required: "Please enter amount"          
        }
      },
    });
  </script>
</body>

</html>