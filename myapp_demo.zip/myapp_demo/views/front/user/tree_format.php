<?php 
// echo '<pre>';print_r($tree);
    // $url1=$_SERVER['REQUEST_URI'];
    // header("Refresh: 30; URL=$url1");
?>
 <!DOCTYPE html>
     <html> 
     <head> 
  <title></title>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <style>
    .row td{
      padding:5px;
      color:#fff;
      height:30px; 
      width:30px;
      font-size: 10px;
    }
  </style>
  </head>
  <body> 
  <?php 
  // echo count($tree[0],true);
  // echo '<br>';
  // echo test_count_recursive($tree[0]);exit;
   ?>
   <table width="270px" cellspacing="0px" cellpadding="0px" border="1px">   
      <?php


   // Output the result
  // print_r(multi_array_search($tree[0], array('user_id' => '361')));
  //     echo '<pre>';
  //     print_r($tree[0]);
  //     exit();
      if(isset($tree[0])){
        $rand = 0;
        foreach ($tree[0] as $tkey => $tvalue) {      	
          echo "<tr class='row'>";
          if($tkey==1){  echo "<td style='padding:5px;color:#fff' height=30px width=30px bgcolor=#000 >1</td></tr><tr class='row'>";  }
          foreach ($tvalue as $key2 => $value2) {	  
          if($value2){
          if($value2['rebirth_level']!=0){
            $background = 'red';
          }else{
            $background = 'black';
          }
          // $rand = $value2['transaction_id'];
          echo "<td style='background:".$background."'>".$value2['user_id']."(". $value2['parent'].")"."</td>";
          // echo "<td style='background:".$background."'>".$value2['user_id']."</td>";
          // }
          }
          }      		
          echo "</tr>";
        }
    }
    ?>
  </table>
  </body>
  </html>
