<?php include realpath(dirname(__DIR__) . '/common/inner_header.php'); ?>
<?php
$unique_id = ($users->unique_id) ? $users->unique_id :'';
$wlink = base_url()."swap?ref=".$unique_id;
?>
<div class="page-body contact-form">
      <div class="container-xl">
        <ol class="breadcrumb breadcrumb-arrows mb-3" aria-label="breadcrumbs">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item active" aria-current="page">Contact</li>
        </ol>
        <div class="row">
          <div class="col-lg-5  mx-auto">
            <div class="row row-cards">
              <div class="col-12">
                <div class="card">
                
                    <?php 
     
                      $prefix = get_prefix();
                      $error = $this->session->flashdata('error');
                      if($error != '') {
                        echo '<div class="note note-danger">
                        <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$error.'</div>';
                    }

                    $success = $this->session->flashdata('success');
                    if($success) {
                        echo '<div class="note note-success">
                        <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$success.'</div>';
                    } 
                    ?>
                    <?php 

                    if(validation_errors()){
                        $error =  validation_errors();
                        echo '<div class="note note-danger">
                        <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$error.'</div>';
                    }

                      $attributes=array('role'=>'form','id'=>'cmttheform',"autocomplete"=>"off",'action'=>$action,'class'=>'deposit_form'); 
                      echo form_open(base_url().'contact-us',$attributes); 
                      ?>
                    <div class="card-body p-0 text-left border rounded-0">
                    <div class="row rounded-0 p-0">
                    
                    
                    <div class="col-sm-6 pr-0">
                      <label for="inp" class="inp border-bottom">
                        <input type="text" id="inp" class="form-control border-0" placeholder=" ">
                        <span class="label">Name: </span> <span class="focus-bg"></span> </label>
                    </div>
                                  
                    <div class="col-sm-6 pl-0">
                    
                      <label for="inp" class="inp border-bottom">
                        <input type="text" id="inp" class="form-control border-0" placeholder=" ">
                        <span class="label">User Id: </span> <span class="focus-bg"></span> </label>
                    </div>
                    
                                  
                    <div class="col-sm-12">
                      <label for="inp" class="inp border-bottom">
                        <input type="text" id="inp" class="form-control border-0" placeholder=" ">
                        <span class="label">Mail Id: </span> <span class="focus-bg"></span> </label>
                    </div>
                    <div class="col-sm-12">
                      <label for="inp" class="inp border-bottom">
                        <input type="text" id="inp" class="form-control border-0" placeholder=" ">
                        <span class="label">LTC Address:</span> <span class="focus-bg"></span> </label>
                    </div>

                    <div class="col-sm-12">
                      <label for="inp" class="inp border-bottom">
                        <input type="file" id="inp" class="form-control border-0" style="border-right:0px;">
                      </label>
                    </div>
                  <div class="col-sm-12">
                      
                      <textarea class="form-control border-0 border-bottom" name="example-textarea-input" rows="3" placeholder="Content:"></textarea>
                     </div>
                    </div>
                  <div class="d-flex justify-content-end w-25 pull-right  "> 
                    <a href="#" class=" text-right border m-2 p-2 mt-3 btn btn-primary text-white" data-bs-toggle="modal" data-bs-target="#modal-deposit">
                    Submit&nbsp;&nbsp;
                    </a> 
                  </div>

                   <?php echo form_close(); ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
        </div>
      </div>
    </div>
  <?php include realpath(dirname(__DIR__) . '/common/inner_footer.php'); ?>