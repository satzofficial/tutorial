<?php $this->load->view('front/common/inner_header'); ?>
   <section class="main-inner-pages">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="inner-page-header">
                        <h2>Profile <span><img src="<?=front_img()?>line.png"></span></h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="dash-profile-body background-grey">
                        <div class="rw">
                            <?php 
                                $attributes=array("id"=>"verification_form","autocomplete"=>"off","class"=>"row"); 
                                 // $action = front_url() . 'profile-edit';
                                echo form_open_multipart('',$attributes); 
                            ?>
                            <div class="col-lg-4">
                                <div class="d-pfle-img">
                                    <?php $img =  ($users->profile_picture)?$users->profile_picture:base_url().'assets/front/images/dash-user.png';?>
                                    <img src="<?=$img?>" class="img-fluid" id="img-profile">
                                </div>
                                <div class="profile-upload-btn">
                                 
                                        <input type='file' style="display: none" class="custom-file-input d-none" name="profile_photo" id="imageUpload" accept=".png, .jpg, .jpeg, .svg" />
                                        <a href="javascript:void(0);" id="profile-upload-btn" class="profile-trigger-btn">Upload Image</a>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                    <div class="form-group row">
                                        First Name
                                        <input type="text" class="form-control " placeholder="<?php echo $this->lang->line('First Name')?>" id="firstname" name="firstname" value="<?php echo $users->ixtoken_fname; ?>">
                                        
                                    </div>
                                    <div class="form-group row">
                                        Last Name
                                     <input type="text" class="form-control " placeholder="<?php echo $this->lang->line('LastName')?>" id="lastname" name="lastname" value="<?php echo $users->ixtoken_lname; ?>">
                                    </div>
                                    <?php $usermail = getUserEmail($users->id);?>
                                    <div class="form-group row">
                                        Email
                                        <input type="text" class="form-control " placeholder="sample@mail.com" disabled id="email" name="email" value="<?php echo ($usermail)?$usermail:'';?>">
                                    </div>
                                    <div class="form-group row">
                                        Address
                                        <input type="text" id="address" name="address" value="<?php echo ($users->street_address)?$users->street_address:'';?>" class="form-control " placeholder="<?php echo $this->lang->line('Enter Address')?>">
                                    </div>
                                    <div class="form-group row">
                                        City
                                        <input type="text" id="city" name="city"  value="<?php echo ($users->city)?$users->city:'';?>" class="form-control " placeholder="<?php echo $this->lang->line('Enter City')?>">
                                    </div>
                                    <div class="form-group row">
                                        State
                                        <input type="text" id="state" name="state" 
                                    value="<?php echo ($users->state)?$users->state:'';?>" class="form-control " placeholder="<?php echo $this->lang->line('Enter State')?>">
                                    </div>

                                    <div class="form-group row">
                                        Country                                           
                                    <select name="register_country" id="register_country" class="custom-select ">
                                        <option>Select country</option>
                                    <?php if($countries) {
                                        foreach($countries as $co) {
                                          ?>
                                          <option <?php if($co->id==$users->country) { echo "selected"; } ?>
                                          value ="<?php echo $co->id; ?>"><?php echo $co->country_name; ?></option>
                                          <?php
                                        }
                                      } ?>
                                </select>
                                    </div>
                                    <div class="form-group row">
                                        Postal Code
                                        <input type="text" id="postal_code" name="postal_code"  value="<?php echo ($users->postal_code)?$users->postal_code:'';?>" class="form-control " placeholder="<?php echo $this->lang->line('Enter Postal')?>">
                                    </div>
                                    <div class="form-group row">
                                        Contact
                                        <input type="text" id="phone" name="phone" 
                                    value="<?php echo ($users->ixtoken_phone)?$users->ixtoken_phone:'';?>" class="form-control " placeholder="<?php echo $this->lang->line('Enter Phone Number')?>">
                                    </div>


                                    <div class="profile-edit-sec">
                                        <div class="row">
                                            <div class="col-lg-4"></div>
                                            <div class="text-left mt-3 mb-2 col-lg-8"><button type="submit" class="auth_btn">Submit</button></div>
                                        </div>

                                    </div>
                            </div>
                            <?php echo form_close();?>
                        </div>                             
                    </div>
                </div>

            </div>
        </div>
    </section>
<?php $this->load->view('front/common/footer'); ?>
<?php $this->load->view('front/common/inner_scripts'); ?>
<script type="text/javascript">
    $(document).ready(function(e){
        function readURL1(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#img-profile').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]); // convert to base64 string
            }
        }
        $("#imageUpload").change(function() {
            readURL1(this);
        });
        $.validator.addMethod('ZipChecker', function() 
        {}, 'Invalid zip code');
        $.validator.addMethod("lettersonly", function(value) {
            return (/^[a-zA-Z\s]*$/.test(value));
        });
        $('#verification_form').validate({
            rules: {
                firstname: {
                  required: true
                },
                lastname: {
                  required: true
                },
                address: {
                  required: true
                },
                city: {
                  required: true,
                  lettersonly: true
                },
                state: {
                  required: true,
                  lettersonly: true
                },
                postal_code: {
                    required: true,
                    number: true,
                    maxlength: 7
                    /*ZipChecker: function(element) {
                        values=$("#postal_code").val();
                        if( values =="0" || values =="00" || values =="000" || values =="0000" || values =="00000"  || values =="000000"   || values =="0000000" )
                        {
                            return true;
                        }
                    }*/
                },
                phone: {
                  required: true
                }
            },
            messages: {
                firstname: {
                    required: "<?php echo $this->lang->line('Please enter first name')?>"
                },
                lastname: {
                    required: "<?php echo $this->lang->line('Please enter last name')?>"
                },
                address: {
                    required: "<?php echo $this->lang->line('Please enter address')?>"
                },
                city: {
                    required: "<?php echo $this->lang->line('Please enter city')?>",
                    lettersonly: "<?php echo $this->lang->line('Please enter letters only')?>"
                },
                state: {
                    required: "<?php echo $this->lang->line('Please enter state')?>",
                    lettersonly: "<?php echo $this->lang->line('Please enter letters only')?>"
                },
                postal_code: {
                    required: "<?php echo $this->lang->line('Please enter postal code')?>"
                },
                phone: {
                    required: "<?php echo $this->lang->line('Please enter phone number')?>"
                }
            }
        });
    });
</script>
</body>
</html>