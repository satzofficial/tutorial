<?php 
    $this->load->view('front/common/header');
    $user_id = $this->session->userdata('user_id');
$this->load->view('front/user/basic_navigation');
?>

<div class="page-wrapper">
	<div class="page-body">
          <div class="container-xl">
            <div class="row">
              <div class="col-9 col-sm-9">

                <div class="card-footer d-flex align-items-center">

                  <div class="col-lg-12">
                    <div class="card-body">
                      <h3 class="card-title" style="font-size: 25px;">Portfolio Balance</h3>
                      <h3 class="card-title" style="font-size: 25px;">€0.00</h3>

                      <div class="col-12">
                        <div class="card">
                          <div class="card-body">
                            <div class="card mb-3">
                              <div class="card-header">
                                <div class="Flex-l69ttv-0 BitcoinUpsell__HeaderRow-sc-1jngfzz-2 dGPybz"><div class="Flex-l69ttv-0 hHFvtm"><h3 class="TextElement__Spacer-hxkcw5-0 cicsNy Header__StyledHeader-sc-1xiyexz-0 htftjJ cardStyles__CardHeader-wgcfkc-1 styles__Header-sc-1jcbqm7-2 iXGIGG">Get started with Bitcoin</h3><a weight="demiBold" color="accent" class="Link__ARouterLink-eh4rrz-1 kWskFQ" href="/price/bitcoin">Learn more</a></div><svg width="38" height="38" viewBox="0 0 38 38" class="BitcoinUpsell__Icon-sc-1jngfzz-0 gMxZnO"><g fill="none" fill-rule="evenodd"><circle fill="#FFAD02" cx="19" cy="19" r="19"></circle><path d="M24.701 19.676a3.63 3.63 0 001.469-2.06c.741-2.767-.46-4.868-3.204-5.604h.001l.888-3.32a.228.228 0 00-.16-.28l-1.317-.353a.227.227 0 00-.275.154l-.892 3.33-1.756-.471.888-3.321a.228.228 0 00-.16-.28l-1.317-.353a.227.227 0 00-.275.154l-.892 3.33-3.735-1a.228.228 0 00-.278.16l-.356 1.33a.236.236 0 00.16.28l.22.058a1.826 1.826 0 011.282 2.242l-1.896 7.084a1.828 1.828 0 01-2.075 1.335.228.228 0 00-.238.114l-.69 1.247a.231.231 0 00-.012.2.227.227 0 00.15.132l3.672.984-.892 3.33c-.027.119.043.239.16.27l1.318.353a.228.228 0 00.279-.162l.891-3.32 1.756.47-.892 3.33c-.027.119.043.239.161.27l1.317.353a.228.228 0 00.279-.162l.891-3.32.877.235c2.744.735 4.835-.484 5.576-3.251a3.633 3.633 0 00-.923-3.488zm-5.96-5.948l2.635.705a1.826 1.826 0 011.281 2.242 1.826 1.826 0 01-2.23 1.3l-2.634-.706.949-3.541zm1.14 9.795l-3.512-.941.95-3.542 3.511.941a1.826 1.826 0 011.282 2.242 1.826 1.826 0 01-2.23 1.3z" fill="#FFF"></path></g></svg></div>

                              </div>
                              <div class="card-body">
                                <div class="row g-3">
                                  <div class="col-12">
                                    <div class="row g-3 align-items-center">
                                  <div class="Flex-l69ttv-0 BitcoinUpsell__BulletPointContent-sc-1jngfzz-4 jWEgtj"><div class="Flex-l69ttv-0 BulletPointRow__BulletPoint-mrg56s-0 fVOOrp"><div class="Flex-l69ttv-0 styles__IconWrapper-sc-1jcbqm7-4 BulletPointRow__BulletIconWrapper-mrg56s-1 dandrs"><svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M14.83 2.82a3.996 3.996 0 00-5.65 0L8 4 6.82 2.82a3.996 3.996 0 00-5.65 5.65L8 15l6.83-6.53a3.996 3.996 0 000-5.65z" fill="#1652F0"></path></svg></div><h3 class="TextElement__Spacer-hxkcw5-0 cicsNy Header__StyledHeader-sc-1xiyexz-0 htftjJ BulletPointRow__BulletPointText-mrg56s-2 fUBNoG">The world’s #1 cryptocurrency</h3></div>
                                  </div>
                                  </div>
                                  <div class="col-12">
                                    <div class="row g-3 align-items-center">
                                      <div class="Flex-l69ttv-0 BulletPointRow__BulletPoint-mrg56s-0 fVOOrp"><div class="Flex-l69ttv-0 styles__IconWrapper-sc-1jcbqm7-4 BulletPointRow__BulletIconWrapper-mrg56s-1 dandrs"><svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path fill-rule="evenodd" clip-rule="evenodd" d="M0 8c0-4.42 3.58-8 8-8s8 3.58 8 8-3.58 8-8 8-8-3.58-8-8zm2 0c0 3.31 2.69 6 6 6s6-2.69 6-6-2.69-6-6-6-6 2.69-6 6zm5 .41V3.33h2v4.26l2.46 2.45-1.42 1.42L7 8.41z" fill="#1652F0"></path></svg></div><h3 class="TextElement__Spacer-hxkcw5-0 cicsNy Header__StyledHeader-sc-1xiyexz-0 htftjJ BulletPointRow__BulletPointText-mrg56s-2 fUBNoG">Trade 24 hours a day</h3></div>
                                    </div>
                                  </div>
                                  <div class="col-12">
                                    <div class="row g-3 align-items-center">
                                      <div class="Flex-l69ttv-0 BulletPointRow__BulletPoint-mrg56s-0 fVOOrp"><div class="Flex-l69ttv-0 styles__IconWrapper-sc-1jcbqm7-4 BulletPointRow__BulletIconWrapper-mrg56s-1 dandrs"><svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path fill-rule="evenodd" clip-rule="evenodd" d="M5.95 8L1 3.05l1.77-1.77L9.49 8l-6.72 6.72L1 12.95 5.95 8zm6.51 0L7.51 3.05l1.77-1.77L16 8l-6.72 6.72-1.77-1.77L12.46 8z" fill="#1652F0"></path></svg></div><h3 class="TextElement__Spacer-hxkcw5-0 cicsNy Header__StyledHeader-sc-1xiyexz-0 htftjJ BulletPointRow__BulletPointText-mrg56s-2 fUBNoG">Get started with as little as $5</h3></div></div>

                                    </div>
                                  </div>

                                  </div>
                                </div>
                              </div>
                            </div>

                          <!-- Card footer -->
                          <div class="card-footer">
                            <a href="#" class="btn btn-primary">Buy Bitcoin</a>
                          </div>
                        </div>
                      </div>
                     
                    </div>
          </div>

                </div>
                <div class="col-12" style="margin-top: 20px;">
                  <div class="card">
                    <div class="row row-0">
                      <div class="col-6">
                        <div class="card">
                          <div class="empty">
                            <h3 class="card-title" style="font-size: 25px;">Deposit Funds</h3>
                            <div class="empty-img" style="margin-top: 20px;">
                              <svg width="64" height="64" viewBox="0 0 32 32" class="CurrencyIcon__makeFiatIcon-sc-12mnnqm-0 iOHINY DepositFunds__StyledCurrencyIcon-sc-1dife4r-4 bZWXWL" size="64" bgcolor="backgroundAccent" lighten="0" role="img"><path d="M16 0C7.176 0 0 7.176 0 16s7.176 16 16 16 16-7.176 16-16S24.824 0 16 0zm0 30.06C8.242 30.06 1.94 23.759 1.94 16 1.94 8.242 8.241 1.94 16 1.94c7.758 0 14.06 6.302 14.06 14.06 0 7.758-6.302 14.06-14.06 14.06z" fill="#1652F0"></path><path d="M20.713 18.288H19.53c-.359 0-.543.165-.602.398-.349 1.503-1.28 2.288-2.705 2.288-1.687 0-2.725-1.076-2.977-3.112h2.803c.174 0 .32-.117.358-.282l.107-.484a.372.372 0 00-.359-.447h-2.967v-1.202h3.394c.174 0 .32-.116.359-.281l.106-.485a.372.372 0 00-.358-.446h-3.443c.262-2.085 1.319-3.239 2.967-3.239 1.339 0 2.26.756 2.59 2.085a.47.47 0 00.465.359h1.328c.185 0 .32-.165.291-.34-.426-2.395-2.114-3.752-4.674-3.752-2.773 0-4.732 1.871-5.139 4.897H9.91a.368.368 0 00-.368.368v.485c0 .204.165.368.368.368h1.096v1.203H9.91a.368.368 0 00-.368.368v.485c0 .204.165.369.368.369h1.164c.398 3.006 2.308 4.81 5.12 4.81 2.657 0 4.354-1.426 4.82-4.035.019-.213-.127-.378-.301-.378z" fill="#1652F0"></path></svg>
                            </div>

                            <p class="empty-subtitle text-muted">
                              Looks like there isn’t any EUR in your account yet. Deposit funds or add a payment method to get started.
                            </p>
                            <div class="empty-action">
                              <a href="./." class="btn btn-primary">
                              Deposit Funds
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col">
                        <div class="card">
                          <div class="empty">
                            <h3 class="card-title" style="font-size: 25px;">Explore Assets</h3>
                            <div class="empty-img" style="margin-top: 20px;">
                              <svg width="64" height="64" viewBox="0 0 64 64" fill="none" class="ExploreAssets__Icon-sc-15eaur1-1 fwTXUP"><path d="M26 52c14.36 0 26-11.64 26-26S40.36 0 26 0 0 11.64 0 26s11.64 26 26 26z" fill="#56B4FC"></path><path d="M48 64c8.837 0 16-7.163 16-16s-7.163-16-16-16-16 7.163-16 16 7.163 16 16 16z" fill="#BFE9FF"></path><path d="M51.2 32.3c-1-.2-2.1-.3-3.2-.3-8.8 0-16 7.2-16 16 0 1.1.1 2.2.3 3.2 9.3-2.3 16.6-9.6 18.9-18.9z" fill="#1652F0"></path><path d="M36 28v-4H16v4h20z" fill="#fff"></path><path d="M24 36h4V16h-4v20z" fill="#fff"></path></svg>
                            </div>

                            <p class="empty-subtitle text-muted">
                              Coinbase adds new cryptocurrencies every week. Find your favorites here.
                            </p>
                            <div class="empty-action">
                              <a href="index.html" class="btn btn-primary">
                               See all Assets
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>


              </div>

              <div class="col-md-3 col-lg-3">
                <div class="col-md-12">
                  <div class="card">
                    <div class="col-sm-12 col-lg-12">
                      <div class="card">
                        <div class="card-header">
                          <h3 class="card-title">Do more with crypto</h3>
                        </div>
                        <div class="card-body">
                          <a href="#" class="dropdown-item">
                            <svg width="32" height="32" viewBox="0 0 64 64" fill="none"><path d="M8 10c-1.1 0-2-.9-2-2V2c0-1.1.9-2 2-2s2 .9 2 2v6c0 1.1-.9 2-2 2zM20 10c-1.1 0-2-.9-2-2V2c0-1.1.9-2 2-2s2 .9 2 2v6c0 1.1-.9 2-2 2zM32 10c-1.1 0-2-.9-2-2V2c0-1.1.9-2 2-2s2 .9 2 2v6c0 1.1-.9 2-2 2zM44 10c-1.1 0-2-.9-2-2V2c0-1.1.9-2 2-2s2 .9 2 2v6c0 1.1-.9 2-2 2zM56 10c-1.1 0-2-.9-2-2V2c0-1.1.9-2 2-2s2 .9 2 2v6c0 1.1-.9 2-2 2z" fill="#BFE9FF"></path><path d="M64 5H0v59h64V5z" fill="#BFE9FF"></path><path d="M64 5H0v8h64V5z" fill="#56B4FC"></path><path d="M56 13H8v43h48V13z" fill="#fff"></path><path d="M44 27.668L41.332 25l-16.01 16.01 2.669 2.668L44 27.668z" fill="#1652F0"></path><path d="M28.005 43.68l2.668-2.667-8.005-8.005L20 35.676l8.005 8.005zM8 10c1.1 0 2-.9 2-2V5H6v3c0 1.1.9 2 2 2zM44 10c1.1 0 2-.9 2-2V5h-4v3c0 1.1.9 2 2 2zM20 10c1.1 0 2-.9 2-2V5h-4v3c0 1.1.9 2 2 2zM32 10c1.1 0 2-.9 2-2V5h-4v3c0 1.1.9 2 2 2zM54 5v3c0 1.1.9 2 2 2s2-.9 2-2V5h-4z" fill="#1652F0"></path></svg>
                            &nbsp;&nbsp;<h3>Invest Over Time</h3>
                          </a>

                        </div>
                        <div class="card-header">
                          <h3 class="card-title">Buy crypto every day, week, or month</h3>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="modal modal-blur fade" id="modal-report" tabindex="-1" role="dialog" aria-hidden="true">
                  <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title">Recent Transactions</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <div class="mb-3">
                          <label class="form-label">Name</label>
                          <input type="text" class="form-control" name="example-text-input" placeholder="Your report name">
                        </div>
                        <label class="form-label">Report type</label>
                        <div class="form-selectgroup-boxes row mb-3">
                          <div class="col-lg-6">
                            <label class="form-selectgroup-item">
                              <input type="radio" name="report-type" value="1" class="form-selectgroup-input" checked>
                              <span class="form-selectgroup-label d-flex align-items-center p-3">
                                <span class="me-3">
                                  <span class="form-selectgroup-check"></span>
                                </span>
                                <span class="form-selectgroup-label-content">
                                  <span class="form-selectgroup-title strong mb-1">Simple</span>
                                  <span class="d-block text-muted">Provide only basic data needed for the report</span>
                                </span>
                              </span>
                            </label>
                          </div>
                          <div class="col-lg-6">
                            <label class="form-selectgroup-item">
                              <input type="radio" name="report-type" value="1" class="form-selectgroup-input">
                              <span class="form-selectgroup-label d-flex align-items-center p-3">
                                <span class="me-3">
                                  <span class="form-selectgroup-check"></span>
                                </span>
                                <span class="form-selectgroup-label-content">
                                  <span class="form-selectgroup-title strong mb-1">Advanced</span>
                                  <span class="d-block text-muted">Insert charts and additional advanced analyses to be inserted in the report</span>
                                </span>
                              </span>
                            </label>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-lg-8">
                            <div class="mb-3">
                              <label class="form-label">Report url</label>
                              <div class="input-group input-group-flat">
                                <span class="input-group-text">
                                  https://tabler.io/reports/
                                </span>
                                <input type="text" class="form-control ps-0"  value="report-01" autocomplete="off">
                              </div>
                            </div>
                          </div>
                          <div class="col-lg-4">
                            <div class="mb-3">
                              <label class="form-label">Visibility</label>
                              <select class="form-select">
                                <option value="1" selected>Private</option>
                                <option value="2">Public</option>
                                <option value="3">Hidden</option>
                              </select>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="modal-body">
                        <div class="row">
                          <div class="col-lg-6">
                            <div class="mb-3">
                              <label class="form-label">Client name</label>
                              <input type="text" class="form-control">
                            </div>
                          </div>
                          <div class="col-lg-6">
                            <div class="mb-3">
                              <label class="form-label">Reporting period</label>
                              <input type="date" class="form-control">
                            </div>
                          </div>
                          <div class="col-lg-12">
                            <div>
                              <label class="form-label">Additional information</label>
                              <textarea class="form-control" rows="3"></textarea>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer">
                        <a href="#" class="btn btn-link link-secondary" data-bs-dismiss="modal">
                          Cancel
                        </a>
                        <a href="#" class="btn btn-primary ms-auto" data-bs-dismiss="modal">
                          <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></svg>
                          Create new report
                        </a>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12 mt-4">
                  <div class="card" style="height: calc(24rem + 10px)">
                    <div class="card-body card-body-scrollable card-body-scrollable-shadow">
                      <div class="divide-y">
                        <div>
                          <div class="row">
                            <div class="col-auto"> </div>
                            <div class="col">
                              <div class="text-truncate"> <strong>Notifications</strong></div>
                              <div class="text-muted"></div>
                            </div>

                          </div>
                        </div>
                        <div>
                          <div class="row">
                            <div class="col-auto"> <span class="avatar">JL</span> </div>
                            <div class="col">
                              <div class="text-truncate"> <strong>Jeffie Lewzey</strong> commented on your <strong>"I'm not a witch."</strong> post. </div>
                              <div class="text-muted">yesterday</div>
                            </div>
                            <div class="col-auto align-self-center">
                              <div class="badge bg-primary"></div>
                            </div>
                          </div>
                        </div>
                        <div>
                          <div class="row">
                            <div class="col-auto"> <span class="avatar" style="background-image: url(./static/avatars/002m.jpg)"></span> </div>
                            <div class="col">
                              <div class="text-truncate"> It's <strong>Mallory Hulme</strong>'s birthday. Wish him well! </div>
                              <div class="text-muted">2 days ago</div>
                            </div>
                            <div class="col-auto align-self-center">
                              <div class="badge bg-primary"></div>
                            </div>
                          </div>
                        </div>
                        <div>
                          <div class="row">
                            <div class="col-auto"> <span class="avatar" style="background-image: url(./static/avatars/003m.jpg)"></span> </div>
                            <div class="col">
                              <div class="text-truncate"> <strong>Dunn Slane</strong> posted <strong>"Well, what do you want?"</strong>. </div>
                              <div class="text-muted">today</div>
                            </div>
                            <div class="col-auto align-self-center">
                              <div class="badge bg-primary"></div>
                            </div>
                          </div>
                        </div>
                        <div>
                          <div class="row">
                            <div class="col-auto"> <span class="avatar" style="background-image: url(./static/avatars/000f.jpg)"></span> </div>
                            <div class="col">
                              <div class="text-truncate"> <strong>Emmy Levet</strong> created a new project <strong>Morning alarm clock</strong>. </div>
                              <div class="text-muted">4 days ago</div>
                            </div>
                            <div class="col-auto align-self-center">
                              <div class="badge bg-primary"></div>
                            </div>
                          </div>
                        </div>
                        <div>
                          <div class="row">
                            <div class="col-auto"> <span class="avatar" style="background-image: url(./static/avatars/001f.jpg)"></span> </div>
                            <div class="col">
                              <div class="text-truncate"> <strong>Maryjo Lebarree</strong> liked your photo. </div>
                              <div class="text-muted">2 days ago</div>
                            </div>
                          </div>
                        </div>
                        <div>
                          <div class="row">
                            <div class="col-auto"> <span class="avatar">EP</span> </div>
                            <div class="col">
                              <div class="text-truncate"> <strong>Egan Poetz</strong> registered new client as <strong>Trilia</strong>. </div>
                              <div class="text-muted">yesterday</div>
                            </div>
                          </div>
                        </div>
                        <div>
                          <div class="row">
                            <div class="col-auto"> <span class="avatar" style="background-image: url(./static/avatars/002f.jpg)"></span> </div>
                            <div class="col">
                              <div class="text-truncate"> <strong>Kellie Skingley</strong> closed a new deal on project <strong>Pen Pineapple Apple Pen</strong>. </div>
                              <div class="text-muted">2 days ago</div>
                            </div>
                          </div>
                        </div>
                        <div>
                          <div class="row">
                            <div class="col-auto"> <span class="avatar" style="background-image: url(./static/avatars/003f.jpg)"></span> </div>
                            <div class="col">
                              <div class="text-truncate"> <strong>Christabel Charlwood</strong> created a new project for <strong>Wikibox</strong>. </div>
                              <div class="text-muted">4 days ago</div>
                            </div>
                          </div>
                        </div>
                        <div>
                          <div class="row">
                            <div class="col-auto"> <span class="avatar">HS</span> </div>
                            <div class="col">
                              <div class="text-truncate"> <strong>Haskel Shelper</strong> change status of <strong>Tabler Icons</strong> from <strong>open</strong> to <strong>closed</strong>. </div>
                              <div class="text-muted">today</div>
                            </div>
                          </div>
                        </div>
                        <div>
                          <div class="row">
                            <div class="col-auto"> <span class="avatar" style="background-image: url(./static/avatars/006m.jpg)"></span> </div>
                            <div class="col">
                              <div class="text-truncate"> <strong>Lorry Mion</strong> liked <strong>Tabler UI Kit</strong>. </div>
                              <div class="text-muted">yesterday</div>
                            </div>
                          </div>
                        </div>
                        <div>
                          <div class="row">
                            <div class="col-auto"> <span class="avatar" style="background-image: url(./static/avatars/004f.jpg)"></span> </div>
                            <div class="col">
                              <div class="text-truncate"> <strong>Leesa Beaty</strong> posted new video. </div>
                              <div class="text-muted">2 days ago</div>
                            </div>
                          </div>
                        </div>
                        <div>
                          <div class="row">
                            <div class="col-auto"> <span class="avatar" style="background-image: url(./static/avatars/007m.jpg)"></span> </div>
                            <div class="col">
                              <div class="text-truncate"> <strong>Perren Keemar</strong> and 3 others followed you. </div>
                              <div class="text-muted">2 days ago</div>
                            </div>
                          </div>
                        </div>
                        <div>
                          <div class="row">
                            <div class="col-auto"> <span class="avatar">SA</span> </div>
                            <div class="col">
                              <div class="text-truncate"> <strong>Sunny Airey</strong> upload 3 new photos to category <strong>Inspirations</strong>. </div>
                              <div class="text-muted">2 days ago</div>
                            </div>
                          </div>
                        </div>
                        <div>
                          <div class="row">
                            <div class="col-auto"> <span class="avatar" style="background-image: url(./static/avatars/009m.jpg)"></span> </div>
                            <div class="col">
                              <div class="text-truncate"> <strong>Geoffry Flaunders</strong> made a <strong>$10</strong> donation. </div>
                              <div class="text-muted">2 days ago</div>
                            </div>
                          </div>
                        </div>
                        <div>
                          <div class="row">
                            <div class="col-auto"> <span class="avatar" style="background-image: url(./static/avatars/010m.jpg)"></span> </div>
                            <div class="col">
                              <div class="text-truncate"> <strong>Thatcher Keel</strong> created a profile. </div>
                              <div class="text-muted">3 days ago</div>
                            </div>
                          </div>
                        </div>
                        <div>
                          <div class="row">
                            <div class="col-auto"> <span class="avatar" style="background-image: url(./static/avatars/005f.jpg)"></span> </div>
                            <div class="col">
                              <div class="text-truncate"> <strong>Dyann Escala</strong> hosted the event <strong>Tabler UI Birthday</strong>. </div>
                              <div class="text-muted">4 days ago</div>
                            </div>
                          </div>
                        </div>
                        <div>
                          <div class="row">
                            <div class="col-auto"> <span class="avatar" style="background-image: url(./static/avatars/006f.jpg)"></span> </div>
                            <div class="col">
                              <div class="text-truncate"> <strong>Avivah Mugleston</strong> mentioned you on <strong>Best of 2020</strong>. </div>
                              <div class="text-muted">2 days ago</div>
                            </div>
                          </div>
                        </div>
                        <div>
                          <div class="row">
                            <div class="col-auto"> <span class="avatar">AA</span> </div>
                            <div class="col">
                              <div class="text-truncate"> <strong>Arlie Armstead</strong> sent a Review Request to <strong>Amanda Blake</strong>. </div>
                              <div class="text-muted">2 days ago</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
</div>






<?php $this->load->view('front/common/footer'); ?>