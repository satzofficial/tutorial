<?php include realpath(dirname(__DIR__) . '/common/header.php'); ?>
<!-- Login In start -->
<section class="sign-in-up login">
    <div class="overlay pt-120 pb-120">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="form-content">
                        <div class="section-header">
                            <h5 class="sub-title">The Power of Financial Freedom</h5>                            
                            <p>Your Security is our top priority. You’ll need this to log into your Ten Realm Account</p>
                        </div>
                    <?php $this->load->view('front/common/flashmessage'); ?>
                    </div>
                    <?php
                      if(validation_errors()){
                          $error =  validation_errors();
                          echo '<div class="note note-danger">
                          <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$error.'</div>';
                      }
                      $action = 'login_check';
                      $attributes=array('class'=>'form-horizontal','id'=>'subForm','autocomplete' => 'off');
                      echo form_open($action,$attributes);                                         
                      ?>
                      <input type="hidden" name="hidden_email" value="<?php echo rand(); ?>" id="hidden_email">
                      <div class="row">
                        <div class="col-12">
                            <div class="single-input">
                                <label for="email">User ID / Email</label>
                                <input type="text" autocomplete="off" name="tenrealm_email" id="tenrealm_email" placeholder="Your User ID here">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="single-input ">
                                <label for="confirmPass">Password</label>
                                <div class="password-show d-flex align-items-center">
                                    <input type="password" class="passInput" name="tenrealm_password" id="tenrealm_password" autocomplete="off" placeholder="Enter Your Password">
                                    <img class="showPass password_on" src="<?php echo $assets_url_var; ?>images/icon/show-hide.png" alt="icon">                                               
                                    <img class="showPass password_off" style="display:none;" src="<?php echo $assets_url_var; ?>images/vision.png" alt="icon">                                               
                                </div>
                                <div id="tenrealm_password_error"></div>
                                <div class="forgot-area text-end">
                                    <a href="<?php echo $base_url_var ?>forgot-password" class="forgot-password">Forgot Password?</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="btn-area">
                        <button type="submit" name="btnsubmit" value="submit" class="cmn-btn">Login</button>
                    </div>
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
</section>
<!-- Login In end -->
<?php include realpath(dirname(__DIR__) . '/common/footer.php'); ?>
<script type="text/javascript">

var baseURL = "<?php echo base_url(); ?>";
var csrf_name = "<?php  echo $this->security->get_csrf_token_name(); ?>"; // for the name
var csrf_token = "<?php  echo $this->security->get_csrf_hash(); ?>";  // for the value   


    $(document).ready(function () {        
        $.validator.addMethod('totalCheck', function(value, element, params) {
            var field_1 = $('#number1').val(),
            field_2 = $('#number2').val();
            return parseInt(value) === (parseInt(field_1) + parseInt(field_2));
        }, "Enter the valid number");


     $.validator.addMethod("email_or_mobile", function(value, element) {

        if(/^\d|\w{10,10}$/.test(value)){
            value.replace(/\s+/, "");
        }
        return /^\d|\w{10,10}$/.test(value) || /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(value) //email or No
    }, "Please enter valid email or 16 digit number");



        $('#subForm').validate({ // initialize the plugin
            rules: {
                first_name: {
                    required: {
                        depends:function(){
                            $(this).val($.trim($(this).val()));
                            return true;
                        }
                    },           
                },
                last_name: {
                    required: {
                        depends:function(){
                            $(this).val($.trim($(this).val()));
                            return true;
                        }
                    },
                },
                tenrealm_email: {
                    required: {
                        depends:function(){
                            $(this).val($.trim($(this).val().replace(/\s+/, "")));
                            return true;
                        }
                    },                    
                    email_or_mobile: true,
                    remote: function() {
                                    var email = $('#tenrealm_email').val();                                    
                                    // if(/^\d{11,11}$/.test(email)){ return;}
                                    // if(/^\d$/.test(email)){ return;}   
                                    if(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(email)){
                                        return { url: baseURL + "is-not-email-exist",type: 'post',data: {'tenrealm_email':email} }    
                                    }                                    
                            },
                },
                tenrealm_password: {
                    required: {
                        depends:function(){
                            $(this).val($.trim($(this).val()));
                            return true;
                        }
                    },
                    minlength: 5
                },

            },
             messages: {
                first_name: "Enter your firstname",
                last_name: "Enter your lastname",
                tenrealm_email: {
                    required: "Enter a User ID or Email",
                    remote: jQuery.validator.format("This {0} does not exist")
                },                
            },
            errorPlacement: function(error, element) {                
              if(element.attr("name") == "tenrealm_password") {                
                error.appendTo( element.parent("div").parent('.single-input').find("div#tenrealm_password_error") );
            } else {
                error.insertAfter(element);
            }
        }
    });


    });

</script>
</body>
</html>