<?php $sitelan = $this->session->userdata('site_lang'); 
       $this->load->view('front/common/inner_header'); 
      $user_id=$this->session->userdata('user_id');

      $name = $sitelan."_name";
      $heading = $sitelan."_heading";
      $content = $sitelan."_content";
?>
      <div class="inner-body">
        <div class="container">
            <div class="inner-card-box">
                <div class="d-flex justify-content-between flex-wrap align-items-center">
                    <div class="inner-card-head">
                        <span>Withdraw</span>
                    </div>

                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="deposit-form">
                            <div class="row align-items-center justify-content-center">
                                <div class="col-lg-6">
                                    <div class="add-copy-sec">
                                    <?php 
                                    $attributes=array('id'=>'deposit_fiatwithdraw_coin','autocomplete'=>'off');
                                    if($currency_name=="USD" || $currency_name=="EUR")
                                    {
                                      $action1 = base_url().'fiat_withdraw/'.$currency_name;
                                    }                                                                        
                                    echo form_open($action1,$attributes);
                                   ?>   
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Amount</label>
                                                <input type="text" class="form-control" id="amount" name="amount" aria-describedby="emailHelp">
                                            </div>

                                            <div class="form-group tfa_section" style="display:none;">
                                                <label for="exampleInputEmail1">Google Authenticator Code</label>
                                                <input type="text" class="form-control" id="tfa_code" name="tfa_code" aria-describedby="emailHelp">
                                                <label id="tfa-error" class="error" for="tfa_code"></label>
                                            </div>

                                        
                                            <p class="with-query">
                                                Minimum Withdraw Amount: <?php echo $fiat_currency->currency_symbol."  ".$fiat_currency->min_withdraw_limit; ?> <br> Maximum Withdraw Amount: <?php echo $fiat_currency->currency_symbol."  ".$fiat_currency->max_withdraw_limit; ?> <br>Commission : <?php echo $fiat_currency->currency_symbol."  ".$fiat_currency->withdraw_fees; ?>
                                            </p>

                                              <input type="submit" name="withdrawcoin" class="withdraw-btn mt-4 clr-white al-center" value="<?php echo $this->lang->line('Submit')?>" />

                                        <?php echo form_close();?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>


        </div>
    </div>
   <?php //$this->load->view('front/common/inner_footer'); ?>
   <?php $this->load->view('front/common/footer'); ?>

  <?php $this->load->view('front/common/scripts'); ?>
  <script type="text/javascript">
      $('#deposit_fiatwithdraw_coin').validate({
      rules: {
        amount: {
          required: true,
          number: true,
        }
      },
      messages: {
       
        amount: {
          required: "Please enter amount",
          number: "Only enter numbers as decimal or float"
        }
      },
      invalidHandler: function(form, validator) {
            if (!validator.numberOfInvalids())
            {
                return;
            }
            else
            {
                var error_element=validator.errorList[0].element;
                error_element.focus();
            }
        },
        highlight: function (element) {
            //$(element).parent().addClass('error')
        },
        unhighlight: function (element) {
            $(element).parent().removeClass('error')
        },

          submitHandler: function(form) 
        { 
          
            $('.pageloadingBG, .pageloading').css('display', '');
            var amount = $("#amount").val();
            var tfa_code = $("#tfa_code").val();
            if(amount !="" && (tfa_code=="" || tfa_code == null || tfa_code == undefined))
            {
             

              $.ajax({
                url: base_url+"tfa_check", 
                type: "POST",             
                data: "user_id="+user_id,
                cache: false,             
                processData: false,      
                success: function(data) 
                {

                    var d = jQuery.parseJSON(data);
                    if(d.tfa_status==0)
                    {
                        toastr.error("Please activate TFA to submit withdraw");
                        return false;
                    }
                    else
                    {
                      $(".tfa_section").show();
                       //form.submit(); 
                       var tfa_code = $("#tfa_code").val();
                       if(tfa_code == null || tfa_code == undefined || tfa_code == "")
                       {

                          $("#tfa-error").html("Please enter tfa code");
                          $("#tfa-error").show();
                          return false;
                       }
                       else
                       {
                          $("#tfa-error").html("");
                          $("#tfa-error").hide();
                       }
                        
                  }
                }
            });
            }
            else if(amount !="" && tfa_code !="")
            {
              form.submit();
            }
            
            return false;
        }
    });
  </script>
</body>

</html>