<?php $sitelan = $this->session->userdata('site_lang'); 
       $this->load->view('front/common/inner_header'); 
      $user_id=$this->session->userdata('user_id');

      $name = $sitelan."_name";
      $heading = $sitelan."_heading";
      $content = $sitelan."_content";
      $all_currency = $this->common_model->getTableData("currency",array("status"=>1))->result();
      if(count($all_currency))
      {
        $tot_balance = 0;
        foreach($all_currency as $cur)
        {
            $balance = getBalance($user_id,$cur->id);
            $usd_balance = $balance * $cur->online_usdprice;

            $tot_balance += $usd_balance;
        }
      }
?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css"/>
<link href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap4.min.css"/>
<style type="text/css">
    #example_filter label { display: none }
    .removeclass { display: none !important; }
    .showclass { display: block !important; }
    .overclass { display: none !important; }
</style>
   <section class="main-inner-pages">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="inner-page-header">
                        <h2>Wallet <span><img src="<?=front_img()?>line.png"></span></h2>
                    </div>
                </div>
            </div>
           <div class="row align-items-center justify-content-end">
                <div class="col-lg-6">
                    <div class="wallet-value">
                        <p>Estimated Value:<span>  <?=number_format($tot_balance, 2)?> USDT</span></p>
                    </div>
                </div>
            </div>
             <div class="row">
                <div class="col-lg-12">
                    <div class="wallet-table">
                        <div class="table-responsive">
                            <table class="table" id="wallet-search">
                                <thead>
                                    <tr>
                                        <th>Coin</th>
                                        <th>Name</th>
                                        <th>Available Balance</th>
                                        <th>USD Value</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        if(count($dig_currency) >0)
                                        {
                                            foreach ($dig_currency as $digital) 
                                            { 
                                                if($digital->type=="fiat")
                                                {
                                                    $format = 2;
                                                }
                                                elseif($digital->currency_symbol=="USDT")
                                                {
                                                    $format = 6;
                                                }
                                                else
                                                {
                                                    $format = 8;
                                                } 
                                                $deposit_status = $digital->deposit_status;
                                                $withdraw_status = $digital->withdraw_status;
                                                $enable_deposit = ($deposit_status==0)?"display:none;":"display:block;";
                                                $disable_deposit = ($deposit_status==0)?"display:block;":"display:none;"; 
                                                $enable_withdraw = ($withdraw_status==0)?"display:none;":"display:block;";
                                                $disable_withdraw = ($withdraw_status==0)?"display:block;":"display:none;"; 
                                                $coin_price_val = to_decimal($wallet['Exchange AND Trading'][$digital->id], $format);
                                                $coin_price = $coin_price_val * $digital->online_usdprice;

                                                // echo "user_id".$user_id."sds".$digital->currency_symbol;

                                                $userbalance = getBalance($user_id,$digital->id);
                                                
                                                $inr_balance = $userbalance * $digital->online_usdprice;
                                               
                                                $inrs_balance = number_format($inr_balance,2);

                                                $pairing = $this->common_model->getTableData('trade_pairs',array('from_symbol_id'=>$digital->id,'status'=>1))->row();
                                                if(!empty($pairing))
                                                {
                                                    $fromid = $pairing->from_symbol_id;
                                                    $fromcurr = $this->common_model->getTableData('currency',array('id'=>$fromid,'status'=>1))->row();
                                                    $fromSYM = $fromcurr->currency_symbol;
                                                    $toid = $pairing->to_symbol_id;
                                                    $tocurr = $this->common_model->getTableData('currency',array('id'=>$toid,'status'=>1))->row();
                                                    $toSYM = $tocurr->currency_symbol;

                                                    $traDepair = $fromSYM."_".$toSYM; 

                                                }
                                                else
                                                {
                                                   $pairing = $this->common_model->getTableData('trade_pairs',array('to_symbol_id'=>$digital->id,'status'=>1))->row();
                                                    $fromid = $pairing->to_symbol_id;
                                                    $fromcurr = $this->common_model->getTableData('currency',array('id'=>$fromid,'status'=>1))->row();
                                                    $fromSYM = $fromcurr->currency_symbol;

                                                    $toid = $pairing->from_symbol_id;
                                                    $tocurr = $this->common_model->getTableData('currency',array('id'=>$toid,'status'=>1))->row();
                                                    $toSYM = $tocurr->currency_symbol;

                                                    $traDepair = $toSYM."_".$fromSYM;

                                                }
                                    ?>
                                                <tr class="<?=($userbalance > 0)?'show-cls':'hide-cls'?>">
                                                    <td><?php echo $digital->currency_symbol;?></td>
                                                    <td><?php echo strtoupper($digital->currency_name);?></td>
                                                    <td><?php echo number_format($userbalance,$digital->currency_decimal); ?></td>             
                                                    <td><?php echo $inrs_balance; ?></td>
                                                    <td class="text-right d-flex justify-content-end">
                                                        <a href="<?php echo base_url(); ?>deposit/<?php echo $digital->currency_symbol;?>" class="wallet-table-btn deposit">Deposit</a>
                                                        <a href="<?php echo base_url(); ?>withdraw/<?php echo $digital->currency_symbol;?>" class="wallet-table-btn withdraw" >Withdraw</a>
                                                        <a href="<?php echo base_url(); ?>trade/<?=$traDepair?>" class="wallet-table-btn">Trade</a>
                                                    </td>
                                                </tr>
                                    <?php
                                            }
                                        }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>            
        </div>
    </section>
<?php $this->load->view('front/common/footer'); ?>
<?php $this->load->view('front/common/inner_scripts'); ?>
<?php
    if(count($dig_currency) >0)
    {
        foreach ($dig_currency as $digital) 
        { 
?>
            <script type="text/javascript">
                function copy_function(value) 
                {
                    var copyText = document.getElementById("crypto_address"+value);
                    copyText.select();
                    document.execCommand("COPY");
                    $('.copy_but').html("COPIED");
                }
            </script>           
<?php 
        } 
    } 
?>
<script type="text/javascript">
    $(document).ready(function() {
        var oTable = $('#wallet-search').DataTable({
            "paging": false,
            "ordering": false,
            "info": false,
            'bSort': false,
            'responsive': true,
            //"searching": false
        });
        $('#example-search-input').keyup(function(){
            oTable.search($(this).val()).draw() ;
        });
        $('#wallet-search_filter').css('display', 'none');


        $("input[type='checkbox']").change(function() {
            if(this.checked) {
                $('.hide-cls').hide();             
            }
            else
            {
                $('.hide-cls').show(); 
            }
        });        
    });
</script>