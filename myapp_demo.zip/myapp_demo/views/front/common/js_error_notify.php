
<script>


// Display network error
function jqueryErrorHandling(xhr, status, exception) {
  // alert('sample EREORE');
  var responseText;
  $("#dialog").html("");

  try {
    responseText = jQuery.parseJSON(xhr.statusText);
    if(responseText == 'OK'){ return;}
    $("#dialog").append("<div><b>" + status + " " + exception + "</b></div>");
    $("#dialog").append("<div><u>Exception</u>:<br /><br />" + responseText.ExceptionType + "</div>");
    $("#dialog").append("<div><u>StackTrace</u>:<br /><br />" + responseText.StackTrace + "</div>");
    $("#dialog").append("<div><u>Message</u>:<br /><br />" + responseText.Message + "</div>");
  } catch (e) {
    var errorMessage = xhr.statusText;
    if(errorMessage == 'OK'){ return;}
    $("#dialog").html(errorMessage);
    $("#dialog").dialog({
      dialogClass:'transparent',
      title: "Exception Details",
      autoOpen: true,
      modal: true,
      width: 700,
      buttons: {
        Close: function() {
          $(this).dialog('close');
        }
      }
    });
  }
}


</script>