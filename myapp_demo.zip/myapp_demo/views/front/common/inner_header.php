<?php
// echo '<pre>sample mode';print_r($country);exit;
$user_id=$this->session->userdata('user_id');
$sitelan = $this->session->userdata('site_lang'); 
$favicon  =  ($site_common['site_settings']->site_favicon) ? $site_common['site_settings']->site_favicon :'';
$english_site_name  =  ($site_common['site_settings']->english_site_name) ? $site_common['site_settings']->english_site_name :'';
$sitelogo = ($site_common['site_settings']->site_logo) ? $site_common['site_settings']->site_logo :'';
$site_email = ($site_common['site_settings']->site_email) ? $site_common['site_settings']->site_email :'';
$assets_url_var = base_url('assets/front/');
$base_url_var = base_url();
$csrf_name = $this->security->get_csrf_token_name(); // for the name
$csrf_token = $this->security->get_csrf_hash();  // for the value
$class = $this->router->fetch_class();
$method = $this->router->fetch_method();
$prefix=get_prefix();
$contact = $sitelan."_contactno";
$pp = ($users && $users->profile_picture) ? $users->profile_picture :'';
$p_name = ($users && $users->tenrealm_fname) ? $users->tenrealm_fname :'';
$dummy_user = dummyuserImg();
?>
<!DOCTYPE html>
<html class="no-js" lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
<meta http-equiv="X-UA-Compatible" content="ie=edge"/>
<title><?php echo $english_site_name; ?></title>
<link rel="icon" type="image/png" href="<?php echo $favicon;?>" />
<!-- CSS files -->
<link href="<?php echo $assets_url_var; ?>dist/css/tenrealm.css?v=<?php echo date('Ymdhis'); ?>" rel="stylesheet"/>
<link rel="stylesheet" href="<?php echo $assets_url_var; ?>js/jquery-ui/jquery-ui.css?v=<?php echo date('Ymdhis'); ?>">

<style type="text/css">
    .error{ color:red; }
    #package-remainder{
      text-transform: uppercase;
    }
    .page-body {
    margin-bottom: 1.25rem;
    }
</style>
</head>
<!-- <body class="antialiased" oncontextmenu="return false;" > -->
<body class="antialiased" >
        <div id="dialog" style="display: none"></div>
        <div class="wrapper">
          <div class="sticky-top">
            <header style="background-color:#350b2d" class="navbar navbar-expand-md navbar-light sticky-top d-print-none">
              <div class="container-xl">
                <button class="navbar-toggler"  style="color:#ffffff;"  type="button" data-bs-toggle="collapse" data-bs-target="#navbar-menu"> <span class="navbar-toggler-icon"></span> </button>
                <h1 class="navbar-brand navbar-brand-autodark d-none-navbar-horizontal pe-0 pe-md-3"> <a href="<?php echo base_url(); ?>"> <img src="https://emush.net/css/assets/images/logos.png" width="110" height="32" alt="tenrealm" class="navbar-brand-image"> </a> </h1>
                <div class="navbar-nav flex-row order-md-last">
                  <div class="nav-item dropdown"> <a href="#" class="nav-link d-flex lh-1 text-reset p-0" data-bs-toggle="dropdown" aria-label="Open user menu"> <span class="avatar avatar-sm" style="background-image: url(<?php echo ($pp)? $pp:$dummy_user; ?>)"></span>
                    <div style="color: #fff!important;" class="d-none d-xl-block ps-2">
                      <div><?php echo getUserDetails($user_id, $prefix=get_prefix().'_username');?></div>
                      <div style="color: #fff!important;" class="mt-1 small text-muted">ID: <?php echo $header_unique_id = getUserDetails($user_id, 'unique_id');?></div>
                    </div>
                  </a>
                  <div class="dropdown-menu dropdown-menu-end dropdown-menu-arrow"> <a href="#" class="dropdown-item"> <span class="avatar avatar-xs rounded me-2" style="background-image: url(<?php echo ($pp)? $pp:$dummy_user; ?>)"></span>
                     <h5 class="m-0 top-header-name">                   
                    <?php echo ($p_name) ? ucfirst($p_name) : ''; ?> </h5>
                  </a>
                  <div class="dropdown-divider"></div>
                  <a href="<?php echo base_url('profile'); ?>" class="dropdown-item">Profile</a>
                  <div class="dropdown-divider"></div>
                 <span>  <span style="display: inline-block; padding-left: 15px">ID :</span> <a href="javascript:;" data-toggle="tooltip" data-placement="button" title="Copy to Clipboard" class="dropdown-item copy-coinprice" id="copy_top_header" style="width: calc(100% - 100px); min-width: auto; display: inline-block;" ><?php echo $header_unique_id; ?></a></span>
                  <span class="badge bg-green-lt mt-1 show_copied_to_clipboard" style="display: none;" id="show_copied_to_clipboard">Copied to clipboard!</span>
                  <div class="dropdown-divider"></div>

                  <?php $sponsor_user_id = (user_id_to_parent_id($user_id)) ? user_id_to_parent_id($user_id) : 0;
                  if($sponsor_user_id!=0) { ?>
                    <a href="javascript:;" class="dropdown-item" id="copy_top_header" ><?php echo 'Sponsor : '.user_id_to_unique_id($sponsor_user_id); ?></a>
                  <?php }?>
                  <div class="dropdown-divider"></div>
                  <a href="<?php echo base_url('logout'); ?>" class="dropdown-item">Logout</a> </div>
                </div>
              </div>
            </div>
          </header>

          <div class="navbar-expand-md">
            <div class="collapse navbar-collapse" id="navbar-menu">
              <div class="navbar navbar-light" style="background-color:#350b2d">
                <div class="container-xl">
                  <ul class="navbar-nav">
                    <li class="nav-item"> <a class="nav-link" href="<?php echo base_url('dashboard'); ?>" > <span style="color: #fff!important;" class="nav-link-title"> Dashboard </span> </a> </li>
                    <li class="nav-item dropdown"> <a class="nav-link dropdown-toggle" href="#navbar-extra" data-bs-toggle="dropdown" role="button" aria-expanded="false" > <span style="color: #fff!important;" class="nav-link-title"> Affiliate </span> </a>
                      <div  style="background-color: #161417;"     class="dropdown-menu"> 
                        <a style="color:#ffff"    href="<?php echo base_url('directs-list'); ?>" class="dropdown-item"> Direct Refferals </a>
                        <a  style="color:#ffff" class="dropdown-item" href="<?php echo base_url('level-income'); ?>" > Autofilled level Segment </a>
                        <a  style="color:#ffff"  class="dropdown-item" href="<?php echo base_url('team-level-income'); ?>" > Team Level Segment </a>
                        <!-- <a class="dropdown-item" href="<?php //echo base_url('sponsor-income'); ?>" > Sponsor Income </a> -->
                      </div>
                    </li>
                    <li class="nav-item dropdown"> <a  style="color:#ffff" class="nav-link dropdown-toggle" href="#navbar-extra" data-bs-toggle="dropdown" role="button" aria-expanded="false" > <span style="color: #fff!important;" class="nav-link-title"> Wallet </span> </a>
                      <div   style="background-color: #161417;" class="dropdown-menu"> <a  style="color:#ffff" class="dropdown-item" href="<?php echo base_url('payment'); ?>" > Deposit / Widthdaw </a> <a style="color:#ffff" class="dropdown-item" href="<?php echo base_url('activation'); ?>" > Activation </a> <a style="color:#ffff" class="dropdown-item" href="<?php echo base_url('user-transfer'); ?>" > Transfer </a><a style="color:#ffff" class="dropdown-item" href="<?php echo base_url('transactions'); ?>" > Transaction </a> </div>
                    </li>
                    <!-- <li class="nav-item"> <a class="nav-link" href="<?php //echo base_url('rewards'); ?>" > <span style="color: #fff!important;" class="nav-link-title"> Rewards </span> </a> </li> -->
                  </ul>

                  <?php if(isset($remaining_period_timestamp)){ ?>
                    <!--<div style="color:#ffff"  class="small mt-1"> Remainder : <span><strong><span id="package-remainder"> </span> UTC</strong></span></div>-->
                  <?php } ?>

                </div>
              </div>
            </div>
          </div>
        </div>
  
  <div class="page-wrapper">