<?php 
include 'header.php'; 
$prefix = get_prefix();
?>
 
  <!-- banner-section start -->
    <section class="banner-section inner-banner contact">
        <div class="overlay">
            <div class="banner-content d-flex align-items-center">
                <div class="container">
                    <div class="row justify-content-start">
                        <div class="col-lg-7 col-md-10">
                            <div class="main-content">
                                <h1>Contact Us</h1>
                                <div class="breadcrumb-area">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb d-flex align-items-center">
                                            <li class="breadcrumb-item"><a href="<?php echo $base_url_var; ?>"><?php echo 'Home'; ?></a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Contact Us</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- banner-section end -->

    <!-- Apply for a loan In start -->
    <section class="apply-for-loan contact">
        <div class="overlay pt-120 pb-120">
            <div class="container wow fadeInUp">
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="section-header text-center">
                            <h2 class="title">Get in touch with us.</h2>
                            <p>Fill up the form and our team will get back to you within 24 hours</p>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-10">
                        <div class="form-content">
                              <?php 
                                $attributes=array('role'=>'form','id'=>'cmttheform',"autocomplete"=>"off",'action'=>$action,'class'=>'deposit_form'); 
                                echo form_open(base_url().'contact-us',$attributes); 
                                ?>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="single-input">
                                            <label for="name">User ID</label>
                                            <input type="text" id="personal_id" name="personal_id" placeholder="What's your User ID?" autofocus autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="single-input">
                                            <label for="name">Name</label>
                                            <input type="text" id="name" name="name" placeholder="What's your name?" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="single-input">
                                            <label for="email">Email</label>
                                            <input type="text" id="email" name="email" placeholder="What's your email?" autocomplete="off">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="single-input">
                                            <label for="phone">Phone</label>
                                            <input type="text" id="phone" name="phone" placeholder="Enter Phone Number" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="single-input">
                                            <label for="loan">Subject</label>
                                            <input type="text" id="subject" name="subject" placeholder="Enter Subject" autocomplete="off">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="single-input">
                                            <label for="message">Message</label>
                                            <textarea id="comments" name="comments" placeholder="I would like to get in touch with you..." cols="30" rows="10"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="btn-area text-center">
                                    <button type="submit" name="cmt-btn-submit" value="submit" id="cmt-btn-submit" class="cmn-btn cmt-btn-submit">Send Message</button>
                                    <div id="form-submit-result" class="form-submit-result">
                                    </div>
                                </div>
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Apply for a loan In end -->

    <!-- Get Start In start -->
    <section class="get-start wow fadeInUp">
        <div class="overlay">
            <div class="container">
                <div class="col-12">
                    <div class="get-content">
                        <div class="section-text">
                            <h3 class="title">Ready to get started?</h3>
                            <p>It only takes a few minutes to Register.</p>
                        </div>
                        <a href="<?php echo $$base_url_var.'register'; ?>" class="cmn-btn">Get Started</a>
                        <img src="<?php echo $assets_url_var; ?>images/get-start.png" alt="images">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Get Start In end -->

<?php include 'footer.php'; ?>

    <script type="text/javascript">
    $(document).ready(function() {
         $.validator.methods.email = function( value, element ) {
            return this.optional( element ) || /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i.test( value );
          }
        $('#cmttheform').validate({
            rules: {
                personal_id:{
                   number: true
                },
                name: {
                    required: true
                },
                email: {
                    required: true,
                    email: true,
                },
                phone:{
                    required:true,
                    number:true,
                    phoneUS: true
                },
                subject: {
                    required: true
                },
                comments: {
                    required: true,
                    rangelength:[0,900]
                }
            },
            messages: {
                personal_id: {
                    required: "Please enter User ID",
                },
                name: {
                    required: "<?php echo $this->lang->line('Please enter name');?>",
                },
                email: {
                    required: "<?php echo $this->lang->line('Please enter email');?>",
                    email: "<?php echo $this->lang->line('Please enter valid email address');?>",
                },
                subject: {
                    required: "<?php echo $this->lang->line('Please enter subject');?>"
                },
                comments: {
                    required: "<?php echo $this->lang->line('Please enter comments');?>",
                    rangelength: "<?php echo $this->lang->line('You are allow upto 900 characters.');?>"
                }
            },
            submitHandler: function(form, event) {
                event.preventDefault();
                $.ajax({
                    url: $(form).attr('action'),
                    type: 'POST',
                    dataType: 'json',
                    data: $(form).serialize(),
                    beforeSend: function() {
                        $('#cmt-btn-submit').attr("disabled", true);
                    },
                    success:function(data){                        
                        if(data.status == true){     
                            $("div#form-submit-result").addClass("alert alert-success");
                            $('div#form-submit-result').html(data.message);
                            $(form)[0].reset();
                        }else{
                            $('div#form-submit-result').empty();
                        }
                        $('#cmt-btn-submit').attr("disabled", false);
                    },
                     error: jqueryErrorHandling,
                });
                
            }
        });
    });



    function jqueryErrorHandling(xhr, status, exception) {
        var responseText;
        $("#dialog").html("");
        try {
            responseText = jQuery.parseJSON(xhr.statusText);
            $("#dialog").append("<div><b>" + status + " " + exception + "</b></div>");
            $("#dialog").append("<div><u>Exception</u>:<br /><br />" + responseText.ExceptionType + "</div>");
            $("#dialog").append("<div><u>StackTrace</u>:<br /><br />" + responseText.StackTrace + "</div>");
            $("#dialog").append("<div><u>Message</u>:<br /><br />" + responseText.Message + "</div>");
        } catch (e) {
            var errorMessage = xhr.statusText;
            $("#dialog").html(errorMessage);
            $("#dialog").dialog({
                title: "Exception Details",
                autoOpen: true,
                modal: true,
                width: 700,
                buttons: {
                    Close: function() {
                        $(this).dialog('close');
                    }
                }
            });
        }
    }
  
</script>