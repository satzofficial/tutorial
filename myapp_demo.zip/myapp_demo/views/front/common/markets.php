<?php 
    $this->load->view('front/common/header');
    $user_id = $this->session->userdata('user_id');

     $settings = $site_common['site_settings']; 
    $sitelan = $this->session->userdata('site_lang');
    $heading = $sitelan."_heading";
    $meta_description = $sitelan."_meta_description";
    $meta_keywords = $sitelan."_meta_keywords";
    $title = $sitelan."_title";
    $copy_right_text = $sitelan."_copy_right_text";
    $cms_title = $sitelan."_title";
    $content_description = $sitelan."_content_description";
    $lang_id = $this->session->userdata('site_lang');
   // echo $lang_id;
   if($lang_id!=''){
      $title = $lang_id.'_name';
      $content = $lang_id.'_content';
      $currencyTitle = $lang_id.'_title';

   }else{
      $title = $site_lang.'_name';
      $content = $site_lang.'_content';
      $currencyTitle = $site_lang.'_title';
   }


?>
<link rel="stylesheet" href="<?php echo front_css();?>jquery.dataTables.min.css">
<style>
.grn {
    color: rgb(5, 177, 105);
}
.rdn {
    color: rgb(223, 95, 103);
}      
</style>
<!-- breadcrumb -->
<div class="me-breadcrumb">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="me-breadcrumb-box">
            <h1><?=$this->lang->line('Price');?></h1>
            <!-- <p><a href="<?php echo base_url();?>"><?php echo $this->lang->line('Home');?></a><?=$this->lang->line('Price');?></p> -->
          </div>
        </div>
      </div>
    </div>
</div>

<!-- price -->
<div class="me-investment-single me-padder-top">
    <div class="container">
      <?php if($this->session->userdata('user_id')!='') {
            $this->load->view('front/user/sidebar_sticky');  
          }?>
      <div class="row">
  <div class="col-lg-12">
     <div class="table-responsive mb-5">
         <table id="marketCms" class="display w-100 table wallet-table">
            <thead>
               <tr>
                    <th class="text-center"><?=$this->lang->line('Pair');?></th>
                    <th class="text-center"><?=$this->lang->line('Last price');?></th>
                    <th class="text-center"><?=$this->lang->line('24H Change');?></th>
                    <th class="text-center"><?=$this->lang->line('24H High');?></th>
                    <th class="text-center"><?=$this->lang->line('24H Low');?></th>
                    <th class="text-center"><?=$this->lang->line('Volume');?></th>
                  <th></th>
               </tr>
            </thead>
            <tbody>
               <?php if(isset($pairs) && !empty($pairs)){
                        foreach($pairs as $pair_details){

                    $from_currency = $this->common_model->getTableData('currency',array('id' => $pair_details->from_symbol_id))->row();
                    $to_currency = $this->common_model->getTableData('currency',array('id' => $pair_details->to_symbol_id))->row();
                    $pair_symbol = $from_currency->currency_symbol.'/'.$to_currency->currency_symbol;
                    $pair_url = $from_currency->currency_symbol.'_'.$to_currency->currency_symbol;
                    $currency = getcryptocurrencydetail($from_currency->id);
                    ?>
                    <tr>
                        <td><img src="<?php echo $currency->image;?>" width="24" alt="<?=$pair_symbol?>" class="table-cryp"> <a href="<?php echo base_url();?>trade/<?=$pair_url;?>"><?=$pair_symbol?></a></td>
                        <td class="text-center"><?php echo TrimTrailingZeroes($pair_details->lastPrice);?></td>
                        <td class="text-center"><span class="<?php echo($pair_details->priceChangePercent>0)?'grn':'rdn';?>"><?php echo number_format($pair_details->priceChangePercent,2);   ?>%</span></td>
                        <td class="text-center"><?php echo TrimTrailingZeroes($pair_details->change_high);?></td>
                        <td class="text-center"><?php echo TrimTrailingZeroes($pair_details->change_low);?></td>
                        <td class="text-center"><?php echo TrimTrailingZeroes($pair_details->volume);?></td>
                        <td class="text-center"><a href="<?php echo base_url();?>trade/<?=$pair_url;?>" class="btn"><?=$this->lang->line('Trade');?></a></td>
                    </tr>
                    <?php } }?>
               
               
            </tbody>
         </table>
          </div>
          </div>
      </div>
    </div>
  </div>

  <!-- Testimonial -->
<!-- <div class="me-testimonial me-padder-top-less me-padder-bottom">
    <div class="container">
        <div class="me-heading2">
            <h1><?php echo $home_banner7->$title;?></h1>
        </div>
        <div class="row">
            <div class="col-md-5">
                <div class="me-testimonial-user">
                    <img src="<?php echo front_img();?>user.jpg" class="img-fluid" alt="image" title="John Doe"/>
                    <img src="<?php echo front_img();?>user2.jpg" class="img-fluid" alt="image" title="John Doe"/>
                    <img src="<?php echo front_img();?>user3.jpg" class="img-fluid" alt="image" title="John Doe"/>
                    <img src="<?php echo front_img();?>user4.jpg" class="img-fluid" alt="image" title="Joolie Desuza"/>
                    <img src="<?php echo front_img();?>user5.jpg" class="img-fluid" alt="image" title="Joolie Desuza"/>
                </div>
            </div>
            <div class="col-md-7">
                <div class="me-testimonial-slider">
                    <div class="me-testimonial-box-shape">
                    </div>
                    <div class="me-testimonial-slider-box">
                        <div class="swiper-container">
                            <div class="swiper-wrapper">
                            <?php if(isset($testimonials) && !empty($testimonials)){
                                    foreach($testimonials as $testimonials_info){ 
                                        if($lang_id!=''){
                                              $testi_title = $lang_id.'_name';
                                              $testi_position = $lang_id.'_position';
                                              $testi_comments = $lang_id.'_comments';
                                           }else{
                                              $testi_title = $site_lang.'_name';
                                              $testi_position = $site_lang.'_position';
                                              $testi_comments = $site_lang.'_comments';
                                           }
                                        ?>    
                                <div class="swiper-slide">
                                    <div class="me-testimonial-data">
                                        <p><?=$testimonials_info->$testi_comments?></p>
                                        <h4><?=$testimonials_info->$testi_title?></h4>
                                        <h6><?=$testimonials_info->$testi_position?></h6>
                                    </div>
                                </div>
                            <?php }}?>    
                               
                            </div>
                        </div>
                    </div>
                    <div class="me-testimonial-button">
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> -->



  <?php $this->load->view('front/common/footer'); ?>

<script type="text/javascript" src="<?php echo front_js();?>dataTables.min.js"></script>
<script type="text/javascript" src="<?php echo front_js();?>datatables.bootstrap4.min.js"></script>
<script>


all_markets = '<?=$this->lang->line('All Markets');?>'; 
sel_market = '<?=$this->lang->line('Select Market');?>'; 
search_coin_name = '<?=$this->lang->line('Search Coin name');?>';   
currency_symbol ='<?=$currency_symbol?>';
next = '<?=$this->lang->line('Next');?>';   
previous = '<?=$this->lang->line('Previous');?>'; 
no_data = '<?=$this->lang->line('No data available in table');?>';   
no_entry = '<?=$this->lang->line('Showing 0 to 0 of 0 entries');?>';   
show_entry = '<?=$this->lang->line('Showing _START_ to _END_ of _TOTAL_ entries');?>';   
filtered = '<?=$this->lang->line('(filtered from _MAX_ total entries)');?>';

 var marketCmsTable = $('#marketCms').DataTable( {
     "order": [[ 5, "desc" ]],
     "pageLength": 10,
     "lengthChange": false,
     language: { 
         search: '<i class="fa fa-search"></i>',
         searchPlaceholder: search_coin_name,
          'paginate': {
          'previous': previous,
          'next': next,
        },
     },
       oLanguage: {
        "sEmptyTable": no_data,
        "infoEmpty": no_entry,
        "info": show_entry,
        "infoFiltered": filtered
     },
     'aoColumnDefs': [{
         'bSortable': false,
         'aTargets': [-1] 
     }],
 });
        
  $('#marketCms_wrapper > .row:first-child > div:first-child').append('<ul class="marketslinqs d-flex"><li><a data-filter="ALL">'+all_markets+'</a></li><li class="dropdown"><a data-filter="">'+sel_market+'</a> <span class="dropdown-toggle"id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> &nbsp;&nbsp;ALL</span><div class="dropdown-menu" aria-labelledby="dropdownMenuButton">'+currency_symbol+'</div></li></ul>');
     
 $('.marketslinqs li a').on( 'click', function () {
     var val = $(this).attr('data-filter');
     var exact = $(this).attr('data-exact');
     if(val != '' && val != undefined && val !== 'ALL'){
         if(exact == 1){
             var regex = '\\b' + val + '\\b';
             marketCmsTable.rows().search(regex, true, false).draw();
         }
         else{
             marketCmsTable.search( val).draw();
         }
         $('input[type=search]').val('');
     }
     else{console.log('sadsad');
         $('input[type=search]').val('');
         marketCmsTable.search('').draw();
     }
 });








// function load_design(decimal)
// { 
//     if(decimal==undefined)
//     {
//       decimal = 8;
//     }
//     else
//     {
//       decimal = decimal;
//     }
//     var decimalpoints=decimal;
//     var decimal=decimal;         

//     //Call WEB SOCKET
//     var param = {  
//     path: "market_prices",
//    };
//    ws.send(JSON.stringify(param));     
// } 
// ws.onopen = function(event) 
// { 
//     console.log("connected websocket....");             
//     //load_design();
// }
// ws.onmessage = function(event) 
// {
//   var browsername=navigator ? navigator.userAgent.toLowerCase() : "other";
//   var resp = browsername.split(" "); 
//   var lengthbrowser=resp.length;
//   var getname=resp[lengthbrowser-1];
//   var res1 = getname.split("/"); 
//   if(res1[1]!='safari')
//   {
//     console.API;
//     if (typeof console._commandLineAPI !== 'undefined') {
//     console.API = console._commandLineAPI; //chrome
//     } else if (typeof console._inspectorCommandLineAPI !== 'undefined') {
//     console.API = console._inspectorCommandLineAPI; //Safari
//     } else if (typeof console.clear !== 'undefined') {
//     console.API = console;
//     }
//   }

//   var res = event.data;
//   var designs=JSON.parse(res);
//   var tableRows = designs.localpair_details;

//   console.log(tableRows);
//   var dataTable = $('#marketCms').DataTable();
//   dataTable.destroy();
//   $(".price_table").empty().promise().done(function(){
//       $(".price_table").html(tableRows);
//       dataTable = $("#marketCms").DataTable();
//   });

// }
// ws.onerror = function(event)
// {
//     var Data = JSON.parse(event);
// };
// ws.onclose = function(event)
// {
//     $("#loader").hide();
// }; 


// setInterval(function () {
//   var decimal_sel = 8; 
//   load_design(decimal_sel);
// },3000);




</script>