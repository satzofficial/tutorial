<li><a title="<?php echo $this->lang->line('Settings')?>" href="<?=base_url();?>settings"><i class="fa fa-cog"></i></a></li>
<li><a title="<?php echo $this->lang->line('Profile Edit')?>" href="<?=base_url();?>profile-edit"><i class="fa fa-user-edit"></i></a></li>
<li><a title="<?php echo $this->lang->line('Logout')?>" href="<?=base_url();?>logout"><i class="fa fa-sign-out-alt"></i></a></li>