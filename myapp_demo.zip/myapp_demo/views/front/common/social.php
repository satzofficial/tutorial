<?php $settings = $site_common['site_settings'];
?>
<ul class="list-inline social_links">
    <li class="list-inline-item">
        <a href="<?=$settings->facebooklink?>" target="_blank"><img src="<?=front_img()?>fb.svg" alt="facebook" class="img-fluid"></a>
    </li>
    <li class="list-inline-item">
        <a href="<?=$settings->twitterlink?>" target="_blank"><img src="<?=front_img()?>tw.svg" alt="Twitter" class="img-fluid"></a>
    </li>
    <li class="list-inline-item">
        <a href="<?=$settings->linkedin_link?>" target="_blank"><img src="<?=front_img()?>linkedin.svg" alt="Linkedin" class="img-fluid"></a>
    </li>
    <li class="list-inline-item">
        <a href="<?=$settings->telegramlink?>" target="_blank"><img src="<?=front_img()?>telegram-circle.svg" alt="Telegram" class="img-fluid"></a>
    </li>
</ul>