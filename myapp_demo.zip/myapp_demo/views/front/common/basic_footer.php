<?php
$user_id = $this->session->userdata('user_id');
$favicon = $site_common['site_settings']->site_favicon;
    $sitelogo = $site_common['site_settings']->site_logo;
     $lang_id = $this->session->userdata('site_lang');
    if($lang_id == '')
    {
      $this->lang->load('content','english');
      $this->session->set_userdata('site_lang','english');
    }
    else
    {
      $this->lang->load('content',$lang_id);  
      $this->session->set_userdata('site_lang',$lang_id);
    }

   if($lang_id!=''){
      $title = $lang_id.'_name';
      $content = $lang_id.'_content';

   }else{
      $title = $site_lang.'_name';
      $content = $site_lang.'_content';
   }
    $seg1 = $this->uri->segment(1);
    $seg2 = $this->uri->segment(2);
       
?>
<!-- Copyright Footer -->
  <div class="me-footer-copyright">
      <div class="container">
          <div class="row">
              <div class="col-lg-6">
                  <div class="me-copyright-block">
                      <a href="<?=base_url()?>"><p><?php echo $site_common['site_settings']->english_copy_right_text;?></p>
                      </a>
                  </div>
              </div>
              
          </div>
      </div>
  </div> 
</div> 

<script src="<?php echo front_lib();?>jquery/jquery.min.js"></script>
<script src="<?php echo front_js();?>bootstrap.min.js"></script>


<script src="<?php echo front_lib();?>bootstrap/js/bootstrap.bundle.min.js"></script> 


<script src="<?php echo front_js();?>jquery.growl.js"></script>



 <?php
    $error      = $this->session->flashdata('error');
    $success    = $this->session->flashdata('success');
    $user_id    = $this->session->userdata('user_id');
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $get_os     = $_SERVER['HTTP_USER_AGENT'];

?>  
<script>
$(document).ready(function() {
  
    var user_id='<?php echo $user_id;?>';
    var ip_address = '<?php echo $ip_address;?>';
    var get_os     = '<?php echo $get_os;?>';

    var success = "<?php echo $this->session->flashdata('success')?>";
    var error = "<?php echo $this->session->flashdata('error')?>";
  

if(success!=''){
    $.growl.notice({location: "cc",size:"large", title: "Share Coin Exchange", message: success });
}
if(error!=''){
    $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: error });
}

});
var base_url='<?php echo base_url();?>';
var front_url='<?php echo front_url();?>';

// Language Loader
function setLang(lang='') {
  window.location.href = front_url+"/switchLang/"+lang;
}

var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';
$.ajaxPrefilter(function (options, originalOptions, jqXHR) {
    if (options.type.toLowerCase() == 'post') {
        options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
        if (options.data.charAt(0) == '&') {
            options.data = options.data.substr(1);
        }
    }
});

$( document ).ajaxComplete(function( event, xhr, settings ) {
    if (settings.type.toLowerCase() == 'post') {
        $.ajax({
            url: front_url+"get_csrf_token",
            type: "GET",
            cache: false,
            processData: false,
            success: function(data) {

                 $("input[name="+csrfName+"]").val(data);
            }
        });
    }
});

$(document).ready(function () {
    $('.dropdown-toggle').dropdown();
});

$(window).on('load', function() {
  $('#loaderstatus').fadeOut(); 
  $('#preloader').delay(350).fadeOut('slow');
  $('body').delay(350).css({'overflow':'visible'});
})   

var user_id='<?php echo $user_id;?>';     
const formatter = new Intl.NumberFormat('en-US', {
   minimumFractionDigits: 6,      
   maximumFractionDigits: 6,
});









</script>
