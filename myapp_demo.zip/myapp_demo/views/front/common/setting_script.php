<script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
<script>
    $(document).ready(function() {
        $('#datepicker').datepicker({
            uiLibrary: 'bootstrap4',
            format: 'yyyy/mm/dd'
        });
    });
</script>
<!--owl-carousel-->
<script src="<?=base_url();?>assets/front/inner/js/owl.carousel.min.js"></script>
<script>
    $(document).ready(function() {
        $('.currency_carousel').owlCarousel({
            loop: true,
            margin: 24,
            autoplay: true,
            center: false,
            autoplayTimeout: 3000,
            autoplayHoverPause: true,
            nav: false,
            dots: false,
            responsive: {
                0: {
                    items: 1
                },
                320: {
                    items: 1
                },
                480: {
                    items: 2
                },
                600: {
                    items: 2
                },
                767: {
                    items: 3
                },
                991: {
                    items: 3
                },
                1200: {
                    items: 4
                }
            }
        });
    });
</script>

<!--datatables-->
<script type="text/javascript" src="https://cdn.datatables.net/w/bs4/dt-1.10.18/datatables.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.js"></script>
<script>
    $(document).ready(function() {
        $('#login_history').DataTable({
            "scrollY": 140,
            "scrollX": true,
            "paging": false,
            "info": false,
            "searching": false
        });
        $('#ticket_list_table').DataTable({
            "scrollY": 350,
            "scrollX": true,
            "paging": false,
            "info": false,
            "searching": false
        });
        $('#deposit').DataTable({
            "scrollY": 150,
            "scrollX": true,
            "paging": false,
            "info": false,
            "searching": false
        });
         $('#withdraw').DataTable({
            "scrollY": 150,
            "scrollX": true,
            "paging": false,
            "info": false,
            "searching": false
        });
        $('#deposits').DataTable({
            "scrollY": 320,
            "scrollX": true,
        });
        $('#withdraws').DataTable({
            "scrollY": 320,
            "scrollX": true,
        });
        $('#trade').DataTable({
            "scrollY": 320,
            "scrollX": true,
        });
        $('#balances').DataTable({
            "scrollY": 350,
            "scrollX": true,
            "order": [[ 2, "asc" ]]
        });
    });
     
</script>
<script>
    $(document).ready(function() {
        $('#recent_transactions').DataTable({
            "scrollY": 140,
            "scrollX": true,
            "paging": false,
            "info": false,
            "searching": false
        });
    });
    $('a[data-toggle="tab"]').on('shown.bs.tab', function(e) {
        $($.fn.dataTable.tables(true)).DataTable()
            .columns.adjust();
    });
    const realFileBtn = document.getElementById("real-file");
    const customBtn = document.getElementById("custom-button");
    const customTxt = document.getElementById("custom-text");
    customBtn.addEventListener("click", function() {
        realFileBtn.click();
    });
    realFileBtn.addEventListener("change", function() {
        if (realFileBtn.value) {
            customTxt.innerHTML = realFileBtn.value.match(
                /[\/\\]([\w\d\s\.\-\(\)]+)$/
            )[1];
        } else {
            customTxt.innerHTML = "No file chosen, yet.";
        }
    });
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
<?php
    $error      = $this->session->flashdata('error');
    $success    = $this->session->flashdata('success');
    $user_id    = $this->session->userdata('user_id');
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $get_os     = $_SERVER['HTTP_USER_AGENT'];
?>
<script type="text/javascript">

    var base_url='<?php echo base_url();?>';
    var front_url='<?php echo front_url();?>';
    var user_id='<?php echo $user_id;?>';
    var ip_address = '<?php echo $ip_address;?>';
    var get_os     = '<?php echo $get_os;?>';

    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';


    $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
        if (options.type.toLowerCase() == 'post') {
            options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
            if (options.data.charAt(0) == '&') {
                options.data = options.data.substr(1);
            }
        }
    });

    $( document ).ajaxComplete(function( event, xhr, settings ) {
        if (settings.type.toLowerCase() == 'post') {
            $.ajax({
                url: front_url+"get_csrf_token", 
                type: "GET",
                cache: false,             
                processData: false,      
                success: function(data) {

                     $("input[name="+csrfName+"]").val(data);
                }
            });
        }
    });
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.js"></script>
    <script>
            toastr.options = { "closeButton": true, "timeOut": "34000", }
    </script>  
    <?php if($this->session->flashdata('success')!= '')
          { ?>   
                <script> toastr.success("<?php echo $this->session->flashdata('success');?>"); </script>
    <?php } ?>

    <?php if($this->session->flashdata('info')!= '')
          { ?>   
                <script> toastr.info("<?php echo $this->session->flashdata('info');?>"); </script>
    <?php } ?>

    <?php if($this->session->flashdata('warning')!= '')
          { ?>   
                <script> toastr.warning("<?php echo $this->session->flashdata('warning');?>"); </script>
    <?php } ?>

    <?php if($this->session->flashdata('error')!= '')
          { ?>   
                <script> toastr.error("<?php echo $this->session->flashdata('error');?>"); </script>
    <?php } ?>
    <script type="text/javascript">
         $.validator.addMethod('ZipChecker', function() {
    }, 'Invalid zip code');
         $('#verification_form').validate({
      rules: {
        firstname: {
          required: true
        },
        username: {
          required: true
        },
        address: {
          required: true
        },
        city: {
          required: true,
          lettersonly: true
        },
        state: {
          required: true,
          lettersonly: true
        },
        postal_code: {
          required: true,
          number: true,
          maxlength: 7,
          ZipChecker: function(element) {
          values=$("#postal_code").val();

           if( values =="0" || values =="00" || values =="000" || values =="0000" || values =="00000"  || values =="000000"   || values =="0000000" )
           {
              return true;
              
           }
           
           }

        },
        phone: {
          required: true
        }
      },
      messages: {
        firstname: {
          required: "<?php echo $this->lang->line('Please enter first name')?>"
        },
        lastname: {
          required: "<?php echo $this->lang->line('Please enter last name')?>"
        },
        address: {
          required: "<?php echo $this->lang->line('Please enter address')?>"
        },
        city: {
          required: "<?php echo $this->lang->line('Please enter city')?>",
          lettersonly: "<?php echo $this->lang->line('Please enter letters only')?>"
        },
        state: {
          required: "<?php echo $this->lang->line('Please enter state')?>",
          lettersonly: "<?php echo $this->lang->line('Please enter letters only')?>"
        },
        postal_code: {
          required: "<?php echo $this->lang->line('Please enter postal code')?>"
        },
        phone: {
          required: "<?php echo $this->lang->line('Please enter phone number')?>"
        }
      }
    });

    $('#change_password').validate({
      rules: {
        oldpass: {
          required: true,
          remote: {
                    url: front_url+'oldpassword_exist',
                    type: "post",
                    csrf_token : csrfName,
                    data: {
                        oldpass: function() {
                        return $( "#oldpass" ).val();
                        }
                    }
                }
        },
       newpass: {
          required: true
        },
        confirmpass: {
          required: true,
          equalTo : "#newpass"
        },
    },
     messages: {
        oldpass: {
          required: "<?php echo $this->lang->line('Please enter Old Password')?>",
           remote: "<?php echo $this->lang->line('Invalid Old Password')?>"
        },
        newpass: {
          required: "<?php echo $this->lang->line('Please enter New Password')?>"
        },
        confirmpass: {
          required: "<?php echo $this->lang->line('Please enter Confirm Password')?>",
          equalTo : "<?php echo $this->lang->line('Confirm Password not matches with New Password')?>"
        },
    }
});
    $('#security').validate({
        rules: {
            code: {
                required: true,
                number: true,
                minlength: 6,
            }
        },
        messages: {
            code: {
                required: '<span style="color:red"><?php echo $this->lang->line('Please enter  code')?></span>',
                number: '<span style="color:red"><?php echo $this->lang->line('Please enter valid code')?></span>',
                minlength:'<span style="color:red"><?php echo $this->lang->line('Please 6 digit valid code')?></span>',
            },
        }
    });
    $('#support_form').validate({
        rules: {
            subject: {
                required: true
            },
            message: {
                required: true
            }
        },
        messages: {
            subject: {
                required: "<?php echo $this->lang->line('Please enter subject')?>"
            },
            message: {
                required: "<?php echo $this->lang->line('Please enter message')?>"
            }
        }
    });
    $('input[type=file]#real-file').change(function(){ 
        $("#image_name").html($("#real-file").val());
        var ext = $('#real-file').val().split('.').pop().toLowerCase();
        if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) {
            $("#img_error").html("Please upload proper file format");
            $(':button[type="submit"]').prop('disabled', true);
        }
        else{  
            $("#img_error").html('');
            $(':button[type="submit"]').prop('disabled', false); 
        }
    });
    $('#reply').validate({
        rules: {
            
            message: {
                required: true
            }
        },
        messages: {
            
            message: {
                required: "<?php echo $this->lang->line('Please enter message')?>"
            }
        },
    });
    $('#deposit_withdraw_coin').validate({
      rules: {
        address: {
          required: true
        },
        amount: {
          required: true,
          number: true,
        }
      },
      messages: {
        address: {
          required: "<?php echo $this->lang->line('Please enter address')?>"
        },
        amount: {
          required: "<?php echo $this->lang->line('Please enter amount')?>",
          number: "<?php echo $this->lang->line('Only enter numbers as decimal or float')?>"
        }
      },
    });

    $("#profile_check").on('click',function(){
        swal("Notice!", "<?php echo $this->lang->line('Your profile not updated')?>", "warning");
    });

    $("#kyc_check").on('click',function(){
        swal("Notice!", "<?php echo $this->lang->line('Your KYC not verified by Team')?>", "warning");
    });



   $('#bankwire').validate({
      rules: {
        currency: {
          required: true
        },
        bank_name: {
          required: true
        },
        bank_account_number: {
          required: true
        },
        bank_account_name: {
          required: true,
          lettersonly: true
        },
        bank_swift: {
          required: true
        },
         bank_address: {
          required: true
        },
        bank_city: {
          required: true,
          lettersonly: true
        },
        bank_country: {
          required: true,
          lettersonly: true
        },
        postal_code: {
          required: true,
          number: true,
          maxlength: 7,
          ZipChecker: function(element) {
          values=$("#postal_code").val();

           if( values =="0" || values =="00" || values =="000" || values =="0000" || values =="00000"  || values =="000000"   || values =="0000000" )
           {
              return true;
              
           }
           
           }

        },
        phone: {
          required: true
        }
      },
      messages: {
        bank_name: {
          required: "<?php echo $this->lang->line('Please enter bank name')?>"
        },
        bank_account_number: {
          required: "<?php echo $this->lang->line('Please enter bank account number')?>"
        },
        bank_account_name: {
          required: "<?php echo $this->lang->line('Please enter bank account name')?>",
          lettersonly: "<?php echo $this->lang->line('Please enter letters only')?>"
        },
        bank_swift: {
          required: "<?php echo $this->lang->line('Please enter bank swift')?>"
        },
        bank_address: {
          required: "<?php echo $this->lang->line('Please enter bank address')?>"
        },
        bank_city: {
          required: "<?php echo $this->lang->line('Please enter bank city')?>",
          lettersonly: "<?php echo $this->lang->line('Please enter letters only')?>"
        },
        bank_country: {
          required: "<?php echo $this->lang->line('Please enter bank bank country')?>",
          lettersonly: "<?php echo $this->lang->line('Please enter letters only')?>"
        },
        postal_code: {
          required: "<?php echo $this->lang->line('Please enter postal code')?>"
        }
      }
    });
    </script> 
