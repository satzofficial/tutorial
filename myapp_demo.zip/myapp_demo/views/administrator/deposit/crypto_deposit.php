<!-- begin #content -->
<div class="page-content-wrapper">
<div class="page-content">
			<?php 
		$error = $this->session->flashdata('error');
		if($error != '') {
			echo '<div class="note note-danger">
			<button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$error.'</div>';
		}
		$success = $this->session->flashdata('success');
		if($success != '') {
			echo '<div class="note note-success">
			<button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$success.'</div>';
		} 
		?>
			<!-- begin page-header -->
			<div class="page-head">
			<div class="page-title">
					<h1>Crypto Deposit Management</h1>
				</div>
                </div>
			<!-- end page-header -->
			<!-- begin breadcrumb -->
			<ul class="page-breadcrumb breadcrumb">
				<li>
					<a href="<?php echo admin_url();?>">Home</a>
					<i class="fa fa-circle"></i>
				</li>
				<li class="active"><a href="javascript:;">Crypto Deposit</a></li>
			</ul>
			<!-- end breadcrumb -->

			<!-- begin row -->
			<div class="row">
				<div class="col-md-12">
			        <!-- begin panel -->
					<div class="portlet light">
					<div class="portlet-title">
                    <div class="caption">
						<span class="caption-subject bold uppercase font-green-haze">Crypto Deposit Management</span>
					</div>
					<div class="tools">
						<a href="javascript:;" class="collapse">
						</a>
						<a href="#portlet-config" data-toggle="modal" class="config">
						</a>
						<a href="javascript:;" class="reload">
						</a>
						<a href="javascript:;" class="fullscreen">
						</a>
						<a href="javascript:;" class="remove">
						</a>
					</div>
                        </div>
					<?php if($view=='view_all'){ ?>
                        <div class="portlet-body">
                        <div class="clearfix">
                       
						</div>
						<br/><br/>
                            <div class="table-responsive">
                                <table id="datas-table" class="table table-striped table-bordered" id="cdeposit">
                                    <thead>
                                        <tr>
                                        <th class="text-center">S.No</th>
                                        <th class="text-center">Username</th>
										<th class="text-center">Date & Time</th>
										<th class="text-center">Hash</th>
										<th class="text-center">Image</th>
										<th class="text-center">Currency</th>
										<th class="text-center">Amount</th>
										<th class="text-center">Status</th>
										<th class="text-center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody style="text-align: center;">
                                    <?php
                                    
                                    if($deposit){ 
                                    	foreach ($deposit as $key => $value) {
                                    		$key = $key + 1;
                                    		 if($value->status == '1'){


                                    		 $edit = '<a href="'.base_url().'tenrealm_admin/deposit/status/'.$value->id.'/0" data-placement="bottom" data-toggle="popover" data-content="De-activate this user" class="poper">Deactive</a>';
                                    		}else{
                                    		 $edit = '<a href="'.base_url().'tenrealm_admin/deposit/status/'.$value->id.'/1" data-placement="bottom" data-toggle="popover" data-content="activate this user" class="poper">Active</a>';	
                                    		}

                                    		if($value->image){
                                    			$image = '<img src="'.$value->image.'" alt="image" >';
                                    		}

                                    	 	?>
                                    	 <tr>
                                    		<td><?php echo $key; ?></td>
                                    		<!-- <td><?php //echo user_id_to_name($value->user_id); ?></td> --> 	
                                    		<td><?php echo user_id_to_name($value->user_id); ?></td> 	
                                    			
                                    		<td><?php echo $value->created_at; ?></td> 
                                    		<td><?php echo $value->hash; ?></td> 
                                    		<td><?php if($value->image){
                                    			echo $image = '<img hight="100px" width="100" src="'.$value->image.'" alt="image" >';
                                    		} ?></td> 
                                    		<td><?php echo $value->currency; ?></td> 	
                                    		<td><?php echo $value->amount; ?></td> 	
                                    		<td><?php echo ($value->status) ? 'Active' : 'Inactive' ?></td> 	
                                    		<td><?php echo $edit; ?></td> 	
                                    	 </tr>
                                    	
                                    
                                  	<?php  }  } ?>
									
                                    </tbody>
                                </table>
                               
                            </div>
                        </div>
					<?php }else{ ?>
					<div class="portlet-body">
						<?php $attributes=array('class'=>'form-horizontal','id'=>'deposit');
				echo form_open_multipart($action,$attributes);
										
				?>
                                <fieldset>
                                  
								<div class="form-group">
                                <label class="col-md-2 control-label">Username</label>
                                <div class="col-md-8 control-label text-left">
								<?php echo $deposit->username; ?>
                                </div>
                                </div>
                                <div class="form-group">
                                <label class="col-md-2 control-label">Currency</label>
                                <div class="col-md-8 control-label text-left">
								<?php echo $deposit->currency_symbol; ?>
                                </div>
                                </div>
                                <div class="form-group">
                                <label class="col-md-2 control-label">Transaction Id</label>
                                <div class="col-md-8 control-label text-left">
								<?php echo ($deposit->wallet_txid!='')?$deposit->wallet_txid:'-'; ?>
                                </div>
                                </div>
                                <div class="form-group">
                                <label class="col-md-2 control-label">Amount</label>
                                <div class="col-md-8 control-label text-left">
								<?php echo $deposit->amount; ?>
                                </div>
                                </div>

                                <div class="form-group">
                                <label class="col-md-2 control-label">Received Address</label>
                                <div class="col-md-8 control-label text-left">
								<?php echo $deposit->crypto_address; ?>
                                </div>
                            	</div>

                            	 <div class="form-group">
                                <label class="col-md-2 control-label">Info</label>
                                <div class="col-md-8 control-label text-left">
								<?php echo ($deposit->information!='')?$deposit->information:'-'; ?>
                                </div>
                            	</div>
                          
                                <div class="form-group">
                                <label class="col-md-2 control-label">Description</label>
                                <div class="col-md-8 control-label text-left">
								<?php echo $deposit->description; ?>
                                </div>
                            	</div>
                                <div class="form-group">
                                <label class="col-md-2 control-label">Deposited On</label>
                                <div class="col-md-8 control-label text-left">
								<?php echo gmdate("d-m-Y h:i a", $deposit->datetime); ?>
                                </div>
                            	</div>
                               <?php if($deposit->payment_type=="bank_wire") { ?>
                               	 <div class="form-group">
                                <label class="col-md-2 control-label">Transaction Proof</label>
                                <div class="col-md-8 control-label text-left">
                                <img src="<?php echo $deposit->transaction_proof; ?>">
                                </div>
                                </div>
                                <?php } ?>
                                <?php if($deposit->status=='Pending'){ ?>
                                <a class="btn btn-small btn-success" href="<?php echo admin_url();?>admin/deposit_confirm/<?php echo base64_encode($deposit->trans_id);?>"  style='margin-left:20px;'>Confirm</a>
                                <?php } ?>

                               
                                </fieldset>
                            </form>
                        </div>
					<?php } ?> 
                    </div>
                    <!-- end panel -->
                </div>
			</div>
			<!-- end row -->

			</div>
		</div>
		<!-- end #content -->
<!-- ================== BEGIN BASE JS ================== -->
	<script src="<?php echo admin_source();?>/plugins/jquery/jquery-1.9.1.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/jquery/jquery-migrate-1.1.0.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/jquery-ui/ui/minified/jquery-ui.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/ckeditor/ckeditor.js"></script>
	<!--[if lt IE 9]>
		<script src="<?php echo admin_source();?>/crossbrowserjs/html5shiv.js"></script>
		<script src="<?php echo admin_source();?>/crossbrowserjs/respond.min.js"></script>
		<script src="<?php echo admin_source();?>/crossbrowserjs/excanvas.min.js"></script>
	<![endif]-->
	<script src="<?php echo admin_source();?>/plugins/slimscroll/jquery.slimscroll.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/jquery-cookie/jquery.cookie.js"></script>
	<!-- ================== END BASE JS ================== -->
	<!-- ================== BEGIN PAGE LEVEL JS ================== -->
	<script src="<?php echo admin_source();?>/plugins/gritter/js/jquery.gritter.js"></script>
	<script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.time.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.resize.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/DataTables/js/jquery.dataTables.min.js"></script> 
<script src="<?php echo admin_source();?>/plugins/DataTables/js/dataTables.responsive.min.js"></script>
	<script src="<?php echo admin_source();?>/js/jquery.validate.min.js"></script>
	<script src="<?php echo admin_source();?>/js/apps.min.js"></script>
	<!-- ================== END PAGE LEVEL JS ================== -->
	<script>
	$(document).ready(function() {
		
		$('#cms').validate({
			rules: {
				heading: {
					required: true
				},
				title: {
					required: true
				},
				meta_keywords: {
					required: true,
				},
				meta_description: {
					required: true
				},
				content_description: {
					required: true,
				}
				
			},
			highlight: function (element) {
				//$(element).parent().addClass('error')
			},
			unhighlight: function (element) {
				$(element).parent().removeClass('error')
			}
		});
	});
</script> 
	<script>
		$(document).ready(function() {
			App.init();
		});
		var admin_url='<?php echo admin_url(); ?>';
		
$(document).ready(function() {
    $('#datas-table').DataTable( {
    	"responsive" : true,
        "processing" : true,
        "pageLength" : 10,
        // "serverSide": true,
        "order": [[0, "asc" ]],
        // "searching": true,
        // "ajax": admin_url+"deposit/cryptodeposit_ajax"
    });
        });
		 $(document).ready(function() {
         $.fn.dataTableExt.sErrMode = 'throw';
         $('#cdeposit').DataTable();
        } );

		
	</script>
	 <script async
src="https://www.googletagmanager.com/gtag/js?id=G-FDX8TJF8SG"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', 'G-FDX8TJF8SG');
</script>