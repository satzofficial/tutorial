<?php 
$favicon  =  ($site_common['site_settings']->site_favicon) ? $site_common['site_settings']->site_favicon :'';
 ?>
<!DOCTYPE html>
<html lang="en">
<!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title><?php echo $title; ?></title>
	<link rel="icon" type="image/png" href="<?php echo $favicon;?>" />
	<meta name="keywords" content="<?php echo $meta_keywords; ?>">
    <meta name="description" content="<?php echo $meta_description; ?>">
	<meta http-equiv="content-type" content="text/html;charset=UTF-8">	
	
	<!-- ================== BEGIN BASE CSS STYLE ================== -->
<link href="<?php echo admin_source();?>plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo admin_source();?>plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo admin_source();?>plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo admin_source();?>plugins/uniform/css/uniform.default.css" rel="stylesheet" type="text/css"/>
<!-- END GLOBAL MANDATORY STYLES -->
<!-- BEGIN PAGE LEVEL STYLES -->
<link href="<?php echo admin_source();?>pages/css/login.css" rel="stylesheet" type="text/css"/>
<!-- END PAGE LEVEL SCRIPTS -->
<!-- BEGIN THEME STYLES -->
<link href="<?php echo admin_source();?>css/components-rounded.css" id="style_components" rel="stylesheet" type="text/css"/>
<link href="<?php echo admin_source();?>css/plugins.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo admin_source();?>layout4/css/layout.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo admin_source();?>layout4/css/themes/default.css" rel="stylesheet" type="text/css" id="style_color"/>
<link href="<?php echo admin_source();?>layout4/css/custom.css" rel="stylesheet" type="text/css"/>
</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="login">
<!-- BEGIN SIDEBAR TOGGLER BUTTON -->
<div class="menu-toggler sidebar-toggler">
</div>
<!-- END SIDEBAR TOGGLER BUTTON -->
<!-- BEGIN LOGO -->
<div class="logo">
	<a href="index.html">

	</a>
</div>
<!-- END LOGO -->
<!-- BEGIN LOGIN -->
<div class="content">
	<!-- BEGIN LOGIN FORM -->
    <?php

		$error = $this->session->flashdata('error');
		if($error != '') {
			echo '<div class="note note-danger">
			<button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$error.'</div>';
		}
		$success = $this->session->flashdata('success');
		if($success != '') {
			echo '<div class="note note-success">
			<button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$success.'</div>';
		} 
		?>
    <?php $attributes=array('class'=>'login-form','id'=>'admin_login');
				echo form_open($action,$attributes); ?>
				<?php
				if($type=='login')
				{ ?>
		<h3 class="form-title">Sign In</h3>
		<div class="note note-danger display-hide">
			<button class="close" data-close="alert"></button>
			<span>
			Enter any username and password. </span>
		</div>
		<div class="form-group">
			<!--ie8, ie9 does not support html5 placeholder, so we just show field title for that-->
			<label class="control-label visible-ie8 visible-ie9">Email</label>
			<input class="form-control form-control-solid placeholder-no-fix" type="email" autocomplete="off" placeholder="email" name="email" value="<?php if(isset($_COOKIE['admin_login_email'])) {echo $_COOKIE['admin_login_email'];}?>"/>
		</div>
		<div class="form-group">
			<label class="control-label visible-ie8 visible-ie9">Password</label>
			<input class="form-control form-control-solid placeholder-no-fix" type="password" autocomplete="off" placeholder="Password" value="<?php if(isset($_COOKIE['admin_login_password'])) {echo $_COOKIE['admin_login_password'];}?>" name="password"/>
            <!--<input type="hidden" value="" name="patterncode" id="patterncode" />-->
        </div>
        <!--<div class="form-group set-pattern-width">-->
        <!--                <div id="patternContainer"></div>-->
        <!--            </div>-->
		<div class="form-actions">
			<button type="submit" class="btn btn-success uppercase">Login</button>
			<label class="rememberme check">
			<input type="checkbox" name="remember" value="1" <?php if(isset($_COOKIE['admin_login_remember'])) {echo 'checked';}?>/>Remember </label>
			<a href="<?php echo admin_url().'admin/forget_password';?>" id="forget-password" class="forget-password">Forgot Password?</a>
		</div>


        <?php }else{ ?>
		<div class="form-group m-b-20">
                        <input type="email" value="" name="email" class="form-control input-lg" placeholder="Email Address" />
                    </div>
					<div class="login-buttons">
                        <button type="submit" class="btn btn-success btn-block btn-lg">Reset Password</button>
                    </div>
                    <div class="m-t-20">
                        Back to Login? Click <a href="<?php echo admin_url().'admin/login';?>">here</a>
                    </div>
					<?php } ?>
                    <?php echo form_close(); ?>	
</div>
<div class="copyright">
	 <?=date('Y')?> © Ten Realm.
</div>
<script src="<?php echo admin_source();?>plugins/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo admin_source();?>plugins/jquery-migrate.min.js" type="text/javascript"></script>
<script src="<?php echo admin_source();?>plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?php echo admin_source();?>plugins/jquery.blockui.min.js" type="text/javascript"></script>
<script src="<?php echo admin_source();?>plugins/uniform/jquery.uniform.min.js" type="text/javascript"></script>
<script src="<?php echo admin_source();?>plugins/jquery.cokie.min.js" type="text/javascript"></script>
<!-- END CORE PLUGINS -->
<!-- BEGIN PAGE LEVEL PLUGINS -->
<script src="<?php echo admin_source();?>plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
<!-- END PAGE LEVEL PLUGINS -->
<!-- BEGIN PAGE LEVEL SCRIPTS -->
<script src="<?php echo admin_source();?>scripts/metronic.js" type="text/javascript"></script>
<script src="<?php echo admin_source();?>layout4/scripts/layout.js" type="text/javascript"></script>
<script src="<?php echo admin_source();?>layout4/scripts/demo.js" type="text/javascript"></script>
<script src="<?php echo admin_source();?>pages/scripts/login.js" type="text/javascript"></script>
<link href="<?php echo admin_source(); ?>/css/patternLock.css"  rel="stylesheet" type="text/css" />
<script src="<?php echo admin_source(); ?>/js/patternLock.js"></script>
<!-- END PAGE LEVEL SCRIPTS -->
<script>
		$(document).ready(function() {
			// App.init();
			Login.init();
			Metronic.init(); // init metronic core components
Layout.init(); // init current layoutDemo.init();
		});
	</script>
    <script>
    $(document).ready(function() {
        
        $('#admin_login').validate({
            rules: {
                email: {
                    required: true
                },
                password: {
                    required: true
                },
            },
            highlight: function (element) {
                //$(element).parent().addClass('error')
            },
            unhighlight: function (element) {
                $(element).parent().removeClass('error')
            }
        });
    });
    </script>

	<script>
var lock = new PatternLock("#patternContainer",{
	 onDraw:function(pattern){
			word();
    }
});
function word()
{
	var pat=lock.getPattern();
	$("#patterncode").val(pat);
}

</script>

<!-- END JAVASCRIPTS -->
</body>
<!-- END BODY -->
</html>