<!-- begin #content -->
<div class="page-content-wrapper">
    <div class="page-content">
        <?php         
        $prefix = get_prefix();
        $error = $this->session->flashdata('error');
        if($error != '') {
            echo '<div class="note note-danger">
            <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$error.'</div>';
        }

        $success = $this->session->flashdata('success');
        if($success) {
            echo '<div class="note note-success">
            <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$success.'</div>';
        } 
        ?>
        <div class="page-head">
            <!-- begin page-header -->
            <div class="page-title">
                <h1>Manage Package</h1>
            </div>
            <!-- <div class="actions btn-set float-right">
                <a href="<?php //echo base_url('tenrealm_admin/package/add'); ?>" data-placement="top" data-toggle="popover" data-content="Add New Package" class="btn btn-success poper" data-original-title="" title="">Add New</a>
            </div> -->
        </div>

        <ul class="page-breadcrumb breadcrumb">
            <li>
                <a href="<?php echo admin_url();?>">Home</a>
                <i class="fa fa-circle"></i>
            </li>
            <li class="active"><a href="javascript:;">Manage Package</a></li>
        </ul>
        <!-- begin row -->
        <div class="row">
            <div class="col-md-12">
                <!-- begin panel -->
                <div class="portlet light">
                    <div class="portlet-title">
                        <div class="caption">
                            <span class="caption-subject bold uppercase font-green-haze">Manage Package</span>
                        </div>
                        <div class="tools">
                            <a href="javascript:;" class="collapse">
                            </a>
                            <a href="#portlet-config" data-toggle="modal" class="config">
                            </a>
                            <a href="javascript:;" class="reload">
                            </a>
                            <a href="javascript:;" class="fullscreen">
                            </a>
                            <a href="javascript:;" class="remove">
                            </a>
                        </div>
                    </div>

                    <div class="portlet-body">
                        <div class="clearfix">
                        </div>
                        <br/><br/>
                        <div class="table-responsive">
                            <table id="package-data" class="table table-striped table-bordered" id="view_all">
                                <thead>
                                    <tr>
                                        <th class="text-center">S.No</th>
                                        <th class="text-center">Package</th>
                                        <th class="text-center">Price</th>
                                        <th class="text-center">Direct Referral Segment</th>
                                        <!-- <th class="text-center">Farming Income</th> -->
                                        <th class="text-center">Team Level Segment</th>
                                        <th class="text-center">Autopool Segment</th>
                                        <th class="text-center">System Segment</th>
                                        <th class="text-center">Status</th>
                                        <th class="text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    if($package_data){

                                        foreach ($package_data as $pdkey => $pdvalue) {    
                                            // echo '<pre>';print_r($pdvalue);exit;
                                            $pdkey = $pdkey + 1;
                                            $row_values = '';
                                            $package_price = 0;
                                            $direct_refferal_price = ($pdvalue['income']) ? $pdvalue['income'] : 0;
                                            echo '<tr>';
                                            
                                            $id = $pdvalue['id'];
                                            
                                            $package_price = $pdvalue['income'] + $pdvalue['branch_income'] + $pdvalue['farming_income'] + $pdvalue['cultivation_income'] + $pdvalue['system_income'];
                                            

                                            if($pdvalue['package_name']){
                                                $row_values .= '<td>'. $pdkey.'</td>';
                                            }else{
                                                $row_values .= '<td></td>';
                                            }

                                            if($pdvalue['package_name']){
                                                $row_values .= '<td>'. $pdvalue['package_name'].'</td>';
                                            }else{
                                                $row_values .= '<td></td>';
                                            }

                                         

                                            if($package_price){
                                                $row_values .= '<td>'. $package_price.'</td>';
                                            }else{
                                                $row_values .= '<td>0</td>';
                                            }

                                            if($direct_refferal_price){
                                                $row_values .= '<td>'. $direct_refferal_price.'</td>';
                                            }else{
                                                $row_values .= '<td>0</td>';
                                            }


                                            // if($pdvalue['branch_income']){                                                    
                                            //     $row_values .= '<td><a href="'.admin_url().'package/branch_income/'.$id.'">'. $pdvalue['branch_income'] .'</a></td>';
                                            // }else{
                                            //     $row_values .= '<td><a href="'.admin_url().'package/branch_income/'.$id.'">0</a></td>';
                                            // }


                                            if($pdvalue['farming_income']){                                                    
                                                $row_values .= '<td><a href="'.admin_url().'package/global_farming_income/'.$id.'">'. $pdvalue['farming_income'] .'</a></td>';
                                            }else{
                                                $row_values .= '<td><a href="'.admin_url().'package/global_farming_income/'.$id.'">0</a></td>';
                                            }


                                            if($pdvalue['cultivation_income']){                                                    
                                                $row_values .= '<td><a href="'.admin_url().'package/global_cultivate_income/'.$id.'">'. $pdvalue['cultivation_income'] .'</a></td>';
                                            }else{
                                                $row_values .= '<td><a href="'.admin_url().'package/global_cultivate_income/'.$id.'">0</a></td>';
                                            }

                                            
                                            if($pdvalue['system_income']){
                                                $row_values .= '<td>'. $pdvalue['system_income'].'</td>';
                                            }else{
                                                $row_values .= '<td></td>';
                                            }


                                            if($pdvalue['status']){
                                                $row_values .= '<td><button type="button" class="btn btn-xs btn-success">Active</button></td>';
                                            }else{
                                                $row_values .= '<td><button type="button" class="btn btn-warning">Inactive</button></td>';
                                            }


                                            if($pdvalue['status']==1){
                                                $row_values .= '<td>';
                                                $row_values .= '<div class="btn-group"><a href="'.admin_url().'package/edit/'.$id .'"><i class="fa fa-pencil fa-1.5x"></i></a>';
                                                $row_values .= '<a href="javascript:;" class="lockme" id="'.$id.'"><i class="fa fa-lock fa-1.5x"></i></a></div>';
                                                $row_values .= '</td>';
                                            }else{
                                                $row_values .= '<td><a href="javascript:;" class="unlockme"  id="'.$id.'"><i class="fa fa-unlock fa-1.5x"></i></a></td>';
                                            }                                            

                                            echo $row_values;                                                
                                            echo '</tr>';
                                        }                                            
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>                    
                </div>
                <!-- end panel -->
            </div>
        </div>
        <!-- end row -->
    </div>

</div>
<!-- end #content -->
<!-- ================== BEGIN BASE JS ================== -->
<script src="<?php echo admin_source();?>/plugins/jquery/jquery-1.9.1.min.js"></script>
<script src="<?php echo admin_source();?>/js/apps.min.js"></script>
<!-- ================== END PAGE LEVEL JS ================== -->
<script>
    $(document).ready(function() {
        App.init();
    });
</script>
<script>     
    var admin_url='<?php echo admin_url(); ?>';    
    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';
    var csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
    $(document).ready(function() {

        $('#package-data').DataTable( {
            "responsive" : true,
            "processing" : true,
            // "pageLength" : 10,
            "order": [[0, "asc" ]],
            "searching": true,
            // "ajax": admin_url+"users/kyc_ajax"
        });


        $(document).on('click', '.lockme, .unlockme', function(){
            var _this = $(this);
            var lockId = _this.attr('id');    
            if(_this.hasClass('lockme')){
                var status = 0;
            }else{
                var status = 1;
            }      

            if (typeof(lockId) != 'undefined' && lockId != null) {                
                $.ajax({
                    url: admin_url + 'package/status',
                    type: 'POST',                    
                    data: {[csrfName]: csrfHash, status:status, id:lockId },                    
                    // data: {[csrfName]: csrfHash, status:status },                    
                    dataType: 'json',
                    success: function(result) {   
                       if (typeof(result) != 'undefined' && result != null && result.status == 'true') {         
                        window.location.reload(1);
                    }
                },
                error: jqueryErrorHandling,
            });                
            }
        });

    });



    function jqueryErrorHandling(xhr, status, exception) {
        var responseText;
        $("#dialog").html("");
        try {
            responseText = jQuery.parseJSON(xhr.statusText);
            $("#dialog").append("<div><b>" + status + " " + exception + "</b></div>");
            $("#dialog").append("<div><u>Exception</u>:<br /><br />" + responseText.ExceptionType + "</div>");
            $("#dialog").append("<div><u>StackTrace</u>:<br /><br />" + responseText.StackTrace + "</div>");
            $("#dialog").append("<div><u>Message</u>:<br /><br />" + responseText.Message + "</div>");
        } catch (e) {
            var errorMessage = xhr.statusText;
            $("#dialog").html(errorMessage);
            $("#dialog").dialog({
                title: "Exception Details",
                autoOpen: true,
                modal: true,
                width: 700,
                buttons: {
                    Close: function() {
                        $(this).dialog('close');
                    }
                }
            });
        }
    }
</script>

<style>
    .u_img{width:125px; height:125px; overflow:hidden; display:inline-block; float:left;}
    .u_img img{   height: auto;
        max-height: 100%;
        width: 100%;
    }
</style>