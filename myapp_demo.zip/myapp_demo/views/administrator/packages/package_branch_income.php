<?php 
$method = $this->router->fetch_method();

?>
<!-- begin #content -->
<div class="page-content-wrapper">
  <div class="page-content">
    <?php         
    $prefix = get_prefix();
    $error = $this->session->flashdata('error');
    if($error != '') {
      echo '<div class="note note-danger">
      <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$error.'</div>';
    }

    $success = $this->session->flashdata('success');
    if($success) {
      echo '<div class="note note-success">
      <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$success.'</div>';
    } 
    ?>
    <div class="page-head">
      <!-- begin page-header -->
      <div class="page-title">
        <h1>Branch Income Chart</h1>
      </div>
    </div>
    <ul class="page-breadcrumb breadcrumb">
      <li>
        <a href="<?php echo admin_url();?>">Home</a>
        <i class="fa fa-circle"></i>
      </li>
      <li>
        <a href="<?php echo admin_url().'package'; ?>">Manage Package</a>
        <i class="fa fa-circle"></i>
      </li>
      <li class="active"><a href="javascript:;"> Branch Income Chart</a></li>
    </ul>
    <!-- begin row -->
    <div class="row">
      <div class="col-md-12">
        <!-- begin panel -->
        <div class="portlet light">
          <div class="portlet-title">
            <div class="caption">
              <span class="caption-subject bold uppercase font-green-haze">Branch Income Chart</span>
            </div>
            <div class="tools">
              <a href="javascript:;" class="collapse">
              </a>
              <a href="#portlet-config" data-toggle="modal" class="config">
              </a>
              <a href="javascript:;" class="reload">
              </a>
              <a href="javascript:;" class="fullscreen">
              </a>
              <a href="javascript:;" class="remove">
              </a>
            </div>
          </div>

          <div class="portlet-body">
            <div class="clearfix">
            </div>
            <br/><br/>
            <div class="table-responsive">

              <div class="panel-body">
                <?php
                if(validation_errors()){
                  $error =  validation_errors();
                  echo '<div class="note note-danger">
                  <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$error.'</div>';
                }
                $action = '';
                $attributes=array('class'=>'form-horizontal','id'=>'package');
                echo form_open($action,$attributes);
                ?>
                <fieldset>
                  <div class="form-group">
                    <label class="col-md-4 control-label">Level 1 <em class="star">*</em></label>
                    <div class="col-md-4">

                      <div class="input-group">
                        <span class="input-group-addon">$</span>
                        <input type="text" autofocus name="income_l1" id="income_l1" class="form-control" value="<?php 
                        if($package_data['income_l1']){
                          echo $package_data['income_l1'];
                          }else if(set_value('income_l1')){
                            echo set_value('income_l1');
                          } ?>" />
                        </div>


                      </div>
                    </div>

                    <div class="form-group">
                      <label class="col-md-4 control-label">Level 2 <em class="star">*</em></label>
                      <div class="col-md-4"><div class="input-group">
                        <span class="input-group-addon">$</span>
                        <input type="text" name="income_l2" id="income_l2" class="form-control" value="<?php 
                        if($package_data['income_l2']){
                          echo $package_data['income_l2'];
                          }else if(set_value('income_l2')){
                            echo set_value('income_l2');
                          } ?>" />
                        </div>
                      </div>
                    </div>



                    <div class="form-group">
                      <label class="col-md-4 control-label">Level 3 <em class="star">*</em></label>
                      <div class="col-md-4">
                        <div class="input-group">
                          <span class="input-group-addon">$</span>
                          <input type="text" name="income_l3" id="income_l3" class="form-control" value="<?php 
                          if($package_data['income_l3']){
                            echo $package_data['income_l3'];
                            }else if(set_value('income_l3')){
                              echo set_value('income_l3');
                            } ?>" />
                          </div>
                        </div>
                      </div>


                      <div class="form-group">
                        <label class="col-md-4 control-label">Level 4 <em class="star">*</em></label>
                        <div class="col-md-4">
                          <div class="input-group">
                            <span class="input-group-addon">$</span>
                            <input type="text" name="income_l4" id="income_l4" class="form-control" value="<?php 
                            if($package_data['income_l4']){
                              echo $package_data['income_l4'];
                              }else if(set_value('income_l4')){
                                echo set_value('income_l4');
                              } ?>" />
                            </div>
                          </div>
                        </div>


                                <div class="form-group">
                                  <div class="col-md-12">
                                    <!-- <button type="submit" class="btn green btn-submit float-right ">Submit</button> -->
                                    <button type="button" class="btn btn-default float-left cancel">Back</button>                      
                                  </div>
                                </div>
                              </fieldset>
                              <?php echo form_close(); ?>
                            </div>
                          </div>
                        </div>                    
                      </div>
                      <!-- end panel -->
                    </div>
                  </div>
                  <!-- end row -->
                </div>
                
              </div>


<script src="<?php echo admin_source();?>/plugins/jquery/jquery-1.9.1.min.js"></script>
<script src="<?php echo admin_source();?>/js/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>

<script type="text/javascript">
 var admin_url='<?php echo admin_url(); ?>';    
 var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';
 var csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
 $(document).ready(function() {


  $.validator.addMethod("greaterThan",
    function (value, element, param) {
      var $otherElement = $(param);
      return parseInt(value, 10) > parseInt($otherElement.val(), 10);
    });

  $(document).on('click','.cancel', function(){
    window.location.href= admin_url + 'package';
  });


$('#package').validate({ // initialize the plugin
  rules: {
    income_l1: {
      required: true,
    // maxlength: 255  
    number:true        
  },
  income_l2: {
    required: true,      
    number:true
  }, 
  income_l3: {
    required: true,      
    number:true
  }, 
  income_l4: {
    required: true,      
    number:true
  }, 
  income_l5: {
    required: true,      
    number:true
  },
  income_l6: {
    required: true,      
    number:true
  },
  income_l7: {
    required: true,      
    number:true
  },
  income_l8: {
    required: true,      
    number:true
  }

},
messages: {
  income_l1:
  {   
    number:"Please enter numbers Only"
  },
  income_l2:
  {
    number:"Please enter numbers Only"
  },
  income_l3:
  {
    number:"Please enter numbers Only"
  },
  income_l4:
  {
    number:"Please enter numbers Only"
  },
  income_l5:
  {
    number:"Please enter numbers Only"
  },
  income_l6:
  {
    number:"Please enter numbers Only"
  },
  income_l7:
  {
    number:"Please enter numbers Only"
  },
  income_l8:
  {
    number:"Please enter numbers Only"
  }
}

});
});
</script>