<?php 
$method = $this->router->fetch_method();
$class = $this->router->fetch_class();
?>
<style>
.fa-gift {
	color: #f44336 !important;
}	
</style>
<!-- BEGIN SIDEBAR -->
<div class="page-sidebar-wrapper">
	<div class="page-sidebar navbar-collapse collapse">
		<ul class="page-sidebar-menu " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200">
			<li class="start <?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/admin/dashboard')) { echo 'active'; } ?> ">
				<a href="<?php echo admin_url();?>admin/dashboard">
					<i class="icon-home"></i>
					<span class="title">Dashboard</span>
				</a>
			</li>
			<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/admin/site_settings') || strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/email_list') || strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/email_template') || strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/admin/asset_list')) { echo 'active'; } ?>">
				<a href="javascript:;">
					<i class="icon-settings"></i>
					<span class="title">Settings</span>
					<span class="arrow "></span>
				</a>
				<ul class="sub-menu">
					<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/admin/site_settings')) { echo 'active';}?>">
						<a href="<?php echo admin_url();?>admin/site_settings">
							<i class="icon-directions"></i>
						Site Settings</a>
					</li>
					<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/email_template')) { echo 'active';}?>">
						<a href="<?php echo admin_url();?>email_template">
							<i class="icon-envelope-open"></i>
						Email Template</a>
					</li>
				</ul>
			</li>

			<li class="<?php if($class == 'package' && ( $method == 'index' || $method == 'add')){echo 'active';} ?>">
				<a href="javascript:;">
					<i class="fa fa-gift"></i>
					<span class="title">Package</span>
					<span class="arrow "></span>
				</a>
				<ul class="sub-menu">
					<li class="<?php if($class == 'package' && ( $method == 'index')){echo 'active';} ?>">
						<a href="<?php echo admin_url().'package';?>">
							<i class="icon-action-redo"></i>
						Manage Package</a>
					</li>
					<li class="<?php if($class == 'package' && ( $method == 'add')){echo 'active';} ?>">
						<a href="<?php echo admin_url();?>package/add">
							<i class="icon-action-redo"></i>
						Add Package</a>
					</li>						
				</ul>
			</li>


			<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/users/payment')) { echo ''; } else if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/users')) { echo 'active'; } ?>">
				<a href="javascript:;">
					<i class="icon-users"></i>
					<span class="title">Users</span>
					<span class="arrow "></span>
				</a>
				<ul class="sub-menu">
					<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/users/verification')) { echo ''; } 
					else if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/users/unverified_users')) { echo ''; }
					else if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/users/payment')) { echo ''; }
					else if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/users/subscribe')) { echo ''; }
					else if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/users/company_verification')) { echo ''; }  
					else if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/users')) { echo 'active'; } ?>">
					<a href="<?php echo admin_url();?>users">
						<i class="icon-action-redo"></i>
					Activated Users</a>
				</li>
				<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/users/unverified_users')) { echo 'active'; } ?>">
					<a href="<?php echo admin_url();?>users/unverified_users">
						<i class="icon-action-redo"></i>
					Unverified Users</a>
				</li>
				<!-- <li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/users/verification')) { echo 'active'; } ?>">
					<a href="<?php echo admin_url();?>users/verification">
						<i class="icon-user-follow"></i>
					KYC User Verification</a>
				</li> -->
			</ul>
		</li>

			<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/withdraw')) { echo 'active'; } ?>">
			<a href="javascript:;">
				<i class="icon-globe"></i>
				<span class="title">Segment Mgmt</span>
				<span class="arrow "></span>
			</a>
			<ul class="sub-menu">
				<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/income/level')) { echo 'active'; } ?>">
					<a href="<?php echo admin_url();?>income/level">
						<i class="icon-action-redo"></i>
					Level</a>
				</li>
				<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/income/x2_profit')) { echo 'active'; } ?>">
					<a href="javascript:;">
						<i class="icon-action-redo"></i>
						<span class="title">Global</span>
						<span class="arrow "></span>
					</a>
					<ul class="sub-menu">
						<!-- <li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/income/x2_profit')) { echo 'active'; } ?>">
						 	<a href="javascript:;">
								<i class="icon-action-redo"></i>
								<span class="title">2X</span>
								<span class="arrow"></span>
							</a> 
							<ul class="sub-menu">
								<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/income/x2_profit')) { echo 'active'; } ?>">
									<a href="<?php echo admin_url();?>income/x2_profit">
										<i class="icon-action-redo"></i> Profit </a>
								</li>
								<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/income/x2_sponsor')) { echo 'active'; } ?>">
									<a href="<?php echo admin_url();?>income/x2_sponsor">
										<i class="icon-action-redo"></i> Sponsor </a>
								</li>
								<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/income/auto_upgrade')) { echo 'active'; } ?>">
									<a href="<?php echo admin_url();?>income/auto_upgrade">
										<i class="icon-action-redo"></i> Auto Upgrade </a>
								</li>
							</ul>
						</li> -->
						<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/income/x4_profit')) { echo 'active'; } ?>">
							<a href="javascript:;">
								<i class="icon-action-redo"></i>
								<span class="title">4X</span>
								<span class="arrow"></span>
							</a>
							<ul class="sub-menu">
								<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/income/x4_profit')) { echo 'active'; } ?>">
									<a href="<?php echo admin_url();?>income/x4_profit">
										<i class="icon-action-redo"></i> Profit </a>
								</li>
								<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/income/x4_sponsor')) { echo 'active'; } ?>">
									<a href="<?php echo admin_url();?>income/x4_sponsor">
										<i class="icon-action-redo"></i> Sponsor </a>
								</li>
							</ul>
						</li>
					</ul>

				</li>
				<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/income/system_income')) { echo 'active'; } ?>">
					<a href="<?php echo admin_url();?>income/system_income">
						<i class="icon-action-redo"></i>
					Admin Revenue</a>
				</li>
			</ul>
		</li>

		<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/wallet')) { echo 'active'; } ?>">
			<a href="javascript:;">
				<i class="icon-wallet"></i>
				<span class="title">Wallet Management</span>
				<span class="arrow "></span>
			</a>
			<ul class="sub-menu">
				<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/wallet')) { echo ''; }elseif(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/wallet/')) { echo 'active'; } ?>">
					<a href="<?php echo admin_url();?>wallet">
						<i class="icon-action-redo"></i>
					Users Wallet</a>
				</li> 
				<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/admin_wallet')) { echo 'active'; } ?>">
					<a href="<?php echo admin_url();?>admin_wallet">
						<i class="icon-action-redo"></i>
					Admin Wallet</a>
				</li>

			</ul>
		</li>


		<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/currency')) { echo 'active'; }elseif(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/coin_request')) { echo 'active'; } ?>">
			<a href="<?php echo admin_url();?>currency">
				<i class="icon-credit-card"></i>
				<span class="title">Currency</span>
			</a>
		</li>

		<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/deposit')) { echo 'active'; } ?>">
			<a href="javascript:;">
				<i class="icon-credit-card"></i>
				<span class="title">Deposit</span>
				<span class="arrow "></span>
			</a>
			<ul class="sub-menu">
				<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/deposit/crypto_deposit')) { echo 'active'; } ?>">
					<a href="<?php echo admin_url();?>deposit/crypto_deposit">
						<i class="icon-action-redo"></i>
					Crypto Deposit</a>
				</li>

			</ul>
		</li>
		<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/withdraw')) { echo 'active'; } ?>">
			<a href="javascript:;">
				<i class="icon-credit-card"></i>
				<span class="title">Withdraw</span>
				<span class="arrow "></span>
			</a>
			<ul class="sub-menu">
				<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/withdraw/crypto_withdraw')) { echo 'active'; } ?>">
					<a href="<?php echo admin_url();?>withdraw/crypto_withdraw">
						<i class="icon-action-redo"></i>
					Crypto Withdraw</a>
				</li>
			</ul>
		</li>
	
		<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/transfer')) { echo 'active'; }elseif(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/transfer')) { echo 'active'; } ?>">
			<a href="<?php echo admin_url();?>transfer">
				<i class="icon-credit-card"></i>
				<span class="title">Transfer</span>
			</a>
		</li>

		<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/withdraw')) { echo 'active'; } ?>">
			<a href="javascript:;">
				<i class="icon-cloud-download"></i>
				<span class="title">Profit</span>
				<span class="arrow "></span>
			</a>
			<ul class="sub-menu">
				<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/admin/coin_profit')) { echo 'active'; } ?>">
					<a href="<?php echo admin_url();?>admin/coin_profit">
						<i class="icon-action-redo"></i>
					Coin Profit</a>
				</li>

			</ul>
		</li>


		<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/contact')) { echo 'active'; } ?>">
			<a href="<?php echo admin_url();?>contact">
				<i class="icon-call-end"></i>
				<span class="title">Contact Us</span>
			</a>
		</li>
		<!-- <li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/support')) { echo 'active'; } ?>">
			<a href="<?php echo admin_url();?>support">
				<i class="icon-support"></i>
				<span class="title">Support</span>
			</a>
		</li> -->

		<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/faq')) { echo 'active'; } elseif(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/news')) { echo 'active'; }elseif(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/cms')) { echo 'active'; }elseif(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/static_content')) { echo 'active'; } elseif(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/meta_content')) { echo 'active'; } elseif(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/partners')) { echo 'active'; }?>">
			<a href="javascript:;">
				<i class="icon-docs"></i>
				<span class="title">Content Management</span>
				<span class="arrow "></span>
			</a>
			<ul class="sub-menu">
				<!-- <li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/faq/add')){ echo ''; } elseif(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/faq')) { echo 'active'; } ?>">
					<a href="<?php echo admin_url();?>faq">
						<i class="icon-action-redo"></i>
					Faq</a>
				</li>
				<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/faq/add')) { echo 'active'; } ?>">
					<a href="<?php echo admin_url();?>faq/add">
						<i class="icon-action-redo"></i>
					Add Faq</a>
				</li> -->
				<!-- <li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/cms')) { echo 'active'; } ?>">
					<a href="<?php echo admin_url();?>cms">
						<i class="icon-action-redo"></i>
					CMS Management</a>
				</li> -->
				<!-- <li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/static_content')) { echo 'active'; } ?>">
					<a href="<?php echo admin_url();?>static_content">
						<i class="icon-action-redo"></i>
					Static Content</a>
				</li> -->
				<li class="<?php if(strpos($_SERVER['REQUEST_URI'],'tenrealm_admin/meta_content')) { echo 'active'; } ?>">
					<a href="<?php echo admin_url();?>meta_content">
						<i class="icon-action-redo"></i>
					Meta Content</a>
				</li>

			</ul>
		</li>

		<li class="last <?php if(strpos($_SERVER['REQUEST_URI'],'admin/logout')) { echo 'active'; } ?>">
			<a href="<?php echo admin_url();?>admin/logout">
				<i class="icon-logout"></i>
				<span class="title">Logout</span>
			</a>
		</li>
	</ul>
	<!-- END SIDEBAR MENU -->
</div>
</div>