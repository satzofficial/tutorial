<!DOCTYPE html>
<html lang="en" class="no-js">
<?php $tt = $this->uri->segment_array();
$page_name = $tt[2];
$prefix = get_prefix();
$site_common = site_common();
$favicon = $site_common['site_settings']->site_favicon;
$sitelogo = $site_common['site_settings']->site_logo;
?>
<head>
	<meta charset="utf-8"/>
	<title><?php echo $title; ?></title>
	<link rel="shortcut icon" href="<?php echo $favicon;?>"/>

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1" name="viewport"/>
	<meta name="keywords" content="<?php echo $meta_keywords; ?>">
	<meta name="description" content="<?php echo $meta_description; ?>">
	<!-- BEGIN GLOBAL MANDATORY STYLES -->
	<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css"/>
	<link href="<?php echo admin_source();?>plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
	<link href="<?php echo admin_source();?>plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css"/>
	<link href="<?php echo admin_source();?>plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
	<link href="<?php echo admin_source();?>plugins/uniform/css/uniform.default.css" rel="stylesheet" type="text/css"/>
	<link href="<?php echo admin_source();?>plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css"/>
	<!-- END GLOBAL MANDATORY STYLES -->
	<!-- BEGIN PAGE LEVEL PLUGIN STYLES -->
	<link href="<?php echo admin_source();?>plugins/bootstrap-daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css"/>
	<link href="<?php echo admin_source();?>plugins/fullcalendar/fullcalendar.min.css" rel="stylesheet" type="text/css"/>
	<link href="<?php echo admin_source();?>plugins/jqvmap/jqvmap/jqvmap.css" rel="stylesheet" type="text/css"/>
	<link href="<?php echo admin_source();?>plugins/morris/morris.css" rel="stylesheet" type="text/css">
	<!-- END PAGE LEVEL PLUGIN STYLES -->
	<!-- BEGIN PAGE STYLES -->
	<link href="<?php echo admin_source();?>pages/css/tasks.css" rel="stylesheet" type="text/css"/>
	<!-- END PAGE STYLES -->

	<link rel="stylesheet" type="text/css" href="<?php echo admin_source();?>plugins/datatables/plugins/bootstrap/dataTables.bootstrap.css"/>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/css/bootstrap-select.min.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@8.17.1/dist/sweetalert2.min.css">
	<!-- <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8.17.1/dist/sweetalert2.all.min.js"></script> -->

	<!-- BEGIN THEME STYLES -->
	<!-- DOC: To use 'rounded corners' style just load 'components-rounded.css' stylesheet instead of 'components.css' in the below style tag -->
	<link href="<?php echo admin_source();?>css/components-rounded.css" id="style_components" rel="stylesheet" type="text/css"/>
	<link href="<?php echo admin_source();?>css/plugins.css" rel="stylesheet" type="text/css"/>
	<link href="<?php echo admin_source();?>layout4/css/layout.css" rel="stylesheet" type="text/css"/>
	<link href="<?php echo admin_source();?>layout4/css/themes/light.css" rel="stylesheet" type="text/css" id="style_color"/>
	<link href="<?php echo admin_source();?>layout4/css/custom.css" rel="stylesheet" type="text/css"/>
	<!-- END THEME STYLES -->
	<style type="text/css">
		.error, .star{
			color:red;
		}
		a+a {
			margin-left: 10px;
		}
	</style>
</head>

<body class="page-header-fixed page-sidebar-closed-hide-logo page-sidebar-fixed page-sidebar-closed-hide-logo">
	<?php 
	$admin = getAdminDetails($this->session->userdata('loggeduser')); 
	$aid = $this->session->userdata('loggeduser');
	?>
	<!-- BEGIN HEADER -->
	<div class="page-header navbar navbar-fixed-top">
		<!-- BEGIN HEADER INNER -->
		<div class="page-header-inner">
			<!-- BEGIN LOGO -->
			<div class="page-logo">
				<a href="<?php echo admin_url();?>">
					<img src="<?php echo getSiteLogo();?>" width="60" alt="logo" class="logo-default"/>
				</a>
				<div class="menu-toggler sidebar-toggler">
					<!-- DOC: Remove the above "hide" to enable the sidebar toggler button on header -->
				</div>
			</div>
			<!-- END LOGO -->
			<!-- BEGIN RESPONSIVE MENU TOGGLER -->
			<a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse">
			</a>
			<!-- END PAGE ACTIONS -->
			<div class="page-top" style="position: absolute; right: 150px; top: 0px; line-height: 77px;">
				<!-- 	<label>LTC: <?php //echo coin_price_conversion('LTC','USD'); ?> </label> -->
			</div>
			<!-- BEGIN PAGE TOP -->
			<div class="page-top">
				<!-- END HEADER SEARCH BOX -->
				<!-- BEGIN TOP NAVIGATION MENU -->
				<div class="top-menu">
					<ul class="nav navbar-nav pull-right">
						<li class="separator hide">
						</li>
						<!-- BEGIN NOTIFICATION DROPDOWN -->
						<!-- DOC: Apply "dropdown-dark" class after below "dropdown-extended" to change the dropdown styte -->
						<?php $this->load->view('administrator/common/kyc_pending_list'); ?>
						<!-- END NOTIFICATION DROPDOWN -->
						<li class="separator hide">
						</li>
						<!-- BEGIN INBOX DROPDOWN -->

						<!-- END INBOX DROPDOWN -->
						<li class="separator hide">
						</li>
						<!-- BEGIN TODO DROPDOWN -->

						<!-- BEGIN USER LOGIN DROPDOWN -->
						<!-- DOC: Apply "dropdown-dark" class after below "dropdown-extended" to change the dropdown styte -->
						<li class="dropdown dropdown-user dropdown-dark">
							<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
								<span class="username username-hide-on-mobile">
									<?php echo $admin->admin_name; ?> </span>
									<!-- DOC: Do not remove below empty space(&nbsp;) as its purposely used -->
									<img alt="" class="img-circle" src="<?php echo admin_source();?>layout4/img/avatar.png"/>
								</a>

								<?php if($aid=='1') { ?>
									<ul class="dropdown-menu dropdown-menu-default">
										<li>
											<a href="<?php echo admin_url();?>admin/site_settings">
												<i class="icon-user"></i>Site Setting </a>
											</li>
											<li>
												<a href="<?php echo admin_url();?>admin/change_password">
													<i class="icon-calendar"></i> Change Password </a>
												</li>
												<li>
													<a href="<?php echo admin_url();?>admin/login_history">
														<i class="icon-envelope-open"></i> Admin Login History </a>
													</li>

													<li class="divider">
													</li>
													<li>
														<a href="<?php echo admin_url().'admin/logout';?>">
															<i class="icon-key"></i> Log Out </a>
														</li>
													</ul>
												<?php } ?>
											</li>
											<!-- END USER LOGIN DROPDOWN -->
										</ul>
									</div>
									<!-- END TOP NAVIGATION MENU -->
								</div>
								<!-- END PAGE TOP -->
							</div>
							<!-- END HEADER INNER -->
						</div>
						<!-- END HEADER -->
						<div class="clearfix">
						</div>
						<!-- BEGIN CONTAINER -->
						<div class="page-container">
							<?php include_once 'include/sidebar.php'; ?>

							<!-- START CONTAINER -->
							<?php $this->load->view('administrator/'.$main_content);?>		
							<!-- END CONTAINER -->
							<!-- BEGIN FOOTER -->
							<div class="page-footer">
								<div class="page-footer-inner">
									<?=date('Y')?> &copy; copyright by Ten Realm
								</div>
								<div class="scroll-to-top">
									<i class="icon-arrow-up"></i>
								</div>
							</div>
							<!-- END FOOTER -->
						</div>

<!--[if lt IE 9]>
<script src="<?php echo admin_source();?>plugins/respond.min.js"></script>
<script src="<?php echo admin_source();?>plugins/excanvas.min.js"></script> 
<![endif]-->
<script src="<?php echo admin_source();?>plugins/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo admin_source();?>js/jquery.validate.min.js"></script>

<script src="<?php echo admin_source();?>plugins/jquery-migrate.min.js" type="text/javascript"></script>
<!-- IMPORTANT! Load jquery-ui.min.js before bootstrap.min.js to fix bootstrap tooltip conflict with jquery ui tooltip -->
<script src="<?php echo admin_source();?>plugins/jquery-ui/jquery-ui.min.js" type="text/javascript"></script>
<script src="<?php echo admin_source();?>plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?php echo admin_source();?>plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js" type="text/javascript"></script>
<script src="<?php echo admin_source();?>plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>

<!-- END CORE PLUGINS -->

<!-- BEGIN PAGE LEVEL SCRIPTS -->
<script src="<?php echo admin_source();?>scripts/metronic.js" type="text/javascript"></script>
<script src="<?php echo admin_source();?>layout4/scripts/layout.js" type="text/javascript"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script> -->

<script src="<?php echo base_url('assets/admin/plugins/DataTables/js/jquery.dataTables.min.js');?>"></script>

<script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap4.min.js"></script>
<!-- END PAGE LEVEL SCRIPTS -->
<script>

jQuery(document).ready(function() {
Metronic.init(); // init metronic core componets
Layout.init(); // init layout
$('div.note .close').on('click', function() {
	$(this).parent().remove(); 
});

	$("#currency_type").on("change",function(){
		var selected = $(this).val();
		console.log(selected);
		if(selected=='fiat'){
			$('#payment_type_section').show();
		}else{
			$('#payment_type_section').hide();
		}
	})
});
	function deleteaction(link)
	{
		Swal.fire({
			title: 'Are you sure?',
			text: "You won't be able to revert this!",
			icon: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes, delete it!'
		}).then((result) => {
			if (result.value) { 
				window.location.href=link;
			}
		})
	}

	var base_url='<?php echo base_url();?>';
	var front_url='<?php echo front_url();?>';
	var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';
	$(document).ready(function() {
		$.ajaxPrefilter(function (options, originalOptions, jqXHR) {
			if (options.type.toLowerCase() == 'post') {
				options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
				if (options.data.charAt(0) == '&') {
					options.data = options.data.substr(1);
				}
			}
		});
		$( document ).ajaxComplete(function( event, xhr, settings ) {
			var n = settings.url.includes("get_csrf_token"); 
			if (!n) {
				$.ajax({
					url: front_url+"get_csrf_token", 
					type: "GET",
					cache: false,             
					processData: false,      
					success: function(data) {
						$("input[name="+csrfName+"]").val(data);
					}
				});
			}
		});
	});
</script>
<!-- END JAVASCRIPTS -->
</body>
<!-- END BODY -->
</html>