<?php
/**
 * Users class
 * @package Spiegel Technologies
 * @subpackage ixtokens
 * @category Controllers
 * @author Pilaventhiran
 * @version 1.0
 * @link http://spiegeltechnologies.com/
 * 
 */
 class Transfer extends CI_Controller {
 	public function __construct() {
 		parent::__construct();
		$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
		$this->output->set_header("Pragma: no-cache");
		$this->load->library(array('form_validation', 'upload'));
		$this->load->helper(array('url', 'language', 'text'));
		
 	}
 	public function block()
	{
		$cip = get_client_ip();
		$match_ip = $this->common_model->getTableData('page_handling',array('ip'=>$cip))->row();
		if($match_ip > 0)
		{
		return 1;
		}
		else
		{
		return 0;
		}
	}

	public function block_ip()
	{
		$this->load->view('front/common/blockips');
	}

	function transfer_ajax()
	{
		$tt=0;
		$sessionvar=$this->session->userdata('loggeduser');
		if (!$sessionvar) {
			admin_redirect('admin', 'refresh');
		}

		$draw = $this->input->get('draw');
		$start = intval($this->input->get("start"));
        $length = intval($this->input->get("length"));
        $order = $this->input->get("order");
        $search= $this->input->get("search");
        $search = $search['value'];
        $encrypt_search = encryptIt($search);
        $col = 0;
        $dir = "";
        if(!empty($order))
        {
            foreach($order as $o)
            {
                $col = $o['column'];
                $dir= $o['dir'];
            }
        }

        if($dir != "asc" && $dir != "desc")
        {
            $dir = "desc";
        }

        $valid_columns = array(
            0=>'id',
            1=>'local_transaction_id',
            1=>'bonus_from',
            2=>'user_id',
            3=>'price',
            4=>'timestamp'
        );
        if(!isset($valid_columns[$col]))
        {
            $order = null;
        }
        else
        {
            $order = $valid_columns[$col];
        }
        if($order !=null)
        {
            //$this->db->order_by($order, $dir);
        }
        $like = '';
        if(!empty($search))
        { 
            $like = array(
            	"local_transaction_id"=>$search); 
        }
  
        $orderBy=array('id','DESC');
        $get = $this->common_model->getTableData('wallet_transfer','','id,send_fname,sender_id,receiver_id,receive_fname,amount,local_transaction_id,type,timestamp','',$like,'',$start,$length,$orderBy,'','','')->result();
        // echo $this->db->last_query();die;
        $num_rows = count($this->common_model->getTableData('wallet_transfer')->result());
		// echo '<PRE>';print_r($num_rows);die;

		if(count($get)>0)
		{		
			$i = 0;
			foreach($get as $res){
				$i++;
				$data[] = array(
					    $i,
                        $res->local_transaction_id, 
					    $res->send_fname,
						$res->receive_fname,
						$res->amount,
						$res->type,
						date('d-m-Y h:i a',$res->timestamp)
					);
			}
		}
		else
		{
			$data = array();
		}
	
		$output = array(
            "draw" => $draw,
            "recordsTotal" => $num_rows,
            "recordsFiltered" => $num_rows,
            "data" => $data,
            "query"=> $tt
        );
		echo json_encode($output);	 
	}




 	function index() 
 	{
		// Is logged in
	$sessionvar=$this->session->userdata('loggeduser');
	if (!$sessionvar) {
		admin_redirect('admin', 'refresh');
	}
	
	   	$data['prefix'] = get_prefix();
		$data['view'] = 'list';
		$data['title'] = 'Transfer Management';
		$data['meta_keywords'] = 'Transfer Management';
		$data['meta_description'] = 'Transfer Management';
		$data['main_content'] = 'transfer/transfer';
		$this->load->view('administrator/admin_template', $data); 
	}


 }
 
