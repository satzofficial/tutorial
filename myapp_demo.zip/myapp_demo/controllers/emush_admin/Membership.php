<?php
/**
 * Pair class
 * @package Spiegel Technologies
 * @subpackage ixtokens
 * @author Pilaventhiran
 * @version 1.0
 * @link http://spiegeltechnologies.com/
 *
 */
 class Membership extends CI_Controller {
 	public function __construct() {
 		parent::__construct();
		$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
		$this->output->set_header("Pragma: no-cache");
		$this->load->library(array('form_validation', 'upload'));
		$this->load->helper(array('url', 'language', 'text'));
 	}
 	//list
	function index()
	{
		$sessionvar=$this->session->userdata('loggeduser');
		if (!$sessionvar) {
			admin_redirect('admin', 'refresh');
		}
		$data['membership'] = $this->common_model->getTableData('membership','','','');
		$data['title'] = 'membership Management';
		$data['meta_keywords'] = 'membership Management';
		$data['meta_description'] = 'membership Management';
		$data['main_content'] = 'membership/membership';
		$data['view'] = 'view_all';
		// print_r($data['membership']);die;
		$this->load->view('administrator/admin_template', $data);
	}
	//create
	function add()
	{
		$sessionvar=$this->session->userdata('loggeduser');
		if (!$sessionvar) {
			admin_redirect('admin', 'refresh');
		}
		if ($this->input->post())
		{
			$lang_id= $this->input->post('lang');
			$insertData=array();
			
			$insertData['plan_name'] = $this->input->post('plan_name');
			$insertData['plan_price'] = $this->input->post('plan_price');
			$insertData['plan_duration'] = $this->input->post('plan_duration');
			$insertData['description'] = $this->input->post('description');
			
			$insertData['status'] = $this->input->post('add_status');
			$insert = $this->common_model->insertTableData('membership', $insertData);
			if ($insert) {
				$this->session->set_flashdata('success', 'membership has been added successfully!');
				admin_redirect('membership', 'refresh');
			} else {
				$this->session->set_flashdata('error', 'Unable to add the new membership !');
				admin_redirect('membership/add', 'refresh');
			}
		}
		$data['action'] = admin_url().'membership/add';
		$data['title'] = 'Add membership';
		$data['meta_keywords'] = 'Add membership';
		$data['meta_description'] = 'Add membership';
		$data['main_content'] = 'membership/membership';
		$data['view'] = 'add';
		$this->load->view('administrator/admin_template', $data);
	}
	// Edit page
	function edit($id)
	{
		$sessionvar=$this->session->userdata('loggeduser');
		if (!$sessionvar)
		{
			admin_redirect('admin', 'refresh');
		}
		if ($id == '')
		{
			$this->session->set_flashdata('error', 'Invalid request');
			admin_redirect('membership');
		}
		$isValid = $this->common_model->getTableData('membership', array('id' => $id));
		if ($isValid->num_rows() == 0)
		{
			$this->session->set_flashdata('error', 'Unable to find this page');
			admin_redirect('membership');
		}
		if ($this->input->post())
		{
			$condition = array('id' => $id);
			$lang_id= $this->input->post('lang');
			$updateData=array();
			
			$updateData['plan_name'] = $this->input->post('plan_name');
			$updateData['plan_price'] = $this->input->post('plan_price');
			$updateData['plan_duration'] = $this->input->post('plan_duration');
			$updateData['description'] = $this->input->post('description');
			
			$updateData['status'] = $this->input->post('status');
			$update = $this->common_model->updateTableData('membership',$condition,$updateData);
			if ($update) {
				$this->session->set_flashdata('success', 'membership has been updated successfully!');
				admin_redirect('membership', 'refresh');
			} else {
				$this->session->set_flashdata('error', 'Unable to update this membership');
				admin_redirect('membership/edit/' . $id, 'refresh');
			}
		}
		$data['membership'] = $isValid->row();
		$data['action'] = admin_url().'membership/edit/'.$id;
		$data['title'] = 'Edit membership';
		$data['meta_keywords'] = 'Edit membership';
		$data['meta_description'] = 'Edit membership';
		$data['main_content'] = 'membership/membership';
		$data['view'] = 'edit';
		$this->load->view('administrator/admin_template', $data);
	}
	// Status change
	function status($id,$status) {
		// Is logged in
		$sessionvar=$this->session->userdata('loggeduser');
		if (!$sessionvar) {
			admin_redirect('admin', 'refresh');
		}
		// Check is valid data
		if ($id == '' || $status == '') {
			$this->session->set_flashdata('error', 'Invalid request');
			admin_redirect('membership');
		}
		$isValid = $this->common_model->getTableData('membership', array('id' => $id))->num_rows();
		if ($isValid > 0) { // Check is valid banner
			$condition = array('id' => $id);
			$updateData['status'] = $status;
			$update = $this->common_model->updateTableData('membership', $condition, $updateData);
			if ($update) { // True // Update success
				if ($status == 1) {
					$this->session->set_flashdata('success', 'membership activated successfully');
				} else {
					$this->session->set_flashdata('success', 'membership de-activated successfully');
				}
				admin_redirect('membership');
			} else { //False
				$this->session->set_flashdata('error', 'Problem occure with membership status updation');
				admin_redirect('membership');
			}
		} else {
			$this->session->set_flashdata('error', 'Unable to find this membership');
			admin_redirect('membership');
		}
	}
	// Delete page
	function delete($id) {
		// Is logged in
		$sessionvar=$this->session->userdata('loggeduser');
		if (!$sessionvar) {
			admin_redirect('admin', 'refresh');
		}
		// Is valid
		if ($id == '') {
			$this->session->set_flashdata('error', 'Invalid request');
			admin_redirect('membership');
		}
		$isValid = $this->common_model->getTableData('membership', array('id' => $id))->num_rows();
		if ($isValid > 0) { // Check is valid
			$condition = array('id' => $id);
			$delete = $this->common_model->deleteTableData('membership', $condition);
			if ($delete) { // True // Delete success
				$this->session->set_flashdata('success', 'membership deleted successfully');
				admin_redirect('membership');
			} else { //False
				$this->session->set_flashdata('error', 'Problem occure with membership deletion');
				admin_redirect('membership');
			}
		} else {
			$this->session->set_flashdata('error', 'Unable to find this page');
			admin_redirect('membership');
		}
	}
	// UPDTAED BY VAISHNUDEVI
	function membership_ajax()
	{
		$sessionvar=$this->session->userdata('loggeduser');
		if (!$sessionvar) {
			admin_redirect('admin', 'refresh');
		}
		$draw = $this->input->get('draw');
		$start = intval($this->input->get("start"));
        $length = intval($this->input->get("length"));
        $order = $this->input->get("order");
        $search= $this->input->get("search");
        $search = $search['value'];
        $encrypt_search = encryptIt($search);
        $col = 0;
        $dir = "";
        if(!empty($order))
        {
            foreach($order as $o)
            {
                $col = $o['column'];
                $dir= $o['dir'];
            }
        }
        if($dir != "asc" && $dir != "desc")
        {
            $dir = "desc";
        }        
        $valid_columns = array(
            0=>'id',
            1=>'plan_name',
            2=>'plan_price',           
            3=>'status'
        );
        if(!isset($valid_columns[$col]))
        {
            $order = null;
        }
        else
        {
            $order = $valid_columns[$col];
        }
        if(!empty(trim($order)))
        {
            $this->db->order_by($order, $dir);
        }

		if(!empty($search))
		{
			$this->db->like('english_question',$search);		                 
		}
		$this->db->limit($length,$start);		
		$memberships = $this->db->get("tenrealm_membership");

        $membership_history_result = $memberships->result();

		$num_rows = count($membership_history_result);

		if(count($membership_history_result)>0)
		{
			foreach($memberships->result() as $membership)
			{
				$i++;
	            if ($membership->status == 1) {
                    $status = '<label class="label label-info">Activated</label>';
                    $extra = array("data-placement"=>"bottom",'data-toggle'=>"popover","data-content"=>"De-activate this membership","class"=>"poper");
                    $changeStatus = anchor(admin_url().'membership/status/' . $membership->id . '/0','<i class="fa fa-unlock text-primary"></i>',$extra);
                } else {
                    $status = '<label class="label label-danger">De-Activated</label>';
                    $extra = array("data-placement"=>"bottom",'data-toggle'=>"popover","data-content"=>"Activate this membership","class"=>"poper");
                    $changeStatus = anchor(admin_url().'membership/status/' . $membership->id . '/1','<i class="fa fa-lock text-primary"></i>',$extra);
                }	
	            $edit = '&nbsp;&nbsp;&nbsp;<a href="' . admin_url() . 'membership/edit/' . $membership->id . '" data-placement="top" data-toggle="popover" data-content="Edit this membership" class="poper"><i class="fa fa-pencil text-primary"></i></a>&nbsp;&nbsp;&nbsp;';
	            $link="'".admin_url().'membership/delete/'.$membership->id."'";	            
	            $delete = '<a onclick="deleteaction('.$link.');" data-placement="right" data-toggle="popover" data-content="If you delete this membership? you cant revert back." class="poper"><i class="fa fa-trash-o text-danger"></i></a>&nbsp;&nbsp;&nbsp;';          
				$data[] = array(
				    $i,
					$membership->plan_name,						
					$membership->plan_price,						
					$status,
					$changeStatus.$edit.$delete
				);
			}
		}
		else
		{
			$data = array();
		}
		$output = array(
            "draw" => $draw,
            "recordsTotal" => $num_rows,
            "recordsFiltered" => $num_rows,
            "data" => $data,
            "query"=> $tt
        );
		echo json_encode($output);
	}
}