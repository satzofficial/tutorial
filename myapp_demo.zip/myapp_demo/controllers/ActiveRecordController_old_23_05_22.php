<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class ActiveRecordController extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
	}

   	function company_user_add_manual(){
		$power = $upto = ($this->input->get('upto')) ? escape_str($this->input->get('upto')) : 1;
		$this->benchmark->mark('code_start');		
		$old_referral_id = 0;
		$id=2;
		$power = $upto = ($this->input->get('upto')) ? escape_str($this->input->get('upto')) : 1;
		$unique_id = randomNumber(14);
		$no_ref_level = 1;
		$matrix_level = 1;
		$this->com_m->insert_update_avail('users_no_ref_level_tracking', ['matrix_level'=>$matrix_level, 'no_ref_level'=>$no_ref_level],['id' => 1]);
		add_table($unique_id, 0);
		// if ($power % 2 == 0) {
			$pwr = floor($power/2);
			$node =2;
			$parent_id=1;
			for($outer=1;$outer<= $pwr;$outer++){
				$four = 1;
				for($inner=2;$inner < pow(2, $outer*2)+1;$inner++){
					$unique_id = randomNumber(14).'|-';
					$matrix_level = $outer;					

					// if($inner==258){
					// 	echo 'END-->';exit;	
					// }
					
					// echo $id++;echo "\t";echo $inner;echo "\t";echo "".$parent_id;echo "\t";echo "".$matrix_level;echo "\t";echo $no_ref_level;echo '<br>';

					add_table($unique_id, $parent_id,$matrix_level,$no_ref_level);
					if($four == 4){
						$parent_id++;
						$four = 0;
					}
					$four++;

					$this->com_m->insert_update_avail('users_no_ref_level_tracking',['no_ref_level' => $no_ref_level],['id' => 1]);
					if($parent_id > 85){						
						$this->com_m->update('users',['matrix_status' => 0],['no_ref_level <=' => ($no_ref_level) ]);						
						$no_ref_level++;
						$parent_id = 22;						
					}				
				}			
			}
		echo base_url('swap?ref='.$unique_id).'<br>';
		echo 'Company user has successfully been created';
		echo $this->benchmark->mark('code_end');
		echo '<br><hr>'.$this->benchmark->elapsed_time('code_start', 'code_end');		
	}
}
