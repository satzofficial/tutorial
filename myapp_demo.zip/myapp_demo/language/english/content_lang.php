<?php
$lang['Your message successfully sent to our team'] = 'Your message successfully sent to our team';

$lang['Error occur!! Please try again'] = 'Error occur!! Please try again';

$lang['Enter Valid Login Details'] = 'Enter Valid Login Details';

$lang['Please check your email to activate Latin Coin Exchange account'] = 'Please check your email to activate Latin Coin Exchange account';

$lang['Welcome back . Logged in Successfully'] = 'Welcome back . Logged in Successfully';

$lang['Enter Valid TFA Code'] = 'Enter Valid TFA Code';

$lang['User does not Exists'] = 'User does not Exists';

$lang['Password reset link is sent to your email'] = 'Password reset link is sent to your email';

$lang['Login error'] = 'Login error';

$lang['Password reset successfully'] = 'Password reset successfully';

$lang['Enter Password and Confirm Password'] = 'Enter Password and Confirm Password';

$lang['Link Expired'] = 'Link Expired';

$lang['Already reset password using this link'] = 'Already reset password using this link';

$lang['Not a valid link'] = 'Not a valid link';

$lang['Entered Email Address Already Exists'] = 'Entered Email Address Already Exists';

$lang['Thank you for Signing up. Please check your e-mail and click on the verification link.'] = 'Thank you for Signing up. Please check your e-mail and click on the verification link & Check your spam.';

$lang['Thank you for Verify. Please check your e-mail and click on the verification link.'] = 'Thank you for Verify. Please check your e-mail and click on the verification link.';

$lang['Logged Out successfully'] = 'Logged Out successfully';

$lang['Your Email is already verified.'] = 'Your Email is already verified.';

$lang['Your Email is verified now.'] = 'Your email is verifed, please login.';

$lang['Activation link is not valid'] = 'Activation link is not valid';

$lang['You are not logged in'] = 'You are not logged in';

$lang['Problem with yourself holding photo ID'] = 'Problem with yourself holding photo ID';

$lang['Profile details Updated Successfully'] = 'Profile details Updated Successfully';

$lang['Something ther is a Problem .Please try again later'] = 'Something ther is a Problem .Please try again later';

$lang['Some datas are missing'] = 'Some datas are missing';

$lang['Profile image Updated Successfully'] = 'Profile image Updated Successfully';

$lang['Something there is a Problem .Please try again later'] = 'Something there is a Problem .Please try again later';

$lang['Problem with your scan of photo id'] = 'Problem with your scan of photo id';

$lang['Your details have been sent to our team for verification'] = 'Your details have been sent to our team for verification';

$lang['Your Address proof cancelled successfully'] = 'Your Address proof cancelled successfully';

$lang['Unable to send your details to our team for verification. Please try again later!'] = 'Unable to send your details to our team for verification. Please try again later!';

$lang['Your ID proof cancelled successfully'] = 'Your ID proof cancelled successfully';

$lang['Your Photo cancelled successfully'] = 'Your Photo cancelled successfully';

$lang['Password changed successfully'] = 'Password changed successfully';

$lang['Confirm password must be same as new password'] = 'Confirm password must be same as new password';

$lang['Your old password is wrong'] = 'Your old password is wrong';

$lang['Please upload proper image format'] = 'Please upload proper image format';

$lang['update deposit success'] = 'update deposit success';

$lang['update deposit failed insufficient balance'] = 'update deposit failed insufficient balance';

$lang['invalid address'] = 'Invalid address';

$lang['Your withdraw request already confirmed'] = 'Your withdraw request already confirmed';

$lang['Your withdraw request already cancelled'] = 'Your withdraw request already cancelled';

$lang['Your are not the owner of this withdraw request'] = 'Your are not the owner of this withdraw request';

$lang['Successfully placed your withdraw request. Our team will also confirm this request'] = 'Successfully placed your withdraw request. Our team will also confirm this request';

$lang['Invalid withdraw confirmation'] = 'Invalid withdraw confirmation';

$lang['Successfully cancelled your withdraw request'] = 'Successfully cancelled your withdraw request';

$lang['Sorry!!! Your previous '] = 'Sorry!!! Your previous ';

$lang['withdrawal is waiting for admin approval. Please use other wallet or be patience'] = 'withdrawal is waiting for admin approval. Please use other wallet or be patience';

$lang['Amount you have entered is more than your current balance'] = 'Amount you have entered is more than your current balance';

$lang['Amount you have entered is less than minimum withdrawl limit'] = 'Amount you have entered is less than minimum withdrawl limit';

$lang['Amount you have entered is more than maximum withdrawl limit'] = 'Amount you have entered is more than maximum withdrawl limit';

$lang['Invalid address'] = 'Invalid address';

$lang['Your withdraw request placed successfully. Please make confirm from the mail you received in your registered mail!'] = 'Your withdraw request placed successfully. Please make confirm from the mail you received in your registered mail!';

$lang['Unable to submit your withdraw request. Please try again'] = 'Unable to submit your withdraw request. Please try again';

$lang['Please check the address'] = 'Please check the address';

$lang['Problem with your coin image'] = 'Problem with your coin image';

$lang['Your add coin request successfully sent to our team'] = 'Your add coin request successfully sent to our team';

$lang['Bank details Updated Successfully'] = 'Bank details Updated Successfully';

$lang['TFA Enabled successfully'] = 'TFA Enabled successfully';

$lang['Please Enter correct code to enable TFA'] = 'Please Enter correct code to enable TFA';

$lang['TFA Disabled successfully'] = 'TFA Disabled successfully';

$lang['Please Enter correct code to disable TFA'] = 'Please Enter correct code to disable TFA';

$lang['Amount you have entered is less than the minimum deposit limit'] = 'Amount you have entered is less than the minimum deposit limit';

$lang['Amount you have entered is more than the maximum deposit limit'] = 'Amount you have entered is more than the maximum deposit limit';

$lang['Your deposit request placed successfully'] = 'Your deposit request placed successfully';

$lang['Unable to submit your deposit request. Please try again'] = 'Unable to submit your deposit request. Please try again';

$lang['Your Fiat Deposit Failed. Please try again.'] = 'Your Fiat Deposit Failed. Please try again.';

$lang['Your Fiat Deposit successfully completed'] = 'Your Fiat Deposit successfully completed';

$lang['Unable to submit your Fiat Deposit request. Please try again'] = 'Unable to submit your Fiat Deposit request. Please try again';

$lang['Something Went Wrong. Please try again.'] = 'Something Went Wrong. Please try again.';

$lang['Your Crypto Deposit Failed. Please try again.'] = 'Your Crypto Deposit Failed. Please try again.';

$lang['Your Crypto Deposit successfully completed'] = 'Your Crypto Deposit successfully completed';

$lang['Ticket Closed'] = 'Ticket Closed';

$lang['Previous'] = 'Previous';

$lang['Next'] = 'Next';

$lang['Promoted Coins'] = 'Promoted Coins';

$lang['Listed Cryptocurrency Price'] = 'Listed Cryptocurrency Price';

$lang['Name'] = 'Name';

$lang['Change'] = 'Change';

$lang['Chart'] = 'Chart';

$lang['Trade'] = 'Trade';

$lang['USD'] = 'USD';

$lang['Trade Now'] = 'Trade Now';

$lang['Why Choose Latin Coin Exchange'] = 'Why Choose Latin Coin Exchange';

$lang['Partners'] = 'Partners';

$lang['Get It On Your Mobile Device'] = 'Get It On Your Mobile Device';

$lang['Coming Soon'] = 'Coming Soon';

$lang['Home'] = 'Home';

$lang['Exchange'] = 'Trading';

$lang['Dashboard'] = 'Dashboard';

$lang['About us'] = 'About us';

$lang['About'] = 'About';

$lang['Faq'] = 'Faq';

$lang['Account'] = 'Account';

$lang['Logout'] = 'Logout';

$lang['Register'] = 'Register';

$lang['Login'] = 'Login';

$lang['Service'] = 'Service';

$lang['Information'] = 'Information';

$lang['News'] = 'News';

$lang['Fee'] = 'Fee';

$lang['Join'] = 'Join';

$lang['Terms and Conditions'] = 'Terms and Conditions';

$lang['Branding & Promotion'] = 'Branding & Promotion';

$lang['Apply For Listing'] = 'Apply For Listing';

$lang['Promotion'] = 'Promotion';

$lang['Privacy Policy'] = 'Privacy Policy';

$lang['Support'] = 'Support';

$lang['Contact Us'] = 'Contact Us';

$lang['Contact'] = 'Contact';

$lang['Get started'] = 'Get started';

$lang['API'] = 'API';

$lang['News'] = 'News';

$lang['Read More'] = 'Read More';

$lang['Email address'] = 'Email Address';

$lang['EMAIL ADDRESS'] = 'EMAIL ADDRESS';

$lang['Subject'] = 'Subject';

$lang['Message'] = 'Message';

$lang['Submit'] = 'Submit';

$lang['Please enter name'] = 'Please enter name';

$lang['Please enter email'] = 'Please enter email';

$lang['Please enter valid email address'] = 'Please enter valid email address';

$lang['Please enter subject'] = 'Please enter subject';

$lang['Please enter comments'] = 'Please enter comments';

$lang['You are allow upto 900 characters.'] = 'You are allow upto 900 characters.';

$lang['Fees'] = 'Fees';

$lang['ASSET'] = 'Asset';

$lang['WITHDRAW FEE'] = 'Withdraw Fee';

$lang['MINIMUM DEPOSIT AMOUNT'] = 'Minimum Deposit Amount';

$lang['MINIMUM WITHDRAW AMOUNT'] = 'Minimum Withdraw Amount';

$lang['MAXIMUM WITHDRAW AMOUNT'] = 'Minimum Withdraw Amount';

$lang['Balance'] = 'Balance';

$lang['Receive'] = 'Receive';

$lang['Send'] = 'Send';

$lang['Profile'] = 'Profile';

$lang['Bank Details'] = 'Bank Details';

$lang['Verification'] = 'Verification';

$lang['Profile Picture'] = 'Profile Picture';

$lang['Change Picture'] = 'Change Picture';

$lang['Date of birth'] = 'Date of birth';

$lang['Email'] = 'Email';

$lang['Address'] = 'Address';

$lang['City'] = 'City';

$lang['State'] = 'State';

$lang['Country'] = 'Country';

$lang['Postal Code'] = 'Postal Code';

$lang['SAVE'] = 'SAVE';

$lang['BANK DETAILS'] = 'BANK DETAILS';

$lang['Account Holder Name'] = 'Account Holder Name';

$lang['Bank Swift/BIC/IFSC'] = 'Bank Swift/BIC/IFSC';

$lang['Swift/BIC Code'] = 'Swift/BIC Code';

$lang['Bank Name'] = 'Bank Name';

$lang['Bank Address'] = 'Bank Address';

$lang['Bank City'] = 'Bank City';

$lang['Bank Country'] = 'Bank Country';

$lang['Select Country'] = 'Select Country';

$lang['Bank Postal Code'] = 'Bank Postal Code';

$lang['Verification'] = 'Verification';

$lang['Address Proof'] = 'Address Proof';

$lang['ID Proof'] = 'ID Proof';

$lang['Close Head Photo'] = 'Close Head Photo';

$lang['Choose file'] = 'Choose file';

$lang['[Note : Maximum File'] = '[Note : Maximum File';

$lang['Size Should Be Below 2mb]'] = 'Size Should Be Below 2mb]';

$lang['CANCEL'] = 'CANCEL';

$lang['Any One Address Proof Document Must Submit'] = 'Any One Address Proof Document Must Submit';

$lang['Bank Debit / Credit Card Statement'] = 'Bank Debit / Credit Card Statement';

$lang['Passport'] = 'Passport';

$lang['Rental / Property Agreement'] = 'Rental / Property Agreement';

$lang['Income Tax / Property Tax'] = 'Income Tax / Property Tax';

$lang['Any Id Proof Document Must Submit'] = 'Any Id Proof Document Must Submit';

$lang['Driving License'] = 'Driving License';

$lang['Insurance Document'] = 'Insurance Document';

$lang['Debit / Credit Card With Photo And Name'] = 'Debit / Credit Card With Photo And Name';

$lang['Following Proof Document Must Submit'] = 'Following Proof Document Must Submit';

$lang['Close Head Photo'] = 'Close Head Photo';

$lang['Please enter address'] = 'Please enter address';

$lang['Please enter city'] = 'Please enter city';

$lang['Please enter letters only'] = 'Please enter letters only';

$lang['Please enter state'] = 'Please enter state';

$lang['Please enter postal code'] = 'Please enter postal code';

$lang['Please enter Account holder name'] = 'Please enter Account holder name';

$lang['Please enter Account number'] = 'Please enter Account number';

$lang['Please enter Account name'] = 'Please enter Account name';

$lang['Please enter Swift Code'] = 'Please enter Swift Code';

$lang['Please enter Bank name'] = 'Please enter Bank name';

$lang['Please enter Bank Address'] = 'Please enter Bank Address';

$lang['Please enter Bank City'] = 'Please enter Bank City';

$lang['Please select Bank Country'] = 'Please select Bank Country';

$lang['Provide Address Proof'] = 'Provide Address Proof';

$lang['No Address proof to cancel'] = 'No Address proof to cancel';

$lang['Provide ID Proof'] = 'Provide ID Proof';

$lang['No ID Proof to cancel'] = 'No ID Proof to cancel';

$lang['Provide Photo Proof'] = 'Provide Photo Proof';

$lang['No Photo Proof to cancel'] = 'No Photo Proof to cancel';

$lang['Buy Crypto'] = 'Buy Crypto';

$lang['Choose coin'] = 'Choose coin';

$lang['Enter Amount'] = 'Enter Amount';

$lang['BUY'] = 'BUY';

$lang['Please enter currency'] = 'Please enter currency';

$lang['Please enter amount'] = 'Please enter amount';

$lang['Please enter valid amount'] = 'Please enter valid amount';

$lang['Deposit'] = 'Deposit';

$lang['Deposit button'] = 'Deposit';

$lang['Enter amount'] = 'Enter amount';

$lang['Reference Number'] = 'Reference Number';

$lang['Payment Details'] = 'Payment Details';

$lang['Deposit Amount'] = 'Deposit Amount';

$lang['Card Owner'] = 'Card Owner';

$lang['Card number'] = 'Card number';

$lang['Card Type'] = 'Card Type';

$lang['Expiration Date'] = 'Expiration Date';

$lang['CVV'] = 'CVV';

$lang['CONFIRM PAYMENT'] = 'CONFIRM PAYMENT';

$lang['Account Details'] = 'Account Details';

$lang['Account Name'] = 'Account Name';

$lang['Account Number'] = 'IBAN';

$lang['IFSC/SWIFT Code'] = 'IFSC/SWIFT Code';

$lang['Branch City'] = 'Branch City';

$lang['Paypal'] = 'Paypal';

$lang['Please Complete KYC'] = 'Please Complete KYC';

$lang['Click here'] = 'Click here';

$lang['Coin address'] = 'Coin address';

$lang['Copy'] = 'Copy';

$lang['Destination Tag'] = 'Destination Tag';

$lang['Important notice'] = 'Important notice';

$lang['It May Take Time For The Network To Confirm The Transaction. We Require %d Network/Block Confirmations.'] = 'It May Take Time For The Network To Confirm The Transaction. We Require %d Network/Block Confirmations.';

$lang['Scan QR Code'] = 'Scan QR Code';

$lang['Wallet Balances'] = 'Wallet Balances';

$lang['Value in USD'] = 'Value in USD';

$lang['Please enter Reference number'] = 'Please enter Reference number';

$lang['Please enter Holder Name'] = 'Please enter Holder Name';

$lang['Please enter Card Number'] = 'Please enter Card Number';

$lang['Please enter valid Card Number'] = 'Please enter valid Card Number';

$lang['Please enter Expiry Date'] = 'Please enter Expiry Date';

$lang['Please enter valid Expiry Date'] = 'Please enter valid Expiry Date';

$lang['Please enter Expiry Year'] = 'Please enter Expiry Year';

$lang['Please enter valid Expiry Year'] = 'Please enter valid Expiry Year';

$lang['Please enter CVV'] = 'Please enter CVV';

$lang['Please enter valid CVV'] = 'Please enter valid CVV';

$lang['KYC Status'] = 'KYC Status';

$lang['Pending'] = 'Pending';

$lang['Completed'] = 'Completed';

$lang['Rejected'] = 'Rejected';

$lang['Withdraw'] = 'Withdraw';

$lang['Withdraw button'] = 'Withdraw';

$lang['Enter amount to Withdraw'] = 'Enter amount to Withdraw';

$lang['Your coin address'] = 'Your coin address';

$lang['S.no'] = 'S.NO';

$lang['Date & Time'] = 'Date & Time';

$lang['Currency'] = 'Currency';

$lang['Trans ID'] = 'Trans ID';

$lang['Sent Amount'] = 'Sent Amount';

$lang['Status'] = 'Status';

$lang['History'] = 'History';

$lang['Buy Crypto'] = 'Buy Crypto';

$lang['Transaction'] = 'Transaction';

$lang['Fees'] = 'Fees';

$lang['Receive Amount'] = 'Receive Amount';

$lang['Type'] = 'Type';

$lang['Pair'] = 'Pair';

$lang['Price'] = 'Price';

$lang['Price Menu'] = 'Price';

$lang['Amount'] = 'Amount';

$lang['Total'] = 'Total';

$lang['Action'] = 'Action';

$lang['Inprogress'] = 'Inprogress';

$lang['No records found !!!'] = 'No records found !!!';

$lang['IP Address'] = 'IP Address';

$lang['Browser'] = 'Browser';

$lang['Apply for Listing'] = 'Apply for Listing';

$lang['Settings'] = 'Settings';

$lang['Password'] = 'Password';

$lang['Change'] = 'Change';

$lang['Old'] = 'Old';

$lang['New'] = 'New';

$lang['Confirm'] = 'Confirm';

$lang['2 STEP VERIFICATION'] = '2 STEP VERIFICATION';

$lang['To Get The Google Authenticator Details Please'] = 'To Get The Google Authenticator Details Please';

$lang['ENABLE'] = 'ENABLE';

$lang['DISABLE'] = 'DISABLE';

$lang['ENABLE AUTHENTICATION IN 2 STEPS'] = 'ENABLE AUTHENTICATION IN 2 STEPS';

$lang['DISABLE AUTHENTICATION IN 2 STEPS'] = 'DISABLE AUTHENTICATION IN 2 STEPS';

$lang['Scan QR Code In Google Authenticator'] = 'Scan QR Code In Google Authenticator';

$lang['Type The Key Manually'] = 'Type The Key Manually';

$lang['Please enter Old Password'] = 'Please enter Old Password';

$lang['Invalid Old Password'] = 'Invalid Old Password';

$lang['Please enter New Password'] = 'Please enter New Password';

$lang['Please enter Confirm Password'] = 'Please enter Confirm Password';

$lang['Confirm Password not matches with New Password'] = 'Confirm Password not matches with New Password';

$lang['Please enter code'] = 'Please enter code';

$lang['Please enter valid code'] = 'Please enter valid code';

$lang['Please 6 digit valid code'] = 'Please 6 digit valid code';

$lang['Select Asset Type'] = 'Select Asset Type';

$lang['COIN'] = 'COIN';

$lang['TOKEN'] = 'TOKEN';

$lang['Full Name of your crypto'] = 'Full Name of your crypto';

$lang['Listing Priority'] = 'Listing Priority';

$lang['Listing Priority'] = 'Listing Priority';

$lang['Cost'] = 'Cost';

$lang['High'] = 'High';

$lang['Standard'] = 'Standard';

$lang['Low'] = 'Low';

$lang['Official Crypto Ticker'] = 'Official Crypto Ticker';

$lang['Logo of Coin (Transparent PNG 250 *250PX)'] = 'Logo of Coin (Transparent PNG 250 *250PX)';

$lang['Maximum Supply'] = 'Maximum Supply';

$lang['Which Blockchain in your crypto based on'] = 'Which Blockchain in your crypto based on';

$lang['Initial Price'] = 'Initial Price';

$lang['COMMUNITY'] = 'COMMUNITY';

$lang['Coin Market Caplink'] = 'Coin Market Caplink';

$lang['Contact Username'] = 'Contact Username';

$lang['Coin Link'] = 'Coin Link';

$lang['Official Twitter Link'] = 'Official Twitter Link';

$lang['Do not need any funds to any address unless you receive mail from our team.'] = 'Do not need any funds to any address unless you receive mail from our team.';

$lang['SUBMIT REQUEST'] = 'SUBMIT REQUEST';

$lang['Please choose coin type'] = 'Please choose coin type';

$lang['Please enter coin name'] = 'Please enter coin name';

$lang['Only strings allowed'] = 'Only strings allowed';

$lang['Please enter coin symbol'] = 'Please enter coin symbol';

$lang['Please enter maximum supply'] = 'Please enter maximum supply';

$lang['Should enter only number'] = 'Should enter only number';

$lang['Please enter coin price'] = 'Please enter coin price';

$lang['Please choose priority'] = 'Please choose priority';

$lang['Please enter username'] = 'Please enter username';

$lang['Invalid Format Email'] = 'Invalid Format Email';

$lang['Ticket'] = 'Ticket';

$lang['Category'] = 'Category';

$lang['Open'] = 'Open';

$lang['Closed'] = 'Closed';

$lang['Please enter subject'] = 'Please enter subject';

$lang['Please enter message'] = 'Please enter message';

$lang['Please upload proper file format'] = 'Please upload proper file format';

$lang['Username'] = 'Username';

$lang['Close'] = 'Close';

$lang['Created On'] = 'Created On';

$lang['View'] = 'View';

$lang['Reply'] = 'Reply';

$lang['Attach Files'] = 'Attach Files';

$lang['Reply Message...'] = 'Reply Message...';

$lang['Remember Me'] = 'Remember Me';

$lang['Forgot'] = 'Forgot';

$lang["Don't have an account?"] = "Don't have an account?";

$lang['Now'] = 'Now';

$lang['Please enter password'] = 'Please enter password';

$lang['Please enter valid tfa code'] = 'Please enter valid tfa code';

$lang['Enter 6 digit valid tfa code'] = 'Enter 6 digit valid tfa code';

$lang['Create your account'] = 'Create your account';

$lang["You're just a few minutes away from trading on LCE global platform."] = "You're just a few minutes away from trading on LCE global platform.";

$lang['Email'] = 'Email';

$lang['Country of Residence'] = 'Country of Residence';

$lang['By Continuing I agree to the'] = 'By Continuing I agree to the';

$lang['Terms of Service'] = 'Terms of Service';

$lang['Privacy Policy'] = 'Privacy Policy';

$lang['Please check here'] = 'Please check here';

$lang['Already have an account'] = 'Already have an account';

$lang['Minimum 8 characters, including UPPER / lower case with numbers & special characters'] = 'Minimum 8 characters, including UPPER / lower case with numbers & special characters';

$lang['Please enter same password'] = 'Please enter same password';

$lang['Please select country'] = 'Please select country';

$lang['Please select terms & conditions'] = 'Please select terms & conditions';

$lang['Reset'] = 'Reset';

$lang['Enter'] = 'Enter';

$lang['Re-enter'] = 'Re-enter';

$lang['MARKETS'] = 'MARKETS';

$lang['PAIR'] = 'PAIR';

$lang['PRICE'] = 'PRICE';

$lang['CHANGE'] = 'CHANGE';

$lang['TRADES'] = 'TRADES';

$lang['AMOUNT'] = 'AMOUNT';

$lang['Buy'] = 'Buy';

$lang['Sell'] = 'Sell';

$lang['Available'] = 'Available';

$lang['Limit'] = 'Limit';

$lang['Market'] = 'Market';

$lang['Amount in USD'] = 'Amount in USD';

$lang['Order Books'] = 'Order Books';

$lang['TOTAL'] = 'TOTAL';

$lang['Last price'] = 'Last price';

$lang['Orders'] = 'Orders';

$lang['TYPE'] = 'TYPE';

$lang['DATE & TIME'] = 'DATE & TIME';

$lang['DATE'] = 'DATE';

$lang['ORDER TYPE'] = 'ORDER TYPE';

$lang['Please enter valid amount and price'] = 'Please enter valid amount and price';

$lang['Minimum trade amount is'] = 'Minimum trade amount is';

$lang['Please enter limit price'] = 'Please enter limit price';

$lang['Insufficient balance'] = 'Insufficient balance';

$lang['Stop price not same as market price'] = 'Stop price not same as market price';

$lang['Limit price not same as market price'] = 'Limit price not same as market price';

$lang['Are you sure you want to cancel this order?'] = 'Are you sure you want to cancel this order?';

$lang['No Trade History'] = 'No Trade History';

$lang['No Orders Found'] = 'No Orders Found';

$lang['No Active Orders Found'] = 'No Active Orders Found';

$lang['Your order has been cancelled successfully'] = 'Your order has been cancelled successfully';

$lang['Something went wrong, Please try again later'] = 'Something went wrong, Please try again later';

$lang['Login to your account'] = 'Login to your account';

$lang['Your order has been placed'] = 'Your order has been placed';

$lang['Upgrade Wallet'] = 'Upgrade Wallet';

$lang['Invest Money'] = 'Invest Money';

$lang['Withdrawl Money'] = 'Withdrawl Money';

$lang['Load more'] = 'Load more';

$lang['Know more'] = 'Know more';

$lang['Learn more'] = 'Learn more';

$lang['Security'] = 'Security';

$lang['License'] = 'License';

$lang['Result'] = 'Result';

$lang['Select Currency'] = 'Select Currency';

$lang['Scan QR Code'] = 'Scan QR Code';

$lang['Copy Address'] = 'Copy Address';

$lang['Send/Receive Currency'] = 'Send/Receive Currency';

$lang['Our Services'] = 'Our Services';

$lang['Help'] = 'Help';

$lang['COMPANY'] = 'COMPANY';

$lang['SUPPORT'] = 'SUPPORT';

$lang['address'] = 'Address';

$lang['Enter Your Email Address'] = 'Enter Your Email Address';

$lang['Enter Your Password'] = 'Enter Your Password';

$lang['Enter Google Authenticator Code'] = 'Enter Google Authenticator Code';

$lang['Forgot Password'] = 'Forgot Password';

$lang['Sign up'] = 'Sign up';

$lang['Don"t have an account?'] = 'Don`t have an account?';

$lang['Google Authenticator Code (if enabled)'] = 'Google Authenticator Code';

$lang['Login with another account'] = 'Login with another account';

$lang['or'] = 'or';

$lang['Confirm Password'] = 'Confirm Password';

$lang['Already have an account?'] = 'Already have an account?';

$lang['Welcome'] = 'Welcome';

$lang['Looks like you are not verified yet. Verify yourself to use the full potential of Trade.'] = 'Looks like you are not verified yet. Verify yourself to use the full potential of Trade.';

$lang['Verify account'] = 'Verify account';

$lang['Two-factor authentication (2FA)'] = 'Two-factor authentication (2FA)';

$lang['Enable 2FA authentication'] = 'Enable 2FA authentication';

$lang['Disable 2FA authentication'] = 'Disable 2FA authentication';

$lang['Edit'] = 'Edit';

$lang['COUNTRY OF RESIDENCE'] = 'COUNTRY OF RESIDENCE';

$lang['JOINED SINCE'] = 'JOINED SINCE';

$lang['VERIFY & UPGRADE'] = 'VERIFY & UPGRADE';

$lang['Account Status'] = 'Account Status';

$lang['Verified'] = 'Verified';

$lang['Your account is unverified. Get verified to enable funding, trading, and withdrawal.'] = 'Your account is unverified. Get verified to enable funding, trading, and withdrawal.';

$lang['Your account is verified.'] = 'Your account is verified.';

$lang['Thank you for verified.'] = 'Thank you for verified.';

$lang['Get Verified'] = 'Get Verified';

$lang['Profile Settings'] = 'Profile Settings';

$lang['User Profile'] = 'User Profile';

$lang['Max file size is 20mb'] = 'Max file size is 20mb';

$lang['Save'] = 'Save';

$lang['Personal Information'] = 'Personal Information';

$lang['First Name'] = 'First Name';

$lang['Last Name'] = 'Last Name';

$lang['Present Address'] = 'building number';

$lang['Permanent Address'] = 'street';

$lang['Select'] = 'Select';

$lang['Phone Number'] = 'Phone Number';

$lang['Wallet'] = 'Wallet';

$lang['Transactions'] = 'Transactions';

$lang['Coin'] = 'Coin';

$lang['Available Balance'] = 'Available Balance';

$lang['Total Balance'] = 'Total Balance';

$lang['Value'] = 'Value';

$lang['Euro'] = 'Euro';

$lang['Estimated Value'] = 'Estimated Value';

$lang['Important'] = 'Important';

$lang['This address is only for'] = 'This address is only for';

$lang['deposits'] = 'deposits';

$lang['Sending any other coin or token to this address may result in the loss of your deposit and is not eligible for recovery'] = 'Sending any other coin or token to this address may result in the loss of your deposit and is not eligible for recovery';

$lang['Deposits will automatically be processed after 3 network confirmations. Deposit confirmation can be delayed depending on network conditions.'] = 'Deposits will automatically be processed after 3 network confirmations. Deposit confirmation can be delayed depending on network conditions.';

$lang['Deposit History'] = 'Deposit History';

$lang['Transaction ID'] = 'Transaction ID';

$lang['Date & Time'] = 'Date & Time';

$lang['Update'] = 'Update';

$lang['Caution'] = 'Caution';

$lang['Withdraw address'] = 'Withdraw address';

$lang['Withdraw Amount'] = 'Withdraw Amount';

$lang['Fee'] = 'Fee';

$lang['Amount You will receive'] = 'Amount You will receive';

$lang['based'] = 'based';

$lang['Mobile Money'] = 'Mobile Money';

$lang['Bank Transfer'] = 'Bank Transfer';

$lang['Invalid Amount'] = 'Invalid Amount';

$lang['Please select currency'] = 'Please select currency';

$lang['Please enter numbers only'] = 'Please enter numbers only';

$lang['Debit/Credit Card'] = 'Debit/Credit Card';

$lang['Withdrawal History'] = 'Withdrawal History';

$lang['Two-Step Verification'] = 'Two-Step Verification';

$lang['Change Password'] = 'Change Password';

$lang['Maximum file size should be below 2mb'] = 'Maximum file size should be below 2mb';

$lang['Upload Image'] = 'Upload Image';

$lang['Upload pdf'] = 'Upload pdf';

$lang['Aadhaar Card'] = 'Aadhaar Card';

$lang['Upload a selfie with Current date'] = 'Upload a selfie with Current date';

$lang['Selfie Proof'] = 'Selfie Proof';

$lang['Insert Code to Enable'] = 'Insert Code to Enable';

$lang['Insert Code to Disable'] = 'Insert Code to Disable';

$lang['Current Password'] = 'Current Password';

$lang['Enter Your Current Password'] = 'Enter Your Current Password';

$lang['New Password'] = 'New Password';

$lang['Enter Your New Password'] = 'Enter Your New Password';

$lang['Confirm New Password'] = 'Confirm New Password';

$lang['Enter Your Confirm New Password'] = 'Enter Your Confirm New Password';

$lang['Create your ticket'] = 'Create your ticket';

$lang['Browse files'] = 'Browse files';

$lang['Upload'] = 'Upload';

$lang['Support History'] = 'Support History';

$lang['Ticket ID'] = 'Ticket ID';

$lang['User Name'] = 'User Name';

$lang['Markets'] = 'Markets';

$lang['Volume'] = 'Volume';

$lang['24H Change'] = '24H Change';

$lang['24H High'] = '24H High';

$lang['24H Low'] = '24H Low';

$lang['Attachment'] = 'Attachment';

$lang['Trade Chart'] = 'Trade Chart';

$lang['Pairs'] = 'Pairs';

$lang['24h Volume'] = '24h Volume';

$lang['All Markets'] = 'All Markets';

$lang['Select Market'] = 'Select Market';

$lang['Search Coin name'] = 'Search address';

$lang['Learn'] = 'Learn';

$lang['It begins'] = 'It begins';

$lang['Cancel'] = 'Cancel';

$lang['Bank Wire'] = 'Bank Wire';

$lang['Bank Wire header'] = 'Bank Wire';

$lang['Coin Name'] = 'Coin Name';

$lang['Year of business'] = 'Year of business';

$lang['Successful transaction'] = 'Successful transaction';

$lang['Member since year'] = 'Member since year';

$lang['National TAX Number (TIN)'] = 'National TAX Number (TIN)';

$lang['KYC'] = 'KYC';

$lang['Your id document front'] = 'Your id document front';

$lang['Your id document back'] = 'Your id document back';

$lang['The transfer is not revocable'] = 'The transfer is not revocable';

$lang['Provide document front'] = 'Provide document front';

$lang['Provide document back'] = 'Provide document back';

$lang['No document to cancel'] = 'No document to cancel';

$lang['Log in to your wallet'] = 'Log in to your wallet';

$lang["If you haven't activated the Google Authenticator feature yet, leave the field below blank"] = "If you haven't activated the Google Authenticator feature yet, leave the field below blank";

$lang['Profile Settings Tab'] = 'My Data';

$lang['Exchange Tab'] = 'Trading platform';

$lang['Two-step verification (called “two-factor authentication”) adds an extra layer of security to your account should your password be discovered. in fact, with the activation of the 2-factor authentication, to access your account you will have to use two steps:'] = 'Two-step verification (called “two-factor authentication”) adds an extra layer of security to your account should your password be discovered. in fact, with the activation of the 2-factor authentication, to access your account you will have to use two steps:';

$lang['- the prime is something you know, for example your password;'] = '- the prime is something you know, for example your password;';

$lang['- the second something you own, for example your phone.'] = '- the second something you own, for example your phone.';

$lang['For more information on Google Authenticator'] = 'For more information on Google Authenticator';

$lang['First you need to download the google Authenticator App'] = 'First you need to download the google Authenticator App';

$lang['To enable two-step verification, frame this QRcode with the Google Authenticator App and enter the code generate from you app in the field below.'] = 'To enable two-step verification, frame this QRcode with the Google Authenticator App and enter the code generate from you app in the field below.';

// $lang['or manually enter the alphanumeric code you find under the QRcode below'] = 'or manually enter the alphanumeric code you find under the QRcode below';

$lang['Transaction is Pending'] = 'Transaction is Pending';

$lang['Simply enter your surname and name as the reason for the transfer, followed by the word "IDENTIFICATION".'] = 'Simply enter your surname and name as the reason for the transfer, followed by the word "IDENTIFICATION".';

$lang['After making the transfer, fill in the fields below and upload a payment receipt in .pdf format (the maximum file size must be less than 2 MB)'] = 'After making the transfer, fill in the fields below and upload a payment receipt in .pdf format (the maximum file size must be less than 2 MB)';

$lang['Provide Document Front'] = 'Provide Document Front';

$lang['No Document Front to cancel'] = 'No Document Front to cancel';

$lang['Provide Document Back'] = 'Provide Document Back';

$lang['No Document Back to cancel'] = 'No Document Back to cancel';

$lang['Problem with your document front'] = 'Problem with your document front';

$lang['Problem with your document back'] = 'Problem with your document back';

$lang['File Size Should be less than 2 MB'] = 'File Size Should be less than 2 MB';

$lang['Please enter first name'] = 'Please enter first name';

$lang['Please enter last name'] = 'Please enter last name';

$lang['Please enter DOB'] = 'Please enter DOB';

$lang['Please enter present address'] = 'Please enter building number';

$lang['Please enter city'] = 'Please enter city';

$lang['Please enter letters only'] = 'Please enter letters only';

$lang['Please enter state'] = 'Please enter state';

$lang['Please enter letters only'] = 'Please enter letters only';

$lang['Please select country'] = 'Please select country';

$lang['Please enter Postal code'] = 'Please enter Postal code';

$lang['Please enter phone number'] = 'Please enter phone number';

$lang['Please Login'] = 'Please Login';

$lang['Problem with profile picture'] = 'Problem with profile picture';

$lang['Your Ethereum Balance is low so you did not able to withdraw for Tether Token'] = 'Your Ethereum Balance is low so you did not able to withdraw for Tether Token';

$lang['Your withdraw request has been placed successfully.'] = 'Your withdraw request has been placed successfully.';

$lang['Please try again after some time or contact Admin.'] = 'Please try again after some time or contact Admin.';

$lang['Your Balance is low so you did not able to withdraw'] = 'Your Balance is low so you did not able to withdraw';

$lang['Funds via Mobile Wallet has been Received. Will Process your Payments within few Minutes'] = 'Funds via Mobile Wallet has been Received. Will Process your Payments within few Minutes';

$lang['Unable to Process your Deposit. Please contact Admin.'] = 'Unable to Process your Deposit. Please contact Admin.';

$lang['Unable to Process your Deposit.'] = 'Unable to Process your Deposit.';

$lang['Payment has been Processing. Please proceed with the popup link'] = 'Payment has been Processing. Please proceed with the popup link';

$lang[' withdrawal is Pending. Please use other wallet or be patience'] = ' withdrawal is Pending. Please use other wallet or be patience';

$lang['Bank Wire withdrawl request has been received. Will Process your Payment within few Minutes'] = 'Bank Wire withdrawl request has been received. Will Process your Payment within few Minutes';

$lang['Unable to Process your Withdraw. Please contact Admin.'] = 'Unable to Process your Withdraw. Please contact Admin.';

$lang['Address Book'] = 'Address Book';

$lang['Click Here'] = 'Click Here';

$lang['Please Complete My Data Information'] = 'Please Complete My Data Information.';

$lang['COPIED'] = 'COPIED';

$lang['select from you address book'] = 'select from you address book';

$lang['username signup'] = 'username';

$lang['password signup'] = 'password';

$lang['confirm password signup'] = 'confirm password';

$lang['Terms and Conditions signup'] = 'Read and accept terms and condition';

$lang['Insert address'] = 'Insert address';

$lang['Added successfully'] = 'Added successfully';

$lang['Changed successfully'] = 'Changed successfully';

$lang['Cancelled successfully'] = 'Cancelled successfully';

$lang['Please select coin'] = 'Please select coin';

$lang['Select coin'] = 'Select coin';

$lang['Address Management'] = 'Address Management';

$lang['You performed an operation with this address. Do you want to add it to your address book?'] = 'You performed an operation with this address. Do you want to add it to your address book?';

$lang['name'] = 'Name';

$lang['coin'] = 'Coin';

$lang['No data available in table'] = 'No data avaible in tablet';

$lang['Showing 0 to 0 of 0 entries'] = 'Showing 0 to 0 of 0 entries';

$lang['Showing _START_ to _END_ of _TOTAL_ entries'] = 'Showing _START_ to _END_ of _TOTAL_ entries';

$lang['Showing _START_ to _END_ of _TOTAL_ entries Transaction'] = 'Showing _START_ to _END_ of _TOTAL_ entries';

$lang['Please enter national tax number'] = 'Please enter national tax number';

$lang['(filtered from _MAX_ total entries)'] = '(filtered from _MAX_ total entries)';

$lang['Recharge'] = 'Recharge';

$lang['Deleted successfully'] = 'Deleted successfully';

$lang['The email addresses is not valid or you left a blank space'] = 'The email addresses is not valid or you left a blank space';

$lang['Please check your email to activate Share Coin Exchange account'] = 'Please check your email to activate Share Coin Exchange account';

$lang['QR code'] = 'QR code';

$lang['Address of sender / receipient'] = 'Address of sender / receipient';

$lang['Amount'] = 'Amount';

$lang['Status'] = 'Status';

$lang['Send / Receive'] = 'Send / Receive';

$lang['Continue with your verification'] = 'Continue with your verification';

$lang['Basic'] = 'Basic';

$lang['Advance'] = 'Advance';

$lang['Pay'] = 'Pay';

$lang['Your Portfolio'] = 'Your Portfolio';

$lang['Your Transactions'] = 'Your Transactions';

$lang['Watchlist'] = 'Watchlist';

$lang['Received'] = 'Received';

$lang['Sent'] = 'Sent';

$lang['Pay with'] = 'Pay with';

$lang['Fee(Other Fee)'] = 'Fee(Other Fee)';

$lang['Amount You will receive'] = 'Amount You will receive';

$lang['balance'] = 'balance';

$lang['Crypto Converter'] = 'Crypto Converter';

$lang['coin'] = 'coin';

$lang['Amount in Euro'] = 'Amount in Euro';

$lang['Price for coin'] = 'Price for coin';

$lang['Trade History'] = 'Trade History';

$lang['Open Order'] = 'Open Order';

$lang['Search Address Book Name'] = 'Search Address Book Name';

$lang['Buy/Sell'] = 'Buy/Sell';

$lang['Fiat Withdraw'] = 'Withdraw';

$lang['Please enter destination tag'] = 'Please enter destination tag';

$lang['Amount in'] = 'Amount in';

$lang['Trading'] = 'Trade';

$lang['View asset'] = 'View asset';

$lang['Total in Euro'] = 'Total in Euro';

$lang['Buy Now'] = 'Buy Now';

$lang['Sell Now'] = 'Sell Now';

$lang['Total in'] = 'Total in';

$lang['Please Complete Bankwire'] = 'Please Complete Bankwire';

$lang['Value in'] = 'Value in';

$lang['Pending Transaction'] = 'Pending';

$lang['Cancelled Transaction'] = 'Cancelled';

$lang['Date'] = 'Date';

$lang['Type'] = 'Type';

$lang['Order Type'] = 'Order Type';

$lang['ACCEPTED FILE JPG AND PNG ONLY'] = 'ACCEPTED FILE JPG AND PNG ONLY';

$lang['Wallet Transactions'] = 'Wallet Transactions';

$lang['Exchange Buy/Sell Transactions'] = 'Exchange Buy/Sell Transactions';

$lang['Select Wallet Type'] = 'Select Wallet Type';

$lang['Select Email Address'] = 'Select Email Address';










?>