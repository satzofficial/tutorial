<?php
$lang['Your message successfully sent to our team'] = 'Il tuo messaggio è stato inviato con successo al nostro team';

$lang['Error occur!! Please try again'] = 'Si è verificato un errore!! Per favore riprova';

$lang['Enter Valid Login Details'] = 'Credenziali errate';

$lang['Please check your email to activate Latin Coin Exchange account'] = 'Please check your email to activate Latin Coin Exchange account';

$lang['Welcome back . Logged in Successfully'] = 'Ben tornato . Accesso effettuato con successo';

$lang['Enter Valid TFA Code'] = 'Inserisci un codice TFA valido';

$lang['User does not Exists'] = 'User does not Exists';

$lang['Password reset link is sent to your email'] = 'Password reset link is sent to your email';

$lang['Login error'] = 'Login error';

$lang['Password reset successfully'] = 'Reimpostazione della password riuscita';

$lang['Enter Password and Confirm Password'] = 'Inserisci la password e conferma la password';

$lang['Link Expired'] = 'Link scaduto';

$lang['Already reset password using this link'] = 'Hai già reimpostato la password utilizzando questo link';

$lang['Not a valid link'] = 'Link non valido';

$lang['Entered Email Address Already Exists'] = "L'indirizzo e-mail inserito esiste già";

$lang['Thank you for Signing up. Please check your e-mail and click on the verification link.'] = 'Grazie per esserti iscritto. Controlla la tua e-mail e clicca sul link di verifica & Controlla la tua cartella spam.';

$lang['Thank you for Verify. Please check your e-mail and click on the verification link.'] = 'Grazie per la verifica. Si prega di controllare la posta elettronica e fare clic sul collegamento di verifica.';

$lang['Logged Out successfully'] = 'Disconnesso con successo';

$lang['Your Email is already verified.'] = 'La tua email è già verificata.';

$lang['Your Email is verified now.'] = 'La tua mail è stata verificata. Clicca login per inserire i tuoi dati';

$lang['Activation link is not valid'] = 'Il link di attivazione non è valido';

$lang['You are not logged in'] = 'Non sei loggato';

$lang['Problem with yourself holding photo ID'] = "Problema con te stesso in possesso di un documento d'identità con foto";

$lang['Profile details Updated Successfully'] = 'Dettagli del profilo aggiornati con successo';

$lang['Something ther is a Problem .Please try again later'] = "Qualcosa c'è un problema. Riprova più tardi";

$lang['Some datas are missing'] = 'Mancano alcuni dati';

$lang['Profile image Updated Successfully'] = 'Immagine del profilo aggiornata con successo';

$lang['Something there is a Problem .Please try again later'] = "Qualcosa c'è un problema. Riprova più tardi";

$lang['Problem with your scan of photo id'] = "Problema con la scansione del documento d'identità con foto";

$lang['Your details have been sent to our team for verification'] = 'I tuoi dati sono stati inviati al nostro team per la verifica';

$lang['Your Address proof cancelled successfully'] = 'La prova del tuo indirizzo è stata annullata con successo';

$lang['Unable to send your details to our team for verification. Please try again later!'] = 'Impossibile inviare i tuoi dati al nostro team per la verifica. Per favore riprova più tardi!';

$lang['Your ID proof cancelled successfully'] = "La tua prova d'identità è stata annullata con successo";

$lang['Your Photo cancelled successfully'] = 'La tua foto è stata annullata con successo';

$lang['Password changed successfully'] = 'password cambiata con successo';

$lang['Confirm password must be same as new password'] = 'La password di conferma deve essere uguale alla nuova password';

$lang['Your old password is wrong'] = 'La tua vecchia password è sbagliata';

$lang['Please upload proper image format'] = 'Si prega di caricare il formato immagine corretto';

$lang['update deposit success'] = 'update deposit success';

$lang['update deposit failed insufficient balance'] = 'update deposit failed insufficient balance';

$lang['invalid address'] = 'Invalid address';

$lang['Your withdraw request already confirmed'] = 'La tua richiesta di prelievo è già stata confermata';

$lang['Your withdraw request already cancelled'] = 'La tua richiesta di prelievo è già stata annullata';

$lang['Your are not the owner of this withdraw request'] = 'Non sei il proprietario di questa richiesta di prelievo';

$lang['Successfully placed your withdraw request. Our team will also confirm this request'] = 'Successfully placed your withdraw request. Our team will also confirm this request';

$lang['Invalid withdraw confirmation'] = 'Conferma di prelievo non valida';

$lang['Successfully cancelled your withdraw request'] = 'Annullato con successo la tua richiesta di prelievo';

$lang['Sorry!!! Your previous '] = 'Scusate!!! Il tuo precedente ';

$lang['withdrawal is waiting for admin approval. Please use other wallet or be patience'] = "il ritiro è in attesa dell'approvazione dell'amministratore. Per favore usa un altro portafoglio o sii paziente";

$lang['Amount you have entered is more than your current balance'] = "L'importo che hai inserito è superiore al tuo saldo attuale";

$lang['Amount you have entered is less than minimum withdrawl limit'] = "L'importo che hai inserito è inferiore al limite minimo di prelievo";

$lang['Amount you have entered is more than maximum withdrawl limit'] = "L'importo che hai inserito è superiore al limite massimo di prelievo";

$lang['Invalid address'] = 'Indirizzo non valido';

$lang['Your withdraw request placed successfully. Please make confirm from the mail you received in your registered mail!'] = 'Il tuo ordine di trasferimento è stato ricevuto. Conferma dalla tua mail, in questo browser, che sei tu ad aver disposto il trasferimento.';

$lang['Unable to submit your withdraw request. Please try again'] = 'Impossibile inviare la richiesta di prelievo. Per favore riprova';

$lang['Please check the address'] = "Si prega di controllare l'indirizzo";

$lang['Problem with your coin image'] = "Problema con l'immagine della tua moneta";

$lang['Your add coin request successfully sent to our team'] = 'La tua richiesta di aggiunta di monete è stata inviata con successo al nostro team';

$lang['Bank details Updated Successfully'] = 'Coordinate bancarie aggiornate con successo';

$lang['TFA Enabled successfully'] = 'TFA abilitato con successo';

$lang['Please Enter correct code to enable TFA'] = 'Inserisci il codice corretto per abilitare TFA';

$lang['TFA Disabled successfully'] = 'TFA disabilitato con successo';

$lang['Please Enter correct code to disable TFA'] = 'Si prega di inserire il codice corretto per disabilitare TFA';

$lang['Amount you have entered is less than the minimum deposit limit'] = "L'importo che hai inserito è inferiore al limite minimo di deposito";

$lang['Amount you have entered is more than the maximum deposit limit'] = "L'importo che hai inserito è superiore al limite massimo di deposito";

$lang['Your deposit request placed successfully'] = 'La tua richiesta di deposito è stata effettuata con successo';

$lang['Unable to submit your deposit request. Please try again'] = 'Impossibile inviare la richiesta di deposito. Per favore riprova';

$lang['Your Fiat Deposit Failed. Please try again.'] = 'Your Fiat Deposit Failed. Please try again.';

$lang['Your Fiat Deposit successfully completed'] = 'Your Fiat Deposit successfully completed';

$lang['Unable to submit your Fiat Deposit request. Please try again'] = 'Impossibile inviare la richiesta di deposito Fiat. Per favore riprova';

$lang['Something Went Wrong. Please try again.'] = 'Qualcosa è andato storto. Per favore riprova.';

$lang['Your Crypto Deposit Failed. Please try again.'] = 'Il tuo deposito di criptovalute non è riuscito. Per favore riprova.';

$lang['Your Crypto Deposit successfully completed'] = 'Il tuo deposito di criptovalute è stato completato con successo';

$lang['Ticket Closed'] = 'Biglietto chiuso';

$lang['Previous'] = 'precedente';

$lang['Next'] = 'prossimo';

$lang['Promoted Coins'] = 'Promoted Coins';

$lang['Listed Cryptocurrency Price'] = 'Listed Cryptocurrency Price';

$lang['Name'] = 'Nome';

$lang['Change'] = 'Change';

$lang['Chart'] = 'Chart';

$lang['Trade'] = 'Acquista';

$lang['USD'] = 'USD';

$lang['Trade Now'] = 'Trade Now';

$lang['Why Choose Latin Coin Exchange'] = 'Why Choose Latin Coin Exchange';

$lang['Partners'] = 'Partners';

$lang['Get It On Your Mobile Device'] = 'Get It On Your Mobile Device';

$lang['Coming Soon'] = 'Coming Soon';

$lang['Home'] = 'Casa';

$lang['Exchange'] = 'Scambio';

$lang['Dashboard'] = 'Pannello di controllo';

$lang['About us'] = 'Chi siamo';

$lang['About'] = 'Di';

$lang['Faq'] = 'FAQ';

$lang['Account'] = 'account';

$lang['Logout'] = 'Disconnettersi';

$lang['Register'] = 'Registrati';

$lang['Login'] = 'Accedere';

$lang['Service'] = 'Servizio';

$lang['Information'] = 'i tuoi dati';

$lang['News'] = 'News';

$lang['Fee'] = 'Fee';

$lang['Join'] = 'Join';

$lang['Terms and Conditions'] = 'Termini e Condizioni';

$lang['Branding & Promotion'] = 'Branding & Promotion';

$lang['Apply For Listing'] = 'Apply For Listing';

$lang['Promotion'] = 'Promotion';

$lang['Privacy Policy'] = 'Privacy Policy';

$lang['Support'] = 'Supporto';

$lang['Contact Us'] = 'Contattaci';

$lang['Contact'] = 'Contatto';

$lang['Get started'] = 'Iniziare';

$lang['API'] = 'API';

$lang['News'] = 'News';

$lang['Read More'] = 'Read More';

$lang['Email address'] = 'Indirizzo e-mail';

$lang['EMAIL ADDRESS'] = 'INDIRIZZO E-MAIL';

$lang['Subject'] = 'Soggetto';

$lang['Message'] = 'Messaggio';

$lang['Submit'] = 'Invia';

$lang['Please enter name'] = 'Per favore inserisci il nome';

$lang['Please enter email'] = "Per favore inserisci l'email";

$lang['Please enter valid email address'] = 'Inserisci indirizzo email valido';

$lang['Please enter subject'] = "Per favore inserisci l'oggetto";

$lang['Please enter comments'] = 'Si prega di inserire commenti';

$lang['You are allow upto 900 characters.'] = 'Sei consentito fino a 900 caratteri.';

$lang['Fees'] = 'Fees';

$lang['ASSET'] = 'Asset';

$lang['WITHDRAW FEE'] = 'Withdraw Fee';

$lang['MINIMUM DEPOSIT AMOUNT'] = 'Minimum Deposit Amount';

$lang['MINIMUM WITHDRAW AMOUNT'] = 'Minimum Withdraw Amount';

$lang['MAXIMUM WITHDRAW AMOUNT'] = 'Minimum Withdraw Amount';

$lang['Balance'] = 'Bilancia';

$lang['Receive'] = 'Ricevere';

$lang['Send'] = 'Spedire';

$lang['Profile'] = 'Profilo';

$lang['Bank Details'] = 'Coordinate bancarie';

$lang['Verification'] = 'Verification';

$lang['Profile Picture'] = 'Profile Picture';

$lang['Change Picture'] = 'Change Picture';

$lang['Date of birth'] = 'Data di nascita';

$lang['Email'] = 'Email';

$lang['Address'] = 'Indirizzo';

$lang['City'] = 'Città';

$lang['State'] = 'State';

$lang['Country'] = 'Nazione';

$lang['Postal Code'] = 'codice postale';

$lang['SAVE'] = 'SAVE';

$lang['BANK DETAILS'] = 'BANK DETAILS';

$lang['Account Holder Name'] = 'Nome del titolare';

$lang['Bank Swift/BIC/IFSC'] = 'Bank Swift/BIC/IFSC';

$lang['Swift/IFSC Code'] = 'Codice Swift/IFSC';

$lang['Bank Name'] = 'Nome della banca';

$lang['Bank Address'] = 'Indirizzo bancario';

$lang['Bank City'] = 'Città della banca';

$lang['Bank Country'] = 'Paese della banca';

$lang['Select Country'] = 'Seleziona il paese';

$lang['Bank Postal Code'] = 'Codice postale della banca';

$lang['Verification'] = 'Verification';

$lang['Address Proof'] = 'Prova di indirizzo';

$lang['ID Proof'] = "Documento d'identità";

$lang['Close Head Photo'] = 'Close Head Photo';

$lang['Choose file'] = 'Choose file';

$lang['[Note : Maximum File'] = '[Note : Maximum File';

$lang['Size Should Be Below 2mb]'] = 'Size Should Be Below 2mb]';

$lang['CANCEL'] = 'CANCEL';

$lang['Any One Address Proof Document Must Submit'] = "Qualsiasi documento di prova dell'indirizzo deve essere inviato";

$lang['Bank Debit / Credit Card Statement'] = 'Estratto conto bancario/carta di credito';

$lang['Passport'] = 'Passaporto';

$lang['Rental / Property Agreement'] = 'Contratto di locazione / proprietà';

$lang['Income Tax / Property Tax'] = 'Imposta sul reddito / Imposta sulla proprietà';

$lang['Any Id Proof Document Must Submit'] = 'Any Id Proof Document Must Submit';

$lang['Driving License'] = 'Patente di guida';

$lang['Insurance Document'] = 'Documento di assicurazione';

$lang['Debit / Credit Card With Photo And Name'] = 'Carta di debito/credito con foto e nome';

$lang['Following Proof Document Must Submit'] = 'Following Proof Document Must Submit';

$lang['Close Head Photo'] = 'Close Head Photo';

$lang['Please enter address'] = "Si prega di inserire l'indirizzo";

$lang['Please enter city'] = 'Please enter city';

$lang['Please enter letters only'] = 'Si prega di inserire solo lettere';

$lang['Please enter state'] = 'Please enter state';

$lang['Please enter Postal code'] = 'Si prega di inserire il codice postale';

$lang['Please enter Account holder name'] = 'Please enter Account holder name';

$lang['Please enter Account number'] = 'Si prega di inserire il numero di conto';

$lang['Please enter Account name'] = "Si prega di inserire il nome dell'account";

$lang['Please enter Swift Code'] = 'Per favore inserisci il codice Swift';

$lang['Please enter Bank name'] = 'Si prega di inserire il nome della banca';

$lang['Please enter Bank Address'] = "Per favore inserisci l'indirizzo della banca";

$lang['Please enter Bank City'] = 'Per favore inserisci la città della banca';

$lang['Please select Bank Country'] = 'Si prega di selezionare il Paese della banca';

$lang['Provide Address Proof'] = "Fornire una prova dell'indirizzo";

$lang['No Address proof to cancel'] = 'Nessuna prova di indirizzo da annullare';

$lang['Provide ID Proof'] = 'Provide ID Proof';

$lang['No ID Proof to cancel'] = 'No ID Proof to cancel';

$lang['Provide Photo Proof'] = 'Provide Photo Proof';

$lang['No Photo Proof to cancel'] = 'No Photo Proof to cancel';

$lang['Buy Crypto'] = 'Buy Crypto';

$lang['Choose coin'] = 'Choose coin';

$lang['Enter amount'] = "Inserire l'importo";

$lang['BUY'] = 'BUY';

$lang['Please enter currency'] = 'Please enter currency';

$lang['Please enter amount'] = "Si prega di inserire l'importo";

$lang['Please enter valid amount'] = 'Please enter valid amount';

$lang['Deposit'] = 'Deposita';

$lang['Deposit button'] = 'Ricevi';

$lang['Enter Amount'] = "Inserire l'importo";

$lang['Reference Number'] = 'Numero di riferimento del bonifico';

$lang['Payment Details'] = 'Payment Details';

$lang['Deposit Amount'] = 'Deposit Amount';

$lang['Card Owner'] = 'Card Owner';

$lang['Card number'] = 'Card number';

$lang['Card Type'] = 'Card Type';

$lang['Expiration Date'] = 'Expiration Date';

$lang['CVV'] = 'CVV';

$lang['CONFIRM PAYMENT'] = 'CONFIRM PAYMENT';

$lang['Account Details'] = 'Dettagli conto bancario su cui effettuare il bonifico';

$lang['Account Name'] = 'Nome utente';

$lang['Account Number'] = 'IBAN';

$lang['Swift/BIC Code'] = 'Codice SWIFT/BIC';

$lang['Branch City'] = 'Città filiale';

$lang['Paypal'] = 'Paypal';

$lang['Please Complete KYC'] = 'Si prega di completare KYC';

$lang['Click here'] = 'Clicca qui';

$lang['Coin address'] = 'Coin address';

$lang['Copy'] = 'copia';

$lang['Destination Tag'] = 'Tag di destinazione';

$lang['Important notice'] = 'Important notice';

$lang['It May Take Time For The Network To Confirm The Transaction. We Require %d Network/Block Confirmations.'] = 'It May Take Time For The Network To Confirm The Transaction. We Require %d Network/Block Confirmations.';

$lang['Scan QR Code'] = 'Scan QR Code';

$lang['Wallet Balances'] = 'Wallet Balances';

$lang['Value in USD'] = 'Value in USD';

$lang['Please enter Reference number'] = 'Si prega di inserire il numero di riferimento';

$lang['Please enter Holder Name'] = 'Please enter Holder Name';

$lang['Please enter Card Number'] = 'Please enter Card Number';

$lang['Please enter valid Card Number'] = 'Please enter valid Card Number';

$lang['Please enter Expiry Date'] = 'Please enter Expiry Date';

$lang['Please enter valid Expiry Date'] = 'Please enter valid Expiry Date';

$lang['Please enter Expiry Year'] = 'Please enter Expiry Year';

$lang['Please enter valid Expiry Year'] = 'Please enter valid Expiry Year';

$lang['Please enter CVV'] = 'Please enter CVV';

$lang['Please enter valid CVV'] = 'Please enter valid CVV';

$lang['KYC Status'] = 'KYC Status';

$lang['Pending'] = 'in attesa di conferma della tua identità';

$lang['Completed'] = 'Completato';

$lang['Rejected'] = 'Respinto';

$lang['Withdraw'] = 'Trasferisci';

$lang['Withdraw button'] = 'Ritirare';

$lang['Enter amount to Withdraw'] = 'Enter amount to Withdraw';

$lang['Your coin address'] = 'Your coin address';

$lang['S.no'] = 'S.NO';

$lang['Date & Time'] = 'Date & Time';

$lang['Currency'] = 'Valuta';

$lang['Trans ID'] = 'Trans ID';

$lang['Sent Amount'] = 'Sent Amount';

$lang['Status'] = 'Stato';

$lang['History'] = 'History';

$lang['Buy Crypto'] = 'Buy Crypto';

$lang['Transaction'] = 'Transaction';

$lang['Fees'] = 'Fees';

$lang['Receive Amount'] = 'Receive Amount';

$lang['Type'] = 'Type';

$lang['Pair'] = 'Rapporto';

$lang['Price'] = 'Prezzi';

$lang['Price Menu'] = 'Quotazioni';

$lang['Amount'] = 'Quantità';

$lang['Total'] = 'Totale';

$lang['Action'] = 'Action';

$lang['Inprogress'] = 'Inprogress';

$lang['No records found !!!'] = 'Nessun record trovato !!!';

$lang['IP Address'] = 'IP Address';

$lang['Browser'] = 'Browser';

$lang['Apply for Listing'] = 'Apply for Listing';

$lang['Settings'] = 'Impostazioni';

$lang['Password'] = 'Parola d"ordine';

$lang['Change'] = 'Change';

$lang['Old'] = 'Old';

$lang['New'] = 'New';

$lang['Confirm'] = 'Conferma';

$lang['2 STEP VERIFICATION'] = '2 STEP VERIFICATION';

$lang['To Get The Google Authenticator Details Please'] = 'Per ottenere i dettagli di Google Authenticator, per favore';

$lang['ENABLE'] = 'ABILITARE';

$lang['DISABLE'] = 'DISATTIVARE';

$lang['ENABLE AUTHENTICATION IN 2 STEPS'] = 'ABILITARE AUTENTICAZIONE IN 2 PASSAGGI';

$lang['DISABLE AUTHENTICATION IN 2 STEPS'] = 'DISABILITA AUTENTICAZIONE IN 2 PASSAGGI';

$lang['Scan QR Code In Google Authenticator'] = 'Scan QR Code In Google Authenticator';

$lang['Type The Key Manually'] = 'Digita la chiave manualmente';

$lang['Please enter Old Password'] = 'Si prega di inserire la vecchia password';

$lang['Invalid Old Password'] = 'Vecchia password non valida';

$lang['Please enter New Password'] = 'Si prega di inserire una nuova password';

$lang['Please enter Confirm Password'] = 'Si prega di inserire Conferma password';

$lang['Confirm Password not matches with New Password'] = 'Conferma password non corrispondente a Nuova password';

$lang['Please enter code'] = 'Please enter code';

$lang['Please enter valid code'] = 'Please enter valid code';

$lang['Please 6 digit valid code'] = 'Please 6 digit valid code';

$lang['Select Asset Type'] = 'Select Asset Type';

$lang['COIN'] = 'COIN';

$lang['TOKEN'] = 'TOKEN';

$lang['Full Name of your crypto'] = 'Full Name of your crypto';

$lang['Listing Priority'] = 'Listing Priority';

$lang['Listing Priority'] = 'Listing Priority';

$lang['Cost'] = 'Cost';

$lang['High'] = 'High';

$lang['Standard'] = 'Standard';

$lang['Low'] = 'Low';

$lang['Official Crypto Ticker'] = 'Official Crypto Ticker';

$lang['Logo of Coin (Transparent PNG 250 *250PX)'] = 'Logo of Coin (Transparent PNG 250 *250PX)';

$lang['Maximum Supply'] = 'Maximum Supply';

$lang['Which Blockchain in your crypto based on'] = 'Which Blockchain in your crypto based on';

$lang['Initial Price'] = 'Initial Price';

$lang['COMMUNITY'] = 'COMMUNITY';

$lang['Coin Market Caplink'] = 'Coin Market Caplink';

$lang['Contact Username'] = 'Contact Username';

$lang['Coin Link'] = 'Coin Link';

$lang['Official Twitter Link'] = 'Official Twitter Link';

$lang['Do not need any funds to any address unless you receive mail from our team.'] = 'Do not need any funds to any address unless you receive mail from our team.';

$lang['SUBMIT REQUEST'] = 'SUBMIT REQUEST';

$lang['Please choose coin type'] = 'Please choose coin type';

$lang['Please enter coin name'] = 'Please enter coin name';

$lang['Only strings allowed'] = 'Only strings allowed';

$lang['Please enter coin symbol'] = 'Please enter coin symbol';

$lang['Please enter maximum supply'] = 'Please enter maximum supply';

$lang['Should enter only number'] = 'Should enter only number';

$lang['Please enter coin price'] = 'Please enter coin price';

$lang['Please choose priority'] = 'Please choose priority';

$lang['Please enter username'] = 'Per favore inserisci il nome utente';

$lang['Invalid Format Email'] = 'Invalid Format Email';

$lang['Ticket'] = 'Ticket';

$lang['Category'] = 'Categoria';

$lang['Open'] = 'Aperto';

$lang['Closed'] = 'Chiuso';

$lang['Please enter subject'] = 'Please enter subject';

$lang['Please enter message'] = 'Please enter message';

$lang['Please upload proper file format'] = 'Please upload proper file format';

$lang['Username'] = 'Nome utente';

$lang['Close'] = 'Close';

$lang['Created On'] = 'Creato';

$lang['View'] = 'Visualizza';

$lang['Reply'] = 'Reply';

$lang['Attach Files'] = 'Attach Files';

$lang['Reply Message...'] = 'Reply Message...';

$lang['Remember Me'] = 'Ricordati di me';

$lang['Forgot'] = 'dimenticato';

$lang["Don't have an account?"] = "Don't have an account?";

$lang['Now'] = 'Now';

$lang['Please enter password'] = 'Per favore, inserisci la password';

$lang['Please enter valid tfa code'] = 'Si prega di inserire un codice tfa valido';

$lang['Enter 6 digit valid tfa code'] = 'Inserisci un codice tfa valido a 6 cifre';

$lang['Create your account'] = 'Create your account';

$lang["You're just a few minutes away from trading on LCE global platform."] = "You're just a few minutes away from trading on LCE global platform.";

$lang['Email'] = 'E-mail';

$lang['Country of Residence'] = 'Country of Residence';

$lang['By Continuing I agree to the'] = 'By Continuing I agree to the';

$lang['Terms of Service'] = 'Terms of Service';

$lang['Privacy Policy'] = 'politica sulla riservatezza';

$lang['Please check here'] = 'Please check here';

$lang['Already have an account'] = 'Already have an account';

$lang['Minimum 8 characters, including UPPER / lower case with numbers & special characters'] = 'Scegli una password di almeno 8 caratteri che includa una Maiscola, un numero e un carattere speciale';

$lang['Please enter same password'] = 'Inserisci la stessa password';

$lang['Please select country'] = 'Please select country';

$lang['Please select terms & conditions'] = 'Si prega di selezionare termini e condizioni';

$lang['Reset'] = 'Reset';

$lang['Enter'] = 'Enter';

$lang['Re-enter'] = 'Re-enter';

$lang['MARKETS'] = 'MARKETS';

$lang['PAIR'] = 'PAIR';

$lang['PRICE'] = 'PRICE';

$lang['CHANGE'] = 'CHANGE';

$lang['TRADES'] = 'TRADES';

$lang['AMOUNT'] = 'AMOUNT';

$lang['Buy'] = 'Compra';

$lang['Sell'] = 'Vendi';

$lang['Available'] = 'Available';

$lang['Limit'] = 'Limit';

$lang['Market'] = 'Market';

$lang['Amount in USD'] = 'Amount in USD';

$lang['Order Books'] = 'Order Books';

$lang['TOTAL'] = 'TOTAL';

$lang['Last price'] = 'Ultimo prezzo';

$lang['Orders'] = 'Orders';

$lang['TYPE'] = 'TYPE';

$lang['DATE & TIME'] = 'DATE & TIME';

$lang['DATE'] = 'DATE';

$lang['ORDER TYPE'] = 'ORDER TYPE';

$lang['Please enter valid amount and price'] = 'Si prega di inserire un importo e un prezzo validi';

$lang['Minimum trade amount is'] = "L'importo minimo di scambio è";

$lang['Please enter limit price'] = 'Si prega di inserire il prezzo limite';

$lang['Insufficient balance'] = 'Fondi insufficienti';

$lang['Stop price not same as market price'] = 'Il prezzo di stop non è uguale al prezzo di mercato';

$lang['Limit price not same as market price'] = 'Prezzo limite diverso dal prezzo di mercato market';

$lang['Are you sure you want to cancel this order?'] = 'Sei sicuro di voler annullare questo ordine?';

$lang['No Trade History'] = 'No Trade History';

$lang['No Orders Found'] = 'No Orders Found';

$lang['No Active Orders Found'] = 'No Active Orders Found';

$lang['Your order has been cancelled successfully'] = 'Your order has been cancelled successfully';

$lang['Something went wrong, Please try again later'] = 'Something went wrong, Please try again later';

$lang['Login to your account'] = 'Accedi al tuo account';

$lang['Your order has been placed'] = 'Il tuo ordine è stato inoltrato';

$lang['Upgrade Wallet'] = 'Portafoglio di aggiornamento';

$lang['Invest Money'] = 'Investire denaro';

$lang['Withdrawl Money'] = 'Prelevare denaro';

$lang['Load more'] = 'Mostra ancora';

$lang['Know more'] = 'Scopri di più';

$lang['Learn more'] = 'Per saperne di più';

$lang['Security'] = 'Sicurezza';

$lang['License'] = 'Licenza';

$lang['Result'] = 'Risultato';

$lang['Select Currency'] = 'Seleziona valuta';

$lang['Scan QR Code'] = 'Scansiona il codice QR';

$lang['Copy Address'] = 'Copia indirizzo';

$lang['Send/Receive Currency'] = 'Invia/Ricevi valuta';

$lang['Our Services'] = 'I nostri servizi';

$lang['Help'] = 'Aiuto';

$lang['COMPANY'] = 'AZIENDA';

$lang['SUPPORT'] = 'SUPPORTO';

$lang['address'] = 'indirizzo';

$lang['Enter Your Email Address'] = 'Inserisci il tuo indirizzo email';

$lang['Enter Your Password'] = 'Inserisci la tua password';

$lang['Enter Google Authenticator Code'] = 'Inserisci Google Authenticator Code';

$lang['Forgot Password'] = 'Hai dimenticato la password';

$lang['Sign up'] = 'Iscriviti';

$lang['Don"t have an account?'] = 'Non hai un account?';

$lang['Google Authenticator Code (if enabled)'] = 'Codice Google Authenticator';

$lang['Login with another account'] = 'Accedi con un altro account';

$lang['or'] = 'Oppure';

$lang['Confirm Password'] = 'conferma password';

$lang['Already have an account?'] = 'Hai già un account?';

$lang['Welcome'] = 'Benvenuto';

$lang['Looks like you are not verified yet. Verify yourself to use the full potential of Trade.'] = 'Non hai completato la verifica della tua identità. Completa la verifica per poter iniziare ad utilizzare i servizi. Puoi anche attivare Google Authenticator per proteggere il tuo account.';

$lang['Verify account'] = 'Verifica Account';

$lang['Two-factor authentication (2FA)'] = 'Autenticazione a due fattori (2FA)';

$lang['Enable 2FA authentication']="Completa l'identificazione e l'autenticazione Google Authenticator";

$lang['Disable 2FA authentication']="Completa l'identificazione e l'autenticazione Google Authenticator";

$lang['Edit'] = 'modificare';

$lang['COUNTRY OF RESIDENCE'] = 'PAESE DI RESIDENZA';

$lang['JOINED SINCE'] = 'ISCRITTO DA';

$lang['VERIFY & UPGRADE'] = 'VERIFICA E AGGIORNA';

$lang['Account Status'] = "stato dell'account";

$lang['Verified'] = 'verificato';

$lang['Your account is unverified. Get verified to enable funding, trading, and withdrawal.'] = 'La tua identità non è verificata. Completa il procedimento di verifica per potere accedere a tutte le funzionalità';

$lang['Your account is verified.'] = 'Il tuo account è verificato.';

$lang['Thank you for verified.'] = 'Grazie per aver verificato.';

$lang['Get Verified'] = 'Essere verificato';

$lang['Profile Settings'] = 'Impostazioni del profilo';

$lang['User Profile'] = 'Profilo utente';

$lang['Max file size is 20mb'] = 'La dimensione massima del file è 20mb';

$lang['Save'] = 'Salva';

$lang['Personal Information'] = 'Informazione personale';

$lang['First Name'] = 'Nome';

$lang['Last Name'] = 'Cognome';

$lang['Present Address'] = 'Indirizzo';

$lang['Permanent Address'] = 'Provincia';

$lang['Select'] = 'Selezionare';

$lang['Phone Number'] = 'Numero di telefono';

$lang['Wallet'] = 'Portafoglio';

$lang['Transactions'] = 'Transazioni';

$lang['Coin'] = 'Moneta';

$lang['Available Balance'] = 'saldo disponibile';

$lang['Total Balance'] = 'Saldo totale';

$lang['Euro'] = 'Euro';

$lang['Value'] = 'Valore';

$lang['Estimated Value'] = 'Valore stimato';

$lang['Important'] = 'Important';

$lang['This address is only for'] = 'Questo indirizzo è solo per';

$lang['deposits'] = 'depositi';

$lang['Sending any other coin or token to this address may result in the loss of your deposit and is not eligible for recovery'] = "L'invio di qualsiasi altra moneta o token a questo indirizzo può comportare la perdita del tuo deposito e non è idoneo per il recupero";

$lang['Deposits will automatically be processed after 3 network confirmations. Deposit confirmation can be delayed depending on network conditions.'] = 'I depositi verranno elaborati automaticamente dopo 3 conferme di rete. La conferma del deposito può essere ritardata a seconda delle condizioni della rete.';

$lang['Deposit History'] = 'Cronologia dei depositi';

$lang['Transaction ID'] = 'ID transazione';

$lang['Date & Time'] = 'Data & Tempo';

$lang['Update'] = 'Aggiornare';

$lang['Caution'] = 'Attenzione';

$lang['Withdraw address'] = "Indirizzo a cui trasferire";

$lang['Withdraw Amount'] = "Importo da trasferire";

$lang['Fee'] = 'Commissione';

$lang['Amount You will receive'] = 'Importo che riceverai';

$lang['based'] = 'basato';

$lang['Mobile Money'] = 'Denaro mobile';

$lang['Bank Transfer'] = 'Trasferimento bancario';

$lang['Invalid Amount'] = 'Importo non valido';

$lang['Please select currency'] = 'Seleziona la valuta';

$lang['Please enter numbers only'] = 'si prega di inserire solo numeri';

$lang['Debit/Credit Card'] = 'Carta di debito/credito';

$lang['Withdrawal History'] = 'Cronologia dei prelievi';

$lang['Two-Step Verification'] = 'Attiva Google Authenticator';

$lang['Change Password'] = 'Cambia la password';

$lang['Maximum file size should be below 2mb'] = 'La dimensione massima del file deve essere inferiore a 2 MB';

$lang['Upload Image'] = 'Carica immagine';

$lang['Upload pdf'] = 'Carica pdf';

$lang['Aadhaar Card'] = 'Carta Aadhaar';

$lang['Upload a selfie with Current date'] = 'Carica un selfie con Data attuale';

$lang['Selfie Proof'] = 'A prova di selfie';

$lang['Insert Code to Enable'] = 'Inserisci codice per disabilitare la doppia autenticazione';

$lang['Insert Code to Disable'] = 'Inserisci codice da disabilitare';

$lang['Current Password'] = 'password attuale';

$lang['Enter Your Current Password'] = 'Inserisci la tua password attuale';

$lang['New Password'] = 'nuova password';

$lang['Enter Your New Password'] = 'Inserisci la tua nuova password';

$lang['Confirm New Password'] = 'Conferma la nuova password';

$lang['Enter Your Confirm New Password'] = 'Inserisci la tua Conferma Nuova Password';

$lang['Create your ticket'] = 'Crea il tuo biglietto';

$lang['Browse files'] = 'Sfoglia i file';

$lang['Upload'] = 'Caricare';

$lang['Support History'] = "Storia dell'assistenza";

$lang['Ticket ID'] = 'ID biglietto';

$lang['User Name'] = 'Nome utente';

$lang['Markets'] = 'mercati';

$lang['Volume'] = 'Capitalizzazione';

$lang['24H Change'] = 'Variazione nel Giorno';

$lang['24H High'] = 'Massimo del Giorno';

$lang['24H Low'] = 'Minimo nel Giorno';

$lang['Attachment'] = 'allegato';

$lang['Trade Chart'] = 'Grafico commerciale';

$lang['Pairs'] = 'coppie';

$lang['24h Volume'] = 'Volume 24 ore';

$lang['All Markets'] = 'Tutti i mercati';

$lang['Select Market'] = 'Seleziona mercato';

$lang['Search Coin name'] = 'Cerca indirizzo';

$lang['Learn'] = 'Scopri';

$lang['It begins'] = 'Crea il tuo portafoglio';

$lang['Cancel'] = 'Annulla';

$lang['Bank Wire'] = 'istruzioni Bonifico bancario';

$lang['Bank Wire header'] = 'Bonifico bancario';

$lang['Coin Name'] = 'Nome della moneta';

$lang['Year of business'] = 'Anno di attività';

$lang['Successful transaction'] = 'Transazione riuscita';

$lang['Member since year'] = "Membro dall'anno";

$lang['National TAX Number (TIN)'] = 'Codice fiscale';

$lang['KYC'] = 'Antiriciclaggio';

$lang['Your id document front'] = 'Documento identità fronte';

$lang['Your id document back'] = 'Documento di identità retro';

$lang['The transfer is not revocable'] = 'Il trasferimento è irrevocabile';

$lang['Provide document front'] = 'Provide document front';

$lang['Provide document back'] = 'Provide document back';

$lang['No document to cancel'] = 'No document to cancel';

$lang['Log in to your wallet'] = 'Accedi al tuo portafoglio';

$lang["If you haven't activated the Google Authenticator feature yet, leave the field below blank"] = "Se non hai ancora attivato la funzione Google Authenticator, lascia vuoto il campo sottostante";

$lang['Profile Settings Tab'] = 'i tuoi dati';

$lang['Exchange Tab'] = 'Piattaforma Trading';

$lang['Two-step verification (called “two-factor authentication”) adds an extra layer of security to your account should your password be discovered. in fact, with the activation of the 2-factor authentication, to access your account you will have to use two steps:'] = 'La verifica in due passaggi (detta “autenticazione a due fattori”) aggiunge un ulteriore livello di sicurezza al tuo account nel caso venisse scoperta la tua password. infatti, con I’attivazione dell" autenticazone a 2 fattori, per accedere al tuo account dovarai usare due passagi:';

$lang['- the prime is something you know, for example your password;'] = '-il primo è qualcosa che conosci, ad esempio la tua password;';

$lang['- the second something you own, for example your phone.'] = '-il secondo qualcosa che possiedi,ad esempio il telefono.';

$lang['For more information on Google Authenticator'] = 'Per ulteriori informazioni su Google Authenticator';

$lang['First you need to download the google Authenticator App'] = 'Per prima cosa è necessario scaricare l’App Google Authenticator';

$lang['To enable two-step verification, frame this QRcode with the Google Authenticator App and enter the code generate from you app in the field below.'] = 'Per attivare la doppia autenticazione, inquadra con la tua app Google Authenticator il Qrcode qui accanto ed inserisce il numero che ti verrà generato nel campo sottostante.';

// $lang['or manually enter the alphanumeric code you find under the QRcode below'] = 'oppure inserisci manualmente qui sotto il codice alfanumerico che trovi sotto il QRcode. Usa questo campo anche per inserire il codice per disattivare Google Authenticator';

$lang['Transaction is Pending'] = 'La transazione è in sospeso';

$lang['Simply enter your surname and name as the reason for the transfer, followed by the word "IDENTIFICATION".'] = 'Inserisci come causale del bonifico semplicemente il tuo cognome e il tuo nome, seguite dalla Parola "IDENTIFICAZIONE".';

$lang['After making the transfer, fill in the fields below and upload a payment receipt in .pdf format (the maximum file size must be less than 2 MB)'] = 'Dopo aver effettuato il bonifico, compila i campi sottostanti e carica una ricevuta del versamento in fomato .pdf (la dimensione massima del file deve essere inferiore a 2 MB)';

$lang['Provide Document Front'] = 'Fornire la parte anteriore del documento';

$lang['No Document Front to cancel'] = 'Nessun fronte documento da annullare';

$lang['Provide Document Back'] = 'Fornisci il documento indietro';

$lang['No Document Back to cancel'] = 'Nessun documento Torna per annullare';

$lang['Problem with your document front'] = 'Problema con il fronte del documento';

$lang['Problem with your document back'] = 'Problema con il documento indietro';

$lang['File Size Should be less than 2 MB'] = 'La dimensione del file dovrebbe essere inferiore a 2 MB';

$lang['Please enter first name'] = 'Si prega di inserire il nome';

$lang['Please enter last name'] = 'Per favore inserisci il cognome';

$lang['Please enter DOB'] = 'Si prega di inserire data di nascita';

$lang['Please enter present address'] = "Si prega di inserire l'indirizzo attuale";

$lang['Please enter city'] = "Per favore inserisci la città";

$lang['Please enter letters only'] = 'Si prega di inserire solo lettere';

$lang['Please enter state'] = 'Si prega di inserire lo stato';

$lang['Please enter letters only'] = 'Si prega di inserire solo lettere';

$lang['Please select country'] = 'Seleziona il paese';

$lang['Please enter postal code'] = 'Si prega di inserire il codice postale';

$lang['Please enter phone number'] = 'Si prega di inserire il numero di telefono';

$lang['Please Login'] = 'Accedete, per favore';

$lang['Problem with profile picture'] = "Problema con l'immagine del profilo";

$lang['Your Ethereum Balance is low so you did not able to withdraw for Tether Token'] = 'Il tuo saldo Ethereum è basso, quindi non hai potuto prelevare per il token Tether';

$lang['Your withdraw request has been placed successfully.'] = 'La tua richiesta di prelievo è stata inoltrata con successo.';

$lang['Please try again after some time or contact Admin.'] = "Riprova dopo un po' di tempo o contatta l'amministratore.";

$lang['Your Balance is low so you did not able to withdraw'] = 'Il tuo saldo è basso, quindi non hai potuto prelevare';

$lang['Funds via Mobile Wallet has been Received. Will Process your Payments within few Minutes'] = 'I fondi tramite Mobile Wallet sono stati ricevuti. Elaborerà i tuoi pagamenti entro pochi minuti';

$lang['Unable to Process your Deposit. Please contact Admin.'] = "Impossibile elaborare il tuo deposito. Si prega di contattare l'amministratore.";

$lang['Unable to Process your Deposit.'] = 'Impossibile elaborare il tuo deposito.';

$lang['Payment has been Processing. Please proceed with the popup link'] = 'Il pagamento è in elaborazione. Si prega di procedere con il collegamento popup';

$lang[' withdrawal is Pending. Please use other wallet or be patience'] = ' il ritiro è in sospeso. Per favore usa un altro portafoglio o sii paziente';

$lang['Bank Wire withdrawl request has been received. Will Process your Payment within few Minutes'] = 'La richiesta di prelievo tramite bonifico bancario è stata ricevuta. Elaborerà il tuo pagamento entro pochi minuti';

$lang['Unable to Process your Withdraw. Please contact Admin.'] = "Impossibile elaborare il prelievo. Si prega di contattare l'amministratore.";

$lang['Address Book'] = 'Rubrica';

$lang['Click Here'] = 'Clicca qui';

$lang['Please Complete My Data Information'] = 'Completa i tuoi dati personali.';

$lang['COPIED'] = 'COPIATO';

$lang['select from you address book'] = 'seleziona dalla tua rubrica';

$lang['username signup'] = 'username';

$lang['password signup'] = 'password';

$lang['confirm password signup'] = 'conferma la password';

$lang['Terms and Conditions signup'] = 'Leggi e accetta le condizioni';

$lang['Insert address'] = 'Inserisci indirizzo';

$lang['Added successfully'] = 'Aggiunto con successo';

$lang['Changed successfully'] = 'Modificato con successo';

$lang['Cancelled successfully'] = 'Annullato con successo';

$lang['Please select coin'] = 'Si prega di selezionare la moneta';

$lang['Select coin'] = 'Seleziona moneta';

$lang['Address Management'] = 'Gestione degli indirizzi';

$lang['You performed an operation with this address. Do you want to add it to your address book?'] = 'Hai effettuato un transazione con questo indirizzo. Lo vuoi aggiungere alla tua rubrica?';

$lang['name'] = 'nome';

$lang['coin'] = 'moneta';

$lang['No data available in table'] = 'Nessun dato salvato';

$lang['Showing 0 to 0 of 0 entries'] = 'Mostro 0 risultati su un totale di 0';

$lang['Showing _START_ to _END_ of _TOTAL_ entries'] = 'Mostrando da _START_ a _END_ di _TOTAL_ voci';

$lang['Showing _START_ to _END_ of _TOTAL_ entries Transaction'] = 'Mostro da _START_ a _END_ di _TOTAL_';

$lang['Please enter national tax number'] = 'Si prega di inserire il codice fiscale nazionale';

$lang['(filtered from _MAX_ total entries)'] = '(filtrato da _MAX_ voci totali)';

$lang['Recharge'] = 'Ricarica';

$lang['Deleted successfully'] = 'Eliminato con successo';

$lang['The email addresses is not valid or you left a blank space'] = "L'indirizzo email non è valido oppure hai lasciato uno spazio vuoto.";

$lang['Please check your email to activate Share Coin Exchange account'] = "Controlla la tua email per attivare l'account Share Coin Exchange";

$lang['QR code'] = 'Qrcode';

$lang['Address of sender / receipient'] = 'Indirizzo della controparte';

$lang['Amount'] = 'Ammontare';

$lang['Status'] = 'Stato';

$lang['Send / Receive'] = 'Spedito/Ricevuto';

$lang['Continue with your verification'] = 'Continua con la tua verifica';

$lang['Basic'] = 'Base';

$lang['Advance'] = 'Avanzato';

$lang['Pay'] = 'Paga';

$lang['Your Portfolio'] = 'Il tuo portafoglio';

$lang['Your Transactions'] = 'Le tue transazioni';

$lang['Watchlist'] = 'Quotazioni';

$lang['Received'] = 'Ricevuto';

$lang['Sent'] = 'Inviato';

$lang['Pay with'] = 'Paga con';

$lang['Fee(Other Fee)'] = 'Commissione (altra tariffa)';

$lang['Amount You will receive'] = 'Importo che riceverai';

$lang['balance'] = 'bilancia';

$lang['Name'] = 'Nome';

$lang['Crypto Converter'] = 'Convertitore di criptovalute';

$lang['Amount in Euro'] = 'Importo in Euro';

$lang['Price for coin'] = 'prezzo cripto';

$lang['Trade History'] = 'Storia transazioni';

$lang['Open Order'] = 'ordini aperti';

$lang['Search Address Book Name'] = 'Cerca in rubrica';

$lang['Buy/Sell'] = 'compra/vendi';

$lang['Fiat Withdraw'] = 'Preleva';

$lang['Please enter destination tag'] = 'Si prega di tag di destinazione';

$lang['Amount in'] = 'Importo in';

$lang['Trading'] = 'Trading';

$lang['View asset'] = 'Visualizza risorsa';

$lang['Total in Euro'] = 'Totale';

$lang['Buy Now'] = 'Compra Ora';

$lang['Sell Now'] = 'Vendi Ora';

$lang['Please Complete Bankwire'] = 'Si prega di completare il bonifico';

$lang['Total in'] = 'Totale in';

$lang['Value in'] = 'Valore in';

$lang['Pending Transaction'] = 'In attesa di';

$lang['Cancelled Transaction'] = 'Annullata';

$lang['Date'] = 'Data';

$lang['Type'] = 'Tipo';

$lang['Order Type'] = 'Tipo di ordine';

$lang['ACCEPTED FILE JPG AND PNG ONLY'] = 'SI ACCETTANO SOLO FILE IN FORMATO JPG E PNG';

$lang['Wallet Transactions'] = 'Transazioni di portafoglio';

$lang['Exchange Buy/Sell Transactions'] = 'Scambia transazioni di compra/vendi';

$lang['Select Wallet Type'] = 'Seleziona il tipo di portafoglio';

$lang['Select Email Address'] = 'Seleziona indirizzo e-mail';

?>