<?php
class MY_Form_validation extends CI_Form_validation {

	// Avaliable or not validation
    public function __is_available_referal_code($str, $field)
    {	
    	$CI =& get_instance();
        $CI->load->database();
        sscanf($field, '%[^.].%[^.]', $table, $field);              
        return isset($CI) ? ($CI->db->get_where($table, array($field => $str))->num_rows() === 1) ? TRUE : FALSE : FALSE;
    }
}