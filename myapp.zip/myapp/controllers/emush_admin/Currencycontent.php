<?php
/**
 * Trade_pairs class
 * @package Spiegel Technologies
 * @subpackage ixtokens
 * @author Pilaventhiran
 * @version 1.0
 * @link http://spiegeltechnologies.com/
 * 
 */
 class Currencycontent extends CI_Controller {
 	public function __construct() {
 		parent::__construct();
		$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
		$this->output->set_header("Pragma: no-cache");
		$this->load->library(array('form_validation', 'upload'));
		$this->load->helper(array('url', 'language', 'text'));
		
 	}
	// list
	function index() { 
		// Is logged in
		$sessionvar=$this->session->userdata('loggeduser');
		if (!$sessionvar) {
			admin_redirect('admin', 'refresh');
		}
		$data['currencycontent'] = $this->common_model->getTableData('currencycontent',array(''));
		$data['title'] = 'Currency Content Management';
		
		$data['meta_keywords'] = 'Currency Content Management';
		$data['meta_content'] = 'Currency Content Management';
		$data['main_content'] = 'currencycontent/currencycontent';
		$data['view'] = 'view_all';
		$this->load->view('administrator/admin_template', $data); 
	}
	// Add
	function add() {
		// Is logged in
		$sessionvar=$this->session->userdata('loggeduser');
		if (!$sessionvar) {
			admin_redirect('admin', 'refresh');
		}

		if($this->input->post('lang')==1) {
			$this->form_validation->set_rules('english_title', 'Name', 'required|xss_clean');
			$this->form_validation->set_rules('english_content', 'Content', 'required|xss_clean');	
		} else {
			$this->form_validation->set_rules('italian_title', 'Name', 'required|xss_clean');
			$this->form_validation->set_rules('italian_content', 'Content', 'required|xss_clean');	
		}

		if ($this->input->post()) {				
			if ($this->form_validation->run())
			{
				$insertData=array();
				$lang_id= $this->input->post('lang'); 
				if($lang_id==1) {
					$insertData['english_title'] = $this->input->post('english_title');
					$insertData['english_content'] = $this->input->post('english_content');
				} else if($lang_id==2) {
					$insertData['italian_title'] = $this->input->post('italian_title');
					$insertData['italian_content'] = $this->input->post('italian_content');
				}
				
				$insertData['status'] = $this->input->post('status');
				// Prepare to insert Data
				$insert = $this->common_model->insertTableData('currencycontent', $insertData);
				if ($insert) {
					$this->session->set_flashdata('success', 'Currency Content has been added successfully!');
					admin_redirect('currencycontent', 'refresh');
				} else {
					$this->session->set_flashdata('error', 'Unable to add the currency content !');
					admin_redirect('currencycontent/add', 'refresh');
				}
			}
			else {
				$this->session->set_flashdata('error', 'Some data are missing!');
				admin_redirect('currencycontent/add', 'refresh');
			}
			
		}
		$data['action'] = admin_url() . 'currencycontent/add';
		
		$data['title'] = 'Add Currency Content';
		$data['meta_keywords'] = 'Add Currency Content';
		$data['meta_content'] = 'Add Currency Content';
		$data['main_content'] = 'currencycontent/currencycontent';
		$data['view'] = 'add';
		$this->load->view('administrator/admin_template', $data);
	}
	// Edit page
	function edit($id) {
		// Is logged in
		$sessionvar=$this->session->userdata('loggeduser');
		if (!$sessionvar) {
			admin_redirect('admin', 'refresh');
		}
		// Is valid
		if ($id == '') {
			$this->session->set_flashdata('error', 'Invalid request');
			admin_redirect('currencycontent');
		}
		$isValid = $this->common_model->getTableData('currencycontent', array('id' => $id));
		if ($isValid->num_rows() == 0) {
			$this->session->set_flashdata('error', 'Unable to find this page');
			admin_redirect('currencycontent');
		}
		// Form validation
		if($this->input->post('lang')==1) {
			$this->form_validation->set_rules('english_title', 'Name', 'required|xss_clean');
			$this->form_validation->set_rules('english_content', 'Content', 'required|xss_clean');	
		} else {
			$this->form_validation->set_rules('italian_title', 'Name', 'required|xss_clean');
			$this->form_validation->set_rules('italian_content', 'Content', 'required|xss_clean');	
		}
		
		if ($this->input->post()) {				
			if ($this->form_validation->run())
			{
				$updateData=array();
				$lang_id= $this->input->post('lang'); 
				if($lang_id==1) {
					$updateData['english_title'] = $this->input->post('english_title');
					$updateData['english_content'] = $this->input->post('english_content');
				} else if($lang_id==2) {
					$updateData['italian_title'] = $this->input->post('italian_title');
					$updateData['italian_content'] = $this->input->post('italian_content');
				}
				$updateData['status'] = $this->input->post('status');
				$condition = array('id' => $id);
				$update = $this->common_model->updateTableData('currencycontent', $condition, $updateData);
				if ($update) {
					$this->session->set_flashdata('success', 'Currency Content has been updated successfully!');
					admin_redirect('currencycontent', 'refresh');
				} else {
					$this->session->set_flashdata('error', 'Unable to update this currency content');
					admin_redirect('currencycontent/edit/' . $id, 'refresh');
				}
			}
			else {
				$this->session->set_flashdata('error', 'Unable to update this currency content');
				admin_redirect('currencycontent/edit/' . $id, 'refresh');
			}
			
		}
		$data['currencycontent'] = $isValid->row();
		$data['action'] = admin_url() . 'currencycontent/edit/' . $id;
		$data['title'] = 'Edit Currency Content';
		$data['meta_keywords'] = 'Edit Currency Content';
		$data['meta_content'] = 'Edit Currency Content';
		$data['main_content'] = 'currencycontent/currencycontent';
		$data['view'] = 'edit';
		$this->load->view('administrator/admin_template', $data);
	}
	// Status change
	function status($id,$status) {
		// Is logged in
		$sessionvar=$this->session->userdata('loggeduser');
		if (!$sessionvar) {
			admin_redirect('admin', 'refresh');
		}
		// Check is valid data 
		if ($id == '' || $status == '') { 
			$this->session->set_flashdata('error', 'Invalid request');
			admin_redirect('trade_pairs');
		}
		$isValid = $this->common_model->getTableData('currencycontent', array('id' => $id))->num_rows();
		if ($isValid > 0) { // Check is valid banner 
			$condition = array('id' => $id);
			$updateData['status'] = $status;
			$update = $this->common_model->updateTableData('currencycontent', $condition, $updateData);
			if ($update) { // True // Update success
				if ($status == 1) {
					$this->session->set_flashdata('success', 'Currency Content activated successfully');
				} else {
					$this->session->set_flashdata('success', 'Currency Content de-activated successfully');
				}
				admin_redirect('currencycontent');
			} else { //False
				$this->session->set_flashdata('error', 'Problem occure with currency content status updation');
				admin_redirect('currencycontent');	
			}
		} else {
			$this->session->set_flashdata('error', 'Unable to find this currency content');
			admin_redirect('currencycontent');
		}
	}
	// Delete page
	function delete($id) {
		// Is logged in
		$sessionvar=$this->session->userdata('loggeduser');
		if (!$sessionvar) {
			admin_redirect('admin', 'refresh');
		}
		// Is valid
		if ($id == '') {
			$this->session->set_flashdata('error', 'Invalid request');
			admin_redirect('trade_pairs');
		}
		$isValid = $this->common_model->getTableData('currencycontent', array('id' => $id))->num_rows();
		if ($isValid > 0) { // Check is valid 
			$condition = array('id' => $id);
			$delete = $this->common_model->deleteTableData('currencycontent', $condition);
			if ($delete) { // True // Delete success
				$this->session->set_flashdata('success', 'Currency Content deleted successfully');
				admin_redirect('currencycontent');
			} else { //False
				$this->session->set_flashdata('error', 'Problem occure with team deletion');
				admin_redirect('currencycontent');	
			}
		} else {
			$this->session->set_flashdata('error', 'Unable to find this page');
			admin_redirect('currencycontent');
		}	
	}
 }