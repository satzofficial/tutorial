<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Package extends CI_Controller {

	public function __construct()
	{	
		parent::__construct();		
		$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
		$this->output->set_header("Pragma: no-cache");	
		$this->load->helper(array('url', 'language'));
		$this->load->model('Common_model','com_m');
		// Session Validator		
		$this->session_var=$this->session->userdata('loggeduser');
		if (!$this->session_var) {
			admin_redirect('admin', 'refresh');
		}
		$this->package_url = admin_url() . 'package';
	}


	public function index()
	{

		$data['title'] = 'Package Management';
		$data['meta_keywords'] = 'Package Management';
		$data['meta_description'] = 'Package Management';
		$data['main_content'] = 'packages/package_list';
		$data['package_data'] = $this->com_m->getTableData('package')->result_array();
		$this->load->view('administrator/admin_template', $data); 
	}



	public function add(){
		// Page config
		try {		
			$this->form_validation->set_rules('package_name', 'Package Name', 'required');
			$this->form_validation->set_rules('income', 'Income', 'required');
			// $this->form_validation->set_rules('branch_income', 'Branch Income', 'required');
			// $this->form_validation->set_rules('farming_income', 'Forming Income', 'required');
			// $this->form_validation->set_rules('cultivation_income', 'Cultivation Income', 'required');
			$this->form_validation->set_rules('system_income', 'System Income', 'required');
			$this->form_validation->set_rules('status', 'Status', 'required');	    
			if ($this->form_validation->run() == true)
			{	
				$data = $this->input->post();
				$this->com_m->insertTableData('package', $data);
				$this->session->set_flashdata('success', 'Successfully added your records');
				redirect(admin_url() . 'package');
			}

			// $data['users'] = $this->common_model->getTableData('users',array('verified'=>0))->result();
			$data['title'] = 'Add Package';
			$data['meta_keywords'] = 'Add Package';
			$data['meta_description'] = 'Package Management';
			$data['main_content'] = 'packages/add_package';
			$this->load->view('administrator/admin_template', $data);
		} catch (Exception $e) {
			echo $e->getMessage();exit;
		}

	}


	public function edit($id=NULL){

		try {
			if(!$id){
				return redirect($this->package_url);exit;
			}			
			// Allow valid URL with ID
			if(!$this->com_m->getrow('package',['id' => $id])){
				return redirect($this->package_url);exit;	
			}

			$this->form_validation->set_rules('package_name', 'Package Name', 'required');
			$this->form_validation->set_rules('income', 'Income', 'required');
			// $this->form_validation->set_rules('branch_income', 'Branch Income', 'required');
			// $this->form_validation->set_rules('farming_income', 'Forming Income', 'required');
			// $this->form_validation->set_rules('cultivation_income', 'Cultivation Income', 'required');
			$this->form_validation->set_rules('system_income', 'System Income', 'required');
			$this->form_validation->set_rules('status', 'Status', 'required');	    
			if ($this->form_validation->run() == true)
			{	

				$data = $this->input->post();
				$this->com_m->updateTableData('package',['id' => $id], $data);
				$this->session->set_flashdata('success', 'Successfully added your records');
				redirect($this->package_url);
			}
			$data['title'] = 'Add Package';
			$data['meta_keywords'] = 'Add Package';
			$data['meta_description'] = 'Package Management';
			$data['main_content'] = 'packages/add_package';
			$data['package_data'] = $this->com_m->getTableData('package',['id' => $id])->row_array();
			$this->load->view('administrator/admin_template', $data); 

		} catch (Exception $e) {
			echo $e->getMessage();exit;
		}
	}


	public function status(){
		try {	
			if (!$this->input->is_ajax_request()) {
				exit('No direct script access allowed');
			}					
			if($this->input->post('id')){
				$id = $this->input->post('id');
				$status = $this->input->post('status');
				$this->com_m->updateTableData('package', ['id' => $id], ['status' => $status]);
				echo json_encode(['status' => 'true' , 'messages' => 'successfully updated']);exit;
			}
		} catch (Exception $e) {			
			echo json_encode(['status' => 'false', 'messages' => $e->getMessage()]);exit;        	
		}    	
	}




	public function branch_income($id=NULL){
		try {
			if(!$id){
				return redirect($this->package_url);exit;
			}			
			// Allow valid URL with ID
			if(!$this->com_m->get_row_counter('package',['id' => $id])){
				return redirect($this->package_url);exit;	
			}

			$conditions = ['package_id' => $id];

			$this->form_validation->set_rules('income_l1', 'Level 1', 'required');
			$this->form_validation->set_rules('income_l2', 'level 2', 'required');
			$this->form_validation->set_rules('income_l3', 'level 3', 'required');
			$this->form_validation->set_rules('income_l4', 'level 4', 'required');
			$this->form_validation->set_rules('income_l5', 'level 5', 'required');
			$this->form_validation->set_rules('income_l6', 'level 6', 'required');
			$this->form_validation->set_rules('income_l7', 'level 7', 'required');
			$this->form_validation->set_rules('income_l8', 'level 8', 'required');
			if ($this->form_validation->run() == true)
			{	
				$data = $this->input->post();							
				$data['package_id'] = $id;				
				$this->com_m->insert_update_avail('branch_income_chart', $data, $conditions);				
				$sum_of_branch_income = 0;				
				$sd=0;
				foreach ($data as $dkey => $dvalue) {
					$k = 'income_l'.$sd++;
					$sum_of_branch_income += $data[$k];
				}										
				$udata = ['branch_income' => $sum_of_branch_income ];
				$conditions1 = ['id' => $id ];
				$this->com_m->insert_update_avail('package', $udata, $conditions1);		

				$this->session->set_flashdata('success', 'Successfully added your records');
				// redirect($this->package_url);
			}

			$data['title'] = 'Add Package Branch Income';
			$data['meta_keywords'] = 'Add Package Branch Income';
			$data['meta_description'] = 'Package Management';
			$data['main_content'] = 'packages/package_branch_income';
			$data['package_data'] = $this->com_m->getTableData('branch_income_chart',$conditions)->row_array();
			$this->load->view('administrator/admin_template', $data); 

		} catch (Exception $e) {
			echo $e->getMessage();exit;
		}
	}



	public function global_farming_income($id=NULL){
		try {
			if(!$id){
				return redirect($this->package_url);exit;
			}			
			// Allow valid URL with ID
			if(!$this->com_m->getrow('package',['id' => $id])){
				return redirect($this->package_url);exit;	
			}

			$conditions = ['package_id' => $id];
			$data['id'] = $id;
			$data['title'] = 'Global Farming Income Chart';
			$data['meta_keywords'] = 'Global Farming Income Chart';
			$data['meta_description'] = 'Global Farming Management';
			$data['main_content'] = 'packages/package_global_farming_income';
			$data['global_farming_income'] = $this->com_m->getTableData('farming_income_chart',$conditions)->result_array();
			$this->load->view('administrator/admin_template', $data); 

		} catch (Exception $e) {
			echo $e->getMessage();exit;
		}
	}




	public function add_gfi($package_id=NULL){
		try {
			if(!$package_id){
				return redirect($this->package_url);exit;
			}			
			// Allow valid URL with ID
			if(!$this->com_m->getrow('package',['id' => $package_id])){
				return redirect($this->package_url);exit;	
			}
			$conditions = ['package_id' => $package_id];
			$this->form_validation->set_rules('price', 'Price', 'required');
			$this->form_validation->set_rules('user', 'User', 'required');
			$this->form_validation->set_rules('total', 'Total', 'required');
			// $this->form_validation->set_rules('ap_upgrade', 'Ap upgrade', 'required');
			// $this->form_validation->set_rules('rebirth', 'Rebirth', 'required');
			$this->form_validation->set_rules('to_sponsor', 'To Sponsor', 'required');
			$this->form_validation->set_rules('profit', 'Profit', 'required');			
			if ($this->form_validation->run() == true)
			{	
				$data = $this->input->post();
				$data['package_id'] = $package_id;
				$this->com_m->insert('farming_income_chart', $data);

				$farming = $this->com_m->get_row_val('farming_income_chart',['package_id' => $package_id, 'status' => 1 ],"sum(price)");
				$udata = ['farming_income' => $farming ];
				$conditions1['id'] = $package_id;
				$this->com_m->insert_update_avail('package', $udata, $conditions1);

				$this->session->set_flashdata('success', 'Successfully added your records');
				redirect($this->package_url.'/global_farming_income/'.$package_id);
			}


			$data['package_id'] = $package_id;
			$data['title'] = 'Global Farming Income Chart';
			$data['mode'] = 'add';
			$data['meta_keywords'] = 'Global Farming Income Chart';
			$data['meta_description'] = 'Global Farming Management';
			$data['main_content'] = 'packages/add_gfi';
			// $data['package_data'] = $this->com_m->getTableData('farming_income_chart',$conditions)->row_array();			
			$this->load->view('administrator/admin_template', $data); 

		} catch (Exception $e) {
			echo $e->getMessage();exit;
		}
	}


	
	public function edit_gfi($package_id=NULL, $id=NULL){
		try {
			if(!$id && !$package_id){
				return redirect($this->package_url);exit;
			}			
			// Allow valid URL with ID
			if(!$this->com_m->getrow('package',['id' => $package_id]) && !$this->com_m->getrow('farming_income_chart',['id' => $id])){
				return redirect($this->package_url);exit;	
			}

			$conditions = ['package_id' => $package_id, 'id' => $id ];

			$this->form_validation->set_rules('price', 'Price', 'required');
			$this->form_validation->set_rules('user', 'User', 'required');
			$this->form_validation->set_rules('total', 'Total', 'required');
			// $this->form_validation->set_rules('ap_upgrade', 'Ap upgrade', 'required');
			// $this->form_validation->set_rules('rebirth', 'Rebirth', 'required');
			$this->form_validation->set_rules('to_sponsor', 'To Sponsor', 'required');
			$this->form_validation->set_rules('profit', 'Profit', 'required');			
			if ($this->form_validation->run() == true)
			{	
				$data = $this->input->post();				
				$this->com_m->update('farming_income_chart', $data, $conditions);

				$farming = $this->com_m->get_row_val('farming_income_chart',['package_id' => $package_id, 'status' => 1 ],"sum(price)");
				$udata = ['farming_income' => $farming ];
				$conditions1['id'] = $package_id;
				$this->com_m->insert_update_avail('package', $udata, $conditions1);

				$this->session->set_flashdata('success', 'Successfully added your records');
				redirect($this->package_url.'/global_farming_income/'.$package_id);
			}


			$data['package_id'] = $package_id;
			$data['mode'] = 'edit';
			$data['title'] = 'Global Farming Income Chart';
			$data['meta_keywords'] = 'Global Farming Income Chart';
			$data['meta_description'] = 'Global Farming Management';
			$data['main_content'] = 'packages/add_gfi';
			$data['package_data'] = $this->com_m->getTableData('farming_income_chart',$conditions)->row_array();			
			$this->load->view('administrator/admin_template', $data); 

		} catch (Exception $e) {
			echo $e->getMessage();exit;
		}
	}



	// Cultivate income 


	public function global_cultivate_income($id=NULL){
		try {
			if(!$id){
				return redirect($this->package_url);exit;
			}			
			// Allow valid URL with ID
			if(!$this->com_m->getrow('package',['id' => $id])){
				return redirect($this->package_url);exit;	
			}

			$conditions = ['package_id' => $id];
			$data['id'] = $id;
			$data['title'] = 'Global Farming Income Chart';
			$data['meta_keywords'] = 'Global Farming Income Chart';
			$data['meta_description'] = 'Global Farming Management';
			$data['main_content'] = 'packages/package_global_cultivation_income';
			$data['global_farming_income'] = $this->com_m->getTableData('cultivation_income_chart',$conditions)->result_array();
			$this->load->view('administrator/admin_template', $data); 

		} catch (Exception $e) {
			echo $e->getMessage();exit;
		}
	}




	public function add_gci($package_id=NULL){
		try {
			if(!$package_id){
				return redirect($this->package_url);exit;
			}			
			// Allow valid URL with ID
			if(!$this->com_m->getrow('package',['id' => $package_id])){
				return redirect($this->package_url);exit;	
			}
			$conditions = ['package_id' => $package_id];
			$this->form_validation->set_rules('price', 'Price', 'required');
			$this->form_validation->set_rules('user', 'User', 'required');
			$this->form_validation->set_rules('total', 'Total', 'required');
			// $this->form_validation->set_rules('ap_upgrade', 'Ap upgrade', 'required');
			// $this->form_validation->set_rules('rebirth', 'Rebirth', 'required');
			$this->form_validation->set_rules('to_sponsor', 'To Sponsor', 'required');
			$this->form_validation->set_rules('profit', 'Profit', 'required');			
			if ($this->form_validation->run() == true)
			{	
				$data = $this->input->post();
				$data['package_id'] = $package_id;
				$this->com_m->insert('cultivation_income_chart', $data);


				$farming = $this->com_m->get_row_val('cultivation_income_chart',['package_id' => $package_id ],"sum(price)");
				$udata = ['cultivation_income' => $farming ];
				$conditions1['id'] = $package_id;
				$this->com_m->insert_update_avail('package', $udata, $conditions1);

				$this->session->set_flashdata('success', 'Successfully added your records');
				redirect($this->package_url.'/global_cultivate_income/'.$package_id);
			}
			$data['package_id'] = $package_id;
			$data['title'] = 'Global Farming Income Chart';
			$data['mode'] = 'add';
			$data['meta_keywords'] = 'Global Farming Income Chart';
			$data['meta_description'] = 'Global Farming Management';
			$data['main_content'] = 'packages/add_gci';
			// $data['package_data'] = $this->com_m->getTableData('farming_income_chart',$conditions)->row_array();			
			$this->load->view('administrator/admin_template', $data); 

		} catch (Exception $e) {
			echo $e->getMessage();exit;
		}
	}


	
	public function edit_gci($package_id=NULL, $id=NULL){
		try {
			if(!$id && !$package_id){
				return redirect($this->package_url);exit;
			}			
			// Allow valid URL with ID
			if(!$this->com_m->getrow('package',['id' => $package_id]) && !$this->com_m->getrow('farming_income_chart',['id' => $id])){
				return redirect($this->package_url);exit;	
			}

			$conditions = ['package_id' => $package_id, 'id' => $id ];

			$this->form_validation->set_rules('price', 'Price', 'required');
			$this->form_validation->set_rules('user', 'User', 'required');
			$this->form_validation->set_rules('total', 'Total', 'required');
			// $this->form_validation->set_rules('ap_upgrade', 'Ap upgrade', 'required');
			// $this->form_validation->set_rules('rebirth', 'Rebirth', 'required');
			$this->form_validation->set_rules('to_sponsor', 'To Sponsor', 'required');
			$this->form_validation->set_rules('profit', 'Profit', 'required');			
			if ($this->form_validation->run() == true)
			{	
				$data = $this->input->post();				
				$this->com_m->update('cultivation_income_chart', $data, $conditions);

				$farming = $this->com_m->get_row_val('cultivation_income_chart',['package_id' => $package_id ],"sum(price)");
				$udata = ['cultivation_income' => $farming ];
				$conditions1['id'] = $package_id;
				$this->com_m->insert_update_avail('package', $udata, $conditions1);


				$this->session->set_flashdata('success', 'Successfully added your records');
				redirect($this->package_url.'/global_cultivate_income/'.$package_id);
			}


			$data['package_id'] = $package_id;
			$data['mode'] = 'edit';
			$data['title'] = 'Global Farming Income Chart';
			$data['meta_keywords'] = 'Global Farming Income Chart';
			$data['meta_description'] = 'Global Farming Management';
			$data['main_content'] = 'packages/add_gci';
			$data['package_data'] = $this->com_m->getTableData('cultivation_income_chart',$conditions)->row_array();			
			$this->load->view('administrator/admin_template', $data); 

		} catch (Exception $e) {
			echo $e->getMessage();exit;
		}
	}





}

/* End of file package.php */
/* Location: ./application/controllers/tenrealm_admin/package.php */