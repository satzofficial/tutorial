<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use Nullix\CryptoJsAes\CryptoJsAes;


class User extends MY_Controller {

    public $outputData;
    public $default_currency_symbol;
    public $view_table;
    public function __construct()
    {   
        parent::__construct();
        
        $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
        $this->output->set_header("Pragma: no-cache");

        $this->load->is_loaded('form_validation');      
        $this->load->is_loaded('session');

        // Switch to the MCrypt driver
        // $this->encryption->initialize(array('driver' => 'mcrypt'));

        // Switch back to the OpenSSL driver
        $this->encryption->initialize(array('driver' => 'openssl'));    

        // $this->db->query("SET GLOBAL sql_mode=(SELECT REPLACE(@@sql_mode,'ONLY_FULL_GROUP_BY',''));");

        ini_set('MAX_EXECUTION_TIME', '-1');

        if($user_id = $this->session->userdata('user_id')){
            
            // To check every request is verified or not
            if(!$this->com_m->get_row_counter('users', array('id' => $user_id, 'verified' => '1'))){
                $info = 'Please check your email to activate account Or Contact admin';

                $this->session->unset_userdata('user_id');
                $this->session->unset_userdata('pass_changed');
                $tokenvalues = $this->session->userdata('tokenvalues');
                $depositvalues = $this->session->userdata('depositvalues');
                if(isset($tokenvalues) && !empty($tokenvalues))
                {
                    $this->session->unset_userdata('tokenvalues');
                }
                if(isset($depositvalues) && !empty($depositvalues))
                {
                    $this->session->unset_userdata('depositvalues');
                }

                if($this->input->is_ajax_request()){
                    echo json_encode(['status' => false, 'msg' => $info ]);
                }

                $this->session->set_flashdata('home_page_info_msg', $info);
                redirect('/','refresh');
            }
            $this->outputData['default_currency_symbol'] = (getcoindetail('LTC')->currency_symbol) ? getcoindetail('LTC')->currency_symbol : 'LTC';
        }

        $this->view_table = '_view';
        $this->_encpassword = md5( $this->security->get_csrf_hash() );
        define("DATADECRYPTPASSWORD", $this->_encpassword );    
    }
    function switchLang($language = "") 
    {
       $language = ($language != "") ? $language : "english";
       $this->session->set_userdata('site_lang', $language);
       redirect($_SERVER['HTTP_REFERER'], 'refresh');
    }
  
  function testnew(){
    $this->load->view('index');
  
  }


  
    public function block()
    {
        $cip = get_client_ip();
        $match_ip = $this->common_model->getTableData('page_handling',array('ip'=>$cip))->row();
        if($match_ip > 0)
        {
        return 1;
        }
        else
        {
        return 0;
        }
    }
    
      public function deposit_page($currency){

        if(!$currency){
            redirect('payment');
        }

        $user_id=$this->session->userdata('user_id');
        if(!$user_id)
        {   
            front_redirect('home');
        }

        if($this->input->post()){
            $insertData = array('user_id' => $user_id);

            if ($_FILES['profile_photo']['name']) 
                {
                    $imagepro = $_FILES['profile_photo']['name'];
                    if($imagepro!="" && getExtension($_FILES['profile_photo']['type']))
                    {
                        $uploadimage1=cdn_file_upload($_FILES["profile_photo"],'uploads/deposit_page/'.$user_id,$this->input->post('profile_photos'));
                        if($uploadimage1)
                        {
                            $imagepro=$uploadimage1['secure_url'];
                        }
                        else
                        {
                            $this->session->set_flashdata('error', $this->lang->line('Problem with profile picture'));
                            front_redirect('profile', 'refresh');
                        } 
                    }               
                    $insertData['image']=$imagepro;
                }

                $insertData['hash'] = $this->input->post('hash');
                $insertData['amount'] = $this->input->post('amount');
                $insertData['currency'] = $currency;
                $insertData['status'] = 0;

                $insert = $this->common_model->insertTableData('deposit_verify', $insertData);
                $this->session->set_flashdata('success', 'waiting for admin approval.');
                redirect('payment');
                
                
                
        }



    $user_id=$this->session->userdata('user_id');
    
        $bankwire = $this->common_model->getTableData('admin_bank_details',array('id'=>1))->row();
    
        $data['user'] = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
        
        
    $data['currency']=$currency;
    
        $data['site_common'] = site_common();
        $this->load->view('front/user/payment_make', $data);



    }


    public function withdraw_page($currency){

        if(!$currency){
            redirect('payment');
        }

        $user_id=$this->session->userdata('user_id');
        if(!$user_id)
        {   
            front_redirect('home');
        }

        if($this->input->post()){
            $insertData = array('user_id' => $user_id);

            // if ($_FILES['profile_photo']['name']) 
            //  {
            //      $imagepro = $_FILES['profile_photo']['name'];
            //      if($imagepro!="" && getExtension($_FILES['profile_photo']['type']))
            //      {
            //          $uploadimage1=cdn_file_upload($_FILES["profile_photo"],'uploads/deposit_page/'.$user_id,$this->input->post('profile_photos'));
            //          if($uploadimage1)
            //          {
            //              $imagepro=$uploadimage1['secure_url'];
            //          }
            //          else
            //          {
            //              $this->session->set_flashdata('error', $this->lang->line('Problem with profile picture'));
            //              front_redirect('profile', 'refresh');
            //          } 
            //      }               
            //      $insertData['image']=$imagepro;
            //  }

                // $insertData['hash'] = $this->input->post('hash');
                $insertData['amount'] = $this->input->post('amount');
                $insertData['currency'] = $currency;
                $insertData['status'] = 2; // 2waiting for admin approval

                $insert = $this->common_model->insertTableData('withdraw_verify', $insertData);
                $this->session->set_flashdata('success', 'waiting for admin approval.');
                redirect('payment');
        }
        
            $user_id=$this->session->userdata('user_id');
    
        $bankwire = $this->common_model->getTableData('admin_bank_details',array('id'=>1))->row();
    
        $data['user'] = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
        
        
    $data['currency']=$currency;

        $data['site_common'] = site_common();
        $this->load->view('front/user/payment_make', $data);



    }

    
    public function block_ip()
    {
        $this->load->view('front/common/blockips');
    }
    function login()
    {       
        $user_id=$this->session->userdata('user_id');
        if($user_id)
        {   
            front_redirect('dashboard');
        }
        $data['site_common'] = site_common();
        $static_content  = $this->common_model->getTableData('static_content',array('english_page'=>'home'))->result();
        $data['meta_content'] = $this->common_model->getTableData('meta_content',array('link'=>'login'))->row();
        $data['action'] = front_url() . 'login_user';       
        $this->load->view('front/user/login', $data);
    }
    public function login_check()
    {
        $ip_address = get_client_ip();

        // $check->id = 2;
        // $session_data = array('user_id' => $check->id);
        // $this->session->set_userdata($session_data);
        // $this->common_model->last_activity('Login', $check->id);
        // $this->session->set_flashdata('success', $this->lang->line('Welcome back . Logged in Successfully'));
        // $array['msg'] = $this->lang->line('Welcome back . Logged in Successfully');
        // $array['login_url'] = 'dashboard';
        // redirect('dashboard');exit;

        $array = array('status' => 0, 'msg' => '');
        $this->form_validation->set_rules('tenrealm_email', 'Email', 'trim|required|xss_clean');
        $this->form_validation->set_rules('tenrealm_password', 'Password', 'trim|required|xss_clean');
        // When Post
        if ($this->input->post()) {
            if ($this->form_validation->run()) {                
                $email = escape_str(lcfirst($this->input->post('tenrealm_email',TRUE)));
                $password = escape_str($this->input->post('tenrealm_password',TRUE));
                $prefix = get_prefix();
                // Validate email
                $email = preg_replace('/\s+/', '', $email);
                if (filter_var($email, FILTER_VALIDATE_EMAIL)) {                    
                    $this->form_validation->set_rules('tenrealm_email', 'Email', 'trim|required|xss_clean|valid_email');
                    if ($this->form_validation->run()) {                    
                    $check = checkSplitEmailOrInteger($password, $email);
                     }else{
                       $this->session->set_flashdata('error', validation_errors());
                       redirect('signin');
                    }      
                    echo 'SATZ2';                
                // }else if (filter_var($email, FILTER_VALIDATE_INT)) {      
                }else {      
                echo 'SATZ3';         
                    $this->form_validation->set_rules('tenrealm_email', 'Number', 'trim|min_length[8]|required|xss_clean|max_length[16]');
                    if ($this->form_validation->run()) {                    
                        $check = checkSplitEmailOrInteger($password, '', $email); 
                    }else{                      
                       $this->session->set_flashdata('error', validation_errors());
                       redirect('signin');
                    }                   
                }
                
                if (!$check) {                  
                    $array['msg'] = $this->lang->line('Enter Valid Login Details');  
                    $this->session->set_flashdata('error', $array['msg']);
                    redirect('signin');
                } else {
                    if ($check->verified != 1) {                          
                        $this->session->set_flashdata('error', 'Please check your email to activate account');
                        redirect('signin');
                    } else { 
                        $session_data = array('user_id' => $check->id);
                        $this->session->set_userdata($session_data);
                        $this->common_model->last_activity('Login', $check->id);
                        $this->session->set_flashdata('success', $this->lang->line('Welcome back . Logged in Successfully'));
                        $array['msg'] = $this->lang->line('Welcome back . Logged in Successfully');
                        $array['login_url'] = 'dashboard';
                        redirect('dashboard');exit;
                    }    
                 
                }
            }             
        } else {
            $this->session->set_flashdata('error', $this->lang->line('Login error'));            
            redirect('signin');
        }        
        redirect('signin');exit;        
    }

    function packages(){

        $data['packages_arr'] = $this->common_model->getTableData('tenrealm_package', array('status' => '1'))->result_array();
        $this->load->view('front/user/packages', $data);
    }





    function checktfa($user_id,$code)
    {
        $this->load->library('Googleauthenticator');
        $ga     = new Googleauthenticator();
        $result = $this->common_model->getTableData('users', array('id' => $user_id))->row_array();
        if(count($result)){
            $secret = $result['secret'];
            $oneCode = $ga->verifyCode($secret,$code,$discrepancy = 3);
            if($oneCode==1)
            {
                return true;
            }
            else
            {
                return false;
            }
       }else
       return false;
    }
    function forgot_user()
    {
        //If Already logged in
        $user_id=$this->session->userdata('user_id');
        if($user_id!="")
        {   
            front_redirect('dashboard', 'refresh');
        }
        $data['site_common'] = site_common();
        $data['meta_content'] = $this->common_model->getTableData('meta_content', array('link' => 'forgot_password'))->row();
        $data['action'] = front_url() . 'forgot_user';
        $data['js_link'] = 'forgot';
        $this->load->view('front/user/forgot_password', $data);
    }
    function forgot_check()
    { 
        $array=array('status'=>0,'msg'=>'');
        $this->form_validation->set_rules('forgot_detail', 'Email or Phone', 'trim|required|xss_clean');
        // When Post
        if ($this->input->post())
        { 
            if ($this->form_validation->run())
            {

                $email = $this->input->post('forgot_detail');
                $uid = $this->input->post('uid');
                $prefix=get_prefix();
                // Validate email
                if (filter_var($email, FILTER_VALIDATE_EMAIL))
                {
                    $check=checkSplitEmail($email);
                    $type=1;
                }
                else
                {
                    $check=checkElseEmail($email);
                    $type=2;
                }
                if (!$check)
                {
                    $msg =$this->lang->line('User does not Exists');
                    $this->session->set_flashdata('error', $msg);
                    redirect('forgot-password');exit;
                }
                else
                {
                        $array['status']=1;
                        $key = sha1(mt_rand() . microtime());
                        $update = array(
                        'forgotten_password_code' => $key,
                        'forgotten_password_time' => time(),
                        'forgot_url'=>0
                        );
                        $link=front_url().'reset_pw_user/'.$key.'/'.$uid;
                        $this->common_model->last_activity('Forgot Password',$check->id);
                        $this->common_model->updateTableData('users',array('id'=>$check->id),$update);

                            $to         = getUserEmail($check->id);
                            $email_template = 3;
                            $username=$prefix.'username';
                            $site_common      =   site_common();
                            $special_vars = array(                  
                            '###USERNAME###' => $check->$username,
                            '###LINK###' => $link
                            );
                 

                            if(!$this->email_model->sendMail($to, '', '', $email_template,$special_vars)){
                                $messages = 'Internal Server Error';
                                $this->session->set_flashdata('error', $messages);
                                redirect('forgot-password');exit;
                            }else{
                                $messages = 'Password reset link is sent to your email';
                                $this->session->set_flashdata('success', $messages);
                                redirect('forgot-password');exit;
                            }
                            
                }
            }
            else
            {
                $error=validation_errors();
                $this->session->set_flashdata('error', $error);
                redirect(current_url());
            }
        }
        else
        {
            $this->session->set_flashdata('error', $this->lang->line('Login error'));
            $array['msg']=$this->lang->line('Login error');
            redirect(current_url());
        }   
        redirect('forgot-password');exit;       
    }


    function reset_pw_user($code = NULL, $uid = NULL)
    {
        if (!$code)
        {   
            $this->session->set_flashdata('error', $this->lang->line('Invalid URL'));
            front_redirect('forgot-password', 'refresh');
        }
        $profile = $this->common_model->getTableData('users', array('forgotten_password_code' => $code,'  unique_id'=>$uid))->row(); 
        if($profile)
        {               
            if($profile->forgot_url!=1)
            {
                $expiration=15*60;
                if (time() - $profile->forgotten_password_time < $expiration)
                {   
                    $this->form_validation->set_rules('reset_password', 'Password', 'trim|required|xss_clean');
                    // When Post
                    if ($this->input->post())
                    {
                        if ($this->form_validation->run())
                        {
                            $prefix=get_prefix();
                            $password=$this->input->post('reset_password');
                            $data = array(
                                $prefix.'password'                  => encryptIt($password),
                                'forgotten_password_code'           => NULL,
                                'verified'                          => 1,
                                'forgot_url'                        => 1
                            );
                            $this->common_model->last_activity('Password Reset',$profile->id);
                            $this->common_model->updateTableData('users',array('forgotten_password_code'=>$code),$data);
                            $this->session->set_flashdata('success',$this->lang->line('Password reset successfully'));
                            front_redirect('login','refresh');
                        }
                        else
                        {
                            $this->session->set_flashdata('error', $this->lang->line('Enter Password and Confirm Password'));
                            front_redirect('reset_pw_user/'.$code,'refresh');
                        }   
                    }
                    $data['action'] = front_url() . 'reset_pw_user/'.$code;
                    $data['site_common'] = site_common();
                    $data['meta_content'] = $this->common_model->getTableData('meta_content', array('link' => 'reset_password'))->row();
                    $data['js_link'] = 'reset_password';
                    $this->load->view('front/user/reset_pwd', $data);
                }
                else
                {
                    $this->session->set_flashdata('error', $this->lang->line('Link Expired'));
                    front_redirect('forgot-password', 'refresh');
                }
            }
            else
            {
                $this->session->set_flashdata('error', $this->lang->line('Already reset password using this link'));
                front_redirect('forgot-password', 'refresh');
            }
        }
        else
        {           
            $this->session->set_flashdata('error', $this->lang->line('Not a valid link'));
            front_redirect('forgot-password', 'refresh');
        }
    }


function terms(){

  $this->load->view('front/emesh/terms');

}

    function signup()
    {   
        
        
        $prefix=get_prefix();
        $data['site_common'] = site_common();       
        if($data['site_common']['site_settings']->newuser_reg_status==0){           
            front_redirect('/', 'refresh');
        }

        if($ref = $this->input->get('ref',true)){   
            $user_id = unique_id_to_user_id($ref);      
            if($this->com_m->get_row_counter('users',['id' => $user_id, 'rebirth_status' => '0' ]) == 1){}else{
                $this->session->set_flashdata('error', 'Invalid reference id');
                redirect('register','refresh');
            }   
        }       

        $data['meta_content'] = $this->common_model->getTableData('meta_content',array('link'=>'signup'))->row();
        $newuser_reg_status = getSiteSettings('newuser_reg_status');
        $user_id = $this->session->userdata('user_id');
        if($user_id!="" || $newuser_reg_status==0)
        {               
            front_redirect('dashboard', 'refresh');
        }   

        if($this->input->post())
        {   
            try {

                // if($parent = $this->input->post('parent', true)!=REGISTER_VAR){
                //  $this->form_validation->set_rules('parent', 'Referal Code', 
                //              'trim|__is_available_referal_code['.$prefix.'users.unique_id]|xss_clean', 
                //              array('__is_available_referal_code' => 'The %s is invalid code 123'));  
                // }


                // $this->form_validation->set_rules('parent', 'Referal Code', 
                //              'trim|required|callback_valid_unique_id', 
                //              array('__is_available_referal_code' => 'The %s is invalid code 69867'));

                $this->form_validation->set_rules('first_name', 'Username', 'trim|required|xss_clean');
                $this->form_validation->set_rules('tenrealm_email', 'Email Address', 'trim|required|xss_clean');
                $this->form_validation->set_rules('tenrealm_password', 'Password', 'trim|required|xss_clean');
                $this->form_validation->set_rules('beb_address', 'Beb Address', 'trim|required|xss_clean');
                $this->form_validation->set_rules('phone', 'phone', 'trim|required|xss_clean');
                $this->form_validation->set_rules('beb_address', 'Beb Address', 'trim|required|xss_clean');
                
                if ($this->form_validation->run())
                {                   
                    $email = $this->db->escape_str(lcfirst($this->input->post('tenrealm_email',TRUE)));
                    $password = $this->db->escape_str($this->input->post('tenrealm_password',TRUE));
                    $uname = $this->db->escape_str($this->input->post('first_name',TRUE));
                    // $check=checkSplitEmail($email);
                    
                    // $check1=$this->common_model->getTableData('users',array($prefix.'username'=>$uname));
                    // if($check)
                    // {                    
                    //  $this->session->set_flashdata('error',$this->lang->line('Entered Email Address Already Exists'));
                    //  front_redirect('register', 'refresh');
                    // }
                    // else
                    // {    
                        // $this->db->trans_start();                    
                        // All constraint success
                        if(!$this->input->post('parent', true) OR $parent = $this->input->post('parent', true)==REGISTER_VAR){
                            // Without reference
                            $this->register_insert();
                        }else{

                            // $beb_address = $this->db->escape_str($this->input->post('beb_address',TRUE));
                            // With referral
                            $this->register_insert();
                        }
                        // $this->db->trans_complete();
                        
                    // }
                }
            } catch (Exception $e) {
             // this will not catch DB related errors. But it will include them, because this is more general.                      
                $message = $e->getMessage();
                $search = 'Duplicate entry ';
                if(preg_match("/{$search}/i", $message)) {              
                    $this->register_insert();
                }               
                $this->session->set_flashdata('error',$e->getMessage());
                front_redirect(current_url(), 'refresh');
            }

        }

        $data['countries'] = $this->common_model->getTableData('countries')->result();
        $data['site_common'] = site_common();
        $data['action'] = front_url() . 'register'; 
        $this->load->view('front/user/register', $data);
    }


    private function register_wt_decision(){
        // $this->benchmark->mark('mk_code_start');
        
        $view_tbl = $this->view_table;      
        try {
            $get_global_level_increament = $this->com_m->get_row_val('users_no_ref_level_tracking',['id' => 1],"matrix_level");
            $flag = false;
            if(!$this->com_m->get_row_counter('users',['id' => '1'])){
                // Matrix Level checker (for 1)                 
                    $this->register_wt_insert(0);
                    $this->com_m->insertTableData('users_no_ref_level_tracking',['matrix_level' => '1','no_ref_level' => '1']);
                    redirect(current_url(),'refresh');
                    return true;
            }else if($get_global_level_increament == 1){
                // Matrix Level two 
                $get_last_record_id_count = $this->com_m->getTableData('users', array('matrix_level' => 1))->num_rows();
                if($get_last_record_id_count > 1 && $get_last_record_id_count % 4 == 0){
                    $this->com_m->updateTableData('users_no_ref_level_tracking',['id' => '1'], ['matrix_level' => 2]);                  
                }
                if($this->register_wt_insert(1)){
                    // return $this->no_ref_level_updator();
                    return true;
                }else{
                    // echo 'sample welcome';exit;
                    redirect(current_url(),'refresh');
                }               
            }else if($get_global_level_increament == 2){
                $get_last_record_id_count = $this->com_m->getTableData('users', array('matrix_level' => 2))->num_rows();
                $matrix_level = pow(2,4);                   
                if($get_last_record_id_count > 1 && ($matrix_level == $get_last_record_id_count)){
                    $this->com_m->updateTableData('users_no_ref_level_tracking',['id' => '1'], ['matrix_level' => 3]);              
                }
                // echo 'sample';exit;
                if($this->level_1_2(1)){
                    // return $this->no_ref_level_updator();
                    return true;
                }else{
                    // echo 'SAMPLE 2';exit;
                    redirect(current_url(),'refresh');
                }
            }else if($get_global_level_increament == 3){
                $get_last_record_id_count = $this->com_m->getTableData('matrix_level'.$view_tbl, array('matrix_level' => 3))->num_rows();
                $matrix_level = pow(2,6);
                if($get_last_record_id_count > 1 && ($matrix_level == $get_last_record_id_count)){
                    $this->com_m->updateTableData('users_no_ref_level_tracking',['id' => '1'], ['matrix_level' => 4]);
                    return true;
                }
                if($this->level_1_2(2)){
                    // return $this->no_ref_level_updator();
                    return true;
                }else{
                    // echo 'SAMPLE 3';exit;
                    redirect(current_url(),'refresh');
                }
            }else{
                $this->no_ref_level_updator();  
                if($this->level_3(3)){
                    return true;
                }else{
                    redirect(current_url(),'refresh');
                }
            }
        } catch (Exception $e) {
            return $this->catchMyError($e);
        }       
        // $this->benchmark->mark('mk_code_start');
        // echo '<br><hr>'.$this->benchmark->elapsed_time('mk_code_start', 'mk_code_start');exit;
    }


    function no_ref_level_updator(){        
        $get_last_or_no_of_record = $this->db->select('count(id) c')->order_by('id',"desc")->limit(1)->where('is_reference',0)->get('users')->row('c');     
        $get_no_ref_level = ($a = floor(enponential($get_last_or_no_of_record)/2)) ? $a: 1;
        $no_ref_level = no_ref_level($get_last_or_no_of_record);
        $this->com_m->updateTableData('users_no_ref_level_tracking',['id' => '1'], ['matrix_level' => $get_no_ref_level, 'no_ref_level' => $no_ref_level]);
        return true;
    }


    function valid_unique_id($str){ 
        $user_id = unique_id_to_user_id($str);  
        if($this->com_m->get_row_counter('users',['id' => $user_id, 'rebirth_status' => '0' ])==1){
          return TRUE;
        }
        else
        {
          return FALSE;
        }
    }

    private function level_1_2($level=2){
        try {
            $new_matrix_condition = [];
            $get_last_record_id = $this->com_m->getTableData('users', array('matrix_level' => $level))->result();
            if($get_last_record_id){
                foreach ($get_last_record_id as $level_key => $level_value) {               
                        $parent = $level_value->id;     
                        $get_four_record = $this->db->get_where('users', ['parent' => $parent, 'matrix_status' => 1]);
                        if($get_four_record->num_rows() > 0){
                            // 2,3,4..                      // 
                            $current_four_parent_id = $get_four_record->result_array();     
                            foreach ($current_four_parent_id as $current_four_parent_id_key => $current_four_parent_id_value) {
                                $parent = $current_four_parent_id_value['parent'];                                  
                                $is_four_record = $this->db->select("count(id) as c")->get_where('users', ['parent' => $parent ])->row('c');
                                if($is_four_record <= 3){                                   
                                    $this->register_wt_insert($parent);                                 
                                    return true;                                
                                }                                   
                            }
                        }else{                          
                            $this->register_wt_insert($parent);
                            return true;exit;
                        }               
                }   
            }else{
                $this->session->set_flashdata('error','Unknown Level of User2');                
                return false;
            }
            return true;
        } catch (Exception $e) {            
            return $this->catchMyError($e);
        }

    }



    private function level_3($level=3){
        $view_tbl = $this->view_table;
        try {
            // echo '<pre>';
            $lvl_table = 'user_matrix_level';           
            $new_matrix_condition = [];
            echo "<hr><hr>Start Here \t";
            $select = "id,parent";
            $get_last_record_id = $this->com_m->getTableData('users', array('matrix_level' => $level),$select)->result();
            echo $this->db->last_query();echo '<br>';
            echo 'Count-->'.count($get_last_record_id );
            // print_r($get_last_record_id);echo '<br>';
            if($get_last_record_id){
                foreach ($get_last_record_id as $level_key => $level_value) {               
                        echo "<hr>";
                        echo 'current node-->'.
                        $parent = $level_value->id;
                        $get_four_record = $this->db->select($select)->get_where('users', ['parent' => $parent, 'matrix_status' => 1]);
                        // $get_four_record = $this->db->select($select)->get_where('users', ['parent' => $parent]);
                        echo 'first parent-->'.$this->db->last_query(); 
                        echo '<br>count-->'.$get_four_record->num_rows();echo "<hr>";
                        if($get_four_record->num_rows() > 0){
                            // 2,3,4..
                            $current_four_parent_id = $get_four_record->result_array();
                            // print_r($current_four_parent_id);exit;
                            foreach ($current_four_parent_id as $current_four_parent_id_key => $current_four_parent_id_value) {
                                echo '<br> get parent-->'.
                                $parent = $current_four_parent_id_value['parent'];                              
                                $is_four_record = $this->db->select("count(id) as c")->get_where('users', ['parent' => $parent,'matrix_status' => '1'])->row('c');
                                echo $this->db->last_query();
                                if($is_four_record <= 3){                               
                                    // echo 'MYPARENT->'.$parent;exit;
                                    $this->register_wt_insert($parent);
                                    echo $is_four_record;
                                    if($is_four_record == 3 && $parent == 85){
                                        echo 'FINAL PARENT';
                                        $get_no_ref_level_inceament = $this->com_m->get_row_val('users_no_ref_level_tracking',['id' => 1],"no_ref_level");
                                        $this->db->where(['matrix_level' => ($get_no_ref_level-1)]);
                                        $this->db->update('users',['matrix_status' => 0]);
                                        echo $this->db->last_query();exit;
                                        return true;
                                    }
                                    return true;                                
                                }                                   
                            }
                        }else{
                            // echo 'Init'.$parent;exit;
                            $this->register_wt_insert($parent);                         
                            return true;exit;
                        }                       
                }   
            }else{
                $this->session->set_flashdata('error','Unknown Level of User4');                
                return false;
            }
            return true;
        } catch (Exception $e) {            
            return $this->catchMyError($e);
        }
    }

    private function register_wt_insert($reference=NULL){

        try {       
        $get_global_level_inceament = $this->com_m->get_row_val('users_no_ref_level_tracking',['id' => 1],"matrix_level");
        $get_no_ref_level_inceament = $this->com_m->get_row_val('users_no_ref_level_tracking',['id' => 1],"no_ref_level");
        $email = $this->db->escape_str(lcfirst($this->input->post('tenrealm_email',TRUE)));
        $no_enc_pwd = $password = $this->db->escape_str($this->input->post('tenrealm_password',TRUE));
        $firstname = $this->db->escape_str($this->input->post('first_name',TRUE));
        $lastname = $this->db->escape_str($this->input->post('last_name',TRUE));
        $beb_address = $this->db->escape_str($this->input->post('beb_address',TRUE));
        $username = $firstname . $lastname;
        $prefix=get_prefix();

        $Exp = explode('@', $email);
        $User_name = $Exp[0];

        $activation_code = randomNumber(20);
        $str=splitEmail($email);
        $ip_address = get_client_ip();

        $dob = date("Y-m-d", strtotime($this->db->escape_str($this->input->post('dob'))));
        $phone_prefix       = $this->db->escape_str($this->input->post('hiden-dialCode',true));
        $tenrealm_phone = $this->db->escape_str($this->input->post('phone',true));

        $user_data = array(
            'usertype'          => '1',
            $prefix.'email'     => $str[1],
            
            $prefix.'fname'     => $firstname,
            $prefix.'lname'     => $lastname,

            $prefix.'username'  => $username,
            $prefix.'password'  => encryptIt($password),
            'activation_code'   => $activation_code,
            'matrix_level'      => ($get_global_level_inceament) ? $get_global_level_inceament : "0",
            'no_ref_level'      => ($get_no_ref_level_inceament) ? $get_no_ref_level_inceament : "1",
            'verified'          => '0',
            'register_from'     => 'Website',
            'ip_address'        => $ip_address,
            'browser_name'      => getBrowser(),
            'verification_level'=> '1',
            'created_on'        => gmdate(time()),
            'unique_id'         => randomNumber(7).'EM',
            'beb_address'       => $beb_address,
            'dob'               => $dob,
            'tenrealm_phone'    => $tenrealm_phone
        );

        if(!$this->input->post('parent', true) OR $parent = $this->input->post('parent', true)==REGISTER_VAR){
            // Without No reference
            $user_data['parent'] = $reference;
        }else{
            $user_data['parent'] = $this->com_m->get_row_val('users', ['unique_id' => $parent], "id");
        }       

        $user_data_clean = $this->security->xss_clean($user_data);

        $this->db->trans_start();
        $id=$this->common_model->insertTableData('users', $user_data_clean);        
        
        $usertype=$prefix.'type';
        $this->common_model->insertTableData('history', array('user_id'=>$id, $usertype=>encryptIt($str[0])));
        $this->common_model->last_activity('Registration',$id);

        $a=$this->common_model->getTableData('currency','id')->result_array();
        $currency = array_column($a, 'id');
        $currency = array_flip($currency);
        $currency = array_fill_keys(array_keys($currency), 0);
        $wallet=array('Exchange AND Trading'=>$currency);

        // $this->common_model->insertTableData('wallet', array('user_id'=>$id, 'crypto_amount'=>serialize($wallet)));
        $this->common_model->insertTableData('wallet', array('user_id'=>$id, 'crypto_amount'=>serialize($wallet),'fiat_amount' => '0'));
        
        // var_dump($this->update_user_ltc_address());exit;

        $b=$this->common_model->getTableData('currency',array('type'=>'digital'),'id')->result_array();
        $currency1 = array_column($b, 'id');
        $currency1 = array_flip($currency1);
        $currency1 = array_fill_keys(array_keys($currency1), 0);

        $this->common_model->insertTableData('crypto_address', array('user_id'=>$id,'status'=>0, 'address'=>serialize($currency1)));
        $this->db->trans_complete();

    // check to see if we are creating the user
        $email_template = 'Registration';
        $site_common      =   site_common();
        $reg_date = $this->com_m->get_row_val('users', array('id' => $id), "created_on");
        $reg_utc_date = date('Y-m-d H:i:s', $reg_date);
        $special_vars = array(
            '###USERNAME###' => $firstname,
            '###LINK###' => front_url().'verify_user/'.$activation_code,
            '###PASSWORD###' => $no_enc_pwd,
            '###USERID###'  => user_id_to_unique_id($id),
            '###REGDATE###' => $reg_utc_date
        );

        $this->email_model->sendMail($email, '', '', $email_template, $special_vars);
        $this->session->set_flashdata('success',$this->lang->line('Thank you for Signing up. Please check your e-mail and click on the verification link.'));
        front_redirect(current_url(), 'refresh');
        return true;
        } catch (Exception $e) {            
            return $this->catchMyError($e);
        }                   
    }

    private function register_insert(){

        $email = $this->db->escape_str(lcfirst($this->input->post('tenrealm_email',TRUE)));
        $no_enc_pwd = $password = $this->db->escape_str($this->input->post('tenrealm_password',TRUE));
        $firstname = $this->db->escape_str($this->input->post('first_name',TRUE));
        
            $country = $this->db->escape_str($this->input->post('country',TRUE));
        
        $lastname = $this->db->escape_str($this->input->post('last_name',TRUE));
        // $beb_address = $this->db->escape_str($this->input->post('beb_address',TRUE));
        $parent = $this->db->escape_str($this->input->post('parent', true));

        $username = $firstname . $lastname;
        $prefix=get_prefix();

        $Exp = explode('@', $email);
        $User_name = $Exp[0];

        $activation_code = randomNumber(20);
        $str=splitEmail($email);
        $ip_address = get_client_ip();

        $dob = date("Y-m-d", strtotime($this->db->escape_str($this->input->post('dob'))));
        $phone_prefix       = $this->db->escape_str($this->input->post('hiden-dialCode',true));
        $tenrealm_phone = $this->db->escape_str($this->input->post('phone',true));

        $user_data = array(
            'usertype'          => '1',
            $prefix.'email'     => $str[1],
            $prefix.'username'  => $username,
            $prefix.'password'  => encryptIt($password),
            'activation_code'   => $activation_code,

            $prefix.'fname'     => $firstname,
            $prefix.'lname'     => $lastname,

            'verified'          => '1',
            'register_from'     => 'Website',
            'ip_address'        => $ip_address,
            'browser_name'      => getBrowser(),
            'verification_level'=> '0',
            'created_on'        => gmdate(time()),
            'unique_id'         => randomNumber(5).'EM',
            'country'           => $country,
            'dob'               => $dob,
            'tenrealm_phone'    => $tenrealm_phone
        );

        if(!$parent OR $parent==REGISTER_VAR){
            // Without No reference     
            // $this->register_wt_decision();
            // redirect(current_url(),'refresh');
            $user_data['parent'] = '1';         
            $user_data['is_reference'] = '0';   
            $user_data['rebirth_status'] = '0';
        }else{
//          $user_data['parent'] = $this->com_m->get_row_val('users', ['unique_id' => $parent], "id");
            
            $user_data['parent'] = unique_id_to_user_id($parent);   
            
            $checkid=$this->common_model->getTableData('users',array('id'=>$user_data['parent']))->row();
            
            if($checkid == ''){
                $this->session->set_flashdata('error','Please Enter Valid Refferal ID');
                 redirect('signup');
                  exit;
                
                
                
            }
            
        
            
            $user_data['is_reference'] = '1';   
            $user_data['rebirth_status'] = '0'; 
        }       

        $user_data_clean = $this->security->xss_clean($user_data);
        
        $this->db->trans_start();

       // print_r($user_data_clean);exit;
        $unique_session_id = $id=$this->common_model->insertTableData('users', $user_data_clean);
        $usertype=$prefix.'type';
        $this->common_model->insertTableData('history', array('user_id'=>$id, $usertype=>encryptIt($str[0])));
        $this->common_model->last_activity('Registration',$id);

        $this->update_user_ltc_address();
        $a=$this->common_model->getTableData('currency','id')->result_array();
        $currency = array_column($a, 'id');
        $currency = array_flip($currency);
        $currency = array_fill_keys(array_keys($currency), 0);
        $wallet=array('Exchange AND Trading'=>$currency);

        // $this->common_model->insertTableData('wallet', array('user_id'=>$id, 'crypto_amount'=>serialize($wallet)));
        $this->common_model->insertTableData('wallet', array('user_id'=>$id, 'crypto_amount'=>serialize($wallet),'fiat_amount' => 0));

        $b=$this->common_model->getTableData('currency',array('type'=>'digital'),'id')->result_array();
        $currency1 = array_column($b, 'id');
        $currency1 = array_flip($currency1);
        $currency1 = array_fill_keys(array_keys($currency1), 0);

        // $this->common_model->insertTableData('crypto_address', array('user_id'=>$id,'status'=>0, 'address'=>serialize($currency1)));
        $this->db->trans_complete();

    // check to see if we are creating the user
        $email_template = 'Registration';
        $site_common      =   site_common();
        $reg_date = $this->com_m->get_row_val('users', array('id' => $id), "created_on");
        $reg_utc_date = date('Y-m-d H:i:s', $reg_date);



    
        $special_vars = array(
            '###USERNAME###' => $firstname,
            '###LINK###' => front_url().'verify_user/'.$activation_code,
            '###PASSWORD###' => $no_enc_pwd,
            '###USERID###'  => user_id_to_unique_id($id),
            '###REGDATE###' => $reg_utc_date
        );

        $this->email_model->sendMail($email, '', '', $email_template, $special_vars);
        
          //  echo "testssss";
       // die;
        if ($_SERVER['REMOTE_ADDR'] == '157.49.251.2261'){
            $url=front_url().'verify_user/'.$activation_code;
      $message='You have register successfully  please click here and verif your account<a href="'.$url.'">LINK TEXT</a>';
      //$message=$url;
      
$this->load->library('email');
$config = Array(
                'protocol' => 'mail',
                'smtp_host' => 'smtp.googlemail.com',
                'smtp_port' => 587,
                'smtp_user' => 'alivejesusalive@gmail.com', // your email
                'smtp_pass' => 'Viva@123', // your password
                'smtp_timeout'=>20,
                'mailtype' => 'text',
                'charset' => 'iso-8859-1',
                'newline'=>"\r\n",
                'wordwrap' => TRUE
              );
 $this->email->set_newline("\r\n"); 
 $this->email->initialize($config);
 $this->email->from('alivejesusalive@gmail.com');
 $this->email->to('balabkcs7@gmail.com');
 $this->email->subject('Email Test');
 $this->email->message($message);  
 $this->email->send();
 $this->email->print_debugger();

      
    //   echo "test";
    //   die;
      
      }
        
        
        
        
        // $this->session->set_flashdata('success',$this->lang->line('Thank you for Signing up. Please check your e-mail and click on the verification link.'));
        
         $check = checkSplitEmailOrInteger($password, $email);
         $session_data = array('user_id' => $unique_session_id);
                        $this->session->set_userdata($session_data);
                        $this->common_model->last_activity('Login', $unique_session_id);
                        $this->session->set_flashdata('success', $this->lang->line('Welcome back . Logged in Successfully'));
                        $array['msg'] = $this->lang->line('Welcome back . Logged in Successfully');
                        $array['login_url'] = 'dashboard';


                        redirect('dashboard');exit;
       
        
        // front_redirect(current_url(), 'refresh');                    
    }

  function sendmessage(){


    echo "test";

//  echo $name=$this->input->post('Name');
// echo  $email=$this->input->post('Email');
// echo  $message=$this->input->post('Message');

die;





  }




    function add_table(){

        // $this->benchmark->mark('code_my_start');
        // $p = $this->com_m->getTableData('users');
        // echo '<pre>';print_r($p->result_array());
        // echo $this->benchmark->mark('code_my_end');
        // echo '<br><hr>'.$this->benchmark->elapsed_time('code_my_start', 'code_my_end');exit;
        
        $upto = (!empty($this->input->get('upto'))) ? $this->input->get('upto') : 2;               
        $this->benchmark->mark('code_start');
        $old_referral_id = 0;            
        $unique_id = randomNumber(7).'EM';
        $no_ref_level = 1;
        $matrix_level = 1;
        $parent_id=1;
            if( $init = ($this->input->get('init')) ? $this->input->get('init') : 0){
                add_table($unique_id, 0);    
            }
            
            $pwr = round($upto, 0, PHP_ROUND_HALF_EVEN);
            
            for($outer=1;$outer<= $pwr;$outer++){
                $four = 1;
                for($inner=1;$inner <= pow(4, $outer);$inner++){
                    
                    // echo pow(4, $outer*2);echo "\n";

                    $unique_id = randomNumber(7).'EM';
                    $matrix_level = $outer;                 

                    if($inner==1000){
                     echo 'CUSTOM TABLE END-->'.time();exit; 
                    }
                    
                    echo 'OUT'."\t ".$outer;echo "\t";
                    echo 'IN'."\t ".$inner;echo "\t \n <br>";
                    // echo "".$parent_id;echo "\t";
                    // echo "".$matrix_level;echo "\t";
                    // echo $no_ref_level;echo "<br> \n";
                    
                    if($outer == $upto){
                        add_table($unique_id, $parent_id,$matrix_level,$no_ref_level);    
                    }
                    
                    // if($four == 4){
                    //     $parent_id++;
                    //     $four = 0;
                    // }
                    // $four++;
                }           
            }
                    // }else{
                    //  echo 'Only allow two digits';
                    // }
        echo 'ADD TABLE END';
        echo '<br> Success';
        echo $this->benchmark->mark('code_end');
        echo '<br><hr>'.$this->benchmark->elapsed_time('code_start', 'code_end');exit;
        return true;exit;
    }

    function oldpassword_exist()
    {
        $oldpass = $this->db->escape_str($this->input->post('oldpass'));
        $prefix=get_prefix();
        $check=$this->common_model->getTableData('users',array($prefix.'password'=>encryptIt($oldpass)))->result();
        //echo count($check);
        if (count($check)>0)
        {
            echo "true";
        }
        else
        {
            echo "false";
        }
    }
    function email_exist()
    {   
        if (!$this->input->is_ajax_request()) {
           exit('No direct script access allowed');
        }
        $email = $this->db->escape_str($this->input->get_post('tenrealm_email',true));
        $check=checkSplitEmail($email);
        if (!$check)
        {
            echo "true";
        }
        else
        {
            echo "false";            
        }
        exit;
    }


    function refferal_exist()
    {   
        if (!$this->input->is_ajax_request()) {
           exit('No direct script access allowed');
        }
        $ref = escape_str($this->input->get_post('parent',true));   
        
        if ($this->input->is_ajax_request()) {      
            if(!$ref){ echo "false"; exit;}
        }
        
        if (checkValidRef($ref))
        {
            echo "true";
        }
        else
        {
            echo "false";            
        }
        exit;
    }



    function beb_exist()
    {   
        if (!$this->input->is_ajax_request()) {
           exit('No direct script access allowed');
        }
        $ref = escape_str($this->input->get_post('beb_address',true));  
        
        if ($this->input->is_ajax_request()) {      
            if(!$ref){ echo "false"; exit;}
        }
        
        if ($this->checkValidBeb($ref))
        {
            echo "true";
        }
        else
        {
            echo "false";            
        }
        exit;
    }


    function checkValidBeb($ref){
        if (!$this->input->is_ajax_request()) {
           exit('No direct script access allowed');
        }

        if(!$this->com_m->get_row_counter('users', array('beb_address' => $ref), 'id')){
            return true;
        }
        return false;
    }

    function is_not_email_exist()
    {   
        if (!$this->input->is_ajax_request()) {
           exit('No direct script access allowed');
        }



        if($this->input->get_post('forgot_detail',true)){
            $inp = $this->input->get_post('forgot_detail',true);
        }else if($this->input->get_post('tenrealm_email',true)){
            $inp = $this->input->get_post('tenrealm_email',true);
        }

      
      $email = $this->db->escape_str($inp);
      
      if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $check=checkSplitEmail($email);
        if ($check)
        {
            echo "true";
        }
        else
        {
            echo "false";            
        }
     
      }else if (filter_var($email, FILTER_VALIDATE_INT)) {
            echo "true";
      }
     exit;
    }


    function username_exist()
    {
        $username = $this->db->escape_str($this->input->get_post('username'));
        $prefix=get_prefix();
        $check=$this->common_model->getTableData('users',array($prefix.'username'=>$username));
        if ($check->num_rows()==0)
        {
            echo "true";
        }
        else
        {
            echo "false";
        }
        exit;
    }   
    function get_csrf_token()
    {
        echo $this->security->get_csrf_hash();
    }   
    function logout(){
        $this->session->unset_userdata('user_id');
        $this->session->unset_userdata('pass_changed');
        $tokenvalues = $this->session->userdata('tokenvalues');
        $depositvalues = $this->session->userdata('depositvalues');
        if(isset($tokenvalues) && !empty($tokenvalues))
        {
            $this->session->unset_userdata('tokenvalues');
        }
        if(isset($depositvalues) && !empty($depositvalues))
        {
            $this->session->unset_userdata('depositvalues');
        }
        $this->session->set_flashdata('success', $this->lang->line('Logged Out successfully'));
        front_redirect('/','refresh');
    }
    function verify_user($activation_code){
        $activation_code=$this->db->escape_str($activation_code);   
        $user_id=$this->session->userdata('user_id');

        if(!$activation_code) { 
            $this->session->set_flashdata('error', 'The Activation code is required!.');
            front_redirect('register', 'refresh');
        }

        $activation=$this->common_model->getTableData('users',array('activation_code'=>urldecode($activation_code)));
        
        if ($activation->num_rows()>0)
        {
            $detail=$activation->row();
            if($detail->verified==1)
            {
                $this->session->set_flashdata('error', $this->lang->line('Your Email is already verified.'));
                front_redirect("", 'refresh');
            }
            else
            {
            
                $this->common_model->updateTableData('users',array('id'=>$detail->id),array('verified'=>1));
                $this->common_model->last_activity('Email Verification',$detail->id);
                $this->session->set_flashdata('success', $this->lang->line('Your Email is verified now.'));
                front_redirect("login", 'refresh');
            }
        }
        else
        {
            $this->session->set_flashdata('error', $this->lang->line('Activation link is not valid'));
            front_redirect("register", 'refresh');
        }
    }
    function profile()
    {               
        $user_id=$this->session->userdata('user_id');
        if($user_id=="")
        {   
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url().'home');
        }       
        $data['users'] = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
        $data['country']= $this->common_model->getTableData('countries',array('id'=>$data['users']->country))->row();
        $data['countries'] = $this->common_model->getTableData('countries')->result();
        $data['site_common'] = site_common();
        $this->load->view('front/user/profile', $data); 
    }
    function editprofile()
    {       
        try {
        
            if (!$this->input->is_ajax_request()) {
               exit('No direct script access allowed');
            }
            if(!$user_id = $this->session->userdata('user_id')){                
                throw new Exception('Authetication Failed.', 401);exit;             
            }
            
            $user_id=$this->session->userdata('user_id');
            if($user_id=="")
            {   
                $this->session->set_flashdata('success', $this->lang->line('Please Login'));
                redirect(base_url().'home');
            }           
        
            

            if($this->input->post('edit_profile_form', true)) {

                // $insertData['tenrealm_fname'] = $this->db->escape_str($this->input->post('firstname',true));
                
                $this->form_validation->set_rules('firstname', 'firstname', 'required|xss_clean');
                if($this->form_validation->run())
                {

                if ($_FILES['profile_photo']['name']) 
                {
                    $imagepro = $_FILES['profile_photo']['name'];
                    if($imagepro!="" && getExtension($_FILES['profile_photo']['type']))
                    {
                        $uploadimage1=cdn_file_upload($_FILES["profile_photo"],'uploads/user/'.$user_id,$this->input->post('profile_photos'));
                        if($uploadimage1)
                        {
                            $imagepro=$uploadimage1['secure_url'];
                        }
                        else
                        {
                            $this->session->set_flashdata('error', $this->lang->line('Problem with profile picture'));
                            front_redirect('profile', 'refresh');
                        } 
                    }               
                    $insertData['profile_picture']=$imagepro;
                }
            
                $insertData['tenrealm_fname'] = $this->db->escape_str($this->input->post('firstname'),true);
                $insertData['tenrealm_lname'] = $this->db->escape_str($this->input->post('lastname'),true);
                $insertData['dob'] = date("Y-m-d", strtotime($this->db->escape_str($this->input->post('dob'))));
                // $insertData['street_address'] = $this->db->escape_str($this->input->post('street_address'),true);
                // $insertData['street_address_2'] = $this->db->escape_str($this->input->post('street_address_2'),true);

                $insertData['country'] = $this->db->escape_str($this->input->post('hiden-countryId'),true);
                // $insertData['state'] = $this->db->escape_str($this->input->post('hiden-stateId'),true);
                // $insertData['city'] = $this->db->escape_str($this->input->post('city'),true);

                $insertData['country_name'] = $this->db->escape_str($this->input->post('hiden-country_name'),true);
                // $insertData['state_name'] = $this->db->escape_str($this->input->post('hiden-state_name'),true);              
                // $insertData['postal_code'] = $this->db->escape_str($this->input->post('postal_code'),true);          

                $insertData['beb_address'] = $this->db->escape_str($this->input->post('beb_address'),true);
                
                    $insertData['busd_address'] = $this->db->escape_str($this->input->post('busd_address'),true);

                $insertData['phone_prefix']     = $this->db->escape_str($this->input->post('hiden-dialCode',true));
                $insertData['tenrealm_phone']   = $this->db->escape_str($this->input->post('phone',true));
                $condition = array('id' => $user_id);
                $insertData_clean = $this->security->xss_clean($insertData);
                $insert = $this->common_model->updateTableData('users',$condition, $insertData_clean);                      
                if ($insert) {
                    $profileupdate = $this->common_model->updateTableData('users',array('id' => $user_id), array('profile_status'=>1));
                    echo json_encode([ 'status' => true, 'msg' => 'Profile details Updated Successfully', 'data' => $insertData]);exit;
                } else {
                    echo json_encode([ 'status' => false, 'msg' => 'Something there is a Problem .Please try again later']);exit;
                }
                }
                else
                {
                    echo json_encode([ 'status' => false, 'msg' => 'Some datas are missing']);exit;
                }
            }


            if($this->input->post('change_password',true)){             
                $user_id=$this->session->userdata('user_id');
                if($user_id=="")
                {    
                    $this->session->set_flashdata('success','you are not logged in');
                    redirect(base_url().'home');
                }
                $data['users'] = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
                $old = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
                if($this->input->post('change_password'))
                {
                    $prefix = get_prefix();
                    $oldpassword = encryptIt($this->input->post("currentpassword",true));
                    $newpassword = encryptIt($this->input->post("password",true));
                    $confirmpassword = encryptIt($this->input->post("cpassword",true));
                    // Check old pass is correct/not
                    $password = $prefix.'password';
                    $op = $prefix.'password';
                    if($oldpassword == $old->$op)
                    {
                           //check new pass is equal to confirm pass
                        if($newpassword == $confirmpassword)
                        {
                            $data=array($prefix.'password'  => $newpassword);             
                            $this->common_model->updateTableData('users',array('id'=>$user_id),$data);
                            // $this->session->set_flashdata('success','Password changed successfully');
                            // front_redirect('change_password', 'refresh');
                            echo json_encode([ 'status' => true, 'msg' => 'Password changed successfully']);exit;    
                        }
                        else
                        {
                            // $this->session->set_flashdata('error','Confirm password must be same as new password');
                            // front_redirect('change_password', 'refresh');
                            echo json_encode([ 'status' => false, 'msg' => 'Confirm password must be same as new password']);exit;    
                        }
                    }
                    else
                    {
                        // $this->session->set_flashdata('error','Your old password is wrong');
                        // front_redirect('change_password', 'refresh');
                        echo json_encode([ 'status' => false, 'msg' => 'Your old password is wrong']);exit;
                    }            
                }        
            }
        echo json_encode([ 'status' => false, 'msg' => 'Some datas are missing2']);exit;
        } catch (Exception $e) {
            echo json_encode(array('error' => array('msg' => $e->getMessage(),'code' => $e->getCode())));exit;  
        }   
    }
    function update_profileimage()
    {
        $user_id=$this->session->userdata('user_id');
        if($user_id=="")
        {   
            front_redirect('', 'refresh');
        }
        if($_FILES)
        {           
                $prefix=get_prefix();
                $imagepro = $_FILES['profile_photo']['name'];
                if($imagepro!="" && getExtension($_FILES['profile_photo']['type']))
                {
                    $uploadimage1=cdn_file_upload($_FILES["profile_photo"],'uploads/user/'.$user_id,$this->input->post('profile_photo'));
                    if($uploadimage1)
                    {
                        $imagepro=$uploadimage1['secure_url'];
                    }
                    else
                    {
                        $this->session->set_flashdata('error', $this->lang->line('Problem with yourself holding photo ID'));
                        front_redirect('profile', 'refresh');
                    } 
                }
                else 
                {
                    $imagepro='';
                }

                $insertData = array();
                $insertData['profile_picture']=$imagepro;               
                $condition = array('id' => $user_id);
                $insert = $this->common_model->updateTableData('users',$condition, $insertData);
                if ($insert) {
                    $this->session->set_flashdata('success',$this->lang->line('Profile image Updated Successfully'));
                    front_redirect('profile', 'refresh');
                } else {
                    $this->session->set_flashdata('error', $this->lang->line('Something there is a Problem .Please try again later'));
                    front_redirect('profile', 'refresh');
                }           
        }
    }
    function kyc()
    {        
        // $this->load->library('session');
        $user_id=$this->session->userdata('user_id');
        if($user_id=="")
        {   
            $this->session->set_flashdata('success', 'you are not logged in');
            redirect(base_url().'home');
        }
        $data['meta_content'] = $this->common_model->getTableData('meta_content',array('link'=>'kyc'))->row();
        $data['users'] = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
        $data['site_common'] = site_common();       
        $this->load->view('front/user/kyc', $data); 
    }
    function address_verification() {
    
        $user_id=$this->session->userdata('user_id');
        if($user_id=="")
        {   
            front_redirect('', 'refresh');
        }
        if($_FILES) {   
            $insertData = array();          
            $prefix=get_prefix();

            $image = $_FILES['photo_id_1']['name'];
            $image1 = $_FILES['photo_id_2']['name'];
            if($image!="" && getExtension($_FILES['photo_id_1']['type']))
            {   
                $ext = getExtension($_FILES['photo_id_1']['type']);
                $Img_Size = $_FILES['photo_id_1']['size'];
                
                if($Img_Size>2000000){
                    $this->session->set_flashdata('error',$this->lang->line('File Size Should be less than 2 MB'));
                    front_redirect('settings', 'refresh');
                }
                $ext = getExtension($_FILES['photo_id_1']['type']);
                if($ext == 'jpg' || $ext == 'jpeg' || $ext == 'png'){
                $upload_image=cdn_file_upload($_FILES["photo_id_1"],'uploads/user/'.$user_id,$this->db->escape_str($this->input->post('photo_id_1')));
                $uploadimage=$upload_image['secure_url'];
                }
                elseif($ext == 'pdf'){
                    
                    $config['upload_path'] = './uploads/';
                    $config['allowed_types'] = 'pdf';       
                    $this->load->library('upload', $config);
                    if (!$this->upload->do_upload('photo_id_1')) {
                        $this->data['error'] = $this->upload->display_errors();
                        print_r($this->data['error']);  
                    } else {
                        $upload_image = $this->upload->data('file_name');
                        $image_path = base_url(). 'uploads/'.$upload_image;
                        $uploadimage=$image_path;
                        
                    }

                }
                if($uploadimage)
                {
                    $image=$uploadimage;
                    
                }
                else
                {
                    $this->session->set_flashdata('error',$this->lang->line('Problem with your document front'));
                    front_redirect('settings', 'refresh');
                }
                $insertData['photo_id_1'] = $image; 
                // print_r($image);
                // exit();

            } 
            
            if($image1!="" && getExtension($_FILES['photo_id_2']['type']))
            {       
                $Img_Size1 = $_FILES['photo_id_2']['size'];
                if($Img_Size1>2000000){
                    $this->session->set_flashdata('error',$this->lang->line('File Size Should be less than 2 MB'));
                    front_redirect('settings', 'refresh');
                }

                $ext = getExtension($_FILES['photo_id_2']['type']);
                if($ext == 'jpg' || $ext == 'jpeg' || $ext == 'png'){
                $upload_image=cdn_file_upload($_FILES["photo_id_2"],'uploads/user/'.$user_id,$this->db->escape_str($this->input->post('photo_id_2')));
                $uploadimage1=$upload_image['secure_url'];
                }
                elseif($ext == 'pdf'){
                    
                    $config['upload_path'] = './uploads/';
                    $config['allowed_types'] = 'pdf';       
                    $this->load->library('upload', $config);
                    if (!$this->upload->do_upload('photo_id_2')) {
                        $this->data['error'] = $this->upload->display_errors();
                        print_r($this->data['error']);  
                    } else {
                        $upload_image = $this->upload->data('file_name');
                        $image_path = base_url(). 'uploads/'.$upload_image;
                        $uploadimage1=$image_path;
                        
                    }

                }
                if($uploadimage1)
                {
                    $image1=$uploadimage1;
                }
                else
                {
                    $this->session->set_flashdata('error',$this->lang->line('Problem with your document back'));
                    front_redirect('settings', 'refresh');
                }
                $insertData['photo_id_2'] = $image1;
            } 
                            
            $insertData['verify_level2_date'] = gmdate(time());
            $insertData['verify_level2_status'] = 'Pending';
            $insertData['photo_1_status'] = 1;     
            $insertData['photo_2_status'] = 1;

            // echo "<pre>";print_r($insertData);die;
            $condition = array('id' => $user_id);
            $insertData_clean = $this->security->xss_clean($insertData);
            $insert = $this->common_model->updateTableData('users',$condition, $insertData_clean);
            if($insert !='' && $_FILES["photo_id_1"]['name'] !='') {
                $this->session->set_flashdata('success',$this->lang->line('Your details have been sent to our team for verification'));
                front_redirect('settings', 'refresh');
            } 
            elseif($insert !='' && $_FILES["photo_id_1"]['name'] =='') {
                $this->session->set_flashdata('success', $this->lang->line('Your Address proof cancelled successfully'));
                front_redirect('settings', 'refresh');
            }
            else {
                $this->session->set_flashdata('error',$this->lang->line('Unable to send your details to our team for verification. Please try again later!'));
                front_redirect('settings', 'refresh');
            }
        }
    }
    function address_verification1() {
        $user_id=$this->session->userdata('user_id');
            if($user_id=="")
            {   
                front_redirect('', 'refresh');
            }
            if($_FILES) {               
                $prefix=get_prefix();

                $image = $_FILES['photo_id_1']['name'];
                    if($image!="" && getExtension($_FILES['photo_id_1']['type']))
                    {       
                        $Img_Size = $_FILES['photo_id_1']['size'];
                        if($Img_Size>2000000){
                            $this->session->set_flashdata('error',$this->lang->line('File Size Should be less than 2 MB'));
                            front_redirect('settings', 'refresh');
                        }
                        $uploadimage=cdn_file_upload($_FILES["photo_id_1"],'uploads/user/'.$user_id,$this->db->escape_str($this->input->post('photo_id_1')));
                        if($uploadimage)
                        {
                            $image=$uploadimage['secure_url'];
                        }
                        else
                        {
                            
                            $this->session->set_flashdata('error',$this->lang->line('Problem with your document front'));
                            front_redirect('settings', 'refresh');
                        }
                    } 
                    elseif($this->input->post('photo_ids_1')=='')
                    {
                        $image = $this->db->escape_str($this->input->post('photo_ids_1'));
                    }
                    else 
                    { 
                        $image='';
                    }
                    $insertData = array();
                    $insertData['photo_id_1'] = $image;                 
                    $insertData['verify_level2_date'] = gmdate(time());
                    $insertData['verify_level2_status'] = 'Pending';
                    $insertData['photo_1_status'] = 1;                  
                    $condition = array('id' => $user_id);
                    $insertData_clean = $this->security->xss_clean($insertData);
                    $insert = $this->common_model->updateTableData('users',$condition, $insertData_clean);
                    if($insert !='' && $_FILES["photo_id_1"]['name'] !='') {
                        $this->session->set_flashdata('success',$this->lang->line('Your details have been sent to our team for verification'));
                        front_redirect('settings', 'refresh');
                    } 
                    elseif($insert !='' && $_FILES["photo_id_1"]['name'] =='') {
                        $this->session->set_flashdata('success', $this->lang->line('Your Address proof cancelled successfully'));
                        front_redirect('settings', 'refresh');
                    }
                    else {
                        $this->session->set_flashdata('error',$this->lang->line('Unable to send your details to our team for verification. Please try again later!'));
                        front_redirect('settings', 'refresh');
                    }
            }
    }
    function id_verification()  {
        $user_id=$this->session->userdata('user_id');
            if($user_id=="")
            {   
                front_redirect('', 'refresh');
            }
            if($_FILES)
            {
                $image = $_FILES['photo_id_2']['name'];
                    if($image!="" && getExtension($_FILES['photo_id_2']['type']))
                    {       

                        $Img_Size = $_FILES['photo_id_2']['size'];
                        if($Img_Size>2000000){
                            $this->session->set_flashdata('error',$this->lang->line('File Size Should be less than 2 MB'));
                            front_redirect('settings', 'refresh');
                        }

                        $uploadimage=cdn_file_upload($_FILES["photo_id_2"],'uploads/user/'.$user_id,$this->db->escape_str($this->input->post('photo_id_2')));
                        if($uploadimage)
                        {
                            $image=$uploadimage['secure_url'];
                        }
                        else
                        {
                            $this->session->set_flashdata('error',$this->lang->line('Problem with your document back'));
                            front_redirect('settings', 'refresh');
                        }
                    } 
                    elseif($this->input->post('photo_ids_2')=='')
                    {
                        $image = $this->db->escape_str($this->input->post('photo_ids_2'));
                    }
                    else 
                    { 
                        $image='';
                    }
                    $insertData = array();
                    $insertData['photo_id_2'] = $image;
                    $insertData['verify_level2_date'] = gmdate(time());
                    $insertData['verify_level2_status'] = 'Pending';
                    $insertData['photo_2_status'] = 1;
                    $condition = array('id' => $user_id);
                    $insertData_clean = $this->security->xss_clean($insertData);
                    $insert = $this->common_model->updateTableData('users',$condition, $insertData_clean);
                    if($insert !='' && $_FILES["photo_id_2"]['name'] !='') {
                        $this->session->set_flashdata('success',$this->lang->line('Your details have been sent to our team for verification'));
                        front_redirect('settings', 'refresh');
                    } 
                    elseif($insert !='' && $_FILES["photo_id_2"]['name'] =='') {
                        $this->session->set_flashdata('success', $this->lang->line('Your ID proof cancelled successfully'));
                        front_redirect('settings', 'refresh');
                    }
                    else {
                        $this->session->set_flashdata('error',$this->lang->line('Unable to send your details to our team for verification. Please try again later!'));
                        front_redirect('settings', 'refresh');
                    }
            }
    }
    function photo_verification(){
        $user_id=$this->session->userdata('user_id');
            if($user_id=="")
            {   
                front_redirect('', 'refresh');
            }
            if($_FILES)
            {
                $image = $_FILES['photo_id_3']['name'];
                    if($image!="" && getExtension($_FILES['photo_id_3']['type']))
                    {       
                        $Img_Size = $_FILES['photo_id_3']['size'];
                        if($Img_Size>2000000){
                            $this->session->set_flashdata('error',$this->lang->line('File Size Should be less than 2 MB'));
                            front_redirect('settings', 'refresh');
                        }

                        $uploadimage=cdn_file_upload($_FILES["photo_id_3"],'uploads/user/'.$user_id,$this->db->escape_str($this->input->post('photo_id_3')));
                        if($uploadimage)
                        {
                            $image=$uploadimage['secure_url'];
                        }
                        else
                        {
                            $this->session->set_flashdata('error', $this->lang->line('Problem with your scan of photo id'));
                            front_redirect('settings', 'refresh');
                        }
                    } 
                    elseif($this->input->post('photo_ids_3')=='')
                    {
                        $image = $this->db->escape_str($this->input->post('photo_ids_3'));
                    }
                    else 
                    { 
                        $image='';
                    }
                    $insertData['photo_id_3'] = $image;
                    $insertData['verify_level2_date'] = gmdate(time());
                    $insertData['verify_level2_status'] = 'Pending';
                    $insertData['photo_3_status'] = 1;
                    $condition = array('id' => $user_id);
                    $insertData_clean = $this->security->xss_clean($insertData);
                    $insert = $this->common_model->updateTableData('users',$condition, $insertData_clean);
                    if($insert !='' && $_FILES["photo_id_3"]['name'] !='') {
                        $this->session->set_flashdata('success',$this->lang->line('Your details have been sent to our team for verification'));
                        front_redirect('settings', 'refresh');
                    } 
                    elseif($insert !='' && $_FILES["photo_id_3"]['name'] =='') {
                        $this->session->set_flashdata('success', $this->lang->line('Your Photo cancelled successfully'));
                        front_redirect('settings', 'refresh');
                    }
                    else {
                        $this->session->set_flashdata('error',$this->lang->line('Unable to send your details to our team for verification. Please try again later!'));
                        front_redirect('settings', 'refresh');
                    }
            }
    }
    function pwcheck(){
        $pwd = $_POST['oldpass'];
        $epwd = encryptIt($pwd);
        $Cnt_Row = $this->common_model->getTableData('users', array('tenrealm_password' => $epwd,'id'=>$this->session->userdata('user_id')))->num_rows();    
        if($Cnt_Row > 0){
            echo '0';
        }
        else{
            echo '1';
        }
    }
    function settings($tab=null)
    {
        $user_id=$this->session->userdata('user_id');
        if($user_id=="")
        {   
            $this->session->set_flashdata('success', $this->lang->line('Please Login'));
            redirect(base_url().'home');
        }

        $data['deposit_history'] = $this->common_model->getTableData('transactions',array('user_id'=>$user_id,'type'=>'Deposit','verify_status'=>'kyc_verify'),'','','','','','',array('trans_id','DESC'))->result();
        $this->load->library('Googleauthenticator');
        $data['meta_content'] = $this->common_model->getTableData('meta_content', array('link'=>'settings'))->row();
        $data['users'] = $this->common_model->getTableData('users',array('id'=>$user_id))->row();

        // echo "<pre>";
        // print_r($data['deposit_history']);
        // exit();
        $data['user_bank'] = $this->common_model->getTableData('user_bank_details', array('user_id'=>$user_id))->row();
        if($data['users']->randcode=="enable" || $data['users']->secret!="")
        {   
            $secret = $data['users']->secret; 
            $data['secret'] = $secret;
            $ga     = new Googleauthenticator();
            $data['url'] = $ga->getQRCodeGoogleUrl('', $secret);
        }
        else
        {
            $ga = new Googleauthenticator();
            $data['secret'] = $ga->createSecret();
            $data['url'] = $ga->getQRCodeGoogleUrl('', $data['secret']);
            $data['oneCode'] = $ga->getCode($data['secret']);
        }
        if(isset($_POST['chngpass']))
        {
            $prefix = get_prefix();
            $oldpassword = encryptIt($this->input->post("oldpass"));
            $newpassword = encryptIt($this->input->post("newpass"));
            $confirmpassword = encryptIt($this->input->post("confirmpass"));
            
            // Check old pass is correct/not
            $password = $prefix.'password';
            if($oldpassword == $data['users']->$password)
            { 
                //check new pass is equal to confirm pass
                if($newpassword==$confirmpassword)
                { 
                    $this->db->where('id',$user_id);
                    $data=array($prefix.'password'  => $newpassword);
                    $this->db->update('users',$data);
                    $this->session->set_flashdata('success',$this->lang->line('Password changed successfully'));
                    front_redirect('settings/account-change-password', 'refresh');
                }
                else
                {
                    $this->session->set_flashdata('error',$this->lang->line('Confirm password must be same as new password'));
                    front_redirect('settings/account-change-password', 'refresh');
                }
            }
            else
            {
                $this->session->set_flashdata('error',$this->lang->line('Your old password is wrong'));
                front_redirect('settings/account-change-password', 'refresh');
            }           
        }
        
        $data['site_common'] = site_common();

        $data['countries'] = $this->common_model->getTableData('countries')->result();
        $data['currencies'] = $this->common_model->getTableData('currency',array('type'=>'fiat','status'=>1))->result();
        $this->load->view('front/user/settings', $data);
    }
    function support()
    { 
                $name = $this->input->post('Name');
                $email = $this->input->post('Email'); 
                $message = $this->input->post('Message');                  
              

                // $status = 0;
                // $contact_data = array(
                //     'username' => $name,
                //     'email' => $email,                    
                //     'subject' => $subject,
                //     'message' => $comments,
                //     'phone' => $phone,
                //     'status' => $status,
                //     'created_on' => date("Y-m-d H:i:s")
                // );
                // $id = $this->common_model->insertTableData('contact_us', $contact_data);
                $email_template = 'Contact_user';
                $email_template1 = 'Contact_admin';
				$username=$this->input->post('Name');
				$message = $this->input->post('Message');
				$link = base_url().'tenrealm_admin/contact';
				$site_common      =   site_common();
				//echo $admin_admin = site_common()['site_settings']->site_email;
                  $admin_admin='support@emush.net';
               // die;
				$special_vars = array(					
				'###USERNAME###' => $username,
				'###MESSAGE###' => $message
				);
				$special_vars1 = array(					
				'###USERNAME###' => $username,
				'###MESSAGE###' => $message,
				//'###LINK###' => $link
				);

				//  print_r($email_template);
				// echo "------------------";
				//  print_r($special_vars1); die;

				    
				$this->email_model->sendMail($email, '', '', $email_template, $special_vars);
                 // echo "<pre>"; print_r($this->email->print_debugger());
                 // die;



				$this->email_model->sendMail($admin_admin, '', '', $email_template1, $special_vars1);
              
                  $this->session->set_flashdata('success', $this->lang->line('Your message successfully sent to our team'));
                   
       
    
        
      
            } 
    function support_reply($code='')
    { 
        $this->load->library('session');
        $user_id=$this->session->userdata('user_id');
        if($user_id=="")
        {   
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url().'home');
        }
        $data['site_common'] = site_common();
        $data['meta_content'] = $this->common_model->getTableData('meta_content',array('link'=>'support'))->row();
        $data['prefix'] = get_prefix();
        $data['support'] = $this->common_model->getTableData('support', array('user_id' => $user_id, 'ticket_id'=>$code))->row();
        $id = $data['support']->id;
        //$data['support_reply'] = $this->common_model->getTableData('support', array('parent_id'=>$data['support']->id,'id'=>$id))->result();
        $data['support_reply'] = $this->db->query("SELECT * FROM `tenrealm_support` WHERE `parent_id` = '".$id."'")->result();
        if($_POST)
        {
            $image = $_FILES['image']['name'];
            if($image!="") {
                if(getExtension($_FILES['image']['type']))
                {           
                    $uploadimage1=cdn_file_upload($_FILES["image"],'uploads/user/'.$user_id);
                    if($uploadimage1)
                    {
                        $image=$uploadimage1['secure_url'];
                    }
                    else
                    {
                        $this->session->set_flashdata('error', 'Please upload proper image format');
                        front_redirect('support_reply/'.$code, 'refresh');
                    }
                    $image=$image;
                }
                else
                {
                    $this->session->set_flashdata('error','Please upload proper image format');
                    front_redirect('support_reply/'.$code, 'refresh');  
                }
            } 
            else 
            { 
                $image = "";
            }
            $insertsData['status'] = '1';
            $update = $this->common_model->updateTableData('support',array('ticket_id'=>$code),$insertsData);
            if($update){
                $insertData['parent_id'] = $data['support']->id;
                $insertData['user_id'] = $user_id;
                $insertData['message'] = $this->input->post('message');
                $insertData['image'] = $image;
                $insertData['created_on'] = gmdate(time());
                $insert = $this->common_model->insertTableData('support', $insertData);
                if ($insert) {

                    $email_template     = 'Support_admin';
                    $email_template_user    = 'Support_user';
                    $site_common        =   site_common();
                    $enc_email = getAdminDetails('1','email_id');
                    $adminmail = decryptIt($enc_email);
                    $usermail = getUserEmail($user_id);
                    $username = getUserDetails($user_id,'tenrealm_username');
                    $message = $this->input->post('message');
                    $special_vars       = array(
                            '###SITELINK###'        => front_url(),
                            '###SITENAME###'        => $site_common['site_settings']->site_name,
                            '###USERNAME###'        => $username,
                            '###MESSAGE###'         => "<span style='color: #500050;'>".$message . "</span><br>",
                            '###LINK###'            => admin_url().'support/reply/'.$data['support']->id
                    );
                    
                    $special_vars_user      = array(
                            '###SITELINK###'        => front_url(),
                            '###SITENAME###'        => $site_common['site_settings']->site_name,
                            '###USERNAME###'        => $username,
                            '###MESSAGE###'         => "<span style='color: #500050;'>".$message . "</span><br>"
                    );

                    // echo $adminmail.'--'.$usermail;die;

                    $this->email_model->sendMail($adminmail, '', '', $email_template, $special_vars);
                    $this->email_model->sendMail($usermail, '', '', $email_template_user, $special_vars_user);

                    $this->session->set_flashdata('success', $this->lang->line('Your message successfully sent to our team'));
                    front_redirect('support_reply/'.$code, 'refresh');
                } else {
                    $this->session->set_flashdata('error', $this->lang->line('Error occur!! Please try again'));
                    front_redirect('support_reply/'.$code, 'refresh');
                }
            }
            else
            {
                $this->session->set_flashdata('error', $this->lang->line('Error occur!! Please try again'));
                front_redirect('support_reply/'.$code, 'refresh');
            }
        }
        $data['code'] = $code;
        $data['user_detail'] = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
        $data['users'] = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
        $data['action'] = front_url() . 'support_reply/'.$code;
        $this->load->view('front/user/support_reply', $data);
    }
    
    function tester(){
    

    
    echo "<pre>";print_r(level_init());exit;

    // echo get_transfer_Balance(393);exit;
    $user_id = 144;
    $package_id = $select_package=3;
    $current_node_id = 10;
    echo "<pre>";
    // print_r(checkAvailableUserChildren(4));exit;
    print_r(downline_remainder($package_id, $user_id, $increment=1, $chart_level=1));
    // echo downline_4x_earning(3);exit;
    // echo user_upline_team_level($user_id, $user_id, 1);
    // echo $this->getCommissionLevel($user_id, $user_id, $select_package, 1);exit;
    // $message = 'SATZ TESTING';

// $this->load->library('email');
// $config = Array(
//                 'protocol' => 'mail',
//                 'smtp_host' => 'smtp.googlemail.com',
//                 'smtp_port' => 587,
//                 'smtp_user' => 'alivejesusalive@gmail.com', // your email
//                 'smtp_pass' => 'Viva@123', // your password
//                 'smtp_timeout'=>20,
//                 'mailtype' => 'text',
//                 'charset' => 'iso-8859-1',
//                 'newline'=>"\r\n",
//                 'wordwrap' => TRUE
//               );
//  $this->email->set_newline("\r\n"); 
//  $this->email->initialize($config);
//  $this->email->from('alivejesusalive@gmail.com');
//  // $this->email->to('balabkcs7@gmail.com');
//  $this->email->to('sakthi@mailinator.com');
//  $this->email->subject('Email Test');
//  $this->email->message($message);  
//  echo $this->email->send();
//  $p = $this->email->print_debugger();
//  print_r($p);

// // the message
// $msg = "First line of text\nSecond line of text";

// // use wordwrap() if lines are longer than 70 characters
// $msg = wordwrap($msg,70);

// // send email
// mail("sakthi@mailinator.com","My subject",$msg);exit;

//  exit;
        // $user_id = 34;
        // $current_package = 3;
        // $level = 1;
        // $parent_id = 2;
        // // echo user_upline_team_level($user_id, $user_id);
        // $ref = 21; $package_id=3;
        // echo upline_4x_level($ref, $package_id);
        // // $p = getCommissionLevel($current_node_id, $user_id, $current_package, $level);
        // // print_r($p);
        // exit;




        // echo 'SIMPLE'.getadminPYMBalance(1,1);exit;
        // var_dump(addAdminBalanceAndCurrency(1));exit;
        // echo get_pym_Balance(660);exit;
        // echo getBalance(2,1);

        // die;
        $site_common      =   site_common();
        $email_template = 'Deposit_Complete';

        $special_vars   =   array(
            '###SITENAME###'  =>  'site',
            '###USERNAME###'    => 'sitename',
            '###AMOUNT###'      => '122',
            '###CURRENCY###'    => 'lss',
            '###HASH###'        => '2423423423',
            '###TIME###'        => time(),
            '###TRANSID###'     => '9759345',
            '####CONTACTLINK###'=> base_url().'contact-us'
        );

        $email = 'sakthi@mailinator.com';
        // $email = 'support@tenrealm.com';
        var_dump($this->email_model->sendMail($email, '', '', $email_template, $special_vars));exit;

        echo encryptIt(1);exit;
        echo decryptIt('WnB1OVZXR0F4NFJsMWNpY002ODRYQT09');die;
        // $currency = getcryptocurrencydetail(1);
        $beb_address = '0xa8adA09aA5beefAc2edb6BCE3FD5Fb1fAbF9af9A';
        $Validate_Address = 0;
        
        // if ($currency->currency_symbol == "LTC") {
  //           $Validate_Address = $this->local_model->validatate_address($currency->currency_name, $beb_address);
  //       } else { 
  //           $Validate_Address = 0;
  //       }


        // $Validate_Address = $this->local_model->BNB_validatate_address('BinanceCoin', $beb_address);

        // if ($Validate_Address == 1) 
        // {
        //  echo "ssss";
        // } else {
        //  echo "noo";
        // }    

        echo "<pre>sample make it easy--".$Validate_Address;
        die;

        die;

        $rebirth_income_arr = get_cultivate_reward_4x_income(3);
        print_r($rebirth_income_arr);
        echo $rebirth_income = $rebirth_income_arr->rebirth;echo '<hr>';
        echo $rewards_income = $rebirth_income_arr->rewards;exit;

        $user_id=$this->session->userdata('user_id');
        $finalbalance = 90.3;
        echo  update_pym_Balance($user_id, $finalbalance);exit;
//      echo $this->coin_price_conversion();
// echo "<br>";
//      echo $ltc = sprintf('%0.8f', (sprintf('%0.8f', $this->coin_price_conversion()) * 0.78434500));
        $ltc = 4;
//      echo '<br>';
        // echo $user_curr_LTC_deposit_amt = 0.13022000; 
        echo $user_curr_LTC_deposit_amt = $ltc; 
        echo '<br>';
        echo $new_withdraw_pym_amount = (sprintf('%0.8f', $this->coin_price_conversion('LTC','USD')));      
        echo '<br>';
        echo 'FINAL '.$pym_amount = ( $new_withdraw_pym_amount * $user_curr_LTC_deposit_amt );exit;

        


        echo decryptIt('WVA4TDFSWVFSVUczdkxPd2pnMVBEQT09');die;
        echo '<pre>';


        $this->benchmark->mark('code_start_3423434');
        
        $user_id = 33;
        $parent = 1367;
        $previous_level = 1;
        $package_id = 3;    
        // print_r(parent_id_to_user_id_4x_arr($user_id, 4));exit;  
        var_dump(is_eligiable_for_4x_package($user_id, $package_id));exit;  
        // echo $previous_level = previous_level($package_id);echo '<br>';
        // echo '<pre>';var_dump(autoUpgradeWithCommission($user_id, $package_id));echo '<br>';exit;
        // echo '<pre>';print_r(downline_level(260, 3));echo '<br>';exit;
        // echo '<pre>';print_r(upline_level(513, 3));exit;

        // echo extraRebirth('1220431365638196', 3);exit;
        // echo add_user_rebirth_address($unique_id, $user_tbl_parent);exit;
        // print_r(downline_4x_earning($package_id,1,1,1));exit;
        // // print_r(get_four_level_parent($package_id));exit;
        // print_r(upline_4x_level($parent, $package_id));exit;

        // $user_id = $this->input->get_post('user_id');
        // if($user_id){    print_r(downline_rebirth_inner_earning($user_id, 3,1,1,1));exit;}
        // if($user_id){    print_r(downline_earning(3,1,1,1));}
        // // if($user_id){ print_r(downline_earning_tester($user_id, 3,1,1,1));exit;}
        // $this->benchmark->mark('code_end_3423434');
        // echo "\n <br>".$this->benchmark->elapsed_time('code_start_3423434', 'code_end_3423434');
        // exit;

        // echo 'SUCESS';exit;

                        
        // echo $package_amount = package_price(5);exit;
        // $parent = 71; $previous_level = 7;$package_id = 3;
        // print_r(find_upline_user_id($parent,upline_level($parent,$previous_level, $package_id),  $package_id));exit;
        // var_dump(branch_income(3,2));exit;

        // print_r(package_price(3));exit;
        // $p = $this->com_m->getTableData('')->result_array();
        // print_r($p);exit;
        // echo refresh_token();exit;
                        // // print_r(get_four_level_parent());exit;
                        print_r(rebirth4X(2,3,0));exit;
                        // // print_r(global_farming_reduce_income(3,1));exit;
                        // print_r(child_downline_earning(1,3,1,1,1));exit;
                        // print_r(downline_earning(3,1,1,1));exit;
                        // print_r(downline_4x_earning(3,1,1,1));exit;
                        
                        print_r(getCommissionLevel(2,2,3,1,0,1));exit;
                        // print_r(autoUpgrade(1, 3));exit;
                        // print_r(getNextPackage(3,'id'));exit;
        echo 'parent 1-->';print_r(get_two_level_parent(7));exit;
        echo 'parent 2-->';print_r(get_two_level_parent());
        exit;
        foreach (range(1,10) as $key => $value) {
            $this->db->query("SELECT * FROM `tenrealm_package_payment` WHERE user_level=".$value." or rebirth_level = ".$value." ORDER BY `id` ASC");
        }
        $parent = 128;
        echo 'Upline Level'.upline_level($parent);exit;
        echo 'FIND UPLINE USER ID ARR';print_r(find_upline_user_id($parent,upline_level($parent)));
        exit;
        // print_r(rebirth4X());
        print_r(get_two_level_parent());exit;
        print_r(find_upline_user_id(1500,10));exit;
    }


    function remaining(){
        echo "<pre>";print_r(remaining_init());exit;
    }

    function testers(){

        echo "<pre>";print_r(remaining_init());exit;
        
     // $value=$this->common_model->getTableData('package_4x_payment')->num_rows();

       $value='20';

       for ($x = 1; $x <= $value; $x++) {


        for ($k = 1; $k <= $x; $k++){



            $get_lavel=$this->common_model->getTableData('package_4x_payment',array('id'=>$k))->row();
            $lavel1_value=$get_lavel->lavel1;
            if($lavel1_value!='0') {
                $lavel1=$get_lavel->lavel1;
                $update_lavel1=$lavel1-1;
                $this->common_model->updateTableData('package_4x_payment',array('id'=>$k),array('lavel1'=>$update_lavel1));
                $update_lavel=$this->common_model->getTableData('package_4x_payment',array('id'=>$k))->row();

                // echo "<pre>";
                // print_r($update_lavel);
                // die;

                $update_current=$this->common_model->getTableData('package_4x_payment',array('id'=>$k+1))->row();


                //  echo $update_lavel->lavel1;

                //  echo "-------";

                //  echo $update_current->lavel1;

                // echo "-----------";

                $B=$update_lavel->lavel1;
                $Y=$update_current->lavel1;

                $update_remails1 = $B + $Y;

                $this->common_model->updateTableData('package_4x_payment',array('id'=>$k+1),array('lavel1'=>$update_remails1));

            }

            $lavel2_value=$get_lavel->lavel2;
            if($lavel2_value!='0'){
                $lavel2=$get_lavel->lavel2;
                $update_lavel2=$lavel2-1;
                $this->common_model->updateTableData('package_4x_payment',array('id'=>$k),array('lavel2'=>$update_lavel2));

                $update_lavel=$this->common_model->getTableData('package_4x_payment',array('id'=>$k))->row();
                $update_current=$this->common_model->getTableData('package_4x_payment',array('id'=>$k+1))->row();

                $B=$update_lavel->lavel2;
                $Y=$update_current->lavel2;

                $update_remails2 = $B + $Y;

                $this->common_model->updateTableData('package_4x_payment',array('id'=>$k+1),array('lavel2'=>$update_remails2));


            }

            $lavel3_value=$get_lavel->lavel3;
            if($lavel3_value!='0'){
                $lavel3=$get_lavel->lavel3;
                $update_lavel3=$lavel3-1;
                $this->common_model->updateTableData('package_4x_payment',array('id'=>$k),array('lavel3'=>$update_lavel3));

                $update_current=$this->common_model->getTableData('package_4x_payment',array('id'=>$k+1))->row();
                $B=$update_lavel->lavel3;
                $Y=$update_current->lavel3;

                $update_remails3 = $B + $Y;

                $this->common_model->updateTableData('package_4x_payment',array('id'=>$k+1),array('lavel3'=>$update_remails3));



            }

            $lavel4_value=$get_lavel->lavel4;
            if($lavel4_value!='0'){
                $lavel4=$get_lavel->lavel4;
                $update_lavel4=$lavel4-1;
                $this->common_model->updateTableData('package_4x_payment',array('id'=>$k),array('lavel4'=>$update_lavel4));
                $update_current=$this->common_model->getTableData('package_4x_payment',array('id'=>$k+1))->row();

                $B=$update_lavel->lavel4;
                $Y=$update_current->lavel4;

                $update_remails4 = $B + $Y;

                $this->common_model->updateTableData('package_4x_payment',array('id'=>$k+1),array('lavel4'=>$update_remails4));

            }

        }
    }
}


    function cron_2x_profit(){
        $this->manual2x();
        echo 'success';
        exit;
        ob_start();
        // $package_id = $this->db->limit(1)->get('package')->row('id');
        $package_id_arr = $this->db->select('id')->get('package')->result_array();      
        if(!empty($package_id_arr)){
            foreach ($package_id_arr as $pkey => $pvalue) {
                if($pvalue){
                    echo '<pre>';print_r(downline_earning($pvalue['id'],1,1,1));        
                }
            }           
            echo 'Success';
        }else{
            return 'No package available';
        }   
        ob_end_clean();
    }


    function cron_42x_profit(){
        $this->manual42x();
        echo 'success';
        exit;
        ob_start();
        // $package_id = $this->db->limit(1)->get('package')->row('id');
        $package_id_arr = $this->db->select('id')->get('package')->result_array();      
        if(!empty($package_id_arr)){
            foreach ($package_id_arr as $pkey => $pvalue) {
                if($pvalue){
                    echo '<pre>';print_r(downline_earning($pvalue['id'],1,1,1));        
                }
            }           
            echo 'Success';
        }else{
            return 'No package available';
        }   
        ob_end_clean();
    }


    function cron_4x_profit(){  
        echo 'success';
        $this->manual4x();
        return true;exit;   
        ob_start();     
        $package_id_arr = $this->db->select('id')->get('package')->result_array();      
        if(!empty($package_id_arr)){
            foreach ($package_id_arr as $pkey => $pvalue) {
                if($pvalue){
                    echo $pvalue['id'];
                    echo '<pre>';print_r(downline_4x_earning($pvalue['id'],1,1,1));     
                }
            }           
            echo 'Success';
        }else{
            return 'No package available';
        }   
        ob_end_clean();
    }


    function manual2x(){
        // ob_start();
        $prefix=get_prefix();
        $table1 = $prefix . 'global_profit';
        $table2 = $prefix . 'global_rebirth';
        $package_id_arr = $this->db->select('id')->get('package')->result_array();
        if(!empty($package_id_arr)){
            foreach ($package_id_arr as $pkey => $pvalue) {
                if($pvalue){
                    echo '<br>package-->'.$pvalue['id'];
                    echo '<pre>';print_r(downline_earning($pvalue['id'],1,1,1,1));      
                }
            }
        }else{
            return 'No package available';
        }
        // ob_end_clean();
        echo 'Success'.rand();exit;
    }


    function manual42x(){
        // ob_start();
        $prefix=get_prefix();
        $table1 = $prefix . 'global_profit';
        $table2 = $prefix . 'global_rebirth';
        $package_id_arr = $this->db->select('id')->get('package')->result_array();
        if(!empty($package_id_arr)){
            foreach ($package_id_arr as $pkey => $pvalue) {
                if($pvalue){
                    echo '<br>package-->'.$pvalue['id'];
                    echo '<pre>';print_r(downline_earning($pvalue['id'],1,1,1,2));      
                }
            }
        }else{
            return 'No package available';
        }
        // ob_end_clean();
        echo 'Success'.rand();exit;
    }


    function manual4x(){
        // ob_start();
        $prefix=get_prefix();
        $table1 = $prefix . 'global_profit';
        $table2 = $prefix . 'global_rebirth';
        $package_id_arr = $this->db->select('id')->get('package')->result_array();
        if(!empty($package_id_arr)){
            foreach ($package_id_arr as $pkey => $pvalue) {
                if($pvalue){
                    echo '<br>package-->'.$pvalue['id'];
                    echo '<pre>';print_r(downline_4x_earning($pvalue['id'],1,1,1));     
                }
            }
        }else{
            return 'No package available';
        }
        // ob_end_clean();
        echo 'Success'.rand();exit;
    }


    function dashboard()
    {   

        $user_id = $this->session->userdata('user_id');
        if($user_id=="")
        {   
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url('home'));
        }

        $unique_id = user_id_to_unique_id($user_id);

        $data['site_common'] = site_common();
        $data['meta_content'] = $this->common_model->getTableData('meta_content', array('link'=>'dashboard'))->row();
        // To check valid user or not
        $data['users'] = $get_user_row = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
        

        $data['login_history'] = $this->common_model->getTableData('user_activity',array('activity' => 'Login','user_id'=>$user_id),'date','','','','','',array('act_id','DESC'))->row_array();

        $data['wallet'] = unserialize($this->common_model->getTableData('wallet',array('user_id'=>$user_id),'crypto_amount')->row('crypto_amount'));

        $data['dig_currency'] = $this->common_model->getTableData('currency',array('status'=>1),'','','','','','',array('sort_order','ASC'))->result();
        /*$data['banners'] = $this->common_model->getTableData('banners',array('status'=>1),'','','','','','', array('id', 'ASC'))->result();*/
        $data['packages'] = $this->common_model->getTableData('package',array('status'=>1))->result_array();

        $manual_already_update_income = $this->com_m->get_row_val('package_payment', ['unique_id' => $unique_id, 'auto_upgrade' => '0'], "sum(already_activated_income)");
    
        
        
        $data['sum_user_global_income'] = (getAllprofit()) ? (getAllprofit() + $manual_already_update_income) : 0;      

            


        $data['sum_user_wt_level_income'] = (getwtAlllevel()) ? getwtAlllevel() : 0;
        
        $data['sum_user_wt_global_income'] = (getwtAllprofit()) ? (getwtAllprofit() + $manual_already_update_income) : 0;       

        $data['sum_user_wt_sponsor_income'] = (getwtAllsponsor()) ? getwtAllsponsor() : 0;

        $data['sum_user_level_income_level'] =  $this->db->order_by('id', 'desc')->limit(1)->select('level')->get_where('global_4x_profit', ['receiver_user_id' => $user_id, 'status' => '1'])->row('level');



        $data['sum_user_team_income'] = (getAllsponsor()) ? getAllsponsor() : 0;
        $data['sum_user_direct_income'] = (getDirectAllincome()) ? getDirectAllincome() : 0;    
        $data['sum_user_level_income'] = (getAlllevel()) ? getAlllevel() : 0;

                
        $user_package_arr = $this->com_m->getTableData('package_4x_payment', array('user_id' => $user_id ), "package_id")->result_array();
        $uArr = [];
            foreach ($user_package_arr as $uskey => $usvalue) {
                $uArr[] = $usvalue['package_id'];
            }
        $data['user_package_arr'] = $uArr;
        $data['current_package_payment'] = $user_package_arr;       
        if(!$user_package_arr && $get_user_row){            
            $time_format = 'Y-m-d H:i:s';
            $data['remaining_period_timestamp'] = $p = strtotime(date($time_format, strtotime(date($time_format, $get_user_row->created_on). ' + 30 days')));           
        }
        $data['trans_history'] = $this->common_model->getTableData('transactions',array('user_id'=>$user_id),'','','','','','',array('trans_id','DESC'))->result();
        $withdraw_cond = array('unique_id' => $unique_id, 'status' => 'Completed', 'user_status' => 'Completed', 'type' => 'Withdraw');
        $data['withdraw_package_payment'] = $this->com_m->getTableData('transactions', $withdraw_cond, "sum(amount) as wt")->row('wt');
        // echo $this->db->last_query();
        // echo '<pre>';print_r($data);exit;
        $data['total_earning'] = (number_format(total_earning($user_id), 2)) ?? 0.00;
        $this->load->view('front/user/dashboard', $data);
    } 

    function user_claim(){
        try {
          $this->via_valid_sess_and_ajax_user();
          $user_id = $this->session->userdata('user_id');
           $type = escape_str($this->input->post('type'));
           $valid = false;
           $unique_id = user_id_to_unique_id($user_id);
           $msg = 'Claimed';
           $level_table = 'top_level_segment';
           $already_activated_income_table = 'package_4x_payment';
           $global_2x_table = 'global_profit';
           $global_4x_table = 'global_4x_profit';
           $wallet_table = 'wallet';
           $wallet_cond = ['user_id' => $user_id ];
           // Validate amount is available or not
           if($type == 'sponsor'){
             $level_cond = array('status' => '1', 'send_to'=> $user_id);
             $lprice =  (getAllsponsor()) ? getAllsponsor() : 0;
             if($lprice > 0){
                $this->com_m->updateTableData($level_table, $level_cond, ['status' => '0']);
                $current_bal = get_pym_Balance($user_id);
                $final_bal = $current_bal + $lprice;
                $this->com_m->updateTableData($wallet_table, $wallet_cond, ['fiat_amount' => $final_bal]);
                echo json_encode(['status'=> true, 'msg' => $msg, 'main_balance' =>  $this->mainBal(),'remaining' => '0' ]);exit;
             }
           }else if($type == 'global'){
            $global_cond = array('status' => '1', 'unique_id'=> $unique_id);
            $already_activated_income_cond = array('direct_parent' => $user_id, 'direct_parent_income_status' => '1');
            $gprice =  (getDirectAllincome()) ? (getDirectAllincome() ) : 0 ;              
             if($gprice){
                $this->com_m->updateTableData($already_activated_income_table, $already_activated_income_cond, ['direct_parent_income_status' => '0']); 
                $current_bal = get_pym_Balance($user_id);
                $final_bal = $current_bal + $gprice;
                $this->com_m->updateTableData($wallet_table, $wallet_cond, ['fiat_amount' => $final_bal]);
                $current_bal = get_pym_Balance($user_id);                           
                echo json_encode(['status'=> true, 'msg' => $msg,  'main_balance' =>  $this->mainBal(),'remaining' => '0' ]);exit;
             }
           }else if($type == 'level'){
                $level = $this->input->post('position');
                // $required_user =  $this->db->select("count('id') as cid")->get_where('package_4x_payment', ['direct_parent' => $user_id ])->row('cid');

                $current_level = $level;
                if($current_level==1){
                    $g4table_cond = array('status' => '1', 'receiver_user_id'=> $user_id, 'level' => '1');
                    $basic_bal = $this->db->get_where('global_4x_profit',  $g4table_cond)->row('profit');
                    $sprice = $basic_bal;
                    $sonsor_cond = array('status' => '1', 'receiver_user_id'=> $user_id, 'level' => $current_level);
                }else{
                    
                        $g4table_cond = array('status' => '1', 'receiver_user_id'=> $user_id, 'level' => $current_level);
                        $basic_bal = $this->db->get_where('global_4x_profit',  $g4table_cond)->row('profit');    
                    
                    $sprice = $basic_bal;
                    $sonsor_cond = array('status' => '1', 'receiver_user_id'=> $user_id, 'level' => $current_level);
                }                    
                    $g4table_data = array('status' => '0', 'basic_amount'=> '0');
                    // $sprice =  (getAlllevel()) ? getAlllevel() : 0 ;            
                     if($sprice > 0){                        
                        $current_bal = get_pym_Balance($user_id);
                        $final_bal = ($current_bal + $sprice);

                        $this->com_m->updateTableData($wallet_table, $wallet_cond, ['fiat_amount' => $final_bal]);
                        $this->com_m->updateTableData($global_4x_table, $sonsor_cond, ['status' => '0']);
                        $json_arr = ['status'=> true, 'msg' => $msg,  'main_balance' =>  $this->mainBal() ];                
                        echo json_encode(['status'=> true, 'msg' => $msg,  'main_balance' =>  $this->mainBal(),'remaining' => getAlllevel() ]);exit;
                     }

           }

        echo json_encode(['status'=> false, 'msg' => 'No amount k567' ]);exit;
        } catch (Exception $e) {
            return $this->catchMyError($e); 
        }

    }


function mainBal(){

        $sum_user_team_income = (getAllsponsor()) ? getAllsponsor() : 0;
        $sum_user_direct_income = (getDirectAllincome()) ? getDirectAllincome() : 0;    
        $sum_user_level_income = (getAlllevel()) ? getAlllevel() : 0;


        $p = $sum_user_team_income + $sum_user_direct_income + $sum_user_level_income;
        return number_format($p,2);
}

function change_address()
    {
        $user_id=$this->session->userdata('user_id');
        $currency_id = $this->input->post('currency_id');
        $coin_address = getAddress($user_id,$currency_id);
        $data['img'] =  "https://chart.googleapis.com/chart?cht=qr&chs=280x280&chl=$coin_address&choe=UTF-8&chld=L";
        $data['address'] = $coin_address;
        
        $currency_det = $this->common_model->getTableData("currency",array('id'=>$currency_id))->row();
        $data['coin_symbol'] = $currency_det->currency_symbol;
        if($data['coin_symbol']=="INR")
        {
            $format = 2;
        }
        else
        {
            $format = 8;
        }
        if($currency_id==6){
            $data['destination_tag'] = secret($user_id);
        }
        $coin_balance = number_format(getBalance($user_id,$currency_id),$format);
        $data['coin_name'] = ucfirst($currency_det->currency_name);
        $data['coin_balance'] = $coin_balance;
        $data['withdraw_fees'] = $currency_det->withdraw_fees;
        $data['withdraw_limit'] = $currency_det->max_withdraw_limit;
        echo json_encode($data);
    }

    function update_user_address()
    {

        $Fetch_coin_list = $this->common_model->getTableData('tenrealm_currency use index (address)',array('type'=>'digital','status'=>'1'))->result();
        foreach($Fetch_coin_list as $coin_address)
        {
            $userdetails = $this->common_model->getTableData('crypto_address',array($coin_address->currency_symbol.'_status'=>'0'),'','','','','','',array('id','DESC'))->result();
            // echo "<pre>";print_r($userdetails);
            foreach($userdetails as $user_details) 
            {
                $User_Address = getAddress($user_details->user_id,$coin_address->id);
                if(empty($User_Address) || $User_Address==0)
                {
                    $parameter = '';
                    if($coin_address->coin_type=="coin")
                    {
         //             if($coin_address->currency_symbol=='ETH')
                        // { 
                        //  $parameter='create_eth_account';
                        //  $Get_First_address = $this->local_model->access_wallet($coin_address->id,'create_eth_account',getUserEmail($user_details->user_id));

                        //  if(!empty($Get_First_address) || $Get_First_address!=0)
                        //  {

                        //      updateAddress($user_details->user_id,$coin_address->id,$Get_First_address);
                        //      echo $coin_address->currency_symbol.' Success1 <br/>';
                        //  }
                        //  else{
                        //      $Get_First_address = $this->common_model->update_address_again($user_details->user_id,$coin_address->id,$parameter);
                        //      if($Get_First_address){
                        //          updateAddress($user_details->user_id,$coin_address->id,$Get_First_address);
                        //          echo $coin_address->currency_symbol.' Success2 <br/>';
                        //      }
                        //  }
                        // }
                        // elseif($coin_address->currency_symbol=='BNB')
                        // {
                        //  $parameter='create_eth_account';

                        //  $Get_First_address = $this->local_model->access_wallet($coin_address->id,'create_eth_account',getUserEmail($user_details->user_id));
                        //  if(!empty($Get_First_address) || $Get_First_address!=0)
                        //  {
                        //      updateAddress($user_details->user_id,$coin_address->id,$Get_First_address);
                        //  }
                        //  else{
                        //      $Get_First_address = $this->common_model->update_address_again($user_details->user_id,$coin_address->id,$parameter);
                        //      if($Get_First_address){
                        //          updateAddress($user_details->user_id,$coin_address->id,$Get_First_address);
                        //      }
                        //  }
                        // }
                        // else
                        // {
                            $parameter='getnewaddress';
                            $Get_First_address1 = $this->local_model->access_wallet($coin_address->id,'getnewaddress',getUserEmail($user_details->user_id));

                            // echo "<pre>";print_r($Get_First_address1);
                            
                            if(!empty($Get_First_address1) || $Get_First_address1!=0){

                                // if($coin_address->currency_symbol=='XRP'){
                                //  echo "Success<br/>";

                                // $Get_First_address = $Get_First_address1->address;
        //                         $Get_First_secret  = $Get_First_address1->secret;
        //                         $Get_First_tag = $Get_First_address1->tag;

        //                         updaterippleSecret($user_details->user_id,$coin_address->id,$Get_First_secret);
        //                         echo "Success2<br/>";
        //                         updaterippletag($user_details->user_id,$coin_address->id,$Get_First_tag);
        //                         echo "Success3<br/>";
                                // }
                                // else{
                                //  $Get_First_address = $Get_First_address1;

                                // }

                                $Get_First_address = $Get_First_address1;
                                // echo "<pre>";print_r($Get_First_address);die;
                                updateAddress($user_details->user_id,$coin_address->id,$Get_First_address);
                            }
                            else{ 
                                if($Get_First_address1){
                                    $Get_First_address = $this->common_model->update_address_again($user_details->user_id,$coin_address->id,$parameter);

                                    updateAddress($user_details->user_id,$coin_address->id,$Get_First_address);
                                    echo $coin_address->currency_symbol.' Success2 <br/>';
                                }
                            }
                        // }
                    }
                    else
                    {       
                        if($coin_address->crypto_type=='eth'){
                        $eth_id = $this->common_model->getTableData('currency',array('currency_symbol'=>'ETH'))->row('id');
                        $eth_address = getAddress($user_details->user_id,$eth_id);
                    }

                    updateAddress($user_details->user_id,$coin_address->id,$eth_address);


          
                    }
                }
            }
        }       
    }
    
    function get_user_list_coin($curr_id)
    {
        $users = $this->common_model->getTableData('users',array('verified'=>1), 'id','','','')->result();
        $rude = array();
        foreach($users as $user)
        {   
            $wallet = unserialize($this->common_model->getTableData('crypto_address',array('user_id'=>$user->id),'address')->row('address'));

            //echo "<pre>"; print_r($wallet); echo "</pre>";
            
            $email = getUserEmail($user->id);
            $currency=$this->common_model->getTableData('currency',array('status'=>1, 'type'=>'digital','id'=>$curr_id))->result();

            //echo "<pre>"; print_r($currency); echo "</pre>";
            $i = 0;
            foreach($currency as $cu)
            {
                    if(($wallet[$cu->id]!='') || ($wallet[$cu->id]!=0))
                    {
                        $balance[$user->id][$i] = array('currency_symbol'=>$cu->currency_symbol, 
                            'currency_name'=>$cu->currency_name,
                            'currency_id'=>$cu->id,
                            'address'=>$wallet[$cu->id],
                            'destination_tag'=>secret($user->id),
                            'user_id'=>$user->id,
                            'user_email'=>$email);
                        array_push($rude, $balance[$user->id][$i]); 
                    }       
                $i++;
            }
        }
        return $rude;   
    }

    function get_user_coin($curr_id)
    {
        $user_id=$this->session->userdata('user_id');

        $user = $this->common_model->getTableData('users',array('id'=>$user_id,'verified'=>1), 'id','','','')->row();
        $rude = array();
        // foreach($users as $user)
        // {    
            $wallet = unserialize($this->common_model->getTableData('crypto_address',array('user_id'=>$user->id),'address')->row('address'));

            //echo "<pre>"; print_r($wallet); echo "</pre>";
            
            $email = getUserEmail($user->id);
            $currency=$this->common_model->getTableData('currency',array('status'=>1, 'type'=>'digital','id'=>$curr_id))->result();

            //echo "<pre>"; print_r($currency); echo "</pre>";
            $i = 0;
            foreach($currency as $cu)
            {
                    if(($wallet[$cu->id]!='') || ($wallet[$cu->id]!=0))
                    {
                        $balance[$user->id][$i] = array('currency_symbol'=>$cu->currency_symbol, 
                            'currency_name'=>$cu->currency_name,
                            'currency_id'=>$cu->id,
                            'address'=>$wallet[$cu->id],
                            'destination_tag'=>secret($user->id),
                            'user_id'=>$user->id,
                            'user_email'=>$email);
                        array_push($rude, $balance[$user->id][$i]); 
                    }       
                $i++;
            }
        // }
        return $rude;   
    }

    public function get_user_with_dep_det($curr_id)
    {
        $users  = $this->get_user_list_coin($curr_id);

        //echo "<pre>";print_r($users); exit;

        $currencydet = $this->common_model->getTableData('currency', array('id'=>$curr_id))->row();

        $orders = $this->common_model->getTableData('transactions', array('type'=>'Deposit', 'user_status'=>'Completed','currency_type'=>'crypto','currency_id'=>$curr_id))->result_array();
        $address_list = $transactionIds = array();
        //collect all users wallet address list
        if(count($users)){
            foreach($users as $user){
                if( $user['address'] != '')
                {
                    $address_list[(string)$user['address']] = $user;
                }
            }
        }
        
        if(count($orders)){
            foreach($orders as $order){
                if(trim($order['wallet_txid']) != '')
                $transactionIds[$order['wallet_txid']] = $order;
            }
        }

        return array('address_list'=>$address_list,'transactionIds'=>$transactionIds,'currency_decimal'=>$currencydet->currency_decimal);
    }

    public function get_user_with_dep_detail($curr_id)
    {
        $users  = $this->get_user_coin($curr_id);

        //echo "<pre>";print_r($users); exit;

        $currencydet = $this->common_model->getTableData('currency', array('id'=>$curr_id))->row();

        $orders = $this->common_model->getTableData('transactions', array('type'=>'Deposit', 'user_status'=>'Completed','currency_type'=>'crypto','currency_id'=>$curr_id))->result_array();
        $address_list = $transactionIds = array();
        //collect all users wallet address list
        if(count($users)){
            foreach($users as $user){
                if( $user['address'] != '')
                {
                    $address_list[(string)$user['address']] = $user;
                }
            }
        }
        
        if(count($orders)){
            foreach($orders as $order){
                if(trim($order['wallet_txid']) != '')
                $transactionIds[$order['wallet_txid']] = $order;
            }
        }

        return array('address_list'=>$address_list,'transactionIds'=>$transactionIds,'currency_decimal'=>$currencydet->currency_decimal);
    }


    public function user_crypto_deposits($coin_name='Litecoin', $data=array()) // LTC
    {

        // error_reporting(E_ALL);
        $coin_name1 = $coin_name;
        $curr_id = $this->common_model->getTableData('currency',array('currency_name'=>$coin_name))->row('id');
        $user_trans_res   = $this->get_user_with_dep_detail($curr_id);
        $address_list     = $user_trans_res['address_list'];
        $transactionIds   = $user_trans_res['transactionIds'];
        $tot_transactions = array();


        $current_address = $data['current_crypto_address'];
        $user_raw_deposit_pym = $data['user_raw_deposit_pym'];
        $admin_pym = $data['admin_pym']; /// New pym with admin fee
        $admin_ltc = $data['admin_ltc'];
        $percentage_amount = $data['percentage_amount'];

        

        // echo "<pre>Transactions"; print_r($current_address);die;

        $curr_symbol = $this->common_model->getTableData('currency',array('currency_name'=>$coin_name))->row('currency_symbol');

        $valid_server =1;
        $coin_type = $this->common_model->getTableData('currency',array('currency_name'=>$coin_name))->row('coin_type');
        $coinDetails = $this->common_model->getTableData('currency',array('currency_name'=>$coin_name))->row('admin_move');

        

        if($valid_server && !empty($data))
        {
            if($coin_type=="coin") // COIN PROCESS
            { 
                switch ($coin_name) 
                {
                    case 'Litecoin':
                        $transactions   = $this->local_model->get_transactions('Litecoin');
                        break;              
                    default:
                        show_error('No directory access');
                        break;
                }
           }
           else // TOKEN PROCESS
           { 
                $transactions    = $this->local_model->get_transactions($coin_name,$user_trans_res);
           }

            // echo "<pre>Transactions"; print_r($transactions); echo "</pre>";die;

            if(count($transactions)>0 || $transactions!='')
            {
                $i=0;
                foreach ($transactions as $key => $value) 
                {
                    $i++;
                    $index = $value['address'].'-'.$value['confirmations'].'-'.$i;
                    
                    $tot_transactions[$index] = $value;
                }
            }
            
            // echo "<pre>Transactions"; print_r($tot_transactions); echo "</pre>";die;

            if(!empty($tot_transactions) && count($tot_transactions)>0)
            {
                $a=0;
                foreach ($tot_transactions as $row) 
                {
                    $a++;$from_address='';
                    // $account       = $row['account'];        
                    $address       = $row['address'];
                    $confirmations = $row['confirmations']; 
                     //$txid          = $row['txid'];
                    $txid          = $row['txid'].'#'.$row['time'];
                    //$time_st       = $row['time'];
                    $time_st       = date("Y-m-d h:i:s",$row['time']);          
                    $amount        = $row['amount'];
                    $category      = $row['category'];      
                    $blockhash     = (isset($row['blockhash']))?$row['blockhash']:'';
                    $ind_val       = $address.'-'.$confirmations.'-'.$a;
                    if($coin_name1=='Ethereum' || $coin_name1=='Tether'){
                        $from_address = $row['from'];
                    }
                    else{
                        $from_address = '';
                    }

                    $admin_address = getadminAddress(1,$curr_symbol);

                    


                    $counts_tx = $this->db->query('select * from tenrealm_transactions where information="'.$row['blockhash'].'" and wallet_txid="'.$txid.'"')->num_rows();

                    $user_curr_deposit_amt = $amount;
                    
                    // echo $confirmations;
                    //  echo "<pre>";
                    // print_r($address_list[$address]);    
                        // die;
                    
                    if( $category == 'receive' && $confirmations > 0 && $counts_tx == 0 && $address_list[$address])
                    {   

                        if(isset($address_list[$address]))
                        {
                            // echo 'ttttt---'.$address_list[$address]['user_id'];
                            if($coin_name1!='Ripple'){
                                $user_id   = $address_list[$address]['user_id'];
                        }
                        else{
                            // echo "Nooooo";die;
                            $user_id = $row['user_id'];
                            
                        }
                            $coin_name = "if".$address_list[$address]['currency_name'];
                            $cur_sym   = $address_list[$address]['currency_symbol'];
                            $cur_ids   = $address_list[$address]['currency_id'];
                            $email     = $address_list[$address]['user_email'];
                        }
                        // else
                        // {

                        //  foreach ($address_list as $key => $value) 
                        //  {                           
                        //      if(($value['currency_symbol'] == 'ETH') && strtolower($address) ==  strtolower($value['address']))  
                        //      {
                        //          $user_id   = $value['user_id'];
                        //          $coin_name = "else".$value['currency_name'];
                        //          $cur_sym   = $value['currency_symbol'];
                        //          $cur_ids   = $value['currency_id'];
                        //          $email     = $value['user_email'];
                        //      }
                        //  }
                        // }


                        $onlinePrice = (sprintf('%0.8f', $this->coin_price_conversion('USD','LTC')));           

                        // echo $from_address.'--'.$address.'---'.$admin_address;die;   
                        // echo "<br>";

                        if(trim($from_address)!=trim($admin_address))
                        { 

                            if(isset($user_id) && !empty($user_id))
                            {
                                $balance = getBalance($user_id,$cur_ids,'crypto'); 
                                $sumBalance = $user_raw_deposit_pym * $onlinePrice;
                                $finalbalance = $balance + $sumBalance; 
                                 
                                // echo $balance.'---'.$user_raw_deposit_pym.'---'.$sumBalance.'--'.$finalbalance;die;  
                                $updatebalance = updateBalance($user_id,$cur_ids,$finalbalance,'crypto'); // Update balance
                                // $last_fiat_amount = get_pym_Balance($user_id);

                                $get_current_pym_Balance = get_pym_Balance($user_id);
                                $final_pym_amount = $get_current_pym_Balance + $user_raw_deposit_pym;
                                $update_pym_balance = update_pym_Balance($user_id,$final_pym_amount); // Update balance

                                // echo $get_current_pym_Balance.'---'.$user_raw_deposit_pym.'---'.$final_pym_amount.'--'.$update_pym_balance;die;

                                // $amount = 0.19837800;
                                // echo "<pre>";print_r($data);die;
                                // echo $amount.'---'.$admin_ltc;die;
                                if($amount == $admin_ltc) 
                                {
                                
                                // Add to reserve amount
                                // $reserve_amount = getcryptocurrencydetail($cur_ids);
                                // $final_reserve_amount = (float)$amount + (float)$reserve_amount->reserve_Amount;
                                // $new_reserve_amount = updatecryptoreserveamount($final_reserve_amount, $cur_ids);

                                $amount = $user_raw_deposit_pym;
                                $fiat_amount = $admin_pym;
                                $transfer_amount = $admin_ltc;
                                $fee = $percentage_amount;  

                                $Ref = $user_id.'#'.current_micro_timestamp();
                                // insert the data for deposit details
                                $dep_data = array(
                                    'user_id'           => $user_id,                                    
                                    'currency_id'       => $cur_ids,
                                    'type'              => "Deposit",
                                    'currency_type'     => "crypto",
                                    'description'       => $coin_name1." Payment",
                                    'unique_id'         => user_id_to_unique_id($user_id),
                                    'created_at'        => timestamp_UTC_conversion($time),
                                    'amount'            => $amount, 
                                    'currency_amount'   => $sumBalance,
                                    'fiat_amount'       => $fiat_amount,
                                    'transfer_amount'   => $transfer_amount, 
                                    'fee'               => $fee, 
                                    'information'       => $blockhash,
                                    'wallet_txid'       => $txid,
                                    'crypto_address'    => $address,
                                    'payment_method'    => 'crypto',
                                    'status'            => "Completed",
                                    'datetime'          => $time_st,
                                    'user_status'       => "Pending",
                                    'transaction_id'    => $Ref,
                                    // 'datetime'           => (empty($txid))?$time_st:time(),
                                    'local_transaction_id' => generate_local_transaction_id(),
                                    'confirmations'     => $confirmations
                                );
                                $ins_id = $this->common_model->insertTableData('transactions',$dep_data);

                                $trans_data = array(
                                    'userId'=>$user_id,
                                    'type'=>'Deposit',
                                    'currency'=>$cur_ids,
                                    'amount'=>$amount,
                                    'profit_amount'=>$fee,
                                    'comment'=>'Deposit #'.$ins_id,
                                    'datetime'=>$time_st,
                                    'currency_type'=>'crypto'
                                );
                                $update_trans = $this->common_model->insertTableData('transaction_history',$trans_data);

                                $prefix = get_prefix();
                                $userr = getUserDetails($user_id);
                                $usernames = $prefix.'username';
                                $username = $userr->$usernames;
                                $sitename = getSiteSettings('english_site_name');

                                $site_common      =   site_common();
                                $email_template = 'Deposit_Complete';

                                $special_vars   =   array(
                                    '###SITENAME###'  =>  $sitename,
                                    '###USERNAME###'    => $username,
                                    '###AMOUNT###'      => $transfer_amount,
                                    '###CURRENCY###'    => $cur_sym,
                                    '###HASH###'        => $blockhash,
                                    '###TIME###'        => $time_st,
                                    '###TRANSID###'     => $txid,
                                    '####CONTACTLINK###'=> base_url().'contact-us'
                                );

                                $this->email_model->sendMail($email, '', '', $email_template, $special_vars);
                                $result = array('status'=>1,'message'=>'update deposit successed','trans_id'=>$ins_id);
                                return json_encode($result);
                            }
                               
                            }
                        } 
                        // elseif($from_address == $admin_address)
                        // {
                        //     if($coinDetails==1)
                        //  {
                        //      $this->transfer_to_admin_wallet($coin_name1);
                        //  }
                        // }   
                    }
                    else
                    {
                        // $result = array('status'=>2,'message'=>'update failed');
                    }
                /*}*/
                }
                
                // $result = array('status'=>'success','message'=>'update deposit successed');
                
            }
            else
            {
                
                $result = array('status'=>3,'message'=>'update failed');
                return json_encode($result);
            }
        }
        else
        {
            $result = array('status'=>0,'message'=>'update failed');
            return json_encode($result);
        }
        
        // die(json_encode($result));

    }


    public function update_crypto_deposits($coin_name='Litecoin') // LTC
    {
        // error_reporting(E_ALL);
        $coin_name1 = $coin_name;
        $curr_id = $this->common_model->getTableData('currency',array('currency_name'=>$coin_name))->row('id');
        $user_trans_res   = $this->get_user_with_dep_det($curr_id);
        $address_list     = $user_trans_res['address_list'];
        $transactionIds   = $user_trans_res['transactionIds'];
        $tot_transactions = array();

        // echo "<pre>";print_r($address_list);die;

        $curr_symbol = $this->common_model->getTableData('currency',array('currency_name'=>$coin_name))->row('currency_symbol');

        $valid_server =1;
        $coin_type = $this->common_model->getTableData('currency',array('currency_name'=>$coin_name))->row('coin_type');
        $coinDetails = $this->common_model->getTableData('currency',array('currency_name'=>$coin_name))->row('admin_move');

        // echo "<pre>Transactions"; print_r($coin_type);die;

        if($valid_server)
        {
            if($coin_type=="coin") // COIN PROCESS
            { 
                switch ($coin_name) 
                {
                    case 'Litecoin':
                        $transactions   = $this->local_model->get_transactions('Litecoin');
                        break;              
                    default:
                        show_error('No directory access');
                        break;
                }
           }
           else // TOKEN PROCESS
           { 
                $transactions    = $this->local_model->get_transactions($coin_name,$user_trans_res);
           }

            // echo "<pre>Transactions"; print_r($transactions); echo "</pre>";die;
            if(count($transactions)>0 || $transactions!='')
            {
                $i=0;
                foreach ($transactions as $key => $value) 
                {
                    $i++;
                    $index = $value['address'].'-'.$value['confirmations'].'-'.$i;
                    
                    $tot_transactions[$index] = $value;
                }
            }
            
            // echo "<pre>Transactions"; print_r($tot_transactions); echo "</pre>";die;

            if(!empty($tot_transactions) && count($tot_transactions)>0)
            {
                $a=0;
                foreach ($tot_transactions as $row) 
                {
                    $a++;$from_address='';
                    // $account       = $row['account'];        
                    $address       = $row['address'];
                    $confirmations = $row['confirmations']; 
                     //$txid          = $row['txid'];
                    $txid          = $row['txid'].'#'.$row['time'];
                    //$time_st       = $row['time'];
                    $time_st       = date("Y-m-d h:i:s",$row['time']);          
                    $amount        = $row['amount'];
                    $category      = $row['category'];      
                    $blockhash     = (isset($row['blockhash']))?$row['blockhash']:'';
                    $ind_val       = $address.'-'.$confirmations.'-'.$a;
                    if($coin_name1=='Ethereum' || $coin_name1=='Tether'){
                        $from_address = $row['from'];
                    }
                    else{
                        $from_address = '';
                    }

                    $admin_address = getadminAddress(1,$curr_symbol);

                    $counts_tx = $this->db->query('select * from tenrealm_transactions where information="'.$row['blockhash'].'" and wallet_txid="'.$txid.'"')->num_rows();

                    $user_curr_deposit_amt = $amount;
                    
                    //  echo "<pre>";
                    // print_r($address_list[$address]);    
                    //  die;
                    
                    if( $category == 'receive' && $confirmations > 0 && $counts_tx == 0)
                    {   

                        if(isset($address_list[$address]))
                        {

                            if($coin_name1!='Ripple'){
                            $user_id   = $address_list[$address]['user_id'];
                        }
                        else{
                            $user_id = $row['user_id'];

                        }

                            $coin_name = "if".$address_list[$address]['currency_name'];
                            $cur_sym   = $address_list[$address]['currency_symbol'];
                            $cur_ids   = $address_list[$address]['currency_id'];
                            $email     = $address_list[$address]['user_email'];
                        }
                        else
                        {
                            foreach ($address_list as $key => $value) 
                            {                           
                                if(($value['currency_symbol'] == 'ETH') && strtolower($address) ==  strtolower($value['address']))  
                                {
                                    $user_id   = $value['user_id'];
                                    $coin_name = "else".$value['currency_name'];
                                    $cur_sym   = $value['currency_symbol'];
                                    $cur_ids   = $value['currency_id'];
                                    $email     = $value['user_email'];
                                }
                            }

                            $user_id='';
                        }

                        // echo $from_address.'---'.$admin_address; 
                        // echo "<br>";

                        if(trim($from_address)!=trim($admin_address))
                        { 

                            if(isset($user_id) && !empty($user_id))
                            {


                                $onlineLTCprice = (sprintf('%0.8f', $this->coin_price_conversion('USD', 'LTC')));
                                $onlineUSDprice = (sprintf('%0.8f', $this->coin_price_conversion('LTC', 'USD')));

                                $PYMPrice = (sprintf('%0.8f', ($amount / $onlineLTCprice)));

                                $FiatPYMPrice = calculated_deposit_percentage($PYMPrice, 'LTC') ? $PYMPrice - calculated_deposit_percentage($PYMPrice, 'LTC') : '0'; 
                                $FiatPYMPrice = (sprintf('%0.8f', $FiatPYMPrice));

                                $currency_amount = (sprintf('%0.8f', ($FiatPYMPrice / $onlineUSDprice)));

                                // echo $PYMPrice .'--'. $amount;
                                // echo "<br>";
                                // echo $FiatPYMPrice .'--'. $currency_amount;
                                // echo $user_id;
                                // echo "<br>";
                                $fee = $PYMPrice - $FiatPYMPrice; 

                                $balance = getBalance($user_id,$cur_ids,'crypto'); // get user bal
                                $finalbalance = $balance + $currency_amount; // LTC bal + dep amount
                                $updatebalance = updateBalance($user_id,$cur_ids,$finalbalance,'crypto'); // Update balance
                                
                                
                                // POPUP
                                // $admin_amount = calculated_deposit_percentage($user_deposit_amount, 'LTC');
                                // $amount = $user_curr_deposit_amt - $admin_amount;
                                // $user_deposit_amount = sprintf('%0.8f', (sprintf('%0.8f', $this->coin_price_conversion()) * $amount));

                                $get_current_pym_Balance = get_pym_Balance($user_id);
                                $final_pym_amount = $get_current_pym_Balance + $FiatPYMPrice;
                                $update_pym_balance = update_pym_Balance($user_id,$final_pym_amount); // Update balance
                                
                                // Add to reserve amount
                                // $reserve_amount = getcryptocurrencydetail($cur_ids);
                                // $final_reserve_amount = (float)$amount + (float)$reserve_amount->reserve_Amount;
                                // $new_reserve_amount = updatecryptoreserveamount($final_reserve_amount, $cur_ids);

                                $Ref = $user_id.'#'.current_micro_timestamp();
                                $dep_data = array(
                                    'user_id'           => $user_id,                                    
                                    'currency_id'       => $cur_ids,
                                    'type'              => "Deposit",
                                    'currency_type'     => "crypto",
                                    'description'       => $coin_name1." Payment",
                                    'unique_id'=> user_id_to_unique_id($user_id),
                                    'created_at' => timestamp_UTC_conversion($time),
                                    'amount'            => $FiatPYMPrice, 
                                    'currency_amount'   => $currency_amount,
                                    'fiat_amount'       => $PYMPrice,   
                                    'transfer_amount'   => $amount, 
                                    'fee'               => $fee, 
                                    'information'       => $blockhash,
                                    'payment_method'    => 'crypto',
                                    'wallet_txid'       => $txid,
                                    'crypto_address'    => $address,
                                    'status'            => "Completed",
                                    'datetime'          => $time_st,
                                    'user_status'       => "Completed",
                                    'transaction_id'    => $Ref,
                                    'datetime'      => (empty($txid))?$time_st:time(),
                                    'local_transaction_id' => generate_local_transaction_id(),
                                    'confirmations'     => $confirmations
                                );

                                $ins_id = $this->common_model->insertTableData('transactions',$dep_data);

                                $prefix = get_prefix();
                                $userr = getUserDetails($user_id);
                                $usernames = $prefix.'username';
                                $username = $userr->$usernames;
                                $sitename = getSiteSettings('english_site_name');
                                $site_common      =   site_common();
                          //        $email_template = 'Deposit_Complete';
                                // $special_vars    =   array(
                                //  '###SITENAME###'  =>  $sitename,
                                //  '###USERNAME###'    => $username,
                                //  '###AMOUNT###'      => $amount,
                                //  '###CURRENCY###'    => $cur_sym,
                                //  '###HASH###'        => $blockhash,
                                //  '###TIME###'        => $time_st,
                                //  '###TRANSID###'     => $txid,
                                // );
                               // $this->email_model->sendMail($email, '', '', $email_template, $special_vars);
                                if($ins_id !="" && $coinDetails==1 ) // ETH and Token
                                {
                                    $this->transfer_to_admin_wallet($coin_name1);
                                }
                            }
                        } 
                        elseif($from_address == $admin_address)
                        {
                            if($coinDetails==1)
                            {
                                $this->transfer_to_admin_wallet($coin_name1);
                            }
                        }   
                    }
                    else
                    {
                        //echo"false";
                    }
                /*}*/
                }
                /*26-6-18*/
                $result = array('status'=>'success','message'=>'update deposit successed');
                /*26-6-18*/
            }
            else
            {
                /*26-6-18*/
                $result = array('status'=>'success','message'=>'update failed1');
            }
        }
        else
        {
            $result = array('status'=>'error','message'=>'update failed');
        }
        die(json_encode($result));

    }   



    public function transfer_to_admin_wallet($coinname)
    {
        $currency_det    =   $this->db->query("select * from tenrealm_currency where currency_name = '".$coinname."' limit 1")->row(); 

        // print_r($currency_det);die;

        if($currency_det->admin_move==1)
        {
        $currency_status = $currency_det->currency_symbol.'_status';
       //$address_list    =  $this->db->query("select * from ixtokens_crypto_address where ".$currency_status." = '1' ")->result(); 
       $address_list    =  $this->db->query("select * from tenrealm_transactions where type = 'Deposit' and status = 'Completed' and currency_id = ".$currency_det->id." and admin_status = 0 and wallet_type = '0'")->result(); 
        /*echo $this->db->last_query();
        exit();*/
        $fetch           =  $this->db->query("select * from tenrealm_admin_wallet where id='1' limit 1")->row(); 
        $get_addr        =  json_decode($fetch->addresses,true);
        $toaddress       =  $get_addr[$currency_det->currency_symbol]; 
        
        $coin_type = $currency_det->coin_type;
        // echo 'Coin decimal--'.$currency_det->currency_decimal;
        $coin_decimal = coin_decimal($currency_det->currency_decimal);
        $crypto_type = $currency_det->crypto_type;
        $min_deposit_limit = $currency_det->move_coin_limit;


        if($coinname!="")
        {
            $i =1;
            if(!empty($address_list)){
            foreach ($address_list as $key => $value) {
                $from='';
                    //$arr       = unserialize($value->address);
                    //$from      = $arr[$currency_det->id];
                    $from = $value->crypto_address;
                    $user_id = $value->user_id;
                    $trans_id = $value->trans_id;
                     $from_address='';$amount=0;
                     if($coin_type=="token" && $crypto_type=='tron')
                     {
                        $tron_private = gettronPrivate($user_id);
                        $amount    = $this->local_model->wallet_balance($coinname,$from,$tron_private);
                     }
                     else
                     {
                        
                        $amount    = $this->local_model->wallet_balance($coinname,$from);
                     }

                     


                    $minamt    = $currency_det->min_withdraw_limit;
                    $from_address = trim($from); 
                    $to = trim($toaddress);
            
                    if($from_address!='0') {
                        /*echo "Address - ".$from_address;
                        echo "Balance - ".$amount;*/
                    if($amount>=$min_deposit_limit) 
                    {
                        echo $amount."<br/>";
                        echo "transfer";
                        
                        if($coin_type=="token")
                        {
                            if($crypto_type=='eth')
                            {
                                $GasLimit = 70000;
                                $GasPrice = $this->check_ethereum_functions('eth_gasPrice','Ethereum');
                                //$GasPrice = 100 * 1000000000;
                                
                                $amount_send = $amount;
                                $amount1 = $amount_send * $coin_decimal;

                                echo "<br/>".$GasPrice."<br/>";

                                $trans_det = array('from'=>$from_address,'to'=>$to,'value'=>(float)$amount1,'gas'=>(float)$GasLimit,'gasPrice'=>(float)$GasPrice);
                            }
                            elseif($crypto_type=='bsc')
                            {
                                $GasLimit = 50000;
                                //$GasPrice = $this->check_ethereum_functions('eth_gasPrice','BNB');

                                $GasPrice = 31000000000;

                                $amount_send = $amount;
                                $amount1 = $amount_send * $coin_decimal;

                                $trans_det = array('from'=>$from_address,'to'=>$to,'value'=>(float)$amount1,'gas'=>(float)$GasLimit,'gasPrice'=>(float)$GasPrice);

                                /*echo "<pre>";print_r($trans_det);
                                exit();*/
                            }
                            else
                            {
                                $amount1 = $amount * $coin_decimal;
                                $fee_limit = 5000000;

                                $privateKey = gettronPrivate($user_id);
                                //$trans_det    = array('owner_address'=>$from_address,'to_address'=>$to,'amount'=>rtrim(sprintf("%.0f", $amount1), "."),'privateKey'=>$privateKey);

                                $trans_det  = array('owner_address'=>$from_address,'to_address'=>$to,'amount'=>(float)$amount1,'privateKey'=>$privateKey);

                            }
                            
                            if($crypto_type=='eth')
                            {
                                $eth_balance = $this->local_model->wallet_balance("Ethereum",$from_address); // get balance from blockchain
                                $transfer_currency = "Ethereum";
                                $check_amount = "0.005";
                                //$check_amount = "0.01";
                            }
                            elseif($crypto_type=='tron')
                            {
                                $eth_balance = $this->local_model->wallet_balance("Tron",$from_address); // get balance from blockchain
                                $transfer_currency = "Tron";
                                $check_amount = "5";
                            }
                            else
                            {
                                $eth_balance = $this->local_model->wallet_balance("BNB",$from_address); // get balance from blockchain
                                $transfer_currency = "BNB";
                                $check_amount = "0.004";
                            }

                            if($eth_balance >= $check_amount)
                            {
                                if($crypto_type=='eth' || $crypto_type=='bsc')
                                {
                                    $txn_count = $this->get_pendingtransaction($from_address,$coinname);
                                }
                                else
                                {
                                    $txn_count = 0;
                                }
                                
                                if($txn_count==0)
                                {
                                    $send_money_res_token = $this->local_model->make_transfer($coinname,$trans_det); // transfer to admin
                                   if($send_money_res_token !="" || $send_money_res_token !="error")
                                    {
                                        $update = $this->common_model->updateTableData("transactions",array("admin_move"=>'0',"trans_id"=>$trans_id),array("admin_move"=>'1'));
                                    }
                                }
                            }
                            else
                            {

                                if($crypto_type=='eth')
                                {
                                $eth_amount = 0.005;
                                $GasLimit1 = 21000;
                                $Gas_calc1 = $this->check_ethereum_functions('eth_gasPrice','Ethereum');
                                $Gwei1 = $Gas_calc1;
                                $GasPrice1 = $Gwei1;
                                $Gas_res1 = $Gas_calc1 / 1000000000;
                                $Gas_txn1 = $Gas_res1 / 1000000000;
                                $txn_fee = $GasLimit1 * $Gas_txn1;
                                //$send_amount = $eth_amount + $txn_fee;
                                $eth_amount1 = $eth_amount * 1000000000000000000;
                                $nonce1 = $this->get_transactioncount($to,$coinname);
                                $eth_trans = array('from'=>$to,'to'=>$from_address,'value'=>(float)$eth_amount1,'gas'=>(float)$GasLimit1,'gasPrice'=>(float)$GasPrice1);

                                }
                                elseif($crypto_type=='bsc')
                                {
                                $eth_amount = 0.005;
                                $GasLimit1 = 50000;
                                //$Gas_calc1 = $this->check_ethereum_functions('eth_gasPrice','BNB');
                                $Gas_calc1 = 31000000000;
                                $Gwei1 = $Gas_calc1;
                                $GasPrice1 = $Gwei1;
                                $Gas_res1 = $Gas_calc1 / 1000000000;
                                $Gas_txn1 = $Gas_res1 / 1000000000;
                                $txn_fee = $GasLimit1 * $Gas_txn1;
                                //$send_amount = $eth_amount + $txn_fee;
                                $eth_amount1 = $eth_amount * 1000000000000000000;
                                $nonce1 = $this->get_transactioncount($to,$coinname);
                                $eth_trans = array('from'=>$to,'to'=>$from_address,'value'=>(float)$eth_amount1,'gas'=>(float)$GasLimit1,'gasPrice'=>(float)$GasPrice1);

                                }
                                else
                                {
                                
                                    $amount1 = 5 * 1000000;
                                    $privateKey = getadmintronPrivate(1);
                                    $eth_trans      = array('fromAddress'=>$to,'toAddress'=>$from_address,'amount'=>(float)$amount1,"privateKey"=>$privateKey);

                                }

                                if($crypto_type=='eth' || $crypto_type=='bsc')
                                {
                                    $txn_count = $this->get_pendingtransaction($to,$transfer_currency);
                                }
                                else
                                {
                                    $txn_count = 0;
                                }
                                
                               if($txn_count==0)
                               {
                                $send_money_res = $this->local_model->make_transfer($transfer_currency,$eth_trans); // admin to user wallet

                                if($send_money_res !="" || $send_money_res !="")
                                {
                                     $tnx_data = array(
                                                'user_id'=>$value->user_id,
                                                'address' => $from_address,
                                                'amount'=>(float)$amount,
                                                'currency_symbol'=>$currency_det->currency_symbol,
                                                'status'=>0,
                                                'created_at'=>date('Y-m-d H:i:s'),
                                                'txn_id'=>$send_money_res
                                            );
                                   //$ins = $this->common_model->insertTableData('admin_move_logs',$tnx_data);
                                }
                               }
                              
                            }
                        }
                         else
                        {
                            $coin_transfer = '';
                            if($crypto_type=='eth')
                            {
                            $GasLimit = 21000;
                            $Gas_calc = $this->check_ethereum_functions('eth_gasPrice','Ethereum');
                            echo "<br/>".$Gas_calc."<br/>";
                            $Gwei = $Gas_calc;
                            $GasPrice = $Gwei;
                            $Gas_res = $Gas_calc / 1000000000;
                            $Gas_txn = $Gas_res / 1000000000;
                            $txn_fee = $GasLimit * $Gas_txn;
                            echo "Transaction Fee".$txn_fee."<br/>";
                            $amount_send = ($amount - $txn_fee)-0.0005;
                            echo "Amount Send ".$amount_send."<br/>";

                            echo "Total Amount ".($txn_fee+$amount_send)."<br/>";
                            $amount1 = ($amount_send * 1000000000000000000);

                            echo sprintf("%.40f", $amount1)."<br/>";
                            $coin_transfer = "Ethereum";
                            $cointrans_det = array('from'=>$from_address,'to'=>$to,'value'=>(float)$amount1,'gas'=>(float)$GasLimit,'gasPrice'=>(float)$GasPrice);

                           /* echo "<pre>";
                            print_r($cointrans_det);*/
                            }
                            elseif($crypto_type=='bsc')
                            {
                            $GasLimit = 50000;
                            $Gas_calc = $this->check_ethereum_functions('eth_gasPrice','BNB');

                            $Gas_calc = 31000000000;
                            $Gwei = $Gas_calc;
                            $GasPrice = $Gwei;
                            $Gas_res = $Gas_calc / 1000000000;
                            $Gas_txn = $Gas_res / 1000000000;
                            $txn_fee = $GasLimit * $Gas_txn;
                            $amount_send = $amount - $txn_fee;
                            $amount1 = $amount_send * 1000000000000000000;
                            $coin_transfer = "BNB";
                            $cointrans_det = array('from'=>$from_address,'to'=>$to,'value'=>(float)$amount1,'gas'=>(float)$GasLimit,'gasPrice'=>(float)$GasPrice);
                            }
                            else
                            {
                                $from_address = trim($from_address);
                                $to = trim($to);    
                                $amount1 = $amount * 1000000;
                                $privateKey = gettronPrivate($user_id);
                                $coin_transfer = "Tron";
                                $cointrans_det = array('fromAddress'=>$from_address,'toAddress'=>$to,'amount'=>(float)$amount1,"privateKey"=>$privateKey);
                            }
                            
                            if($crypto_type=='eth' || $crypto_type=='bsc')
                            {
                                $txn_count = $this->get_pendingtransaction($from_address,$coin_transfer);
                            }
                            else
                            {
                                $txn_count = 0;
                            }
                            
                            echo "txn count";
                             echo "<br>";
                            echo $txn_count;
                            echo "<br>";
                            if($txn_count==0)
                            {
                            
                            $send_money_res_coin = $this->local_model->make_transfer($coin_transfer,$cointrans_det); // transfer to admin

                            if($send_money_res_coin !="" || $send_money_res_coin !="")
                            {
                            $update = $this->common_model->updateTableData("transactions",array("admin_status"=>0,"trans_id"=>$trans_id),array("admin_status"=>'1'));
                            }
                                
                                
                                
                            }
                            

                          
                           
                            
                        }
               
                       
                          
                            $result = array('status'=>'success','message'=>'update deposit success');
                       
                    }
                    else
                    {
                      $result = array('status'=>'failed','message'=>'update deposit failed insufficient balance');
                    }

                }
                else
                {
                    $result = array('status'=>'failed','message'=>'invalid address');   
                }

            $i++;}
           }
           else
            {
                $result = array("status"=>"failed","message"=>"transactions not found for admin wallet");
            }

        }
        echo json_encode($result);

        }

    
    }

    public function transfer_to_admin_wallet1($coinname)
    {
        $coinname = str_replace("%20"," ",$coinname);
        $currency_det =   $this->db->query("select * from tenrealm_currency where currency_name = '".$coinname."' ")->row(); // get currency detail
        $currency_status = $currency_det->currency_symbol.'_status';
        $address_list   =  $this->db->query("select * from tenrealm_crypto_address where ".$currency_status." = 1")->result(); // get user addresses
        $fetch          =  $this->db->query("select * from tenrealm_admin_wallet where id='1'")->row(); // get admin wallet
        $get_addr       =  json_decode($fetch->addresses,true);
        $toaddress      =  $get_addr[$currency_det->currency_symbol]; // get admin address

        $min_deposit_limit = $currency_det->move_coin_limit;

        if($coinname!="")
        {
            $i =1;

            foreach ($address_list as $key => $value) {

                    $arr       = unserialize($value->address);
                    $from      = $arr[$currency_det->id];
                    echo 'from'.$from.'<br>';

                    $amount    = $this->local_model->wallet_balance($coinname,$from); // get balance 
                    echo 'amount'.$amount.'<br>';
                    $minamt       = $currency_det->min_withdraw_limit; // get minimum withdraw limit
                    $from_address = trim($from); // get user address- from address
                    $to = trim($toaddress); // get admin address - to address
                   
                   echo 'to'.$to.'<br>';

                    if($from_address!='0') { // check user address to be valid

                    if($amount>$min_deposit_limit) // check transfer amount with min withdraw limit and to be valid
                    {
                        switch ($coinname) 
                        {
                            case 'Ethereum': // get transcation details for eth
                            $GasLimit = 21000;
                            $Gas_calc = $this->check_ethereum_functions('eth_gasPrice');
                            $Gwei = $Gas_calc;
                            $GasPrice = $Gwei;
                            $Gas_res = $Gas_calc / 1000000000;
                            $Gas_txn = $Gas_res / 1000000000;
                            $txn_fee = $GasLimit * $Gas_txn;
                            $amount_send = $amount - $txn_fee;
                            $amounts = $amount_send * 1000000000000000000;
                            $amount1 = rtrim(sprintf("%u", $amounts), ".");
                            $nonce = $this->get_transactioncount($from_address);
                            $trans_det      = array('from'=>$from_address,'to'=>$to,'value'=>(float)$amount1,'gas'=>(float)$GasLimit,'gasPrice'=>(float)$GasPrice,'nonce'=>$nonce);
                            break;

                            case 'Tether': // get transcation details for usdt
                            $GasLimit = 50000;
                            $Gas_calc = $this->check_ethereum_functions('eth_gasPrice');
                            $Gwei = $Gas_calc;
                            $GasPrice = $Gwei;
                            $Gas_res = $Gas_calc / 1000000000;
                            $Gas_txn = $Gas_res / 1000000000;
                            $txn_fee = $GasLimit * $Gas_txn;
                            $amount_send = $amount;
                            $amounts = $amount_send * 1000000;
                            $amount1 = rtrim(sprintf("%u", $amounts), ".");
                            $nonce = $this->get_transactioncount($from_address);
                            $contract_address = $currency_det->contract_address;
                            $trans_det      = array('from'=>$from_address,'to'=>$to,'value'=>(float)$amount1,'gas'=>(float)$GasLimit,'gasPrice'=>(float)$GasPrice,'nonce'=>$nonce);
                            break;

                            
                        } 

                        //print_r($trans_det); exit;

                        if($coinname=="Tether") // check eth balance for usdt transfer
                        {
                            $eth_balance = $this->local_model->wallet_balance("Ethereum",$from_address); // get balance from blockchain
                            //$eth_balance = getBalance($value->user_id,3); // get balance from db
                            if($eth_balance >= "0.001")
                            {
                                $send_money_res = $this->local_model->make_transfer($coinname,$trans_det); // transfer to admin
                                //$send_money_res = "test";
                            }
                            else
                            {
                                $eth_amount = 0.002;
                                $GasLimit1 = 50000;
                                $Gas_calc1 = $this->check_ethereum_functions('eth_gasPrice');
                                $Gwei1 = $Gas_calc1;
                                $GasPrice1 = $Gwei1;
                                $Gas_res1 = $Gas_calc1 / 1000000000;
                                $Gas_txn1 = $Gas_res1 / 1000000000;
                                $txn_fee = $GasLimit1 * $Gas_txn1;
                                $send_amount = $eth_amount + $txn_fee;
                                $eth_amounts = $send_amount * 1000000000000000000;
                                $eth_amount1 =  rtrim(sprintf("%u", $eth_amounts), ".");
                                $nonce1 = $this->get_transactioncount($to);
                                $eth_trans = array('from'=>$to,'to'=>$from_address,'value'=>(float)$eth_amount1,'gas'=>(float)$GasLimit1,'gasPrice'=>(float)$GasPrice1,'nonce'=>$nonce1);
                                $send_money_res1 = $this->local_model->make_transfer("Ethereum",$eth_trans); 
                               /* updateBalance($value->user_id,2,$eth_amount);
                                $admin_ethbalance = getadminBalance(1,2); // get admin eth balance
                                $eth_bal = $admin_ethbalance - $eth_amount; // calculate remaining eth amount in admin wallet
                                updateadminBalance(1,2,$eth_bal); // update eth balance in admin wallet*/
                            }
                        }
                        else if($coinname=="Ripple") // check eth balance for usdt transfer
                        {
                            echo "Ripple";
                        }

                        else
                        {
                            $send_money_res = $this->local_model->make_transfer($coinname,$trans_det); // transfer to admin
                            //$send_money_res = "test";
                        }

                        // add to admin wallet logs
                        if($send_money_res!="" || $send_money_res!="error")
                        {
                        $trans_data = array(
                                            'userid'=>$value->user_id,
                                            'crypto_address' => $from_address,
                                            'type'=>'deposit',
                                            'amount'=>(float)$amount,
                                            'currency_symbol'=>$currency_det->currency_symbol,
                                            'status'=>'Completed',
                                            'date_created'=>date('Y-m-d H:i:s'),
                                            'currency_id'=>$currency_det->id,
                                            'txn_id'=>$send_money_res
                                        );
                        $insert = $this->common_model->insertTableData('admin_wallet_logs',$trans_data);
                        $result = array('status'=>'success','message'=>'update deposit success');
                        }

                    }
                    else
                    {
                       $result = array('status'=>'failed','message'=>'update deposit failed insufficient balance');
                    }

                }
                else
                {
                      $result = array('status'=>'failed','message'=>'invalid address'); 
                }

            $i++;}

        }
        die(json_encode($result));

    }

        function get_pendingtransaction($address,$coin_name)
    {
      $ctype = $this->db->select('*')->where(array('currency_name'=>$coin_name,'status'=>'1'))->get('currency')->row();
      if($ctype->coin_type=="coin")
      {
         $model_currency = $coin_name;
      }
      else
      {
        if($ctype->crypto_type=='eth'){
            $model_currency = "token";
            
        }
        else{
            $model_currency = "token_bnb";
        }

      } 
      
       
       $model_name = strtolower($model_currency).'_wallet_model';
       $model_location = 'wallets/'.strtolower($model_currency).'_wallet_model';
       
       $this->load->model($model_location,$model_name);
       $pending = $this->$model_name->eth_pendingTransactions();
       $txn_count = 0;
       if(count($pending) >0)
       {
        foreach($pending as $txn)
        {
            if($address==$txn->from)
            {
              $txn_count++;
            }
        }
       }
       return $txn_count;
    }
    
    function get_transactioncount($address)
    {
       $coin_name = 'Ethereum';
       $model_name = strtolower($coin_name).'_wallet_model';
       $model_location = 'wallets/'.strtolower($coin_name).'_wallet_model';
       $this->load->model($model_location,$model_name);
       $getcount = $this->$model_name->eth_getTransactionCount($address);
       //echo "Get TransactionCount ===========> ".$getcount;
       return $getcount;
    }
    function check_ethereum_functions($value)
    {
        $coin_name = 'Ethereum';
        $model_name = strtolower($coin_name).'_wallet_model';
        $model_location = 'wallets/'.strtolower($coin_name).'_wallet_model';
        $this->load->model($model_location,$model_name);
        if($value=='eth_gasPrice')
        {
            $parameter = "";
            $gas_price = $this->$model_name->eth_gasPrice($parameter);

            return $gas_price;
        }
        else
        {
            return '1';
        }

    }

    function withdraw_coin_user_confirm_old($id)
    {

        $user_id=$this->session->userdata('user_id');
        if($user_id=="")
        {   
            $this->session->set_flashdata('error','Your Not Login Please Login and try');
            front_redirect('', 'refresh');
        }
        $id = decryptIt($id);

        $isValids = $this->common_model->getTableData('transactions', array('trans_id' => $id, 'type' =>'withdraw', 'status'=>'Pending'));

        $isValid = $isValids->num_rows();
        $withdraw = $isValids->row();

        // echo '<pre>';print_r($isValid);die;  

        if($isValid > 0)
        {
              $datetime =  $withdraw->datetime;
          
          // echo $datetime.'<br>';
          //      $time = strtotime($datetime);

            $withdraw_timestamp = strtotime(date("Y-m-d H:i:s", strtotime("+10 minutes", $datetime))); // Check whether the time exceeds 10 mins
            $current_time = date('Y-m-d H:i:s', time());
            $current_date_timestamp = strtotime($current_time);

            // echo '<pre>';print_r($withdraw);exit;
            // echo $withdraw_timestamp.'--'.$current_date_timestamp;die;

            if($withdraw->user_status=='Completed')
            {
                // echo "11";die;
                $this->session->set_flashdata('error','Your withdraw request already confirmed');
                front_redirect('wallet', 'refresh');
            }
            else if($withdraw->user_status=='Cancelled')
            {
                // echo "22";die;
                $this->session->set_flashdata('error','Your withdraw request already cancelled');
                front_redirect('wallet', 'refresh');
            }
            else if($withdraw->user_id != $user_id)
            {
                // echo "33";die;
                // echo $withdraw->user_id."--".$user_id;die;
                $this->session->set_flashdata('error','Your are not the owner of this withdraw request');
                front_redirect('wallet', 'refresh');
            }
            // elseif($withdraw_timestamp < $current_date_timestamp)
            // {

            //  // echo date('d m Y', strtotime($withdraw_timestamp));
            //  echo gmdate(current_micro_timestamp());
            //  echo "<br>";
            //  echo $withdraw_timestamp.'--'.$current_date_timestamp;die;
            //  $currency = $withdraw->currency_id;
            //  $amount = $withdraw->amount;
            //  $balance = getBalance($user_id,$currency,'crypto');
            //  $finalbalance = $balance+$amount;

            //  // echo $balance.'--'.$finalbalance;die;
            //  $updatebalance = updateBalance($user_id,$currency,$finalbalance,'crypto');
            //  $updateData['user_status'] = 'Cancelled';
            //  $updateData['status'] = 'Cancelled';
            //  $condition = array('trans_id' => $id,'type' => 'withdraw','currency_type'=>'crypto');
            //  $update = $this->common_model->updateTableData('transactions', $condition, $updateData);
            //  $this->session->set_flashdata('error','Withdraw Declined!. Balance reverted to your account.');
            //  front_redirect('wallet', 'refresh');
            // }
            else {
                // echo "else";die;
                $updateData['user_status'] = 'Completed';
                $condition = array('trans_id' => $id,'type' => 'withdraw','currency_type'=>'crypto');
                $update = $this->common_model->updateTableData('transactions', $condition, $updateData);
                        $link_ids = base64_encode($id);
                        $enc_email = getAdminDetails('1','email_id');
                        $email = decryptIt($enc_email);
                        // $email = 'satheesh@spiegeltechnologies.com';
                        $prefix = get_prefix();
                        $user = getUserDetails($user_id);
                        $usernames = $prefix.'username';
                        $username = $user->$usernames;
                        $currency_name = getcryptocurrency($withdraw->currency_id);
                        $sitename = getSiteSettings('site_name');
                        
                            $email_template = 'Withdraw_User_Complete';
                                $special_vars = array(
                                '###SITENAME###' => $sitename,
                                '###USERNAME###' => 'Admin',
                                '###AMOUNT###'   => $withdraw->amount,
                                '###CURRENCY###' => $currency_name,
                                '###FEES###' => $withdraw->fee,
                                '###CRYPTOADDRESS###' => $withdraw->crypto_address,
                                '###CONFIRM_LINK###' => admin_url().'admin/withdraw_coin_confirm/'.$link_ids,
                                '###CANCEL_LINK###' => admin_url().'admin/withdraw_coin_cancel/'.$link_ids,
                                );
                    $this->email_model->sendMail($email, '', '', $email_template, $special_vars);

                $this->session->set_flashdata('success','Successfully placed your withdraw request. Our team will also confirm this request');
                front_redirect('wallet', 'refresh');
            }
        }
        else
        {
            $this->session->set_flashdata('error','Invalid withdraw confirmation');
            front_redirect('wallet', 'refresh');
        }
    


    }


    function withdraw_coin_user_confirm($id)
    {           
        $user_id=$this->session->userdata('user_id');
        if($user_id=="")
        {   
            front_redirect('/', 'refresh');
        }

        $id = decryptIt($id);
        $isValids = $this->common_model->getTableData('transactions', array('trans_id' => $id, 'type' =>'withdraw', 'user_status'=>'Pending','status'=>'Pending'));

        $isValid = $isValids->num_rows();
        $withdraw = $isValids->row();
        if($isValid > 0)
        {
            
            $fromid     = $withdraw->user_id;
            $fromuser  = $this->common_model->getTableData('users',array('id'=>$fromid))->row();
            $fromacc   = getUserEmail($fromid);

            if($withdraw->user_status=='Completed')
            {
                $this->session->set_flashdata('error',$this->lang->line('Your withdraw request already confirmed'));
                front_redirect('payment', 'refresh');
            }
            else if($withdraw->user_status=='Cancelled')
            {
                $this->session->set_flashdata('error',$this->lang->line('Your withdraw request already cancelled'));
                front_redirect('payment', 'refresh');
            }
            elseif($withdraw->user_id != $user_id)
            { 
                $this->session->set_flashdata('error',$this->lang->line('Your are not the owner of this withdraw request'));
                front_redirect('payment', 'refresh');
            }
            else {
                // if($withdraw->currency_id!=5){ 

                    $amount         = $withdraw->transfer_amount;
                    $address        = $withdraw->crypto_address;
                    $currency       = $withdraw->currency_id;
                    $tagid = $withdraw->destination_tag;
                    $coin_name      = getcryptocurrencys($currency);
                    $coin_symbol    = getcryptocurrency($currency);
                    $currency_det = getcryptocurrencydetail($currency);
                    $coin_type = $currency_det->coin_type;

                    if($coin_type == "token" && $withdraw->wallet_type==0) // TOKEN
                    {

                        $eth_id = $this->common_model->getTableData("currency",array("currency_symbol"=>"ETH"))->row('id');

                        $eth_admin_balance = getadminbalance(1,$eth_id);
                        $mini_balance = "0.005";

                        if($eth_admin_balance <= $mini_balance)
                        { 
                            $this->session->set_flashdata('error',$this->lang->line('Your Ethereum Balance is low so you did not able to withdraw for Tether Token'));
                            front_redirect('withdraw/'.$coin_symbol, 'refresh');
                        }
                    }
 
                    $from_address1 = getadminAddress(1,$coin_symbol);
                    $user_address = getAddress($withdraw->user_id,$withdraw->currency_id);

                    // echo $coin_symbol.'----'.$user_address.'<br>';

                    $wallet_bal     = $this->local_model->wallet_balance($coin_name, $user_address); 
                    
                    // echo $wallet_bal.'--'.$amount;die;

                    $currency_det = getcryptocurrencydetail($currency);
                    $coin_type = $currency_det->coin_type;
                    $coin_decimal = $currency_det->currency_decimal;
                    $decimal_places = coin_decimal($coin_decimal);

                    $coinDetails = $currency_det->admin_move;

                    $wallet_bal = number_format((float)$wallet_bal,8);
                    $amount = number_format($amount,8);
                    $wallet_bal = str_replace(',', '', $wallet_bal);
                    
                    // $wallet_bal = 100; // to_check

                    if($wallet_bal >= $amount)
                    {
                        if($coin_type=="coin")
                        {
                            switch ($coin_name) 
                            {
                                case 'Ethereum':
                                    $from_address = trim($from_address1);
                                    $to = trim($address);   
                                    $GasPrice = $this->check_ethereum_functions('eth_gasPrice');
                                    $amount1 = $amount * 1000000000000000000;
                                    $GasLimit = 70000;                                  
                                    $trans_det      = array('from'=>$from_address,'to'=>$to,'value'=>(float)$amount1,'gas'=>(float)$GasLimit,'gasPrice'=>(float)$GasPrice);
                                    
                                break;
                                case "Ripple":
                                $xrp_tag_det = $this->common_model->getTableData('crypto_address', array('user_id' => $fromid))->row();
                                $from_address = trim($from_address1);
                                    $to = trim($address);
                                $trans_det = array('fromacc' => $fromacc, 'toaddress' => $to, 'amount' => (float) $amount, 'tagid' => $xrp_tag_det->payment_id, 'destag' => $tagid, 'secret' => $xrp_tag_det->auto_gen, 'comment' => 'User Confirms Withdraw', 'comment_to' => 'Completed');
                                break;                                                          
                                default:
                                    $trans_det      = array('address'=>$address,'amount'=>(float)$amount,'comment'=>'User Confirms Withdraw');
                                break;
                            }
                        }
                        else
                        {
                            $from_address = trim($from_address1);
                            $to = trim($address);   
                            $GasPrice = $this->check_ethereum_functions('eth_gasPrice');
                            // $GasPrice = 120 * 1000000000;
                            $amount1 = $amount * $decimal_places;
                            $GasLimit = 70000;  
                            $trans_det = array('from'=>$from_address,'to'=>$to,'value'=>(float)$amount1,'gas'=>(float)$GasLimit,'gasPrice'=>(float)$GasPrice);
                        }
                        /*echo "<pre>";
                        print_r($trans_det);
                        exit();*/
                        
                        $send_money_res = $this->local_model->make_transfer($coin_name,$trans_det);
                        // $send_money_res = 'transactions#'.time();


                        // if($withdraw->wallet_type==0){ // External
                        //  // $send_money_res = $this->local_model->make_transfer($coin_name,$trans_det);
                            
                        // }
                        // else{ // Internal
                        //  $uid = $withdraw->user_id;
                        //  $cid = $withdraw->currency_id;
                        //  $coin_adr = getAddress($uid,$cid);

                        //  $send_money_res = 'Internal Transfer';
                        //  $currency_sym = $currency_det->currency_symbol;
                        //  $getuserid = $this->common_model->getTableData('crypto_address','','user_id',array('address'=>$withdraw->crypto_address))->row();

                        //  $insertInternalData = array(
                        //      'transaction_id'=>strtotime(date('d-m-Y h:i:s')),
                        //      'user_id'=>$getuserid->user_id,
                        //      'payment_method'=>'crypto',
                        //      'currency_id'=>$currency,
                        //      'amount'=>$amount,
                        //      'transfer_amount'=>$amount,
                        //      'datetime'=>gmdate(time()),
                        //      'type'=>'Deposit',
                        //      'crypto_address'=>$coin_adr,
                        //      'status'=>'Completed',
                        //      'user_status'=>'Completed',
                        //      'currency_type'=>'crypto',
                        //      'payment_mode'=>'0',
                        //      );

                        //  // echo "<pre>";print_r($getuserid);die;
                        //  $insertdatas = $this->common_model->insertTableData('transactions', $insertInternalData);
                        //  if ($insertdatas) {

                        //      $userid = $getuserid->user_id;
                        //      $balance = getBalance($userid,$currency,'crypto');
                        //      $finalbalance = $balance+$amount;
                        //      $updatebalance =updateBalance($userid,$currency,$finalbalance,'crypto');

                        //      $prefix = get_prefix();
                        //      $userr = getUserDetails($userid);
                        //      $usernames = $prefix.'username';
                        //      $username = $userr->$usernames;

                        //      $email = getUserEmail($userid);
                        //      $sitename = getSiteSettings('english_site_name');
                        //      $site_common      =   site_common();
                        //      $email_template   = 'Deposit_Complete';     
                        //          $special_vars = array(
                        //          '###SITENAME###' => $sitename,          
                        //          '###USERNAME###' => $username,
                        //          '###AMOUNT###'   => number_format($amount,8),
                        //          '###CURRENCY###' => $currency_sym,
                        //          '###MSG###' => '',
                        //          '###STATUS###'   => ucfirst('Completed')
                        //          );
                        //      $this->email_model->sendMail($email, '', '', $email_template, $special_vars);       
                        //  }
                        // }
                    // print_r($send_money_res);
                    // die; 
                        if($send_money_res){
                            $updateData  = array('user_status'=>"Completed",'status'=>"Completed",'wallet_txid'=>$send_money_res);
                        $condition = array('trans_id' => $id,'type' => 'withdraw','currency_type'=>'crypto');
                        $update = $this->common_model->updateTableData('transactions', $condition, $updateData);

                        // Reserve amount
                        $reserve_amount = getcryptocurrencydetail($withdraw->currency_id);
                        $final_reserve_amount = (float)$reserve_amount->reserve_Amount + (float)$amount;
                        $new_reserve_amount = updatecryptoreserveamount($final_reserve_amount, $withdraw->currency_id);


                        if($coinDetails==1 ) // Eth or Tokens
                        {
                            $admin_balance = getadminBalance(1,$withdraw->currency_id); // get admin balance
                            $admin_bal = $admin_balance - $withdraw->transfer_amount;
                            updateadminBalance(1,$withdraw->currency_id,$admin_bal); // update balance in admin wallet
                        }

                        // add to transaction history
                        $trans_data = array(
                            'userId'=>$withdraw->user_id,
                            'type'=>'Withdraw',
                            'currency'=>$withdraw->currency_id,
                            'amount'=>$withdraw->amount,
                            'profit_amount'=>$withdraw->fee,
                            'comment'=>'Withdraw #'.$withdraw->trans_id,
                            'datetime'=>date('Y-m-d h:i:s'),
                            'currency_type'=>'crypto',
                        );
                        $update_trans = $this->common_model->insertTableData('transaction_history',$trans_data);

                            $prefix = get_prefix();
                            $user = getUserDetails($user_id);
                            $usernames = $prefix.'username';
                            $username = $user->$usernames;
                            $email = getUserEmail($user_id);
                            $currency_name = getcryptocurrency($id);
                            $sitename = getSiteSettings('english_site_name');
                            $site_common      =   site_common();    
                        
                            $email_template = 'Withdraw_Complete';
                            $special_vars = array(
                                '###SITENAME###' => $sitename,          
                                '###USERNAME###' => $username,
                                '###AMOUNT###'   => $amount,
                                '###CURRENCY###' => $reserve_amount->currency_symbol,
                                '###TX###' => $isValids->transaction_id
                            );
                            
                    $this->email_model->sendMail($email, '', '', $email_template, $special_vars);
                    // $this->email_model->sendMail('saravanan@spiegeltechnologies.com', '', '', $email_template, $special_vars);

                $this->session->set_flashdata('success',$this->lang->line('Your withdraw request has been placed successfully.'));

                // $sesArray = array('coin'=>$currency_det->currency_symbol, 'address'=>$withdraw->crypto_address);  
                // $getAdrInfo=$this->common_model->getTableData('address_book',array('user_id'=>$user_id,'coin'=>$currency_det->currency_symbol,'address'=>$withdraw->crypto_address))->row();
                // if(empty($getAdrInfo)) { 
                //  $this->session->set_userdata($sesArray);
                // }
                front_redirect('payment', 'refresh');
                        }
                        else{
                            $this->session->set_flashdata('error',$this->lang->line('Please try again after some time or contact Admin.'));
                            front_redirect('payment', 'refresh');
                        }

            } else {
                $this->session->set_flashdata('error',$this->lang->line('Your Balance is low so you did not able to withdraw'));
                front_redirect('payment', 'refresh');
            }
        
        // } else {

        //  $updateData['user_status'] = 'Completed';
        //  $updateData['status'] = 'Pending';
        //  $condition = array('trans_id' => $id,'type' => 'withdraw','currency_type'=>'fiat');
        //  $update = $this->common_model->updateTableData('transactions', $condition, $updateData);
        //  $this->session->set_flashdata('success',$this->lang->line('Your withdraw request has been placed successfully.'));
        //  front_redirect('wallet', 'refresh');
        // }


      }
    
    }
    else
        {
            $this->session->set_flashdata('error',$this->lang->line('Invalid withdraw confirmation'));
            front_redirect('payment', 'refresh');
        }
}
    function withdraw_coin_user_cancel($id)
    {

        $user_id=$this->session->userdata('user_id');
        if($user_id=="")
        {   
            front_redirect('', 'refresh');
        }
        $id = decryptIt($id);   
        $isValids = $this->common_model->getTableData('transactions', array('trans_id' => $id, 'type' =>'Withdraw', 'user_status'=>'Pending' ,'status'=>'Pending','currency_type'=>'crypto'));
        $isValid = $isValids->num_rows();
        $withdraw = $isValids->row();
        // echo "<pre>";print_r($withdraw);die;
        if($isValid > 0)
        {
            if($withdraw->user_status=='Completed')
            { 
                // echo "11";die;
                $this->session->set_flashdata('error',$this->lang->line('Your withdraw request already confirmed'));
                front_redirect('payment', 'refresh');
            }
            else if($withdraw->user_status=='Cancelled')
            {
                // echo "22";die;
                $this->session->set_flashdata('error',$this->lang->line('Your withdraw request already cancelled'));
                front_redirect('payment', 'refresh');
            }
            elseif($withdraw->user_id != $user_id)
            {
                // echo "33";die;
                $this->session->set_flashdata('error',$this->lang->line('Your are not the owner of this withdraw request'));
                front_redirect('payment', 'refresh');
            }
            else {
                // echo "44";die;
                $currency = $withdraw->currency_id;
                $amount = $withdraw->amount;
                $currency_amount = $withdraw->currency_amount;

                $balance = getBalance($user_id,$currency,'crypto');
                $finalbalance = $balance+$currency_amount;
                $updatebalance = updateBalance($user_id,$currency,$finalbalance,'crypto');

                $currency_pym_balance = get_pym_Balance($user_id,$currency);
                $final_pym_balance = $currency_pym_balance + $amount;
                update_pym_Balance($user_id,$final_pym_balance);

                // echo $balance .'--'. $currency_amount .'--'. $finalbalance;
                // echo "<br>";
                // echo $currency_pym_balance .'--'. $amount .'--'. $final_pym_balance;
                // die;

                $updateData['user_status'] = 'Cancelled';
                $updateData['status'] = 'Cancelled';
                $condition = array('trans_id' => $id,'type' => 'withdraw','currency_type'=>'crypto');
                $update = $this->common_model->updateTableData('transactions', $condition, $updateData);
                $this->session->set_flashdata('success',$this->lang->line('Successfully cancelled your withdraw request'));
                front_redirect('payment', 'refresh');
            }
        }
        else
        {
            $this->session->set_flashdata('error',$this->lang->line('Invalid withdraw confirmation'));
            front_redirect('payment', 'refresh');
        }
    }
    function getValue()
    {
        $currency_id = $_POST['currency_id'];
        $currency_det = $this->common_model->getTableData('currency', array('id' => $currency_id))->row();    
        if(count($currency_det) > 0){
           $response = array('usd_value'=>$currency_det->online_usdprice,'status'=>'success');
        }
        else{
            $response = array('status'=>'failed');
        }
        echo json_encode($response);

    }   
    function transaction()
    {
        $user_id=$this->session->userdata('user_id');
        if($user_id=="")
        {   
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url());
        }
        

        if(isset($_POST))
        {
            $this->form_validation->set_rules('ids', 'ids', 'trim|required|xss_clean|numeric');
            $this->form_validation->set_rules('amount', 'Amount', 'trim|required|xss_clean');
            $id = $this->db->escape_str($this->input->post('ids'));
            if($id!=7){
            $this->form_validation->set_rules('address', 'Address', 'trim|required|xss_clean');
        }

            if ($this->form_validation->run())
            {

                $id = $this->db->escape_str($this->input->post('ids'));
                $amount = $this->db->escape_str($this->input->post('amount'));
                if($id!=7){
                $address = $this->db->escape_str($this->input->post('address'));
                $Payment_Method = 'crypto';
                $Currency_Type = 'crypto';
                $Bank_id = '';
            }
            else{
                $address = '';
                $Payment_Method = 'bank';
                $Currency_Type = 'fiat';
                $Bank_id = $this->common_model->getTableData('user_bank_details',array('user_id'=>$user_id,'status'=>'Verified'))->row('id');
            }
                $balance = getBalance($user_id,$id,'crypto');
                $currency = getcryptocurrencydetail($id);
                $w_isValids   = $this->common_model->getTableData('transactions', array('user_id' => $user_id, 'type' =>'Withdraw', 'status'=>'Pending','user_status'=>'Pending','currency_id'=>$id));
                 $count        = $w_isValids->num_rows();
                 $withdraw_rec = $w_isValids->row();
                $final = 1;
                $Validate_Address = 1;
                if($Validate_Address==1)
                {   
                    if($count>0)
                    {
                            
                        $this->session->set_flashdata('error', $this->lang->line('Sorry!!! Your previous ') . $currency->currency_symbol . $this->lang->line('withdrawal is waiting for admin approval. Please use other wallet or be patience'));
                        front_redirect('withdraw', 'refresh');  
                    }
                    else
                    {
                        if($amount>$balance)
                        {
                            $this->session->set_flashdata('error', $this->lang->line('Amount you have entered is more than your current balance'));
                            front_redirect('withdraw', 'refresh');  
                        }
                        if($amount < $currency->min_withdraw_limit)
                        {
                            $this->session->set_flashdata('error',$this->lang->line('Amount you have entered is less than minimum withdrawl limit'));
                            front_redirect('withdraw', 'refresh');  
                        }
                        elseif($amount>$currency->max_withdraw_limit)
                        {
                            $this->session->set_flashdata('error', $this->lang->line('Amount you have entered is more than maximum withdrawl limit'));
                            front_redirect('withdraw', 'refresh');  
                        }
                        elseif($final!=1)
                        {
                            $this->session->set_flashdata('error',$this->lang->line('Invalid address'));
                            front_redirect('withdraw', 'refresh');  
                        }
                        else
                        {
                            $withdraw_fees_type = $currency->withdraw_fees_type;
                            $withdraw_fees = $currency->withdraw_fees;

                            if($withdraw_fees_type=='Percent') { $fees = (($amount*$withdraw_fees)/100); }
                            else { $fees = $withdraw_fees; }
                            $total = $amount-$fees;
                            $user_status = 'Pending';
                            $insertData = array(
                                'user_id'=>$user_id,
                                'payment_method'=>$Payment_Method,
                                'currency_id'=>$id,
                                'amount'=>$amount,
                                'fee'=>$fees,
                                'crypto_address'=>$address,
                                'transfer_amount'=>$total,
                                'datetime'=>gmdate(time()),
                                'type'=>'Withdraw',
                                'status'=>'Pending',
                                'currency_type'=>$Currency_Type,
                                'user_status'=>$user_status
                                );
                            $finalbalance = $balance - $amount;
                            $updatebalance = updateBalance($user_id,$id,$finalbalance,'crypto');
                            $insertData_clean = $this->security->xss_clean($insertData);
                            $insert = $this->common_model->insertTableData('transactions', $insertData_clean);
                            if($insert) 
                            {
                                $prefix = get_prefix();
                                $user = getUserDetails($user_id);
                                $usernames = $prefix.'username';
                                $username = $user->$usernames;
                                $email = getUserEmail($user_id);
                                $currency_name = getcryptocurrency($id);
                                $link_ids = base64_encode($insert);
                                $sitename = getSiteSettings('site_name');
                                $site_common      =   site_common();                            

                                if($id!=7){
                                $email_template = 'Withdraw_User_Complete';
                                    $special_vars = array(
                                    '###SITENAME###' => $sitename,
                                    '###USERNAME###' => $username,
                                    '###AMOUNT###'   => (float)$amount,
                                    '###CURRENCY###' => $currency_name,
                                    '###FEES###' => $fees,
                                    '###CRYPTOADDRESS###' => $address,
                                    '###CONFIRM_LINK###' => base_url().'withdraw_coin_user_confirm/'.$link_ids,
                                    '###CANCEL_LINK###' => base_url().'withdraw_coin_user_cancel/'.$link_ids
                                    );
                                }
                                else{
                                   $email_template = 'Withdraw_User_Complete_fiat';
                                    $special_vars = array(
                                    '###SITENAME###' => $sitename,
                                    '###USERNAME###' => $username,
                                    '###AMOUNT###'   => (float)$amount,
                                    '###CURRENCY###' => $currency_name,
                                    '###FEES###' => $fees,
                                    '###CONFIRM_LINK###' => base_url().'withdraw_coin_user_confirm/'.$link_ids,
                                    '###CANCEL_LINK###' => base_url().'withdraw_coin_user_cancel/'.$link_ids
                                    );
                                }
                                $this->email_model->sendMail($email, '', '', $email_template, $special_vars);                               
                                $this->session->set_flashdata('success',$this->lang->line('Your withdraw request placed successfully. Please make confirm from the mail you received in your registered mail!'));
                                front_redirect('wallet', 'refresh');
                            } 
                            else 
                            {
                                $this->session->set_flashdata('error',$this->lang->line('Unable to submit your withdraw request. Please try again'));
                                front_redirect('wallet', 'refresh');
                            }
                        }
                    }
                }
                else
                {

                    $this->session->set_flashdata('error', $this->lang->line('Please check the address'));
                    front_redirect('wallet', 'refresh');
                }   
            }
            else
            {
                $this->session->set_flashdata('error', validation_errors());
                front_redirect('wallet', 'refresh');
            }
        }

        else{
            front_redirect('wallet', 'refresh');
        }
    }
    function wallet()
    {        
        $this->load->library('session');
        $user_id=$this->session->userdata('user_id');
        if($user_id=="")
        {   
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url().'home');
        }

        $data['site_common'] = site_common();
        $data['wallet'] = unserialize($this->common_model->getTableData('wallet',array('user_id'=>$user_id),'crypto_amount')->row('crypto_amount'));
        
        $data['users'] = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
        $data['dig_currency'] = $this->common_model->getTableData('currency', array('status' => 1), '', '', '', '', '', '', array('sort_order', 'ASC'))->result();
        $data['meta_content'] = $this->common_model->getTableData('meta_content',array('link'=>'wallet'))->row();
        $this->load->view('front/user/wallet', $data);
    }
    function history()
    {
        $user_id=$this->session->userdata('user_id');
        if($user_id=="")
        {   
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url().'home');
        }
        $data['site_common'] = site_common();
        $data['user_id'] = $user_id;        

        $data['login_history'] = $this->common_model->getTableData('user_activity',array('user_id'=>$user_id),'','','','','','',array('act_id','DESC'))->result();
                

        $data['deposit_history'] = $this->common_model->getTableData('transactions',array('user_id'=>$user_id,'type'=>'Deposit'),'','','','','','',array('trans_id','DESC'))->result();

        $data['withdraw_history'] = $this->common_model->getTableData('transactions',array('user_id'=>$user_id,'type'=>'Withdraw'),'','','','','','',array('trans_id','DESC'))->result();

        $data['buycrypto_history'] = $this->common_model->getTableData('transactions',array('user_id'=>$user_id,'type'=>'buy_crypto'),'','','','','','',array('trans_id','DESC'))->result();

        $data['trade_history'] = $this->common_model->getTableData('coin_order',array('userId'=>$user_id),'','','','','','',array('trade_id','DESC'))->result();

        $data['users'] = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
        $data['action'] = front_url() . 'history';
        $data['js_link'] = '';
        $meta = $this->common_model->getTableData('meta_content', array('link' => 'coin_request'))->row();
        $data['meta_content'] = $this->common_model->getTableData('meta_content',array('link'=>'history'))->row();
        $this->load->view('front/user/history', $data); 
    }

     function update_adminaddress($coin_symbol)
    {
echo $coin_symbol;
exit();
        $Fetch_coin_list = $this->common_model->getTableData('currency',array('currency_symbol'=>$coin_symbol,'status'=>'1'))->result();

        $whers_con = "id='1'";

        // $get_admin  =   $this->common_model->getrow("bluerico_admin", $whers_con);
        // print_r($get_admin); exit();

        $admin_id = "1";

        $enc_email = getAdminDetails($admin_id, 'email_id');

        $email = decryptIt($enc_email);


        $get_admin = $this->common_model->getrow("tenrealm_admin_wallet", $whers_con);
        
        if(!empty($get_admin)) 
        {
            $get_admin_det = json_decode($get_admin->addresses, true);

            foreach($Fetch_coin_list as $coin_address)
            {           
                //$currency_exit =  array_key_exists($coin_address->currency_symbol, $get_admin_det)?true:false;
                
                if(array_key_exists($coin_address->currency_symbol, $get_admin_det))
                {
                    //$currency_address_checker = (!empty($get_admin_det[$coin_address->currency_symbol]))?true:false;

                    if(empty($get_admin_det[$coin_address->currency_symbol]))
                    {
                        $parameter = '';

                        switch ($coin_address->coin_type) {
                            case 'coin':
                                
                                switch ($coin_address->currency_symbol) {
                                    case 'ETH':
                                        $parameter='create_eth_account';
                                
                                        $Get_First_address = $this->local_model->access_wallet($coin_address->id,'create_eth_account', $email);
                                        
                                            $get_admin_det[$coin_address->currency_symbol] = $Get_First_address;

                                            $update['addresses'] = json_encode($get_admin_det);

                                            $this->common_model->updateTableData("admin_wallet",array('user_id' => $admin_id),$update);
                                        
                                        

                                        break;
                                    
                                    default:
                                        $parameter='getnewaddress';

                                        $Get_First_address = $this->local_model->access_wallet($coin_address->id,'getnewaddress', $email);

                            

                                            $get_admin_det[$coin_address->currency_symbol] = $Get_First_address;

                                            $update['addresses'] = json_encode($get_admin_det);

                                            $this->common_model->updateTableData("admin_wallet",array('user_id'=>$admin_id),$update);
                                        
                                    
                                        break;
                                }

                                break;
                            case 'token':

                                $get_admin_det[$coin_address->currency_symbol] = $get_admin_det['ETH'];

                                $update['addresses'] = json_encode($get_admin_det);
                                
                                $this->common_model->updateTableData("admin_wallet",array('user_id'=>$admin_id),$update);

                                break;
                            default:
                                break;
                        }                  
                    }
                }
            }
        }
    }


    function add_coin()
    {
        if($this->block() == 1)
{ 
front_redirect('block_ip');
}
        $user_id=$this->session->userdata('user_id');
        if($user_id=="")
        {   
            front_redirect('login', 'refresh');
        }
        if($this->input->post())
        {
            $image = $_FILES['coin_logo']['name'];
            if($image!="") {
            $uploadimage=cdn_file_upload($_FILES["coin_logo"],'uploads/coin_request');
            if($uploadimage)
            {
                $image=$uploadimage['secure_url'];
            }
            else
            {
                $this->session->set_flashdata('error',$this->lang->line('Problem with your coin image'));
                front_redirect('add_coin', 'refresh');
            }
            } 
            else 
            { 
                $image=""; 
            }
            $insertData['user_id'] = $user_id;
            $insertData['coin_type'] = $this->input->post('coin_type');
            $insertData['coin_name'] = $this->input->post('coin_name');
            $insertData['coin_symbol'] = $this->input->post('coin_symbol');
            $insertData['coin_logo'] = $image;
            $insertData['max_supply'] = $this->input->post('max_supply');
            $insertData['coin_price'] = $this->input->post('coin_price');
            $insertData['priority'] = $this->input->post('priority');
            if($this->input->post('crypto_type') !='')
            {
            $insertData['crypto_type'] = $this->input->post('crypto_type');
            }
            if($this->input->post('token_type') !='')
            {
            $insertData['token_type'] = $this->input->post('token_type');
            }
            $insertData['marketcap_link'] = $this->input->post('marketcap_link');
            $insertData['coin_link'] = $this->input->post('coin_link');
            $insertData['twitter_link'] = $this->input->post('twitter_link');
            $insertData['username'] = $this->input->post('username');
            $insertData['email'] = $this->input->post('email');
            $insertData['status'] = '0';
            $insertData['added_by'] = 'user';
            $insertData['added_date'] = date('Y-m-d h:i:s');
            /*$insertData['type'] = 'digital';
            $insertData['verify_request'] = 0;*/
            $username = $this->input->post('username');
            $user_mail = $this->input->post('email');
            $coin_name = $this->input->post('coin_name');
            $insert = $this->common_model->insertTableData('add_coin', $insertData);
            $email_template = 'Coin_request';
            $special_vars = array(
            '###USERNAME###' => $username,
            '###COIN###' => $coin_name
            );
            //-----------------
            $this->email_model->sendMail($user_mail, '', '', $email_template, $special_vars);
            if ($insert) {

                $this->session->set_flashdata('success', $this->lang->line('Your add coin request successfully sent to our team'));
                front_redirect('add_coin', 'refresh');
            } else {
                $this->session->set_flashdata('error', $this->lang->line('Error occur!! Please try again'));
                front_redirect('add_coin', 'refresh');
            }
        }
        $data['site_common'] = site_common();
        $meta = $this->common_model->getTableData('meta_content', array('link' => 'coin_request'))->row();
        $data['action'] = front_url() . 'add_coin';
        $data['heading'] = $meta->heading;
        $data['title'] = $meta->title;
        $data['meta_keywords'] = $meta->meta_keywords;
        $data['meta_description'] = $meta->meta_description;
        $this->load->view('front/user/add_coin', $data);
    }

    public function account(){
        if($this->block() == 1)
                { 
                front_redirect('block_ip');
                }
        $user_id=$this->session->userdata('user_id');
        if($user_id=="")
        {   
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url().'home');
        }

        $data['users'] = $this->common_model->getTableData('users',array('id'=>$user_id))->row();

        $data['bank_details'] = $this->common_model->getTableData('user_bank_details',array('user_id'=>$user_id))->row();

        $data['site_common'] = site_common();
        $data['meta_content'] = $this->common_model->getTableData('meta_content',array('link'=>'profile-edit'))->row();
        $data['countries'] = $this->common_model->getTableData('countries')->result();
        $this->load->view('front/user/account', $data); 
    }


    function update_bank_details()
    {        
        $this->load->library('session','form_validation');
        $user_id=$this->session->userdata('user_id');
        if($user_id=="")
        {   
            $this->session->set_flashdata('success', $this->lang->line('Please Login'));
            redirect(base_url().'home');
        }
        if($_POST)
        {
            $this->form_validation->set_rules('bank_account_number', 'Bank Account number', 'required|xss_clean');
            if($this->form_validation->run())
            {
                $insertData['user_id'] = $user_id;
                $insertData['currency'] = $this->db->escape_str($this->input->post('currency'));
                $insertData['bank_account_name'] = $this->db->escape_str($this->input->post('bank_account_name'));
                $insertData['bank_account_number'] = $this->db->escape_str($this->input->post('bank_account_number'));
                $insertData['bank_swift'] = $this->db->escape_str($this->input->post('bank_swift'));
                $insertData['bank_name'] = $this->db->escape_str($this->input->post('bank_name'));
                $insertData['bank_address'] = $this->db->escape_str($this->input->post('bank_address'));
                $insertData['bank_city'] = $this->db->escape_str($this->input->post('bank_city'));
                $insertData['bank_country'] = $this->db->escape_str($this->input->post('bank_country'));
                $insertData['bank_postalcode'] = $this->db->escape_str($this->input->post('bank_postalcode'));
                $insertData['added_date'] = date("Y-m-d H:i:s");                
                $insertData['status'] = 'Pending';
                $insertData['user_status'] = '1';
                
                // echo "<pre>";print_r($insertData);die;
                $insertData_clean = $this->security->xss_clean($insertData);
                $get = $this->common_model->getTableData('user_bank_details',array('user_id'=>$user_id))->row();
                if(empty($get)) {
                    $insert=$this->common_model->insertTableData('user_bank_details',$insertData_clean);
                } else {
                    $insert = $this->common_model->updateTableData('user_bank_details',array('id'=>$user_id),$insertData_clean);
                }

                
                if ($insert) {
                    $this->session->set_flashdata('success', $this->lang->line('Bank details Updated Successfully'));

                    front_redirect('update_bank_details', 'refresh');
                } else {
                    $this->session->set_flashdata('error', $this->lang->line('Something ther is a Problem .Please try again later'));
                    front_redirect('update_bank_details', 'refresh');
                }
            }
            else
            {
                $this->session->set_flashdata('error',$this->lang->line('Some datas are missing'));
                front_redirect('update_bank_details', 'refresh');
            }
        }       

        $data['fiat_currency'] = $this->common_model->getTableData('currency',array('type'=>'fiat','status'=>1),'','','','','','',array('id','ASC'))->result();
        $data['bankwire'] = $this->common_model->getTableData('user_bank_details',array('user_id'=>$user_id))->row();
        $data['countries'] = $this->common_model->getTableData('countries')->result();
        $data['users'] = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
        $this->load->view('front/user/user_bank_details', $data); 
        
        // echo "<pre>";print_r($data['bankwire']);die;
    }

    function security()
    {   
        $this->load->library('session','form_validation');
        $user_id=$this->session->userdata('user_id');
        if($user_id=="")
        {   
            front_redirect('', 'refresh');
        }
        $data['users'] = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
        $this->load->library('Googleauthenticator');
        if($data['users']->randcode=="enable" || $data['users']->secret!="")
        {   
            $secret = $data['users']->secret; 
            $data['secret'] = $secret;
            $ga     = new Googleauthenticator();
            $data['url'] = $ga->getQRCodeGoogleUrl('', $secret);
        }
        else
        {
            $ga = new Googleauthenticator();
            $data['secret'] = $ga->createSecret();
            $data['url'] = $ga->getQRCodeGoogleUrl('', $data['secret']);
            $data['oneCode'] = $ga->getCode($data['secret']);
        }

        if($_POST)
        {

            $secret_code = $this->db->escape_str($this->input->post('secret'));
            $onecode = $this->db->escape_str($this->input->post('code'));
            $code = $ga->verifyCode($secret_code,$onecode,$discrepancy = 3);

            if($data['users']->randcode != "enable")
            {

                if($code=='1')
                {
                    $this->db->where('id',$user_id);
                    $data1=array('secret'  => $secret_code,'randcode'  => "enable");
                    $this->db->update('users',$data1);                  
                    $this->session->set_flashdata('success', $this->lang->line('TFA Enabled successfully'));
                    front_redirect('settings/twostep-verification', 'refresh');
                }
                else
                {
                    $this->session->set_flashdata('error', $this->lang->line('Please Enter correct code to enable TFA'));
                    
                    front_redirect('settings/twostep-verification', 'refresh');
                    
                }
            }
            else
            {
                if($code=='1')
                {
                    $this->db->where('id',$user_id);
                    $data1=array('secret'  => $secret_code,'randcode'  => "disable");
                    $this->db->update('users',$data1);  
                    $this->session->set_flashdata('success', $this->lang->line('TFA Disabled successfully'));
                    front_redirect('settings/twostep-verification', 'refresh');
                }
                else
                {
                    $this->session->set_flashdata('error', $this->lang->line('Please Enter correct code to disable TFA'));
                    /*echo $secret_code."<br/>";
                    echo $code."Pila<br/>";
                    echo $onecode;
                    exit();*/
                    front_redirect('settings/twostep-verification', 'refresh');
                }
            }
        }

        front_redirect('settings/twostep-verification', 'refresh');
    }

    function deposit($cur='LTC')
    {
        if($this->block() == 1){ 
            front_redirect('block_ip');
        }
        $user_id=$this->session->userdata('user_id');
        if($user_id=="") {  
            front_redirect('', 'refresh');




        }
        $bankwire = $this->common_model->getTableData('admin_bank_details',array('id'=>1))->row();
        if(!empty($bankwire)) {
            $data['bankwire'] = $bankwire;
        }
        $data['user'] = $this->common_model->getTableData('users',array('id'=>$user_id))->row();

        $data['fiat_currency'] = $this->common_model->getTableData('currency',array('status'=>1,'type'=>'fiat'))->row();

        $data['admin_bankdetails'] = $this->common_model->getTableData('admin_bank_details', array('currency'=>$data['fiat_currency']->id))->row();

        $data['user_bank'] = $this->common_model->getTableData('user_bank_details',array('user_id'=>$user_id,'status'=>'1'))->row();
        
        $data['dig_currency'] = $this->common_model->getTableData('currency',array('type'=>'digital','status'=>1),'','','','','','',array('id','ASC'))->result();
        $data['sel_currency'] = $this->common_model->getTableData('currency',array('currency_symbol'=>$cur),'','','','','','',array('id','ASC'))->row();
        $cur_id = $data['sel_currency']->id;

        if($data['sel_currency']->currency_symbol=='XRP')
        {
            $data['destination_tag'] = secret($user_id);
        }

        $data['all_currency'] = $this->common_model->getTableData('currency',array('status'=>1),'','','','','','',array('id','ASC'))->result();

        $data['wallet'] = unserialize($this->common_model->getTableData('wallet',array('user_id'=>$user_id),'crypto_amount')->row('crypto_amount'));

        $data['balance_in_usd'] = to_decimal(Overall_USD_Balance($user_id),2);

        $data['deposit_history'] = $this->common_model->getTableData('transactions',array('user_id'=>$user_id,'type'=>'Deposit'),'','','','','','',array('trans_id','DESC'))->result();
         
        // if(isset($_POST['deposit_mobile']))
        // {
        //   $Currency_Id = $this->input->post('currency');
        //  $data['slct_fiat_currency'] = $this->common_model->getTableData('currency',array('status'=>1, 'id'=>$this->input->post('currency')))->row();
        //      $slct_fiat_currency = $data['slct_fiat_currency'];
        //      $value = $this->db->escape_str($this->input->post('amount'));
                 
        //      if($value < $slct_fiat_currency->min_deposit_limit)
        //      {
        //          $this->session->set_flashdata('error', $this->lang->line('Amount you have entered is less than the minimum deposit limit'));
        //          front_redirect('deposit', 'refresh');   
        //      }
        //      elseif($value>$slct_fiat_currency->max_deposit_limit)
        //      {
        //      $this->session->set_flashdata('error', $this->lang->line('Amount you have entered is more than the maximum deposit limit'));
        //      front_redirect('deposit', 'refresh');   
        //      }
        //      $deposit_max_fees = $data['slct_fiat_currency']->deposit_max_fees;
        //         $deposit_fees_type = $data['slct_fiat_currency']->deposit_fees_type;
        //         $deposit_fees = $data['slct_fiat_currency']->deposit_fees;
        //         if($deposit_fees_type=='Percent') { $fees = (($value*$deposit_fees)/100); }
        //         else { $fees = $deposit_fees; }
        //         if($fees>$deposit_max_fees) { $final_fees = $deposit_max_fees; }
        //         else { $final_fees = $fees; }
        //         $total = $value-$final_fees;
                
        //      // Added to reserve amount
                
        //  $mobile_number     = $this->db->escape_str($this->input->post('mobile_number'));
        //  $pay_name      = $this->db->escape_str($this->input->post('pay_name'));
        //  $product_code = $this->db->escape_str($this->input->post('productcode'));
        //  $payment_types = $this->db->escape_str($this->input->post('payment_types'));
        //  $narration = $this->db->escape_str($this->input->post('narration'));

        //  $PayPeaks = array();
        //  $PayPeaks['Ref'] = 'IX'.$user_id.'#'.strtotime(date('d-m-Y h:i:s'));
        //  $PayPeaks['Msisdn'] = $mobile_number;
        //  $PayPeaks['Name'] = $pay_name;
        //  $PayPeaks['Narration'] = $narration;
        //  $PayPeaks['Product'] = $product_code;
        //  $PayPeaks['Amount'] = $value;
        //  $PayPeaks['Currency'] = $slct_fiat_currency->currency_symbol;
        //  $PayPeaks['MerchantId'] = getUserDetails($user_id,'merchant_id');
        //  $PayPeaks['Channel'] = 'WA';

        //  $PayPeaks_Response = paypeaks_receive_money($PayPeaks);
            
        //  if(isset($PayPeaks_Response) && $PayPeaks_Response!='0'){
        //      $Response_Code = $PayPeaks_Response->ResponseCode;
        //      if($Response_Code=='00'){

        //      $insertData = array(
        //      'user_id'=>$user_id,
        //      'payment_method'=>'Mobile Wallet',
        //      'currency_id'=>$this->db->escape_str($this->input->post('currency')),
        //      'amount'=>$this->db->escape_str($this->input->post('amount')),
        //      'transaction_id'=>$PayPeaks['Ref'],
        //      'description'=>$narration,
        //      'fee'=>$final_fees,
        //      'transfer_amount'=>$total,
        //      'datetime'=>gmdate(time()),
        //      'type'=>'Deposit',
        //      'status'=>'Pending',
        //      'user_status'=>'Completed',
        //      'currency_type'=>'fiat',
        //      'merchant_id'=>$PayPeaks['MerchantId'],
        //      'payment_mode'=>'1',
        //      'product_code'=>$PayPeaks['Product']
        //      );

        //  $insert = $this->common_model->insertTableData('transactions', $insertData);
        //  if ($insert) {
        //      $this->session->set_flashdata('success', $this->lang->line('Funds via Mobile Wallet has been Received. Will Process your Payments within few Minutes'));
        //      front_redirect('deposit/GHS', 'refresh');
        //  }
        //  else {
        //      $this->session->set_flashdata('error', $this->lang->line('Unable to Process your Deposit. Please contact Admin.'));
        //      front_redirect('deposit/GHS', 'refresh');
        //  }
            
        // }else {
        //  if($Response_Code=='02'){
        //      $Error_Message = 'Duplicate transaction';
        //  }
        //  elseif($Response_Code=='07'){
        //      $Error_Message = 'Error processing transaction';
        //  }
        //  elseif($Response_Code=='09'){
        //      $Error_Message = 'Transaction/entry failed';
        //  }
        //  elseif($Response_Code=='10'){
        //      $Error_Message = 'Insufficient Account Balance';
        //  }
        //  else{
        //      $Error_Message = 'Invalid Request';
        //  }
        //      $this->session->set_flashdata('error', $this->lang->line('Unable to Process your Deposit.').$Error_Message);
        //      front_redirect('deposit/GHS', 'refresh');
        //  }
        //  }
        //  else {
        //      $this->session->set_flashdata('error', $this->lang->line('Unable to Process your Deposit. Please contact Admin.'));
        //      front_redirect('deposit/GHS', 'refresh');
        //  }
        // } 

        // if(isset($_POST['deposit_bank']))
        // {
        //  if($this->input->post('kyc_verify')) {

        //      if($_FILES['upload_pdf']['name']!='') {

        //          $file_size = $_FILES['upload_pdf']['size'];
        //          $config['upload_path'] = './uploads/';
        //          $config['allowed_types'] = 'pdf';       
        //          $this->load->library('upload', $config);
        //          if (!$this->upload->do_upload('upload_pdf')) {
        //              $this->data['error'] = $this->upload->display_errors();
        //              print_r($this->data['error']);  
        //          } else {
        //              $fname = $this->upload->data('file_name');
        //              $update = $this->common_model->updateTableData('users',array('id'=>$user_id),array('photo_id_3'=>$fname));
        //          }
        //      } else{
        //          $this->session->set_flashdata('error', 'Please upload the bankwire receipt pdf and try again!!!');
        //          front_redirect('settings', 'refresh');
        //      }
        //  } else {
        //      if($_FILES['upload_pdf_deposit']['name']!='') {
        //          $config['upload_path'] = './uploads/';
        //          $config['allowed_types'] = 'pdf';       
        //          $this->load->library('upload', $config);
        //          if (!$this->upload->do_upload('upload_pdf_deposit')) {
        //              $this->data['error'] = $this->upload->display_errors();
        //              print_r($this->data['error']);  
        //          } else {
        //              $fname = $this->upload->data('file_name');
        //          }
        //      } else{
        //          $this->session->set_flashdata('error', 'Please upload the bankwire receipt pdf and try again!!!');
        //          front_redirect('deposit/EUR', 'refresh');
        //      }
        //  }    
           

        //  $Currency_Id = $this->input->post('currency');   
        //  $coin_name = $this->input->post('coin_name');    
            
        //  $data['slct_fiat_currency'] = $this->common_model->getTableData('currency',array('status'=>1, 'id'=>$this->input->post('currency')))->row();
        //  $slct_fiat_currency = $data['slct_fiat_currency'];
        //  $value = $this->db->escape_str($this->input->post('amount'));

        //  if($value < $slct_fiat_currency->min_deposit_limit)
        //  {
        //      $this->session->set_flashdata('error', $this->lang->line('Amount you have entered is less than the minimum deposit limit'));
        //      front_redirect('deposit', 'refresh');   
        //  }
        //  elseif($value>$slct_fiat_currency->max_deposit_limit)
        //  {
        //      $this->session->set_flashdata('error', $this->lang->line('Amount you have entered is more than the maximum deposit limit'));
        //      front_redirect('deposit', 'refresh');   
        //  }
        //  $deposit_max_fees = $data['slct_fiat_currency']->deposit_max_fees;
     //        $deposit_fees_type = $data['slct_fiat_currency']->deposit_fees_type;
     //        $deposit_fees = $data['slct_fiat_currency']->deposit_fees;
     //        if($deposit_fees_type=='Percent') { $fees = (($value*$deposit_fees)/100); }
     //        else { $fees = $deposit_fees; }
     //        if($fees>$deposit_max_fees) { $final_fees = $deposit_max_fees; }
     //        else { $final_fees = $fees; }
     //        $total = $value-$final_fees;
            
        //  // Added to reserve amount
        //  $reserve_amount = getcryptocurrencydetail($this->input->post('currency'));
        //  $final_reserve_amount = (float)$this->input->post('amount') + (float)$reserve_amount->reserve_Amount;
        //  $new_reserve_amount = updatefiatreserveamount($final_reserve_amount, $this->input->post('currency'));

        //  // $ref_no     = $this->db->escape_str($this->input->post('ref_no'));
        //  $bank_no       = $this->db->escape_str($this->input->post('bank'));
        //  $payment_types = $this->db->escape_str($this->input->post('payment_types'));
        //  $description = $this->db->escape_str($this->input->post('description'));
        //  $kyc_bank_status = $this->db->escape_str($this->input->post('kyc_verify')); 
        //  $account_number = $this->db->escape_str($this->input->post('account_number'));
        //  $account_name = $this->db->escape_str($this->input->post('account_name'));
        //  $bank_name = $this->db->escape_str($this->input->post('bank_name'));
        //  $bank_swift = $this->db->escape_str($this->input->post('bank_swift'));
        //  $bank_country = $this->db->escape_str($this->input->post('bank_country'));
        //  $bank_city = $this->db->escape_str($this->input->post('bank_city'));
        //  $bank_address = $this->db->escape_str($this->input->post('bank_address'));
        //  $bank_postalcode = $this->db->escape_str($this->input->post('bank_postalcode'));

        //  if($kyc_bank_status!='') {
        //      $kyc_verify = $kyc_bank_status; 
        //      $update = $this->common_model->updateTableData('users',array('id'=>$user_id),array('photo_3_status'=>1));
        //  } else {
        //      $kyc_verify = '';
        //  }
        //  $Ref = $user_id.'#'.strtotime(date('d-m-Y h:i:s'));     
            
        //  if($_POST['admin_id']) {
        //      $admin_id = $_POST['admin_id'];
        //  } else {
        //      $admin_id = 0;
        //  }   
        //  $insertData = array(
        //      'user_id'=>$user_id,
        //      'admin_id'=>$admin_id,
        //      'payment_method'=>$payment_types,
        //      'currency_id'=>$this->db->escape_str($this->input->post('currency')),
        //      'amount'=>$this->db->escape_str($this->input->post('amount')),
        //      'transaction_id'=>$Ref,
        //      'bank_id'=>$bank_no,
        //      'fee'=>$final_fees,
        //      'transfer_amount'=>$total,
        //      'datetime'=>gmdate(time()),
        //      'type'=>'Deposit',
        //      'status'=>'Pending',
        //      'currency_type'=>'fiat',
        //      'verify_status'=>$kyc_verify,
        //      'account_number'=>$account_number,
        //      'account_name'=>$account_name,
        //      'bank_name'=>$bank_name,
        //      'bank_swift_code'=>$bank_swift,
        //      'bank_country'=>$bank_country,
        //      'bank_city'=>$bank_city,
        //      'bank_address'=>$bank_address,
        //      'bank_postalcode'=>$bank_postalcode,
        //      'upload_pdf_deposit'=>$fname,
        //      );

        //  $insert = $this->common_model->insertTableData('transactions', $insertData);
        //  $usersvalid = $this->common_model->getTableData('users', array('id' => $user_id));
        //  if ($insert) {                          
        //      if($kyc_verify=='') {
        //          $users = $usersvalid->row();
  //                   $prefix = get_prefix();
  //                   $user = getUserDetails($user_id);
  //                   $usernames = $prefix.'username';
     //                $username = $user->$usernames;
        //          $enc_email = getAdminDetails('1','email_id');
        //          $adminmail = decryptIt($enc_email);
        //          $email_template = 'Deposit_request';
        //          $special_vars = array(
        //              '###USERNAME###' => $username,
        //              '###COIN###' => $coin_name,
        //              '###AMOUNT###' => $total,
        //              '###CONFIRM_LINK###' => front_url().'tenrealm_admin/deposit/view/'.$insert,
        //          );
        //          $this->email_model->sendMail($adminmail, '', '', $email_template, $special_vars);
        //      } else {
        //          $users = $usersvalid->row();
        //          $email = getUserEmail($users->id);
        //          $prefix = get_prefix();
        //          $user = getUserDetails($user_id);
        //          $usernames = $prefix.'username';
        //          $username = $user->$usernames;
        //          $email_template = 'user_Deposit_Process_AML';
        //          $special_vars = array(
        //              '###USERNAME###' => $username
        //          );
  //                $this->email_model->sendMail($email, '', '', $email_template, $special_vars);
        //      }
        //      $this->session->set_flashdata('success', $this->lang->line('Your deposit request placed successfully'));
        //      if($payment_types == 'paypal')
        //      {
        //          front_redirect('pay/'.$insert, 'refresh');
        //      }
        //      else
        //      {
        //          if($kyc_verify=='kyc_verify') front_redirect('settings', 'refresh');
        //              else front_redirect('deposit/EUR', 'refresh');
        //      }
        //  } else {
        //      $this->session->set_flashdata('error', $this->lang->line('Unable to submit your deposit request. Please try again'));
        //      if($kyc_verify=='kyc_verify') front_redirect('settings', 'refresh');
        //          else front_redirect('deposit/EUR', 'refresh');
        //  }

        // }

        // if(isset($_POST['deposit_card']))
        // {
        //   $Currency_Id = $this->input->post('currency');
        //  $data['slct_fiat_currency'] = $this->common_model->getTableData('currency',array('status'=>1, 'id'=>$this->input->post('currency')))->row();
        //      $slct_fiat_currency = $data['slct_fiat_currency'];
        //      $value = $this->db->escape_str($this->input->post('amount'));
                 
        //      if($value < $slct_fiat_currency->min_deposit_limit)
        //      {
        //          $this->session->set_flashdata('error', $this->lang->line('Amount you have entered is less than the minimum deposit limit'));
        //          front_redirect('deposit', 'refresh');   
        //      }
        //      elseif($value>$slct_fiat_currency->max_deposit_limit)
        //      {
        //      $this->session->set_flashdata('error', $this->lang->line('Amount you have entered is more than the maximum deposit limit'));
        //      front_redirect('deposit', 'refresh');   
        //      }
        //      $deposit_max_fees = $data['slct_fiat_currency']->deposit_max_fees;
        //         $deposit_fees_type = $data['slct_fiat_currency']->deposit_fees_type;
        //         $deposit_fees = $data['slct_fiat_currency']->deposit_fees;
        //         if($deposit_fees_type=='Percent') { $fees = (($value*$deposit_fees)/100); }
        //         else { $fees = $deposit_fees; }
        //         if($fees>$deposit_max_fees) { $final_fees = $deposit_max_fees; }
        //         else { $final_fees = $fees; }
        //         $total = $value-$final_fees;
                
        //      // Added to reserve amount
                

        //  $card_number       = $this->db->escape_str($this->input->post('card_number'));
        //  $card_type     = $this->db->escape_str($this->input->post('card_type'));
        //  $product_code = $this->db->escape_str($this->input->post('productcode'));
        //  $payment_types = $this->db->escape_str($this->input->post('payment_types'));
        //  $ex_date = $this->db->escape_str($this->input->post('ex_date'));
        //  $ex_year = $this->db->escape_str($this->input->post('ex_year'));
        //  $card_ver_num = $this->db->escape_str($this->input->post('card_ver_num'));

        //  $PayPeaks = array();
        //  $PayPeaks['Ref'] = 'IX'.$user_id.'#'.strtotime(date('d-m-Y h:i:s'));
        //  $PayPeaks['CardNumber'] = $card_number;
        //  $PayPeaks['Cvv'] = $card_ver_num;
        //  $PayPeaks['ExpiryMonth'] = $ex_date;
        //  $PayPeaks['ExpiryYear'] = $ex_year;
        //  $PayPeaks['Amount'] = $value;$PayPeaks['Email'] = getUserEmail($user_id);
        //  $PayPeaks['Pin'] = '';
        //  $PayPeaks['Product'] = $product_code;
        //  $PayPeaks['MerchantId'] = getUserDetails($user_id,'merchant_id');
        //  $PayPeaks['Channel'] = 'WA';

        //  $PayPeaks_Response = paypeaks_receive_money_card($PayPeaks);

        //  echo "<pre>";
        //  print_r(json_encode($PayPeaks));
        //  print_r($PayPeaks_Response);
        //  exit();

        //  if(isset($PayPeaks_Response) && $PayPeaks_Response!='0'){
        //      $Response_Code = $PayPeaks_Response->ResponseCode;
        //      $Card_Redirect_URL = $PayPeaks_Response->url;
        //      if($Response_Code=='00'){

        //      $insertData = array(
        //      'user_id'=>$user_id,
        //      'payment_method'=>'Card Processing',
        //      'currency_id'=>$this->db->escape_str($this->input->post('currency')),
        //      'amount'=>$this->db->escape_str($this->input->post('amount')),
        //      'transaction_id'=>$PayPeaks['Ref'],
        //      'description'=>'Credit Card Processing',
        //      'fee'=>$final_fees,
        //      'transfer_amount'=>$total,
        //      'datetime'=>gmdate(time()),
        //      'type'=>'Deposit',
        //      'status'=>'Pending',
        //      'user_status'=>'Completed',
        //      'currency_type'=>'fiat',
        //      'merchant_id'=>$PayPeaks['MerchantId'],
        //      'payment_mode'=>'1',
        //      'product_code'=>$PayPeaks['Product'],
        //      'card_number'=>$card_number,
        //      'cvv'=>$card_ver_num,
        //      'exp_date'=>$ex_date,
        //      'exp_year'=>$ex_year,
        //      'card_url'=>$Card_Redirect_URL
        //      );

        //  $insert = $this->common_model->insertTableData('transactions', $insertData);
        //  if ($insert) {

        //      //echo 'window.open('.$Card_Redirect_URL.')';

        //      //header("location: ".$Card_Redirect_URL."?pop=yes");
        //      echo "<script type='text/javascript'>window.open('".$Card_Redirect_URL."');</script>";

        //      $this->session->set_flashdata('success', $this->lang->line('Payment has been Processing. Please proceed with the popup link'));
        //      front_redirect('deposit/GHS', 'refresh');
        //  }
        //  else {
        //      $this->session->set_flashdata('error', $this->lang->line('Unable to Process your Deposit. Please contact Admin.'));
        //      front_redirect('deposit/GHS', 'refresh');
        //  }
            
        // }else {
        //  if($Response_Code=='02'){
        //      $Error_Message = 'Duplicate transaction';
        //  }
        //  elseif($Response_Code=='07'){
        //      $Error_Message = 'Error processing transaction';
        //  }
        //  elseif($Response_Code=='09'){
        //      $Error_Message = 'Transaction/entry failed';
        //  }
        //  elseif($Response_Code=='10'){
        //      $Error_Message = 'Insufficient Account Balance';
        //  }
        //  else{
        //      $Error_Message = 'Invalid Request';
        //  }
        //      $this->session->set_flashdata('error', $this->lang->line('Unable to Process your Deposit.').$Error_Message);
        //      front_redirect('deposit/GHS', 'refresh');
        //  }

        //  }
        //  else {
        //      $this->session->set_flashdata('error', 'Unable to Process your Deposit. Please contact Admin.');
        //      front_redirect('deposit/GHS', 'refresh');
        //  }

        // }

        
        if($cur=='')
        {
            $Fetch_coin_list = $this->common_model->getTableData('currency',array('type'=>'digital','status'=>'1'),'id')->row();
            $coin_address = getAddress($user_id,$Fetch_coin_list->id);
        }
        else
        {
            $Fetch_coin_list = $this->common_model->getTableData('currency',array('type'=>'digital','status'=>'1'),'id')->row();
            $coin_address = getAddress($user_id,$cur_id);
        }

        // print_r($user_id);die;
        $data['First_coin_image'] = "https://chart.googleapis.com/chart?cht=qr&chs=280x280&chl=$coin_address&choe=UTF-8&chld=L";
        $data['crypto_address'] = $coin_address;
        $data['site_common'] = site_common();
        $data['action'] = front_url() . 'deposit';
        $data['js_link'] = 'deposit';
        $meta = $this->common_model->getTableData('meta_content', array('link' => 'deposit'))->row();
        $data['heading'] = $meta->heading;
        $data['title'] = $meta->title;
        $data['meta_keywords'] = $meta->meta_keywords;
        $data['meta_description'] = $meta->meta_description;
        $data['selcur_id'] = $Fetch_coin_list->id;
        $data['selcur_id'] = 1;
        // echo '<pre>';print_r($data);exit;
        $data['currency_balance'] = getBalance($user_id, $data['selcur_id']);
        $this->load->view('front/user/deposit', $data); 
        // $this->load->view('front/user/mywithdraw', $data);
    }


    function deposit_amount(){

        $this->load->view('front/user/deposit_amount', $data);
    }


    // function withdraw($cur='LTC')
    // { 
 //        $this->load->library(array('form_validation','session'));
    //  $user_id=$this->session->userdata('user_id');
    //  if($user_id=="")
    //  {   
    //      $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
    //      redirect(base_url().'home');
    //  }
        

    //  // $bankwire = $this->common_model->getTableData('user_bank_details',array('user_id'=>$user_id))->row();
    //  // $bankwire = $this->common_model->getTableData('admin_bank_details',array('id'=>1))->row();
    //  // if(!empty($bankwire)) {
    //  //  $data['bankwire'] = $bankwire;
    //  // }
    //  $data['user'] = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
    //  /*if($data['user']->randcode!='enable')
    //  {
    //      $this->session->set_flashdata('error', 'Please Enable 2 Step Verification.');
    //      front_redirect('settings', 'refresh');
    //  }*/
    //  $data['site_common'] = site_common();   
    //  $data['currency'] = $this->common_model->getTableData('currency',array('status'=>1),'','','','','','',array('id','ASC'))->result(); 

    //  if(isset($cur) && !empty($cur)){
    //      $data['sel_currency'] = $this->common_model->getTableData('currency',array('currency_symbol'=>$cur),'','','','','','',array('id','ASC'))->row();
    //      $data['selcsym'] = $cur;

    //      $data['fees_type'] = $data['sel_currency']->withdraw_fees_type;
    //      $data['fees'] = $data['sel_currency']->withdraw_fees;
    //  }
    //  else{
    //      $data['sel_currency'] = $this->common_model->getTableData('currency',array('status' => 1),'','','','','','',array('id','ASC'))->row();
    //      $data['selcsym'] = $data['sel_currency']->currency_symbol;
            
    //      $data['fees_type'] = $data['sel_currency']->withdraw_fees_type;
    //      $data['fees'] = $data['sel_currency']->withdraw_fees;
    //  }
        
    //  $data['user_id'] = $user_id;
    //  $data['selcur_id'] = $data['sel_currency']->id;
    //  $data['currency_balance'] = getBalance($user_id,$data['selcur_id']);
    //  $data['wallet'] = unserialize($this->common_model->getTableData('wallet',array('user_id'=>$user_id),'crypto_amount')->row('crypto_amount'));

    //  $data['meta_content'] = $this->common_model->getTableData('meta_content',array('link'=>'wallet'))->row();
    //  $data['withdraw_history'] = $this->common_model->getTableData('transactions',array('user_id'=>$user_id,'type'=>'Withdraw'),'','','','','','',array('trans_id','DESC'))->result();


    //  if(isset($_POST['withdrawcoin']))
    //     { 
    //      $this->form_validation->set_rules('ids', 'ids', 'trim|required|xss_clean|numeric');
    //      $this->form_validation->set_rules('amount', 'Amount', 'trim|required|xss_clean');
    //      $passinp = $this->db->escape_str($this->input->post('ids'));
    //      $myval = explode('_',$passinp);
    //      $id = $myval[0]; 
    //      $name = $myval[1];
    //      $bal = $myval[2];

    //      $this->form_validation->set_rules('address', 'Address', 'trim|required|xss_clean');         
            
    //      $amount = $this->db->escape_str($this->input->post('amount'));
    //      $address = $this->db->escape_str($this->input->post('address'));
    //      $Payment_Method = 'crypto';
    //      $Currency_Type = 'crypto';
            
 //             $balance = getBalance($user_id,$id,'crypto');
    //      $currency = getcryptocurrencydetail($id);
    //      $w_isValids   = $this->common_model->getTableData('transactions', array('user_id' => $user_id, 'type' =>'Withdraw', 'status'=>'Pending','user_status'=>'Pending','currency_id'=>$id));
    //      $count        = $w_isValids->num_rows();
 //            $withdraw_rec = $w_isValids->row();
 //            $final = 1;
 //            $Validate_Address = 1;

    //      if($Validate_Address==1)
    //      {   
    //          if($count>0)
    //          {                           
    //              $this->session->set_flashdata('error', $this->lang->line('Sorry!!! Your previous ') . $currency->currency_symbol . $this->lang->line('Transaction is Pending'));
    //              front_redirect('withdraw/'.$cur, 'refresh');    
    //          }
    //          else
    //          {  
    //              if($amount>$balance)
    //              { 
    //                  $this->session->set_flashdata('error', $this->lang->line('Amount you have entered is more than your current balance'));
    //                  front_redirect('withdraw/'.$cur, 'refresh');
    //              }
    //              if($amount < $currency->min_withdraw_limit)
    //              { 
    //                  $this->session->set_flashdata('error',$this->lang->line('Amount you have entered is less than minimum withdrawl limit'));
    //                  front_redirect('withdraw/'.$cur, 'refresh');
    //              }
    //              elseif($amount>$currency->max_withdraw_limit)
    //              { 
    //                  $this->session->set_flashdata('error', $this->lang->line('Amount you have entered is more than maximum withdrawl limit'));
    //                  front_redirect('withdraw/'.$cur, 'refresh');    
    //              }
    //              elseif($final!=1)
    //              { 
    //                  $this->session->set_flashdata('error',$this->lang->line('Invalid address'));
    //                  front_redirect('withdraw/'.$cur, 'refresh');
    //              }
    //              else
    //              { 
    //                  $withdraw_fees_type = $currency->withdraw_fees_type;
    //                  $withdraw_fees = $currency->withdraw_fees;

                        

    //                  $valid_address = $this->input->post('valid_address');

    //                  if($valid_address=='0') {
    //                      if($withdraw_fees_type=='Percent') { $fees = (($amount*$withdraw_fees)/100); 
    //                      } else { $fees = $withdraw_fees; }
        
    //                      $wallet_type = 0;
    //                  } else {
    //                      $fees = 0;
    //                      $total = $amount;
    //                      $wallet_type = 1;
    //                  }
    //                  $Ref = $user_id.'#'.strtotime(date('d-m-Y h:i:s'));
    //                  $user_status = 'Pending';
    //                  $insertData = array(
    //                      'user_id'=>$user_id,
    //                      'payment_method'=>$Payment_Method,
    //                      'currency_id'=>$id,
    //                      'amount'=>$amount,
    //                      'transaction_id'=>$Ref,
    //                      'fee'=>$fees,
    //                      'sharecoin_fee'=>sprintf('%f', $fees_s),
    //                      'bank_id'=>$Bank_id,
    //                      'crypto_address'=>$address,
    //                      'destination_tag'=>$Destination_Tag,
    //                      'transfer_amount'=>$total,
    //                      'datetime'=>gmdate(time()),
    //                      'type'=>'Withdraw',
    //                      'status'=>'Pending',
    //                      'currency_type'=>$Currency_Type,
    //                      'user_status'=>$user_status,
    //                      'wallet_type'=>$wallet_type
    //                      );
    //                  $finalbalance = $balance - $amount;

    //                   //echo "<pre>";print_r($insertData);die;

    //                  $updatebalance = updateBalance($user_id,$id,$finalbalance,'crypto');
    //                  $insertData_clean = $this->security->xss_clean($insertData);
    //                  $insert = $this->common_model->insertTableData('transactions', $insertData_clean);
    //                  if($insert) 
    //                  {
    //                      $prefix = get_prefix();
    //                      $user = getUserDetails($user_id);
    //                      $usernames = $prefix.'username';
    //                      $username = $user->$usernames;
    //                      $email = getUserEmail($user_id);
    //                      $currency_name = getcryptocurrency($id);
    //                      $link_ids = encryptIt($insert);
    //                      $sitename = getSiteSettings('english_site_name');
    //                      $site_common = site_common();                           

    //                          $email_template = 'Withdraw_User_Complete';
    //                          $special_vars = array(
    //                          '###SITENAME###' => $sitename,
    //                          '###USERNAME###' => $username,
    //                          '###AMOUNT###'   => (float)$amount,
    //                          '###CURRENCY###' => $currency_name,
    //                          '###FEES###' => $fees,
    //                          '###CRYPTOADDRESS###' => $address,
    //                          '###CONFIRM_LINK###' => base_url().'withdraw_coin_user_confirm/'.$link_ids,
    //                          '###CANCEL_LINK###' => base_url().'withdraw_coin_user_cancel/'.$link_ids
    //                          );
                            
                            
    //                      $this->email_model->sendMail($email, '', '', $email_template, $special_vars);
    //                      $this->session->set_flashdata('success',$this->lang->line('Your withdraw request placed successfully. Please make confirm from the mail you received in your registered mail!'));
    //                      front_redirect('wallet', 'refresh');
    //                  } 
    //                  else 
    //                  {
    //                      $this->session->set_flashdata('error',$this->lang->line('Unable to submit your withdraw request. Please try again'));
    //                      front_redirect('withdraw/'.$cur, 'refresh');
    //                  }
    //              }
    //          }
    //      }
    //      else
    //      {
    //          $this->session->set_flashdata('error', $this->lang->line('Please check the address'));
    //          front_redirect('withdraw/'.$cur, 'refresh');
    //      }   
    //     }

    //     if(isset($_POST['withdraw_bank']))
    //     {           
    //      $this->form_validation->set_rules('currency', 'Currency', 'trim|required|xss_clean');
    //      // $this->form_validation->set_rules('account_number', 'Account number', 'trim|required|xss_clean');
    //      // $this->form_validation->set_rules('pay_name', 'Pay Name', 'trim|required|xss_clean');
    //      // $this->form_validation->set_rules('productcode', 'Product Code', 'trim|required|xss_clean');
    //      $this->form_validation->set_rules('amount2', 'Amount', 'trim|required|xss_clean');
    //      // $this->form_validation->set_rules('narration', 'Narration', 'trim|required|xss_clean');

    //      if ($this->form_validation->run()) {
    //      $Payment_Method = 'bank';
    //      $Currency_Type = 'fiat';

    //      $Currency_Id = $this->db->escape_str($this->input->post('currency'));
    //      $account_number = $this->db->escape_str($this->input->post('account_number'));
    //      $account_name = $this->db->escape_str($this->input->post('account_name'));
    //      $bank_name = $this->db->escape_str($this->input->post('bank_name'));
    //      $bank_swift = $this->db->escape_str($this->input->post('bank_swift'));
    //      $bank_country = $this->db->escape_str($this->input->post('bank_country'));
    //      $payment_types = $this->db->escape_str($this->input->post('payment_types'));
    //      $amount = $this->db->escape_str($this->input->post('amount2'));
    //      $bank_city = $this->db->escape_str($this->input->post('bank_city'));
    //      $bank_address = $this->db->escape_str($this->input->post('bank_address'));
    //      $bank_postalcode = $this->db->escape_str($this->input->post('bank_postalcode'));

    //      $balance = getBalance($user_id,$Currency_Id,'fiat');
    //      $currency = getcryptocurrencydetail($Currency_Id);
    //      $w_isValids   = $this->common_model->getTableData('transactions', array('user_id' => $user_id, 'type' =>'Withdraw', 'status'=>'Pending','user_status'=>'Completed','currency_id'=>$Currency_Id));
    //          $count        = $w_isValids->num_rows();
    //             $withdraw_rec = $w_isValids->row();
 //                $final = 1;
                
 //           if($count>0)
    //      {   
    //          $this->session->set_flashdata('error', $this->lang->line('Sorry!!! Your previous '). $currency->currency_symbol .$this->lang->line(' withdrawal is Pending. Please use other wallet or be patience')) ;
    //          front_redirect('withdraw/'.$cur, 'refresh');    
    //      }
    //      else{
    //          if($amount>$balance)
    //          { 
    //              $this->session->set_flashdata('error', $this->lang->line('Amount you have entered is more than your current balance'));
    //              front_redirect('withdraw/'.$cur, 'refresh');
    //          }
    //          if($amount < $currency->min_withdraw_limit)
    //          {
    //              $this->session->set_flashdata('error',$this->lang->line('Amount you have entered is less than minimum withdrawl limit'));
    //              front_redirect('withdraw/'.$cur, 'refresh');
    //          }
    //          elseif($amount>$currency->max_withdraw_limit)
    //          {
    //              $this->session->set_flashdata('error', $this->lang->line('Amount you have entered is more than maximum withdrawl limit'));
    //              front_redirect('withdraw/'.$cur, 'refresh');    
    //          }
    //          elseif($final!=1)
    //          {
    //              $this->session->set_flashdata('error',$this->lang->line('Invalid address'));
    //              front_redirect('withdraw/'.$cur, 'refresh');
    //          }
    //          else{
    //              $withdraw_fees_type = $currency->withdraw_fees_type;
    //              $withdraw_fees = $currency->withdraw_fees;

    //              if($withdraw_fees_type=='Percent') { $fees = (($amount*$withdraw_fees)/100); }
    //              else { $fees = $withdraw_fees; }
    //              $total = $amount-$fees;
    //              $user_status = 'Pending';

    //      $Ref = $user_id.'#'.strtotime(date('d-m-Y h:i:s'));     
    //      $insertData = array(
    //          'user_id'=>$user_id,
    //          'payment_method'=>$Payment_Method,
    //          'currency_id'=>$Currency_Id,
    //          'amount'=>$amount,
    //          'transaction_id'=>$Ref,
    //          'fee'=>$fees,
    //          'transfer_amount'=>$total,
    //          'datetime'=>gmdate(time()),
    //          'type'=>'Withdraw',
    //          'status'=>'Pending',
    //          'user_status'=>'Completed',
    //          'currency_type'=>'fiat',
    //          'payment_mode'=>'1',
    //          'account_number'=>$account_number,
    //          'account_name'=>$account_name,
    //          'bank_name'=>$bank_name,
    //          'bank_swift_code'=>$bank_swift,
    //          'bank_country'=>$bank_country,
    //          'bank_city'=>$bank_city,
    //          'bank_address'=>$bank_address,
    //          'bank_postalcode'=>$bank_postalcode,
    //          );

                
    //      $insertData_clean = $this->security->xss_clean($insertData);
    //      $insert = $this->common_model->insertTableData('transactions', $insertData_clean);
    //      if ($insert) {
    //          $finalbalance = $balance - $amount;
    //          $updatebalance = updateBalance($user_id,$Currency_Id,$finalbalance,'fiat');
    //          $insertData_clean = $this->security->xss_clean($insertData);
                
 //                 $enc_email = getAdminDetails('1','email_id');
    //          $adminmail = decryptIt($enc_email);
    //          $prefix = get_prefix();
    //          $user = getUserDetails($user_id);
    //          $usernames = $prefix.'username';
    //          $username = $user->$usernames;
    //          // $email = getUserEmail($user_id);
    //          $currency_name = getcryptocurrency($Currency_Id);
    //          // $link_ids = encryptIt($insert);
    //          // $sitename = getSiteSettings('site_name');
    //          // $site_common      =   site_common();

    //          $email_template = 'Withdraw_request_fiat';
    //          $special_vars = array(
    //          '###USERNAME###' => $username,
    //          '###AMOUNT###'   => (float)$amount,
    //          '###CURRENCY###' => $currency_name,
    //          '###CONFIRM_LINK###' => front_url().'tenrealm_admin/withdraw/view/'.$insert,
    //          );
    //          $this->email_model->sendMail($adminmail, '', '', $email_template, $special_vars); 

    //          $this->session->set_flashdata('success', $this->lang->line('Bank Wire withdrawl request has been received. Will Process your Payment within few Minutes'));
    //          front_redirect('withdraw/'.$cur, 'refresh');
    //      }
    //      else {
    //          $this->session->set_flashdata('error', $this->lang->line('Unable to Process your Withdraw. Please contact Admin.'));
    //          front_redirect('withdraw/'.$cur, 'refresh');
    //      }

    //      }

    //      }
    //  }
    //  }
    //  else {
 //                $data['msg'] = 'Unable to Process your Withdraw. Please contact Admin.';
 //            }
 //            $this->load->view('front/user/withdraw', $data);
    //     }
      


    function withdraw($cur='LTC')
    {   

        $user_id=$this->session->userdata('user_id');
        if($user_id=="")
        {   
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url().'home');
        }
        if(!$cur) redirect(base_url('/'));

        try {   

        if (!$this->input->is_ajax_request()) {
               exit('No direct script access allowed');
        }

        if(!$user_id = $this->session->userdata('user_id')){                
            throw new Exception('Authetication Failed.', 401);exit;             
        }

        $this->form_validation->set_rules('amount', 'Amount', 'trim|required|xss_clean'); 
        $this->form_validation->set_rules('address', 'Address', 'trim|required|xss_clean'); 
        if ($this->form_validation->run() == FALSE){
            $errors = validation_errors();
            echo json_encode(['status' => false, 'msg' => $errors]);exit;
        }

        if($this->input->post('withdrawcoin'))
        {
        $data['user'] = $this->common_model->getTableData('users',array('id'=>$user_id))->row();    
        $cur_name = $cur;   
        if(isset($cur) && !empty($cur)){

            $data['sel_currency'] = $this->common_model->getTableData('currency',array('currency_symbol'=>$cur),'','','','','','',array('id','ASC'))->row();
            $data['selcsym'] = $cur;
            $fees_type = $data['sel_currency']->withdraw_fees_type;
            $fees = $data['sel_currency']->withdraw_fees;           
            $id = $data['sel_currency']->id;
            $name = $data['sel_currency']->currency_name;   
            $data['wallet'] = unserialize($this->common_model->getTableData('wallet',array('user_id'=>$user_id),'crypto_amount')->row('crypto_amount'));            
            $bal = ($data['wallet']['Exchange AND Trading'][$id]) ? $data['wallet']['Exchange AND Trading'][$id] : 0;               
            $data['user_id'] = $user_id;
            $data['currency_symbol'] = $data['sel_currency']->currency_symbol;
            $data['currency_balance']  = $currency_pym_balance = get_pym_Balance($user_id,$id);

            $amount = $this->db->escape_str($this->input->post('amount'));
            $address = $this->db->escape_str($this->input->post('address'));
            $admin_percentage = $this->db->escape_str($this->input->post('user_withdraw_ltc_percentage_hidden'));
            $admin_pym_amount = $this->db->escape_str($this->input->post('widthdraw_admin_pym_amount_hidden'));
            $Currency_Type = $this->com_m->get_row_val('currency',['currency_symbol' => $cur ], "withdraw_fees_type");
            $Payment_Method = 'crypto';         
            
            $balance = getBalance($user_id,$id,'crypto'); 
            $PYMbalance = get_pym_Balance($user_id,$id,'crypto');

            $currency = getcryptocurrencydetail($id);
            $w_isValids = $this->common_model->getTableData('transactions', array('user_id' => $user_id, 'type' =>'Withdraw', 'status'=>'Pending','user_status'=>'Pending','currency_id'=>$id));
            $count        = $w_isValids->num_rows();
            $withdraw_rec = $w_isValids->row();
            $final = 1;
            $Validate_Address = 1;

            if($Validate_Address==1)
            {   
                if($count>0)
                {       
                    // echo '1';                    
                    $this->session->set_flashdata('error', $this->lang->line('Sorry!!! Your previous ') . $currency->currency_symbol .' '. $this->lang->line('Transaction is Pending'));
                    front_redirect('withdraw/'.$cur, 'refresh');    
                }
                else
                {  
                    // echo  $amount;echo '<hr>';
                    // echo $balance;exit;
                    if($amount>$PYMbalance)
                    { 
                        // echo '2';exit;
                        $this->session->set_flashdata('error', $this->lang->line('Amount you have entered is more than your current balance'));
                        front_redirect('withdraw/'.$cur, 'refresh');
                    }
                    if($amount < $currency->min_withdraw_limit)
                    {   
                        // echo '3';exit;
                        $this->session->set_flashdata('error',$this->lang->line('Amount you have entered is less than minimum withdrawl limit'));
                        front_redirect('withdraw/'.$cur, 'refresh');
                    }
                    elseif(!empty($currency->max_withdraw_limit) && $amount>$currency->max_withdraw_limit)
                    { 
                        // echo '4';exit;
                        $this->session->set_flashdata('error', $this->lang->line('Amount you have entered is more than maximum withdrawl limit'));
                        front_redirect('withdraw/'.$cur, 'refresh');    
                    }
                    elseif($final!=1)
                    { 
                        // echo '5';exit;
                        $this->session->set_flashdata('error',$this->lang->line('Invalid address'));
                        front_redirect('withdraw/'.$cur, 'refresh');
                    }
                    else
                    { 
                    $new_withdraw_pym_amount = (sprintf('%0.8f', $this->coin_price_conversion('USD', 'LTC')));      
                    $pym_amount_ltc = ( $new_withdraw_pym_amount * $admin_pym_amount );
                    $amount_ltc = ( $new_withdraw_pym_amount * $amount );

                    // echo $new_withdraw_pym_amount.'---'.$admin_pym_amount.'---'.$pym_amount_ltc.'--'.$amount;die;

                    $withdraw_fees_type = $currency->withdraw_fees_type;
                    $withdraw_fees = $currency->withdraw_fees;
            
                        $curr_symbol = $cur;                        
                        $Ref = $user_id.'#'.current_micro_timestamp();
                        // $Ref = $user_id.'#'.strtotime(date('d-m-Y h:i:s'));
                        $user_status = 'Pending';
                        $time = date("Y-m-d h:i:s",time());
                        $insertData = array(
                            'user_id'=>$user_id,
                            'unique_id'=> user_id_to_unique_id($user_id),
                            'created_at' => timestamp_UTC_conversion($time),
                            'payment_method'=>$Payment_Method,
                            'currency_id'=>$id,
                            'transaction_id'=>$Ref,
                            'amount'=>$amount,
                            'currency_amount'=>$amount_ltc,
                            'crypto_address'=>$address,                     
                            'fee'=>$admin_percentage,
                            'transfer_amount'=>$pym_amount_ltc,
                            'fiat_amount'=>$admin_pym_amount,
                            'bank_id'=>'',
                            'datetime'=>time(),
                            'type'=>'Withdraw',
                            'status'=>'Pending',
                            'currency_type'=>'crypto',
                            'user_status'=>$user_status,
                            'wallet_type'=>$wallet_type,
                            'local_transaction_id' => generate_local_transaction_id()
                        );
                       
                        
                        
                        $finalbalance = $balance - $amount_ltc;
                        $updatebalance = updateBalance($user_id,$id,$finalbalance,'crypto');

                        $final_pym_balance = $currency_pym_balance - $amount;
                        update_pym_Balance($user_id,$final_pym_balance);

                        // echo 'LTC--'.$balance .'--'. $pym_amount_ltc .'--'. $finalbalance;
                        // echo "<br>";
                        // echo 'PYM--'.$currency_pym_balance .'--'. $admin_pym_amount .'--'. $final_pym_balance;
                        // die;

                        $this->db->trans_begin();
                        $insertData_clean = $this->security->xss_clean($insertData);
                        $insert = $this->common_model->insertTableData('transactions', $insertData_clean);

                        if ($this->db->trans_status() === FALSE)
                        {
                            $this->db->trans_rollback();
                        }
                        else
                        {
                            $this->db->trans_commit();
                            if($insert) 
                            {
                                $prefix = get_prefix();
                                $user = getUserDetails($user_id);
                                $usernames = $prefix.'username';
                                $username = $user->$usernames;
                                $email = getUserEmail($user_id);
                                // $email = 'satheesh@spiegeltechnologies.com';
                                $currency_name = getcryptocurrency($id);
                                $link_ids = encryptIt($insert);
                                $sitename = getSiteSettings('english_site_name');
                                $site_common = site_common();                           

                                $email_template = 'Withdraw_User_Complete';
                                $special_vars = array(
                                    '###SITENAME###' => $sitename,
                                    '###USERNAME###' => $username,
                                    '###AMOUNT###'   => (float)$pym_amount_ltc,
                                    '###CURRENCY###' => $currency_name,
                                    '###FEES###'     => $fees,
                                    '###CRYPTOADDRESS###' => $address,
                                    '###CONFIRM_LINK###' => base_url().'withdraw_coin_user_confirm/'.$link_ids,
                                    '###CANCEL_LINK###' => base_url().'withdraw_coin_user_cancel/'.$link_ids
                                );
                                
                                $this->email_model->sendMail($email, '', '', $email_template, $special_vars);
                                // $this->email_model->sendMail('saravanan@spiegeltechnologies.com', '', '', $email_template, $special_vars);
                                echo json_encode(['status' => true, 'msg' => 'Your withdraw request placed successfully. Please make confirm from the mail you received in your registered mail!']);
                                exit;
                            } 
                            else 
                            {                               
                                echo json_encode(['status' => true, 'msg' => 'Unable to submit your withdraw request. Please try again!']);
                                exit;
                            }
                        }
                        }
                    }
                }
                else
                {
                    $this->session->set_flashdata('error', $this->lang->line('Please check the address'));
                    front_redirect('withdraw/'.$cur, 'refresh');
                }   
            }
            }
            echo json_encode(['status' => true ]);exit;
            // $this->load->view('front/user/withdraw', $data);
        } catch (Exception $e) {
            print_r( 'error', $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() );exit;
        }
    }
      

    function change_address_withdraw(){
        $user_id=$this->session->userdata('user_id');
        $currency_id = $this->input->post('currency_id');

        $Currency_detail = getcurrencydetail($currency_id);
        $data['balance']    =   getBalance($user_id,$currency_id);
        $data['symbol']     =   currency($currency_id);
        $data['transaction_fee']    =   (float)$Currency_detail->withdraw_fees;
        $data['minimum_withdrawal'] =   (float)$Currency_detail->min_withdraw_limit;        
        echo json_encode($data);
    }

    function buy_crypto()
    {    
        $user_id = $this->session->userdata('user_id');
        if($user_id=="")
        {   
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url('home'));
        }
        
        $data['site_common'] = site_common();
        $data['meta_content'] = $this->common_model->getTableData('meta_content', array('link'=>'dashboard'))->row();
        $data['users'] = $this->common_model->getTableData('users',array('id'=>$user_id))->row();

        $data['dig_currency'] = $this->common_model->getTableData('currency',array('wyre_currency'=>1,'status'=>1),'','','','','','',array('sort_order','ASC'))->result();

        $this->load->view('front/user/buy_crypto', $data);
    } 

    function buycrpy()
    {
        $user_id = $this->session->userdata('user_id');
        $currency_id = $this->input->post("currency");
        $amount = $this->input->post("amount");
        $currency_symbol    =   currency($currency_id);
        $Currency_detail = getcurrencydetail($currency_id);
        $currency_name = strtolower($Currency_detail->currency_name);
        $wyre_settings = $this->common_model->getTableData('wyre_settings',array('id'=>1))->row();
        $address = $currency_symbol."_address"; 
        $admincoin_address = $wyre_settings->$address;
        $userinfo = getUserDetails($user_id); 
        $country_id = $userinfo->country;
        $user_countries = $this->common_model->getTableData('countries',array('id'=>$country_id))->row();
        
        $useremal = getUserEmail($user_id);
        $user_countries->country_code;

         $secert_key = decryptIt($wyre_settings->secret_key);
         $referrerAccountId = decryptIt($wyre_settings->account_id);

            $postg = '{
    "amount":'.$amount.',
    "sourceCurrency":"USD",
    "destCurrency":"'.$currency_symbol.'",
    "referrerAccountId":"'.$referrerAccountId.'",
    "email":"'.$useremal.'",
    "dest":"'.$currency_name.':'.$admincoin_address.'",
    "firstName":"'.$userinfo->tenrealm_fname.'",
    "city":"'.$userinfo->city.'",
    "phone":"+'.$user_countries->phone_number.$userinfo->tenrealm_phone.'",
    "street1":"'.$userinfo->street_address.'",
    "country":"'.$user_countries->country_code.'",
    "redirectUrl":"'.$wyre_settings->redirect_url.'/'.base64_encode($user_id).'",
    "failureRedirectUrl":"'.$wyre_settings->failure_url.'/'.base64_encode($user_id).'",
    "paymentMethod":"debit-card",
    "state":"'.$userinfo->state.'",
    "postalCode":"'.$userinfo->postal_code.'",
    "lastName":"'.$userinfo->tenrealm_lname.'",
    "lockFields":[]
}';

$url = ($wyre_settings->mode==0)?'https://api.testwyre.com/v3/orders/reserve':'https://api.sendwyre.com/v3/orders/reserve';
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postg);

            $headers = array();
            $headers[] = 'Authorization:Bearer '.$secert_key;
            $headers[] = 'Content-Type:application/json';
            //$headers[] = 'Postman-Token:7ad1cd47-a7bc-4126-9333-4983f4c6da5d';
            $headers[] = 'Cache-Control:no-cache';
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            $result = curl_exec($ch); 
            //$resp = json_decode($result);             
            curl_close($ch);
            print_r($result);exit;
    } 


    function getresponse_wyre($userid)
    {
        $myarray = $_REQUEST;
        if(empty($myarray))
        {
            $this->session->set_flashdata('error',$this->lang->line('Something Went Wrong. Please try again.'));
            front_redirect('buy_crypto', 'refresh');
        }
        $status = $_REQUEST['status'];
        $user_id = base64_decode($userid);
        $userId = $user_id;
        $wyre_settings = $this->common_model->getTableData('wyre_settings',array('id'=>1))->row();
        if(strtoupper($status)=='COMPLETE' || strtoupper($status)=='PROCESSING')
        {
            $amount = $_REQUEST['purchaseAmount'];
            $source_amount = $_REQUEST['sourceAmount'];
            $destination_currency = $_REQUEST['destCurrency'];
            $source_currency = $_REQUEST['sourceCurrency'];
            $transaction_id = $_REQUEST['transferId'];
            $date_occur = $_REQUEST['createdAt'];
            $payment_method = 'Wyre';
            $description = $_REQUEST['dest'];
            $pay_status = 'Completed';
            $payment_status = 'Paid';

            if($transaction_id!='')
            { 
                $ch = curl_init();
                $url = ($wyre_settings->mode==0)?'https://api.testwyre.com/v2/transfer/':'https://sendwyre.com/v2/transfer/';

                curl_setopt($ch, CURLOPT_URL, $url.$transaction_id.'/track');
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                $headers = array();
                $headers[] = 'Content-Type:application/json';
                $headers[] = 'Cache-Control:no-cache';
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                $result = curl_exec($ch); 
                $resp = json_decode($result);           
                curl_close($ch);
                //echo '<pre>';print_r($resp);
                if($resp->transferId == $transaction_id)
                {
                    $fee = $resp->fee;
                    $crypto_amount = $resp->destAmount;
                    $rate = $resp->rate;

                    $currency = $this->common_model->getTableData('currency',array('currency_symbol'=>$destination_currency))->row();
                    $userbalance = getBalance($userId,$currency->id);
                    $finalbalance = $crypto_amount+$userbalance;
                    // Update user balance  
                    $updatebalance = updateBalance($userId,$currency->id,$finalbalance,'');

                    $dataInsert = array(
                    'user_id' => $user_id,
                    'currency_id' => $currency->id,
                    'currency_name' => $destination_currency,
                    'amount' => $amount,
                    'description' => 'Paid for '.$source_amount.' '.$source_currency,
                    'type' => 'buy_crypto',
                    'payment_method' => 'Wyre',
                    'transfer_amount' => $crypto_amount,
                    'transfer_fee' => $rate,
                    'paid_amount' => $crypto_amount,
                    'transaction_id'=>$transaction_id,
                    'status' => $pay_status,
                    'payment_status' => $payment_status,
                    'currency_type' => 'crypto',
                    'payment_type' => 'fiat',
                    'datetime' => date("Y-m-d h:i:s")
                    );               
                    $ins_id = $this->common_model->insertTableData('transactions', $dataInsert); 
                    if($ins_id) 
                    {
                        $prefix = get_prefix();
                        $user = getUserDetails($userId);
                        $usernames = $prefix.'username';
                        $username = $user->$usernames;
                        $email = getUserEmail($userId);
                        $link_ids = base64_encode($ins_id);
                        $sitename = getSiteSettings('site_name');
                        $site_common      =   site_common();
                        $email_template   = 'Deposit_Complete';     
                            $special_vars = array(
                            '###SITENAME###' => $sitename,          
                            '###USERNAME###' => $username,
                            '###AMOUNT###'   => number_format($crypto_amount,8),
                            '###CURRENCY###' => $destination_currency,
                            '###MSG###' => $msg,
                            '###STATUS###'   => ucfirst($pay_status)
                            );
                        // USER NOTIFICATION
                        $email = 'manimegalai@spiegeltechnologies.com';
                        $this->email_model->sendMail($email, '', '', $email_template, $special_vars);
                        if($pay_status=='Pending')
                        {
                            $this->session->set_flashdata('error',$this->lang->line('Your Crypto Deposit Failed. Please try again.'));
                        }
                        
                        else
                        {
                            $this->session->set_flashdata('success',$this->lang->line('Your Crypto Deposit successfully completed'));
                        }
                        front_redirect('buy_crypto', 'refresh');
                    } 
                    else 
                    {
                        $this->session->set_flashdata('error', $this->lang->line('Unable to submit your Fiat Deposit request. Please try again'));
                        front_redirect('buy_crypto', 'refresh');
                    }
                }
            }
        }
        else
        {
            $this->session->set_flashdata('error',$this->lang->line('Something Went Wrong. Please try again.'));
            front_redirect('buy_crypto', 'refresh');
        }
    } 

    function getfailureresponse_wyre($userid)
    {       
        $this->session->set_flashdata('error',$this->lang->line('Something Went Wrong. Please try again.'));
        front_redirect('buy_crypto', 'refresh');
    }  

function close_ticket($code='')
    {
        $this->load->library('session');
        $user_id=$this->session->userdata('user_id');
        if($user_id=="")
        {   
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url().'home');
        }

        $support= $this->common_model->getTableData('support', array('user_id' => $user_id, 'ticket_id'=>$code))->row();
        $id = $support->id;

        $updateData['close'] = '1';
        $condition = array('id' => $id);
        $update = $this->common_model->updateTableData('support', $condition, $updateData);
        if($update){
            $this->session->set_flashdata('success',$this->lang->line('Ticket Closed'));
            front_redirect('support', 'refresh');
        }
        else{
            $this->session->set_flashdata('error',$this->lang->line('Something Went Wrong. Please try again.'));
            front_redirect('support_reply/'.$code, 'refresh');
        }

    }

function paypeaks_status(){
    $Transactions= $this->common_model->getTableData('transactions', array('status'=>'Pending','user_status'=>'Completed', 'payment_mode'=>'1'))->result();

    foreach($Transactions as $trans){
        $PayPeaks = array();
        $PayPeaks['merchantid'] = $trans->merchant_id;
        $PayPeaks['refno'] = $trans->transaction_id;
        $PayPeaks['productcode'] = $trans->product_code;
        $user_id = $trans->user_id;
        $Currency_Id = $trans->currency_id;
        $Amount = $trans->amount;
        //echo $PayPeaks['refno']."<br/>";
        echo "<pre>";
        print_r(json_encode($PayPeaks));

        $Paypeaks_Response = paypeaks_status($PayPeaks);
        echo "<pre>";
        print_r($Paypeaks_Response);
        //exit();

        if(isset($Paypeaks_Response) && !empty($Paypeaks_Response)){
        if(isset($Paypeaks_Response->Responsecode) && $Paypeaks_Response->Responsecode=='01'){
            if($trans->type=='Deposit'){
                $userbalance = getBalance($user_id,$Currency_Id); 
                $finalbalance = ($Amount)+($userbalance);
                $updatebalance = updateBalance($user_id,$Currency_Id,$finalbalance,'');

                $reserve_amount = getcryptocurrencydetail($Currency_Id);
                $final_reserve_amount = (float)$Amount + (float)$reserve_amount->reserve_Amount;
                $new_reserve_amount = updatefiatreserveamount($final_reserve_amount, $Currency_Id);

                $updateData['status'] = 'Completed';
                $condition = array('trans_id' => $trans->trans_id);
                $update = $this->common_model->updateTableData('transactions', $condition, $updateData);

                $prefix = get_prefix();
                $user = getUserDetails($user_id);
                $usernames = $prefix.'username';
                $username = $user->$usernames;
                $email = getUserEmail($user_id);
                $sitename = getSiteSettings('site_name');
                $site_common      =   site_common();
                $email_template   = 'Fiat_Deposit';     
                    $special_vars = array(
                    '###SITENAME###' => $sitename,          
                    '###USERNAME###' => $username,
                    '###AMOUNT###'   => $Amount,
                    '###CURRENCY###' => 'GHS',
                    '###MSG###' => 'Funds has been deposited successfully',
                    '###STATUS###'   => ucfirst('Completed')
                    );
                $this->email_model->sendMail($email, '', '', $email_template, $special_vars);

                if($update){
                    echo 'Deposit Transaction ID - '.$trans->trans_id.' Completed';
                }
            }
            else{
                $updateData['status'] = 'Completed';
                $condition = array('trans_id' => $trans->trans_id);
                $update = $this->common_model->updateTableData('transactions', $condition, $updateData);

                if($update){
                    $prefix = get_prefix();
                $user = getUserDetails($user_id);
                $usernames = $prefix.'username';
                $username = $user->$usernames;
                $email = getUserEmail($user_id);
                $sitename = getSiteSettings('site_name');
                $site_common      =   site_common();
                $email_template   = 'Withdraw_Complete';        
                    $special_vars = array(
                    '###SITENAME###' => $sitename,          
                    '###USERNAME###' => $username,
                    '###AMOUNT###'   => $Amount,
                    '###CURRENCY###' => 'GHS',
                    '###TX###' => $trans->transaction_id
                    );
                $this->email_model->sendMail($email, '', '', $email_template, $special_vars);

                echo 'Withdraw Transaction ID - '.$trans->trans_id.' Completed';
                }
            }
        }
        if($Paypeaks_Response->Responsecode=='9' || $Paypeaks_Response->Responsecode=='7' || $Paypeaks_Response->Responsecode=='8' || $Paypeaks_Response->Responsecode=='6'){
            $updateData['status'] = 'Cancelled';
                $condition = array('trans_id' => $trans->trans_id);
                $update = $this->common_model->updateTableData('transactions', $condition, $updateData);

                if($update){
                    if($trans->type=='Withdraw'){
                        $balance = getBalance($trans->user_id,$trans->currency_id,'fiat');

                        $finalbalance = $balance+$trans->amount;
                $updatebalance = updateBalance($trans->user_id,$trans->currency_id,$finalbalance,'fiat');
                    }
                }
        }
    }
    else{
        echo "<pre>";
        print_r($Paypeaks_Response);
    }
    }
}

function paypeaks_product(){

    $type = array('DEBIT','CREDIT','CARD');

    foreach($type as $value){

    $PayPeaks['ProductType'] = $value;

    $Paypeaks_Response = paypeaks_product($PayPeaks);
    echo "<pre>";
    print_r($Paypeaks_Response);

    if($Paypeaks_Response->ResponseCode=='00'){
        foreach($Paypeaks_Response->data as $data_val){
            $Product_Code = $data_val->Code;
            $Description = $data_val->Description;

            $Exp = explode(' - ', $Description);
            $Product_name = $Exp[0];
            $Product_mode = $Exp[1];

            $Row_Count = $this->common_model->getTableData('products',array('product_type'=>$value,'product_mode'=>$Product_mode,'product_code'=>$Product_Code,'product_name'=>$Product_name))->num_rows();
            if($Row_Count==0){

                $Product_data = array(
                    'product_type'  => $value,
                    'product_mode'         =>trim($Product_mode),
                    'product_code'    =>trim($Product_Code),
                    'product_name'       =>trim($Product_name)
                    );
                    $Product_data_clean = $this->security->xss_clean($Product_data);
                    $Insert=$this->common_model->insertTableData('products', $Product_data_clean);
                    if($Insert){
                        echo "Product Code - ".$Product_Code." - Inserted<br/>";
                    }


            }
            else{
                        echo "Product Code - ".$Product_Code." - Already Exists<br/>";
                    }
        }
    }


    }
    
}

function payment_status(){

    $user_id=$this->session->userdata('user_id');
    $trans_id = decryptIt($this->input->post('id'));
    //echo $trans_id;

    $Transactions= $this->common_model->getTableData('transactions', array('trans_id'=>$trans_id,'user_id'=>$user_id,'status'=>'Pending', 'payment_mode'=>'1'))->row();

    if(isset($Transactions) && !empty($Transactions)){

        $PayPeaks = array();
        $PayPeaks['merchantid'] = $Transactions->merchant_id;
        $PayPeaks['refno'] = $Transactions->transaction_id;
        $PayPeaks['productcode'] = $Transactions->product_code;
        $user_id = $Transactions->user_id;
        $Currency_Id = $Transactions->currency_id;
        $Amount = $Transactions->amount;

        $Paypeaks_Response = paypeaks_status($PayPeaks);

        if(isset($Paypeaks_Response) && !empty($Paypeaks_Response)){
        if(isset($Paypeaks_Response->Responsecode) && $Paypeaks_Response->Responsecode=='01'){
            if($trans->type=='Deposit'){
                $userbalance = getBalance($user_id,$Currency_Id); 
                $finalbalance = ($Amount)+($userbalance);
                $updatebalance = updateBalance($user_id,$Currency_Id,$finalbalance,'');

                $reserve_amount = getcryptocurrencydetail($Currency_Id);
                $final_reserve_amount = (float)$Amount + (float)$reserve_amount->reserve_Amount;
                $new_reserve_amount = updatefiatreserveamount($final_reserve_amount, $Currency_Id);

                $updateData['status'] = 'Completed';
                $condition = array('trans_id' => $trans->trans_id);
                $update = $this->common_model->updateTableData('transactions', $condition, $updateData);

                

                if($update){

                $prefix = get_prefix();
                $user = getUserDetails($user_id);
                $usernames = $prefix.'username';
                $username = $user->$usernames;
                $email = getUserEmail($user_id);
                $sitename = getSiteSettings('site_name');
                $site_common      =   site_common();
                $email_template   = 'Fiat_Deposit';     
                    $special_vars = array(
                    '###SITENAME###' => $sitename,          
                    '###USERNAME###' => $username,
                    '###AMOUNT###'   => $Amount,
                    '###CURRENCY###' => 'GHS',
                    '###MSG###' => 'Funds has been deposited successfully',
                    '###STATUS###'   => ucfirst('Completed')
                    );
                $this->email_model->sendMail($email, '', '', $email_template, $special_vars);

                    $data['msg'] = 'Updated Successfully';
                    $data['status'] = 'Completed';
                }
            }
            else{
                $updateData['status'] = 'Completed';
                $condition = array('trans_id' => $trans->trans_id);
                $update = $this->common_model->updateTableData('transactions', $condition, $updateData);

                if($update){
                    $prefix = get_prefix();
                $user = getUserDetails($user_id);
                $usernames = $prefix.'username';
                $username = $user->$usernames;
                $email = getUserEmail($user_id);
                $sitename = getSiteSettings('site_name');
                $site_common      =   site_common();
                $email_template   = 'Withdraw_Complete';        
                    $special_vars = array(
                    '###SITENAME###' => $sitename,          
                    '###USERNAME###' => $username,
                    '###AMOUNT###'   => $Amount,
                    '###CURRENCY###' => 'GHS',
                    '###TX###' => $trans->transaction_id
                    );
                $this->email_model->sendMail($email, '', '', $email_template, $special_vars);

                $data['msg'] = 'Updated Successfully';
                $data['status'] = 'Completed';
                }
            }
        }
        else if($Paypeaks_Response->Responsecode=='9' || $Paypeaks_Response->Responsecode=='7' || $Paypeaks_Response->Responsecode=='8' || $Paypeaks_Response->Responsecode=='6'){
            $updateData['status'] = 'Cancelled';
                $condition = array('trans_id' => $trans->trans_id);
                $update = $this->common_model->updateTableData('transactions', $condition, $updateData);

                if($update){
                    if($trans->type=='Withdraw'){
                        $balance = getBalance($trans->user_id,$trans->currency_id,'fiat');

                        $finalbalance = $balance+$trans->amount;
                $updatebalance = updateBalance($trans->user_id,$trans->currency_id,$finalbalance,'fiat');
                    }
                }
                $data['msg'] = $Paypeaks_Response->ResponseDesc;
                $data['status'] = 'Cancelled';
        }
        else{
            $data['msg'] = $Paypeaks_Response->ResponseDesc;
            $data['status'] = 'Pending';
        }
    }
    }
    else{
        $data['msg'] = 'No Transaction found';
        $data['status'] = 'Pending';
    }
    echo json_encode($data);

    }

    function settings_profile()
    {        
        $this->load->library('session');
        $user_id=$this->session->userdata('user_id');
        if($user_id=="")
        {   
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url().'home');
        }       
        $data['users'] = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
        $data['countries'] = $this->common_model->getTableData('countries')->result();
        $data['site_common'] = site_common();
        $this->load->view('front/user/settings_profile', $data); 
    }

    function verify_email()
    {   
        $this->load->library('session');
        $user_id=$this->session->userdata('user_id');
        
        $activation_code = time().rand(); 
        $users = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
        $uname = $users->tenrealm_username;
        $email = getUserEmail($users->id);
        
        $email_template = 'Registration';
        $site_common      =   site_common();
        $special_vars = array(
        '###USERNAME###' => $uname,
        '###LINK###' => front_url().'verify_user/'.$users->activation_code
        );
        $this->email_model->sendMail($email, '', '', $email_template, $special_vars);   
        $this->session->set_flashdata('success',$this->lang->line('Thank you for Verify. Please check your e-mail and click on the verification link.'));
        front_redirect('profile', 'refresh');
    }

    function download_pdf($coin, $adr) {
        $coin_address = base64_decode($adr);
        $data['First_coin_image'] = "https://chart.googleapis.com/chart?cht=qr&chs=280x280&chl=$coin_address&choe=UTF-8&chld=L";
        $data['coin_image'] = base_url() . 'assets/front/coins/'.$coin.'.jpg';
        $data['address'] = $coin_address;
        $data['coin_name'] = $coin;
        $html = $this->load->view('front/user/download_qr_pdf',$data, true);
        // echo $html;die;
        $pdfFilename = time().".pdf";
        $this->load->library('m_pdf');
        $this->m_pdf->pdf->WriteHTML($html);
        $this->m_pdf->pdf->Output($pdfFilename, "D");
    }

    function validaddress() {
        
        $address = $this->input->post('address');
        $result=0;
        $adrDet = $this->common_model->getRecord($address)->row();
        if(!empty($adrDet)){            
            $unserialize = unserialize($adrDet->address);
            if(in_array($address, $unserialize)) {
                $result = $address;
            } 
        }
            echo $result;
    }

    function crypto_address()
    {        
        $this->load->library('session');
        $user_id=$this->session->userdata('user_id');
        if($user_id=="") {  
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url().'home');
        }       
        $data['crypto_address'] = $this->common_model->getTableData('address_book',array('user_id'=>$user_id))->result();
        $data['currency']=$this->common_model->getTableData('currency',array('type'=>'digital'),'currency_symbol')->result();
        // echo "<pre>";print_r($data['currency']);die;
        $data['site_common'] = site_common();
        $this->load->view('front/user/crypto_address', $data); 
    }
    function ajax_email()
    {        
        $this->load->library('session');
            
        $user_id=$this->session->userdata('user_id');
        $email = getalluserEmail($user_id);
    
        
        
    }

    function transaction_history($currency_id)
    {   
        $currency = decryptIt($currency_id);
        $this->load->library('session');
        $user_id=$this->session->userdata('user_id');
        if($user_id=="") {  
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url().'home');
        }       
        $data['history']=$this->common_model->getTableData('transactions',array('user_id'=>$user_id,'currency_id'=>$currency),'','','','','','',array('trans_id','DESC'),'','',array('type'=>'Deposit,Withdraw'))->result();
        $data['site_common'] = site_common();
        $this->load->view('front/user/transaction_history', $data); 
    }

    function trade_ajax($currency)
    {
        $user_id = $this->session->userdata('user_id');
        $sym = decryptIt($currency);
        $get=$this->common_model->getTableData('currency',array('id'=>$sym),array('currency_symbol'))->row();
        $cur = $get->currency_symbol;
        
        $draw = $this->input->get('draw');
        $start = intval($this->input->get("start"));
        $length = intval($this->input->get("length"));
        $order = $this->input->get("order");
        $search= $this->input->get("search");
        $search = $search['value'];
        $col = 0;
        $dir = "";
        if(!empty($order))
        {
            foreach($order as $o)
            {
                $col = $o['column'];
                $dir= $o['dir'];
            }
        }

        if($dir != "asc" && $dir != "desc")
        {
            $dir = "desc";
        }
        $valid_columns = array(
            0=>'id',
            1=>'datetime',
            3=>'currency_name', 
            4=>'amount',
            5=>'Price',
            6=>'Fee',
            7=>'Total',
            8=>'Type',
            9=>'status'
        );
        if(!isset($valid_columns[$col]))
        {
            $order = null;
        }
        else
        {
            $order = $valid_columns[$col];
        }
        if($order !=null)
        {
            $this->db->order_by($order, $dir);
        }

        if(!empty($search))
        { 
            $like = " AND (d.currency_symbol LIKE '%".$search."%' OR e.currency_symbol LIKE '%".$search."%' OR a.amount LIKE '%".$search."%' OR a.Price LIKE '%".$search."%' OR a.Fee LIKE '%".$search."%' OR a.Total LIKE '%".$search."%' OR a.status LIKE '%".$search."%')";

            $query = "SELECT a.*, b.from_symbol_id as from_currency_id, b.to_symbol_id as to_currency_id, c.tenrealm_username as username, d.currency_symbol as from_currency_symbol, e.currency_symbol as to_currency_symbol FROM tenrealm_coin_order as a JOIN tenrealm_trade_pairs as b ON a.pair = b.id JOIN tenrealm_users as c ON a.userId = c.id JOIN tenrealm_currency as d ON b.from_symbol_id = d.id JOIN tenrealm_currency as e ON b.to_symbol_id = e.id WHERE a.userId = ".$user_id." AND a.pair_symbol LIKE '%".$cur."%' ".$like." ORDER BY a.tradetime DESC LIMIT ".$start.",".$length;

            $countquery = $this->db->query("SELECT a.*, b.from_symbol_id as from_currency_id, b.to_symbol_id as to_currency_id, c.tenrealm_username as username, d.currency_symbol as from_currency_symbol, e.currency_symbol as to_currency_symbol FROM tenrealm_coin_order as a JOIN tenrealm_trade_pairs as b ON a.pair = b.id JOIN tenrealm_users as c ON a.userId = c.id JOIN tenrealm_currency as d ON b.from_symbol_id = d.id JOIN tenrealm_currency as e ON b.to_symbol_id = e.id WHERE a.userId = ".$user_id." AND a.pair_symbol LIKE '%".$cur."%' ".$like." ORDER BY a.tradetime DESC");

            $users_history = $this->db->query($query);
            $users_history_result = $users_history->result(); 
            $num_rows = $countquery->num_rows();

        } else {
            $query = "SELECT a.*, b.from_symbol_id as from_currency_id, b.to_symbol_id as to_currency_id, c.tenrealm_username as username, d.currency_symbol as from_currency_symbol, e.currency_symbol as to_currency_symbol FROM tenrealm_coin_order as a JOIN tenrealm_trade_pairs as b ON a.pair = b.id JOIN tenrealm_users as c ON a.userId = c.id JOIN tenrealm_currency as d ON b.from_symbol_id = d.id JOIN tenrealm_currency as e ON b.to_symbol_id = e.id WHERE a.userId = ".$user_id." AND a.pair_symbol LIKE '%".$cur."%' ORDER BY a.tradetime DESC LIMIT ".$start.",".$length;

            $countquery = $this->db->query("SELECT a.*, b.from_symbol_id as from_currency_id, b.to_symbol_id as to_currency_id, c.tenrealm_username as username, d.currency_symbol as from_currency_symbol, e.currency_symbol as to_currency_symbol FROM tenrealm_coin_order as a JOIN tenrealm_trade_pairs as b ON a.pair = b.id JOIN tenrealm_users as c ON a.userId = c.id JOIN tenrealm_currency as d ON b.from_symbol_id = d.id JOIN tenrealm_currency as e ON b.to_symbol_id = e.id WHERE a.userId = ".$user_id." AND a.pair_symbol LIKE '%".$cur."%' ORDER BY a.tradetime DESC");
            $users_history = $this->db->query($query);
            $users_history_result = $users_history->result(); 
            $num_rows = $countquery->num_rows(); 
        }
        $tt = $query;
        if($num_rows>0)
        {
            $basic_pairid =array(4,7,8,9,10);
            foreach($users_history->result() as $result){
                if($result->exchange_type==0){
                    $extype="Advance";
                } else{
                    $extype ="Basic";
                }
                $i++;
                if((in_array($result->pair, $basic_pairid))&&($result->ordertype=='instant')) {
                    $sym = $result->to_currency_symbol;
                    $sym1 = $result->from_currency_symbol;

                }else{
                    $sym = $result->from_currency_symbol;
                    $sym1 = $result->to_currency_symbol;

                }               
                    $data[] = array(
                        $i, 
                        gmdate("d-m-Y h:i a", strtotime($result->datetime)),
                        $result->from_currency_symbol.'-'.$result->to_currency_symbol,
                        $result->Amount." ".$sym,
                        $result->Price." ".$result->to_currency_symbol,
                        $result->Fee." ".$result->to_currency_symbol,
                        $result->Total." ".$sym1,
                        $result->Type,
                        $extype,
                        ucfirst($result->status)
                    );
                }
        }
        else
        {
            $data = array();
        }
        $output = array(
            "draw" => $draw,
            "recordsTotal" => $num_rows,
            "recordsFiltered" => $num_rows,
            "data" => $data,
            "query"=> $tt
        );
        echo json_encode($output);
    }

    function transaction_history_pdf($currency_id)
    {        
        $this->load->library('session');
        $user_id=$this->session->userdata('user_id');
        if($user_id=="") {  
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url().'home');
        }       
        $data['history']=$this->common_model->getTableData('transactions',array('user_id'=>$user_id,'currency_id'=>$currency_id),'','','','','','',array('trans_id','DESC'),'','',array('type'=>'Deposit,Withdraw'))->result();
        $html = $this->load->view('front/user/transaction_history_pdf', $data, true); 
        // echo $html;die;
        $pdfFilename = "Transaction_History-".time().".pdf";
        $this->load->library('m_pdf');
        $this->m_pdf->pdf->WriteHTML($html);
        $this->m_pdf->pdf->Output($pdfFilename, "D");
    }
    
    function address_book()
    {        
        $this->load->library('session');
        $user_id=$this->session->userdata('user_id');
        if($user_id=="") {  
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url().'home');
        }       
        if ($this->input->post()) {
            $coin = $this->input->post('coin');
            $adr = $this->input->post('address');
            $filename = $this->input->post('filename');

            $bookArr = array('filename'=>$filename,'user_id'=>$user_id,'coin'=>$coin,'address'=>$adr);

            $get=$this->common_model->getTableData('address_book',array('user_id'=>$user_id,'coin'=>$coin,'address'=>$adr))->row(); 
            if(empty($get)) {
                $this->common_model->insertTableData('address_book', $bookArr);
            } else {
                $fname = array('filename'=>$filename);
                $this->common_model->updateTableData('address_book',array('id'=>$get->id),$fname);
            }
            $this->session->unset_userdata('coin');
            $this->session->unset_userdata('address');
            // echo "string";print_r($_POST);die;
        }
        front_redirect('wallet', 'refresh');
    }
    
    function add_address_book()
    {        
        $this->load->library('session');
        $user_id=$this->session->userdata('user_id');
        if($user_id=="") {  
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url().'home');
        }       
        if ($this->input->post()) {
            $coin = $this->input->post('coin');
            $adr = $this->input->post('address');
            $filename = $this->input->post('filename');
            $coin_id = $this->input->post('coin_id');
            $wallet_type = $this->input->post('wallet_type');
            $email_address = $this->input->post('email_address');

            if($this->input->post('destination_tag')) $des_tag = $this->input->post('destination_tag');
              else $des_tag = '';

            $bookArr = array('filename'=>$filename,'user_id'=>$user_id,'coin'=>$coin,'destination_tag'=>$des_tag,'address'=>$adr,'wallet_type'=>$wallet_type,'email_address'=>$email_address);
            // $get=$this->common_model->getTableData('address_book',array('user_id'=>$user_id,'coin'=>$coin,'address'=>$adr))->row();  
        
            if(empty($coin_id)) {
                $this->common_model->insertTableData('address_book', $bookArr);
                $this->session->set_flashdata('success', $this->lang->line('Added successfully')); 
            } else {
                $fname = array('filename'=>$filename);
                $this->common_model->updateTableData('address_book',array('id'=>$coin_id),$fname);
                $this->session->set_flashdata('success', $this->lang->line('Changed successfully')); 
            }
        }
        front_redirect('crypto_address', 'refresh');
    }

    function address_destroy() 
    {
        $this->session->unset_userdata('coin');
        $this->session->unset_userdata('address');
    }

    function delete_address($id) 
    {
        $data = array('id'=>$id);
        $this->common_model->deleteTableData('address_book', $data);
        $this->session->set_flashdata('success', $this->lang->line('Deleted successfully'));
        front_redirect('crypto_address', 'refresh'); 
    }


    function basic_trade()
    {
        $this->load->library('session');
        $user_id=$this->session->userdata('user_id');
        if($user_id=="")
        {   
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url().'home');
        }
        $data['mycontroller'] = $this->outputData;
        $data['site_common'] = site_common();
        //$data['dig_currency'] = $this->common_model->getTableData('currency', array('status' => 1,'type'=>'digital'), '', '', '', '', '', '', array('id', 'ASC'))->result();
        $data['dig_currency'] = $this->common_model->getTableData('currency', array('status' => 1), '', '', '', '', '', '', array('id', 'ASC'))->result();
        
        $currency_info=[];
        foreach ($data['dig_currency'] as $key => $cur) {
            
            $getInfo = $this->callAPI($cur->currency_symbol);
            $currency_info[$cur->currency_name] = $getInfo;
        }
        $data['currency_info'] = $currency_info;
        // echo "<pre>";  print_r($currency_info);die;

        $data['users'] = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
        $data['meta_content'] = $this->common_model->getTableData('meta_content',array('link'=>'wallet'))->row();
        $this->load->view('front/user/cb_trade', $data);
    }

    function callAPI($currency) 
    {
        $url = 'https://api.pro.coinbase.com/products/'.$currency.'-EUR/stats';
        $agent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)";
        $curlSession = curl_init();
        curl_setopt($curlSession, CURLOPT_URL, $url);
        curl_setopt($curlSession, CURLOPT_BINARYTRANSFER, true);
        curl_setopt($curlSession, CURLOPT_USERAGENT, $agent);
        curl_setopt($curlSession, CURLOPT_RETURNTRANSFER, true);
        $jsonData = json_decode(curl_exec($curlSession));
        curl_close($curlSession);
        return $jsonData;
        // echo "<pre>";print_r($jsonData);die;
    }
    function whitepaper($currency) 
    {
        $user_id=$this->session->userdata('user_id');
        if($user_id=="") {
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url().'home');
        }
        $filepath = FCPATH.'uploads/whitepaper/'.$currency.'_white_paper.pdf';
        if (!file_exists($filepath)) {
            throw new Exception("File $filepath does not exist");
        }
        if (!is_readable($filepath)) {
            throw new Exception("File $filepath is not readable");
        }
        http_response_code(200);
        header('Content-Length: '.filesize($filepath));
        header("Content-Type: application/pdf");
        // header('Content-Disposition: attachment; filename="downloaded.pdf"'); 
        readfile($filepath);
        die;
    }
    function basic_portfolio() 
    {
        $user_id=$this->session->userdata('user_id');
        if($user_id=="")
        {   
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url().'home');
        }
        $data['site_common'] = site_common();
        $this->load->view('front/user/basic_portfolio', $data);
    }
    function basic_notification() 
    {
        $user_id=$this->session->userdata('user_id');
        if($user_id=="")
        {   
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url().'home');
        }
        $data['site_common'] = site_common();
        $this->load->view('front/user/basic_notification', $data);
    }
    function basic_home() 
    {
        $user_id=$this->session->userdata('user_id');
        if($user_id=="")
        {   
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url().'home');
        }
        $data['mycontroller'] = $this->outputData;
        $data['site_common'] = site_common();
        $currency_sym = array('BTC','ETH','BCH','USDT','LIR');
        $where_in = array('currency_symbol', $currency_sym);
        $currencyDet = $this->common_model->getTableData('currency','',array('id','currency_symbol','currency_name','image','type','online_usdprice','online_europrice'),'','','','','','','','',$where_in)->result();
        foreach ($currencyDet as $key => $cur) {
            $getInfo = $this->callAPI($cur->currency_symbol);
            $currencyDet[$key]->euro_price = $getInfo->last;
            $change = (($getInfo->last-$getInfo->open)/$getInfo->last)*100;
            $currencyDet[$key]->change_price = $change;
        }
        $data['currencyDet'] = $currencyDet;
        $data['history']=$this->common_model->getTableData('transactions',array('user_id'=>$user_id),'','','','','',5,array('trans_id','DESC'),'','',array('type'=>'Deposit,Withdraw'))->result();
        // echo "<pre>";print_r($data['history']);die;
        $this->load->view('front/user/basic_home', $data);
    }
    function get_chartData() 
    {
        $currency_sym = array('BTC','ETH','BCH','USDT');
        $where_in = array('currency_symbol', $currency_sym);
        $currencyDet = $this->common_model->getTableData('currency','','','','','','','','','','',$where_in)->result();

        $endDate = new \DateTime();
        $startDate = new \DateTime('-30 days');
        $charts=[];
        foreach ($currencyDet as $ckey => $cur) { 
            $symbol = $cur->currency_symbol;
            
            $end = $endDate->format('Y-m-d');
            $start = $startDate->format('Y-m-d');

            $url = 'https://api.pro.coinbase.com/products/'.$symbol.'-EUR/candles?start='.$start.'&end='.$end.'&granularity=86400';
            $agent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)";
            $curlSession = curl_init();
            curl_setopt($curlSession, CURLOPT_URL, $url);
            curl_setopt($curlSession, CURLOPT_BINARYTRANSFER, true);
            curl_setopt($curlSession, CURLOPT_USERAGENT, $agent);
            curl_setopt($curlSession, CURLOPT_RETURNTRANSFER, true);
            $jsonData = json_decode(curl_exec($curlSession));
            curl_close($curlSession);

            $chartDet=[];
            foreach ($jsonData as $key => $val) { 
                $time = date('Y-m-d', $val[0]);
                $price = $val[4];
                $chartDet[] = array($time, $price);
            }
            $Json_chartDet = json_encode($chartDet,true);
            $charts[$cur->currency_name] = $Json_chartDet;
            
        }
        $data['charts'] = json_encode($charts);
        echo $data['charts'];
        // echo "<pre>"; print_r($charts);
        
    }
    function basic_chart($sym) 
    {
        $user_id=$this->session->userdata('user_id');
        if($user_id=="")
        {   
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url().'home');
        }
        $data['mycontroller'] = $this->outputData;
        $exp = explode('-', $sym);
        $endDate = new \DateTime();
        $startDate = new \DateTime('-30 days');
        $end = $endDate->format('Y-m-d');
        $start = $startDate->format('Y-m-d');

        $data['symbol'] = $sym;
        $url = 'https://api.pro.coinbase.com/products/'.$sym.'/candles?start='.$start.'&end='.$end.'&granularity=86400';
        $agent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)";
        $curlSession = curl_init();
        curl_setopt($curlSession, CURLOPT_URL, $url);
        curl_setopt($curlSession, CURLOPT_BINARYTRANSFER, true);
        curl_setopt($curlSession, CURLOPT_USERAGENT, $agent);
        curl_setopt($curlSession, CURLOPT_RETURNTRANSFER, true);
        $jsonData = json_decode(curl_exec($curlSession));
        curl_close($curlSession);

        $data['coinInfo'] = $this->callAPI($exp[0]);
        $time=[]; $prices=[];
        foreach ($jsonData as $key => $val) { 
            $time[] = date('Y-m-d', $val[0]);
            $prices[] = $val[4];
        }
        $data['datetime'] = json_encode(array_reverse($time));
        $data['prices'] = json_encode(array_reverse($prices));
        $data['currencyInfo'] = $this->common_model->getTableData('currency',array('currency_symbol'=>$exp[0]))->row();
        // echo "<pre>";print_r( $data['dig_currency'] );die;
        $data['site_common'] = site_common();
        $this->load->view('front/user/basic_chart', $data);
    }
    function basic_wallet($sym) 
    {

        $user_id=$this->session->userdata('user_id');
        if($user_id=="") {  
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url().'home');
        }
        $data['symbol'] = $sym;
        $exp = explode('-', $sym);
        $data['user'] = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
        if(isset($_POST['withdrawcoin'])) {
            // echo "<pre>";print_r( $_POST );die;
            $this->form_validation->set_rules('ids', 'ids', 'trim|required|xss_clean|numeric');
            $this->form_validation->set_rules('amount', 'Amount', 'trim|required|xss_clean');
            $id = escape_str($this->input->post('ids'));
            $sharecoin_fee = escape_str($this->input->post('sharecoin_fee'));
            $other_fee = escape_str($this->input->post('other_fee'));
            $receive_amt = escape_str($this->input->post('receive_amt'));

            $this->form_validation->set_rules('address', 'Address', 'trim|required|xss_clean');

            $kyc_status = $data['user']->verify_level2_status; 
            if($kyc_status=='' || $kyc_status=='Pending') {
                $this->session->set_flashdata('error', "Please verify your kyc");
                front_redirect('basic-wallet/'.$exp[0], 'refresh');
            }
            
            $amount = escape_str($this->input->post('amount'));
            $address = escape_str($this->input->post('address'));
            $Payment_Method = 'crypto';
            $Currency_Type = 'crypto';
            $Bank_id = '';

            if($id==6){
                $Destination_Tag = $this->db->escape_str($this->input->post('destination_tag'));
            }
            else{
                $Destination_Tag = '';
            }
            $balance = getBalance($user_id,$id,'crypto');
            $currency = getcryptocurrencydetail($id);
            $w_isValids   = $this->common_model->getTableData('transactions', array('user_id' => $user_id, 'type' =>'Withdraw', 'status'=>'Pending','user_status'=>'Pending','currency_id'=>$id));
            $count        = $w_isValids->num_rows();
            $withdraw_rec = $w_isValids->row();
            $final = 1;
            $Validate_Address = 1;

            if($Validate_Address==1)
            {   
                if($count>0)
                {                           
                    $this->session->set_flashdata('error', $this->lang->line('Sorry!!! Your previous ') . $currency->currency_symbol . $this->lang->line('Transaction is Pending'));
                    front_redirect('basic-wallet/'.$exp[0], 'refresh'); 
                }
                else
                {  
                    if($amount>$balance)
                    { 
                        $this->session->set_flashdata('error', $this->lang->line('Amount you have entered is more than your current balance'));
                        front_redirect('basic-wallet/'.$exp[0], 'refresh');
                    }
                    if($amount < $currency->min_withdraw_limit)
                    {  
                        $this->session->set_flashdata('error',$this->lang->line('Amount you have entered is less than minimum withdrawl limit'));
                        front_redirect('basic-wallet/'.$exp[0], 'refresh');
                    }
                    elseif($amount>$currency->max_withdraw_limit)
                    {  
                        $this->session->set_flashdata('error', $this->lang->line('Amount you have entered is more than maximum withdrawl limit'));
                        front_redirect('basic-wallet/'.$exp[0], 'refresh'); 
                    }
                    elseif($final!=1)
                    { 
                        $this->session->set_flashdata('error',$this->lang->line('Invalid address'));
                        front_redirect('basic-wallet/'.$exp[0], 'refresh');
                    }
                    else
                    { 
                        $withdraw_fees_type = $currency->withdraw_fees_type;
                        $withdraw_fees = $currency->withdraw_fees;

                        $sharecoin_fees_type = $currency->sharecoin_fees_type;
                        $sharecoin_fees = $currency->sharecoin_fees;

                        $valid_address = escape_str($this->input->post('valid_address'));
                        if($valid_address=='0') {

                            $fees_s = $sharecoin_fee;
                            $fees = $other_fee;
                            $total = $receive_amt;
                            $wallet_type = 0;
                        } else {
                            $fees = 0;
                            $total = $amount;
                            $wallet_type = 1;
                        }

                        $user_status = 'Pending';
                        $insertData = array(
                            'user_id'=>$user_id,
                            'payment_method'=>$Payment_Method,
                            'currency_id'=>$id,
                            'amount'=>$amount,
                            'fee'=>$fees,
                            'sharecoin_fee'=>sprintf('%f', $fees_s),
                            'bank_id'=>$Bank_id,
                            'crypto_address'=>$address,
                            'destination_tag'=>$Destination_Tag,
                            'transfer_amount'=>$total,
                            'datetime'=>time(),
                            'type'=>'Withdraw',
                            'status'=>'Pending',
                            'currency_type'=>$Currency_Type,
                            'user_status'=>$user_status,
                            'wallet_type'=>$wallet_type
                            );
                        $finalbalance = $balance - $amount;

                         //echo "<pre>";print_r($insertData);die;
                        $updatebalance = updateBalance($user_id,$id,$finalbalance,'crypto');
                        $insertData_clean = $this->security->xss_clean($insertData);
                        $insert = $this->common_model->insertTableData('transactions', $insertData_clean);
                        if($insert) 
                        {
                            $prefix = get_prefix();
                            $user = getUserDetails($user_id);
                            $usernames = $prefix.'username';
                            $username = $user->$usernames;
                            $email = getUserEmail($user_id);
                            $currency_name = getcryptocurrency($id);
                            $link_ids = encryptIt($insert);
                            $sitename = getSiteSettings('english_site_name');
                            $site_common = site_common();                           

                                $email_template = 'Withdraw_User_Complete';
                                $special_vars = array(
                                '###SITENAME###' => $sitename,
                                '###USERNAME###' => $username,
                                '###AMOUNT###'   => (float)$amount,
                                '###CURRENCY###' => $currency_name,
                                '###FEES###' => $fees,
                                '###CRYPTOADDRESS###' => $address,
                                '###CONFIRM_LINK###' => base_url().'withdraw_coin_user_confirm/'.$link_ids,
                                '###CANCEL_LINK###' => base_url().'withdraw_coin_user_cancel/'.$link_ids
                                );
                            
                            
                            $this->email_model->sendMail($email, '', '', $email_template, $special_vars);
                            $this->session->set_flashdata('success',$this->lang->line('Your withdraw request placed successfully. Please make confirm from the mail you received in your registered mail!'));
                            front_redirect('basic-wallet/'.$exp[0], 'refresh');
                        } 
                        else 
                        {
                            $this->session->set_flashdata('error',$this->lang->line('Unable to submit your withdraw request. Please try again'));
                            front_redirect('basic-wallet/'.$exp[0], 'refresh');
                        }
                    }
                }
            }
            else
            {
                $this->session->set_flashdata('error', $this->lang->line('Please check the address'));
                front_redirect('basic-wallet/'.$exp[0], 'refresh');
            }       
        }

        $data['mycontroller'] = $this->outputData;
        $data['site_common'] = site_common();
        $data['dig_currency'] = $this->common_model->getTableData('currency',array('currency_symbol'=>$exp[0]))->row();
        $data['coin_address'] = getAddress($user_id, $data['dig_currency']->id);
        $data['First_coin_image'] = "https://chart.googleapis.com/chart?cht=qr&chs=280x280&chl=".$data['coin_address']."&choe=UTF-8&chld=L";
        $this->load->view('front/user/basic_wallet', $data);
    }

    function basic_pay() 
    {
        $this->load->library(array('form_validation','session'));
        $user_id=$this->session->userdata('user_id');
        if($user_id=="") {  
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url().'home');
        }
        $data['user'] = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
        if(isset($_POST['withdrawcoin'])) {
            // echo "<pre>";print_r( $_POST );die;
            $this->form_validation->set_rules('ids', 'ids', 'trim|required|xss_clean|numeric');
            $this->form_validation->set_rules('amount', 'Amount', 'trim|required|xss_clean');
            $id = escape_str($this->input->post('ids'));
            $sharecoin_fee = escape_str($this->input->post('sharecoin_fee'));
            $other_fee = escape_str($this->input->post('other_fee'));
            $receive_amt = escape_str($this->input->post('receive_amt'));

            $this->form_validation->set_rules('address', 'Address', 'trim|required|xss_clean');

            $kyc_status = $data['user']->verify_level2_status; 
            if($kyc_status=='' || $kyc_status=='Pending') {
                $this->session->set_flashdata('error', "Please verify your kyc");
                front_redirect('basic-pay', 'refresh');
            }
            
            $amount = escape_str($this->input->post('amount'));
            $address = escape_str($this->input->post('address'));
            $Payment_Method = 'crypto';
            $Currency_Type = 'crypto';
            $Bank_id = '';

            if($id==6){
                $Destination_Tag = $this->db->escape_str($this->input->post('destination_tag',true));
            }
            else{
                $Destination_Tag = '';
            }
            
            $balance = getBalance($user_id,$id,'crypto');
            $currency = getcryptocurrencydetail($id);
            $w_isValids   = $this->common_model->getTableData('transactions', array('user_id' => $user_id, 'type' =>'Withdraw', 'status'=>'Pending','user_status'=>'Pending','currency_id'=>$id));
            $count        = $w_isValids->num_rows();
            $withdraw_rec = $w_isValids->row();
            $final = 1;
            $Validate_Address = 1;

            if($Validate_Address==1)
            {   
                if($count>0)
                {                           
                    $this->session->set_flashdata('error', $this->lang->line('Sorry!!! Your previous ') . $currency->currency_symbol . $this->lang->line('Transaction is Pending'));
                    front_redirect('basic-pay', 'refresh'); 
                }
                else
                {  
                    if($amount>$balance)
                    { 
                        $this->session->set_flashdata('error', $this->lang->line('Amount you have entered is more than your current balance'));
                        front_redirect('basic-pay', 'refresh');
                    }
                    if($amount < $currency->min_withdraw_limit)
                    {  
                        $this->session->set_flashdata('error',$this->lang->line('Amount you have entered is less than minimum withdrawl limit'));
                        front_redirect('basic-pay', 'refresh');
                    }
                    elseif($amount>$currency->max_withdraw_limit)
                    {  
                        $this->session->set_flashdata('error', $this->lang->line('Amount you have entered is more than maximum withdrawl limit'));
                        front_redirect('basic-pay', 'refresh'); 
                    }
                    elseif($final!=1)
                    { 
                        $this->session->set_flashdata('error',$this->lang->line('Invalid address'));
                        front_redirect('basic-pay', 'refresh');
                    }
                    else
                    { 
                        $withdraw_fees_type = $currency->withdraw_fees_type;
                        $withdraw_fees = $currency->withdraw_fees;

                        $sharecoin_fees_type = $currency->sharecoin_fees_type;
                        $sharecoin_fees = $currency->sharecoin_fees;

                        $valid_address = escape_str($this->input->post('valid_address'));
                        if($valid_address=='0') {

                            $fees_s = $sharecoin_fee;
                            $fees = $other_fee;
                            $total = $receive_amt;
                            $wallet_type = 0;
                        } else {
                            $fees = 0;
                            $total = $amount;
                            $wallet_type = 1;
                        }

                        $user_status = 'Pending';
                        $insertData = array(
                            'user_id'=>$user_id,
                            'payment_method'=>$Payment_Method,
                            'currency_id'=>$id,
                            'amount'=>$amount,
                            'fee'=>$fees,
                            'sharecoin_fee'=>sprintf('%f', $fees_s),
                            'bank_id'=>$Bank_id,
                            'crypto_address'=>$address,
                            'destination_tag'=>$Destination_Tag,
                            'transfer_amount'=>$total,
                            'datetime'=>gmdate(time()),
                            'type'=>'Withdraw',
                            'status'=>'Pending',
                            'currency_type'=>$Currency_Type,
                            'user_status'=>$user_status,
                            'wallet_type'=>$wallet_type
                            );
                        $finalbalance = $balance - $amount;

                         //echo "<pre>";print_r($insertData);die;

                        $updatebalance = updateBalance($user_id,$id,$finalbalance,'crypto');
                        $insertData_clean = $this->security->xss_clean($insertData);
                        $insert = $this->common_model->insertTableData('transactions', $insertData_clean);
                        if($insert) 
                        {
                            $prefix = get_prefix();
                            $user = getUserDetails($user_id);
                            $usernames = $prefix.'username';
                            $username = $user->$usernames;
                            $email = getUserEmail($user_id);
                            $currency_name = getcryptocurrency($id);
                            $link_ids = encryptIt($insert);
                            $sitename = getSiteSettings('english_site_name');
                            $site_common = site_common();                           

                                $email_template = 'Withdraw_User_Complete';
                                $special_vars = array(
                                '###SITENAME###' => $sitename,
                                '###USERNAME###' => $username,
                                '###AMOUNT###'   => (float)$amount,
                                '###CURRENCY###' => $currency_name,
                                '###FEES###' => $fees,
                                '###CRYPTOADDRESS###' => $address,
                                '###CONFIRM_LINK###' => base_url().'withdraw_coin_user_confirm/'.$link_ids,
                                '###CANCEL_LINK###' => base_url().'withdraw_coin_user_cancel/'.$link_ids
                                );
                            
                            
                            $this->email_model->sendMail($email, '', '', $email_template, $special_vars);
                            $this->session->set_flashdata('success',$this->lang->line('Your withdraw request placed successfully. Please make confirm from the mail you received in your registered mail!'));
                            front_redirect('basic-pay', 'refresh');
                        } 
                        else 
                        {
                            $this->session->set_flashdata('error',$this->lang->line('Unable to submit your withdraw request. Please try again'));
                            front_redirect('basic-pay', 'refresh');
                        }
                    }
                }
            }
            else
            {
                $this->session->set_flashdata('error', $this->lang->line('Please check the address'));
                front_redirect('basic-pay', 'refresh');
            }       
        }
        $data['mycontroller'] = $this->outputData;
        $data['site_common'] = site_common();
        $data['dig_currency'] = $this->common_model->getTableData('currency', array('status' => 1,'type'=>'digital'), '', '', '', '', '', '', array('id', 'ASC'))->result();
        $data['coin_address'] = getAddress($user_id, $data['dig_currency'][0]->id);
        $data['First_coin_image'] = "https://chart.googleapis.com/chart?cht=qr&chs=280x280&chl=".$data['coin_address']."&choe=UTF-8&chld=L";
        // echo "<pre>";print_r( $data['First_coin_image'] );die;
        $this->load->view('front/user/basic_pay', $data);
    }

    // function basicbuytransaction($sym) 
    // {    
    //  $user_id=$this->session->userdata('user_id');
    //  if($user_id=="")
    //  {   
    //      $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
    //      redirect(base_url().'home');
    //  }
    //  $fiat = $this->input->post('FiatCurrencyInput');
    //  $crypto_amount = $this->input->post('amount');
    //  $currency_id = $this->input->post('currency_id');
    //  $payment_type = $this->input->post('payment_type');
    //  $bfees_p = $this->input->post('bfees_p');
    //  $bamount_receive = $this->input->post('bamount_receive');

    //  $getCryptoBalance = getBalance($user_id,$currency_id);
    //  $getEuroBalance = getBalance($user_id,5);

    //  $finalFiatbalance = $getEuroBalance - $fiat; 
    //  $finalCryptobalance = $getCryptoBalance + $crypto_amount; 
    //  $updateFiatBalance = updateBalance($user_id, 5 ,$finalFiatbalance); 
    //  $updateCryptoBalance = updateBalance($user_id, $currency_id ,$finalCryptobalance); 

    //  // echo $getEuroBalance.'---'.$fiat.'---'.$finalFiatbalance;
    //  // echo $getCryptoBalance.'---'.$crypto_amount.'---'.$finalCryptobalance;
    //  $insertData = array(
    //      'user_id'           => $user_id,
    //      'spend_coin_id'     => 5,
    //      'spend_amount'      => $fiat,
    //      'receive_coin_id'   => $currency_id,
    //      'receive_amount'    => $crypto_amount,
    //      'transaction_id'    => rand(100000000,10000000000),
    //      'fee'               => $bfees_p,
    //      'transfer_amount'   => $bamount_receive,
    //      'process_type'      => 'buy',
    //      'payment_type'      => $payment_type,
    //      'status'            => 0,
    //      'create_on'         =>date('Y-m-d h:i:s'),
    //  );
    //  $this->common_model->insertTableData('basic_transactions',$insertData); 
    //  front_redirect('basic-pay', 'refresh');   
    // }

    // function basicselltransaction($sym) 
    // {    
    //  $user_id=$this->session->userdata('user_id');
    //  if($user_id=="")
    //  {   
    //      $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
    //      redirect(base_url().'home');
    //  }
    //  $fiat = $this->input->post('FiatCurrencyInput');
    //  $crypto_amount = $this->input->post('amount');
    //  $currency_id = $this->input->post('currency_id');
    //  $payment_type = $this->input->post('payment_type');
    //  $bfees_p = $this->input->post('sfees_p');
    //  $bamount_receive = $this->input->post('samount_receive');

    //  $getCryptoBalance = getBalance($user_id,$currency_id);
    //  $getEuroBalance = getBalance($user_id,5);

    //  $finalFiatbalance = $getEuroBalance + $fiat; 
    //  $finalCryptobalance = $getCryptoBalance - $crypto_amount; 
    //  $updateFiatBalance = updateBalance($user_id, 5 ,$finalFiatbalance); 
    //  $updateCryptoBalance = updateBalance($user_id, $currency_id ,$finalCryptobalance); 
    //  $insertData = array(
    //      'user_id'           => $user_id,
    //      'spend_coin_id'     => 5,
    //      'spend_amount'      => $fiat,
    //      'receive_coin_id'   => $currency_id,
    //      'receive_amount'    => $crypto_amount,
    //      'transaction_id'    => rand(100000000,10000000000),
    //      'fee'               => $bfees_p,
    //      'transfer_amount'   => $bamount_receive,
    //      'process_type'      => 'sell',
    //      'payment_type'      => $payment_type,
    //      'status'            => 0,
    //      'create_on'         =>date('Y-m-d h:i:s'),
    //  );
    //  // echo "<pre>";print_r($insertData);die;
    //  $this->common_model->insertTableData('basic_transactions',$insertData); 
    //  front_redirect('basic-pay', 'refresh');
    // }

    function basic_exchange($pair_symbol='') 
    {
        $user_id=$this->session->userdata('user_id');
        if($user_id=="")
        {   
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url().'home');
        }

        $data['user_id'] = $user_id;
    $data['user'] = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
    $pair=explode('_',$pair_symbol);
    $pair_id=0;
    if(count($pair)==2)
    {
        $joins = array('currency as b'=>'a.from_symbol_id = b.id','currency as c'=>'a.to_symbol_id = c.id');
        $where = array('a.status'=>1,'b.status!='=>0,'c.status!='=>0,'b.currency_symbol'=>$pair[0],'c.currency_symbol'=>$pair[1]);
        $orderprice = $this->common_model->getJoinedTableData('trade_pairs as a',$joins,$where,'a.*');
        if($orderprice->num_rows()==1)
        {
            $pair_details=$orderprice->row();
            $pair_id=$pair_details->id;
        }
    }
    if($pair_id==0)
    {
        $joins = array('currency as b'=>'a.from_symbol_id = b.id','currency as c'=>'a.to_symbol_id = c.id');
        $where = array('a.status'=>1,'b.status!='=>0,'c.status!='=>0);
        $orderprice = $this->common_model->getJoinedTableData('trade_pairs as a',$joins,$where,'a.id,b.currency_symbol as fromcurrency,c.currency_symbol as tocurrency','','','','','',array('a.id','asc'))->row();
        $pair_url=$orderprice->fromcurrency.'_'.$orderprice->tocurrency;
        front_redirect('basic-exchange/'.$pair_url, 'refresh');
    }
    $data['tradeInfo'] = $this->common_model->getTableData('trade_pairs',array('id'=>$pair_details->id))->row();
    
    // echo $pair_id;die;
    $data['pair']=$pair;
    $data['pair_id']=$pair_id;
    $data['pair_symbol']=$pair[0].'/'.$pair[1];
    $from_currency = $this->common_model->getTableData('currency',array('id' => $pair_details->from_symbol_id))->row();
    $to_currency = $this->common_model->getTableData('currency',array('id' => $pair_details->to_symbol_id))->row();
    $data['from_currdet'] = $from_currency;
    $data['to_currdet'] = $to_currency;
    $data['apicheck'] = checkapi($pair_id);
    $data['pair_details'] = $pair_details;
    if ($user_id != 0) { 
      $data['from_cur'] = number_format(getBalance($user_id,$pair_details->from_symbol_id), 8);
      $data['to_cur'] = number_format(getBalance($user_id,$pair_details->to_symbol_id), 8);
    } else {
      $data['from_cur'] = 0;
      $data['to_cur'] = 0;
    }
    
    $this->trade_prices($pair_id,'trade');

    $data['pagetype'] = $this->uri->segment(1);
    $tradesym = $pair[0].'_'.$pair[1];
    
    $pair_currency = $this->common_model->customQuery("select id, from_symbol_id, to_symbol_id, lastPrice, priceChangePercent from tenrealm_trade_pairs where status='1' order by id DESC")->result();
    if(isset($pair_currency) && !empty($pair_currency))
    {
        $Pairs_List = array();
        foreach($pair_currency as $Pair_Currency)
        {
            $from_currency_det = getcryptocurrencydetail($Pair_Currency->from_symbol_id);
            $to_currency_det = getcryptocurrencydetail($Pair_Currency->to_symbol_id);
            $pairname = $from_currency_det->currency_symbol."/".$to_currency_det->currency_symbol;
            $pairurl = $from_currency_det->currency_symbol."_".$to_currency_det->currency_symbol;

            $Site_Pairs[$Pair_Currency->id] = array(
                "currency_pair" => $pairname,
                "price" =>  ($Pair_Currency->lastPrice!='')?$Pair_Currency->lastPrice:'0.000',
                "change"    => ($Pair_Currency->priceChangePercent!='')?$Pair_Currency->priceChangePercent:'0.000',
                "pairurl"   => $pairurl
            );
        }
        $data['Site_Pairs'] = array_reverse($Site_Pairs);
    }
    $data['meta_content'] = $this->common_model->getTableData('meta_content',array('link'=>'trade'))->row();
    $data['currencies'] = $this->common_model->customQuery("select * from tenrealm_currency where status='1' and currency_symbol in ('BTC','ETH','BCH','XRP','BNB','EURO')")->result();
    $data['allcurrencies'] = $this->common_model->customQuery("select * from tenrealm_currency where status='1' ")->result();

        $data['site_common'] = site_common();
        $this->load->view('front/user/basic_exchange', $data);
    }

    function trade_prices($pair,$pagetype='')
    {
        $this->marketprice = marketprice($pair);
        $this->lastmarketprice = lastmarketprice($pair);
        $this->minimum_trade_amount = get_min_trade_amt($pair);
        $this->maker=getfeedetails_buy($pair);
        $this->taker=getfeedetails_sell($pair);
        $user_id=$this->session->userdata('user_id');
        if($user_id)
        {
            $this->user_id = $user_id;
            $this->user_balance = getBalance($user_id);
        } else {
            $this->user_id = 0;
            $this->user_balance = 0;
        }
    }


    function mywithdraw(){

        $user_id=$this->session->userdata('user_id');
        if(!$user_id)
        {   
            front_redirect('/', 'refresh');
        }
        // echo '<pre>';print_r($this);exit;
        $this->load->view('front/user/mywithdraw');
    }

    function withdraw_validation()
    {           
        try {
            $status = '';
            $this->via_valid_sess_and_ajax_user();

            $this->form_validation->set_rules('amount', 'Amount', 'trim|required|xss_clean|numeric'); 
            $this->form_validation->set_rules('address', 'Address', 'trim|required|xss_clean');             
            if ($this->form_validation->run() == FALSE){
                $errors = validation_errors();
                echo json_encode(['error'=>$errors]);exit;
            }

            $currency_symbol = $this->outputData['default_currency_symbol'];

            $currency = $this->common_model->getTableData('currency',array('currency_symbol'=>$currency_symbol),'','','','','','',array('id','ASC'))->row();            
            $id = $currency->id;
            $user_id = $this->session->userdata('user_id');
            $amount = escape_str($this->input->post('amount',TRUE));
            $cur = $this->outputData['default_currency_symbol'];
            $currency_id = $this->com_m->get_row_val('currency',['currency_symbol' => $cur], "id");

            $ltc_balance = getBalance($user_id,$id,'crypto');           
            $balance = get_pym_Balance($user_id,$id,'crypto');
            if(!$balance){
                $status = 'No balance';
            }           
            if(!$ltc_balance){
                $status = 'No balance.';
            }
            $currency = getcryptocurrencydetail($currency_id);          
            if($amount > $balance)
            { 
                $status = 'Amount you have entered is more than your current balance';          
            }
            else if(!empty($currency->min_withdraw_limit) && $amount < $currency->min_withdraw_limit)
            { 
                $status = $this->lang->line('Amount you have entered is less than minimum withdrawl limit');            
            }
            else if(!empty($currency->max_withdraw_limit) && $amount>$currency->max_withdraw_limit)
            { 
                $status = $this->lang->line('Amount you have entered is more than maximum withdrawl limit');            
            }else{
                $w_isValids = $this->common_model->getTableData('transactions', array('user_id' => $user_id, 'type' =>'Withdraw', 'status'=>'Pending','user_status'=>'Pending','currency_id'=>$id));        
                if($w_isValids->num_rows()>0){

                    $status = $this->lang->line('Sorry!!! Your previous ') . $currency->currency_symbol .' '. $this->lang->line('Transaction is Pending');                  
                }   
            }          
            if($status){
                $status = '<div class="error">' .$status. '</div>';
            }else{
                $status = true;
            }
            echo json_encode([ 'error' => $status ]);exit;

        } catch (Exception $e) {
            echo get_try_catch_message($e);exit;
        }finally {
            echo get_try_catch_message($e);exit;
        }

    }



    function get_deposit_details(){

        try {
            $data = [];
            $data['status'] = false;
            $data['msg'] = "No data";

            $this->via_valid_sess_and_ajax_user();          
            $user_id = $this->session->userdata('user_id');

            $this->form_validation->set_rules('user_deposit_amount', 'Amount', 'trim|required|xss_clean|numeric'); 
            if ($this->form_validation->run() == FALSE){
                $data['msg'] = validation_errors();
                echo json_encode($data);exit;
            }          

            $user_deposit_amount = $this->input->post('user_deposit_amount', true);
            $currency_symbol = $this->outputData['default_currency_symbol'];
            if($currency_symbol)
            {
            $Fetch_coin_list = $this->com_m->getTableData('currency',array('type'=>'digital','status'=>'1', 'currency_symbol' => $currency_symbol),'id')->row();
            $target_time = strtotime(date("Y-m-d H:i:s"). DEPOSITE_TARGET_TIMER);           
            $current_time = time();
            if($this->session->userdata('deposit_timer_'.$user_id)){
              if($current_time >= $this->session->userdata('deposit_timer_'.$user_id)){             
                // session after set new timer and set new crypto address for deposit
                $target_time = strtotime(date("Y-m-d H:i:s"). DEPOSITE_TARGET_TIMER);           
                $this->db->trans_start();
                    // $this->update_user_ltc_address();
                $this->db->trans_complete();
                $coin_address = getAddress($user_id, $Fetch_coin_list->id);
              }else{
                $target_time = $this->session->userdata('deposit_timer_'.$user_id);
                $coin_address = getAddress($user_id, $Fetch_coin_list->id);
              }   
            }else{
              // Set New Timer(init)
              $coin_address = getAddress($user_id, $Fetch_coin_list->id);
            }

            $this->session->set_userdata('deposit_timer_'.$user_id, $target_time);
            $data['status']  = true;            
            $data['ca'] = ($coin_address) ? $coin_address: '';  
            // $data['ca'] = 'sam'; 
                        
            $data['user_current_timestamp'] = $current_time;            
            $data['user_target_timestamp'] = $target_time;  
            $admin_amount = calculated_deposit_percentage($user_deposit_amount, 'LTC');
            // $admin_amount = 0;
            $amount = $user_deposit_amount + $admin_amount;
            $data['c_p_conversion'] = sprintf('%0.8f', (sprintf('%0.8f', $this->coin_price_conversion()) * $amount));
            $data['user_deposit_amount'] = $amount;
            echo json_encode($data);exit;
            }
            echo json_encode($data);exit;
        } catch (Exception $e) {
            echo json_encode(array('error' => array('msg' => $e->getMessage(),'code' => $e->getCode())));exit;          
            // echo get_try_catch_message($e);exit;
        }
    }


    function is_completed_transaction(){
        try {
            $data = [];
            $data['status'] = 0;
            $this->via_valid_sess_and_ajax_user();

            $this->form_validation->set_rules('ca', 'User address code', 'trim|required|xss_clean');            
            if ($this->form_validation->run() == FALSE){
                $errors = validation_errors();
                echo json_encode(['status'=> false, 'msg' => $errors]);exit;
            }
            
            $current_crypto_address = escape_str($this->input->post('ca', true));
            $user_id = getCurrencyAddressId(escape_str($this->input->post('ca', true)));

            if($this->session->userdata('deposit_timer_'.$user_id)){
                $user_raw_deposit_pym = escape_str($this->input->post('user_raw_deposit'));
                $admin_pym = escape_str($this->input->post('admin_pym'));
                $admin_ltc = escape_str($this->input->post('admin_ltc'));
                $percentage_amount = escape_str($this->input->post('percentage_amount'));

                $data = array('current_crypto_address' => $current_crypto_address,
                        'user_raw_deposit_pym' => $user_raw_deposit_pym,
                        'admin_pym' => $admin_pym,
                        'admin_ltc' => $admin_ltc,
                        'percentage_amount' => $percentage_amount
                    );

                $check = $this->user_crypto_deposits('Litecoin', $data);
                if($check) {
                    $result = json_decode($check);
                    // print_r($result);    
                    if($result->status==1) {

                        $this->common_model->updateTableData('transactions',array('trans_id'=>$result->trans_id,'user_status'=>'Pending','crypto_address'=>$current_crypto_address), array('user_status'=>'Completed'));

                        $data['msg'] = "Deposit success";
                        echo json_encode(['status' => true, 'msg' => $data]);exit;
                    } else {
                        // echo "Noo--";
                    }    


                }
                // echo "<pre>";print_r($check);


       //       if($this->com_m->get_row_counter('transactions',['user_status' => 'Pending' ,'crypto_address' => $current_crypto_address ]) > 0){
       //           $this->common_model->updateTableData('transactions',array('user_id'=>$user_id,'user_status'=>'Pending','crypto_address'=>$current_crypto_address), array('user_status'=>'Completed'));
       //           // $this->update_user_ltc_address();
                //  echo json_encode(['status' => true, 'msg' => 'Transaction is completed.']);exit;
                // }
            }else{
                // $this->update_user_ltc_address();
                $data['msg'] = "Completed your deposite timer";
                echo json_encode(['status' => false, 'msg' => $data]);exit;
            }

        } catch (Exception $e) {
            return $this->catchMyError($e);
        }


    }



    function user_deposit(){
        return $this->secure_user_deposit();
    }

    public function update_user_ltc_address()
    {
        try {   
        $status = false;    
        $data = [];
        $data['status'] = 0;
        // if (!$this->input->is_ajax_request()) {
        //    exit('No direct script access allowed');
        // }
     //    if(!$user_id = $this->session->userdata('user_id')){             
     //     throw new Exception('Authetication Failed.', 401);exit;             
        // }
        $user_id = $this->session->userdata('user_id');
        $coin_address = $this->common_model->getTableData('tenrealm_currency use index (address)',array('type'=>'digital','status'=>'1'))->row();

        $userdetails = $this->common_model->getTableData('crypto_address',array('user_id' => $user_id))->result();
        $User_Address = getAddress($user_id,$coin_address->id);

        
        if(!empty($User_Address))
        {
            $parameter = '';
            if($coin_address->coin_type=="coin")
            {
                if($coin_address->currency_symbol=='LTC')
                {
                    $parameter='getnewaddress';
                    $Get_First_address1 = $this->local_model->access_wallet($coin_address->id,'getnewaddress',getUserEmail($user_id));

                    if(!empty($Get_First_address1) || $Get_First_address1!=0){
                        $Get_First_address = $Get_First_address1;
                        updateAddress($user_id,$coin_address->id,$Get_First_address);
                    }
                }
            }        
            return true;         
        }

        } catch (Exception $e) {
            // echo json_encode(array('error' => array('msg' => $e->getMessage(),'code' => $e->getCode())));exit;
            return $this->catchMyError($e);
        }
    

    }



    public function update_user_ltc_address_old()
    {       
        try {   
        $status = false;    
        $data = [];
        $data['status'] = 0;
        // if (!$this->input->is_ajax_request()) {
        //    exit('No direct script access allowed');
        // }
     //    if(!$user_id = $this->session->userdata('user_id')){             
     //     throw new Exception('Authetication Failed.', 401);exit;             
        // }
        $user_id = $this->session->userdata('user_id');
        $Fetch_coin_list = $this->common_model->getTableData('tenrealm_currency use index (address)',array('type'=>'digital','status'=>'1'))->result();

        echo "<pre>";print_r($Fetch_coin_list);die;     
        foreach($Fetch_coin_list as $coin_address)
        {
            $userdetails = $this->common_model->getTableData('crypto_address',array('user_id' => $user_id))->result();
            foreach($userdetails as $user_details) 
            {
                $User_Address = getAddress($user_details->user_id,$coin_address->id);
                if(empty($User_Address) || $User_Address==0)
                {
                    $parameter = '';
                    if($coin_address->coin_type=="coin")
                    {
                        if($coin_address->currency_symbol=='LTC')
                        {
                            $parameter='getnewaddress';
                            $Get_First_address1 = $this->local_model->access_wallet($coin_address->id,'getnewaddress',getUserEmail($user_details->user_id));
                            if(!empty($Get_First_address1) || $Get_First_address1!=0){
                                $Get_First_address = $Get_First_address1;
                                updateAddress($user_details->user_id,$coin_address->id,$Get_First_address);
                            }
                            else{ 
                                if($Get_First_address1){
                                    $Get_First_address = $this->common_model->update_address_again($user_details->user_id,$coin_address->id,$parameter);
                                    updateAddress($user_details->user_id,$coin_address->id,$Get_First_address);
                                    echo $coin_address->currency_symbol;
                                }
                            }
                        }
                    }        
                    return true;         
                    }
                }
            }   
             return $status;
        } catch (Exception $e) {
            echo json_encode(array('error' => array('msg' => $e->getMessage(),'code' => $e->getCode())));exit;          
        }
    }



    function user_activation(){
        return $this->select_package();
    }


    function package_before_purchasing_validation(){
        // 1. User & reference id validation
        // User  balance checking
        // To Check user & reference previous package status

        try {

            $this->via_valid_sess_and_ajax_user();
            
            $this->form_validation->set_rules('user_reference_id', 'reference code', 'trim|required|xss_clean');
            $this->form_validation->set_rules('purchase_amount', 'EMD', 'trim|required|xss_clean|numeric');
            if ($this->form_validation->run() == FALSE){
                $errors = validation_errors();
                echo json_encode(['status' => false,'msg'=>$errors]);exit;
            }
            $currency_symbol = $this->outputData['default_currency_symbol'];
            $unique_id = escape_str($this->input->post('user_reference_id', true));
            $purchase_amount = escape_str($this->input->post('purchase_amount', true));
            $select_package = escape_str($this->input->post('current_package', true));


            $p = $user_id = unique_id_to_user_id($unique_id);


            $init_package_id = $this->com_m->getTableData('package', ['status' => '1'], "id","", "", "","","1",array('id', "asc") )->row("id");

                if(!($this->com_m->get_row_counter('package_4x_payment',['user_id' => $user_id, 'package_id' => $init_package_id ]))){
                    if($init_package_id == $select_package){
                        if(!(get_pym_Balance())){
                    echo json_encode(array('status' => false,'msg' => 'No balance'));exit;
                }
                
                if( (get_pym_Balance() < $purchase_amount)){                
                    echo json_encode(array('status' => false,'msg' => 'Amount you have entered is more than your current balance'));exit;
                }

                    $status = $this->getCommissionLevel($user_id, $user_id, $select_package, 1);
                    // $this->package_acvtivation_email($p, $purchase_amount);        
                    echo json_encode(['status' => true, 'msg'=>'Successfully package activated.', 'same_id' => encryptIt($p) ]);exit;
                }else{
                    echo json_encode(array('status' => false,'msg' => 'Please purchase initial package.'));exit;    
                }               
            }
            
            // if($init_package_id < $select_package){
            //  echo json_encode(array('status' => false,'msg' => 'Please purchase initial package..'));exit;
            // }

            if(!$this->com_m->get_row_counter('users', ['unique_id' => $unique_id])){               
                echo json_encode(array('status' => false,'msg' => 'Invalid user id'));exit;
            }

            if(($this->com_m->get_row_counter('users',['id' => $user_id, 'verified' => '0' ]))){
                echo json_encode(array('status' => false,'msg' => 'Your reference hasn\'t been verified!.'));exit;
            }


            if($user_id != 1){
                if((!($this->com_m->get_row_counter('users',['id' => $user_id, 'parent !=' => '0' ])))){                
                    echo json_encode(array('status' => false,'msg' => 'You have no reference!.'));exit;
                }
            }

            if(($this->com_m->get_row_counter('package_4x_payment',['user_id' => $user_id, 'package_id' => $select_package ]))){
                echo json_encode(array('status' => false,'msg' => 'Already purchased the package'));exit;
            }
                        
            if(!(get_pym_Balance())){
                echo json_encode(array('status' => false,'msg' => 'No balance'));exit;
            }
            
            if( (get_pym_Balance() < $purchase_amount)){                
                echo json_encode(array('status' => false,'msg' => 'Amount you have entered is more than your current balance'));exit;
            }           
           echo 'Not working';exit;
            $current_package = $this->com_m->get_row_val('package_4x_payment',['user_id' => $user_id],"max(package_id)");

            if($current_package){
                    $previous_package_id = $this->com_m->getTableData('package', ['id <' => $current_package, 'status' => '1'], "id","", "", "","","1")->row();
                    $next_package_id = $this->com_m->getTableData('package', ['id >' => $current_package, 'status' => '1'], "id","", "", "","","1")->row();
                    $pre_pp_id = ($previous_package_id) ? $previous_package_id->id : 0;
                    $next_pp_id = ($next_package_id) ? $next_package_id->id : 0;
                        if(!(($pre_pp_id < $select_package) && (($next_pp_id) >= $select_package))){
                            echo json_encode(array('status' => false,'msg' => 'You can not choose a high level directly; instead, you must choose a package from the beginning to the end.'));exit;
                        }
            }else{
                $current_package = $this->com_m->getTableData('package', ['status' => '1'], "id","", "", "","","1")->row('id');
                if(!$current_package){
                    echo json_encode(['status' => false, 'msg' => 'No package available']);
                }
            }
            
            $status = $this->getCommissionLevel($user_id, $user_id, $select_package, 1);
            // $this->package_acvtivation_email($p, $purchase_amount);
            echo json_encode(['status' => true, 'msg'=>'Successfully package activated.', 'abalance' => get_pym_Balance(), 'same_id' => encryptIt($p) ]);exit;
        } catch (Exception $e) {
            echo json_encode(array('status' => false, 'error' => array('msg' => $e->getMessage(),'code' => $e->getCode())));exit;       
        }    
    }


    private function package_acvtivation_email($id, $purchase_amount){
        $email = getUserEmail($id);
        $uname = user_id_to_name($id);
        $site_common = site_common();
        $email_template = 'Package Activated';
        $special_vars = array(
        '###USERNAME###' => $uname,
        '###AMOUNT###' => $purchase_amount,
        '###LINK###' => front_url().'contact-us/'
        );
        $this->email_model->sendMail($email, '', '', $email_template, $special_vars);
        return true;
    }


    function print_user_details(){

        try {           
            $container_arr = array();
            $this->via_valid_sess_and_ajax_user();
            $user_id = $this->session->userdata('user_id');
            $this->form_validation->set_rules('user_reference_id', 'reference code', 'trim|required|xss_clean');            
            if ($this->form_validation->run() == FALSE){
                $errors = validation_errors();
                echo json_encode(['status'=> false, 'msg' => $errors]);exit;
            }
            $user_parent_id = escape_str($this->input->post('user_reference_id',true));         
            if($pro = unique_id_to_user_id($user_parent_id,true)){
                $prefix = get_prefix();
                $fname = $pro[$prefix.'fname'];
                $lname = $pro[$prefix.'lname'];
                $container_arr['username'] = ($lname) ? $fname.' '. $lname : $fname;
                if($container_arr){
                    $output = ['status' => true, 'data' => $container_arr ];
                    echo json_encode($output);exit;
                }
            }
            $output = ['status' => false, 'msg' => '<div class="error" >Invalid User ID!.</div>' ];
            echo json_encode($output);exit;
        } catch (Exception $e) {
            // echo json_encode(array('status' => false, 'error' => array('msg' => $e->getMessage(),'code' => $e->getCode())));exit;
            return $this->catchMyError($e);
        }
    }
    

    private function catchMyError($e){
        $data = array('status' => false, 'msg' => $e->getMessage(),'code' => $e->getCode());
        if ($this->input->is_ajax_request()) {
           echo json_encode($data);exit($e->getMessage());
        }
        
        $this->load->view('errors/error404', $data);
        echo $this->output->get_output();
        exit(4);
    }


    private function via_valid_sess_and_ajax_user(){

        if (!$this->input->is_ajax_request()) {
           exit('No direct script access allowed');
        }
        $user_id = $this->session->userdata('user_id');

        if(!$user_id){      
            throw new Exception('Authetication Failed.', 401);exit;
        }

        if(!$user_id)
        {   
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url());
        }
        return true;

    }

    function level_activation_income(){     
        try {

            if(!$user_id = $this->session->userdata('user_id')){        
                $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
                redirect(base_url());
            }
            $data = $this->site_common();                       
            $data['packages_arr'] = $this->common_model->getTableData('tenrealm_package', array('status' => '1'))->result_array();  
            $this->load->view('front/user/level_income', $data);
        } catch (Exception $e) {
            return $this->catchMyError($e);
        }

    }

  function dep(){
      try {

            if(!$user_id = $this->session->userdata('user_id')){        
                $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
                redirect(base_url());
            }
            $data = $this->site_common();                       
            $data['dep'] = $this->common_model->getTableData('tenrealm_deposit_verify', array('status' => '1','user_id'=>$user_id))->result(); 
     
            $this->load->view('front/user/dep', $data);
        } catch (Exception $e) {
            return $this->catchMyError($e);
        }
    
  
  }
  
        function team_level_income(){       
        try {

            if(!$user_id = $this->session->userdata('user_id')){        
                $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
                redirect(base_url());
            }
            $data = $this->site_common();                       
            $data['packages_arr'] = $this->common_model->getTableData('tenrealm_package', array('status' => '1'))->result_array();  
            $this->load->view('front/user/top_level_income', $data);
        } catch (Exception $e) {
            return $this->catchMyError($e);
        }

    }



    private function site_common(){
        if(!$user_id = $this->session->userdata('user_id')){  
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url());           
        }
        $data['site_common'] = site_common();
        $data['meta_content'] = $this->common_model->getTableData('meta_content', array('link'=>'dashboard'))->row();
        $data['users'] = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
        return $data;
    }

    function tree(){

        // $data['tree'] = $this->common_model->getTableData('package_payment',"","id")->result();
        $x = escape_str($this->input->get_post('x',true));
        $user_id = escape_str($this->input->get_post('user_id',true));
        $package_id = escape_str($this->input->get_post('package_id',true));
        $table = escape_str($this->input->get_post('table',true));
        $user_id = ($user_id) ? $user_id : '';
        $package_id = ($package_id) ? $package_id : 3;
        $table = ($table==2) ? $table : 1;
        if($x==4){
            $data['tree'] = downline_4x_earning_tester($package_id, $user_id,1,1);
        }else{
            $data['tree'] = downline_earning_tester($package_id, $user_id,1,1,1, $table);   
        }
        
        // echo '<pre>';print_r($data['tree']);
        $this->load->view('front/user/tree_format', $data);
    }


    function sponsor_income_chart(){
            try {           
                if(!$user_id = $this->session->userdata('user_id'))
                {   
                    $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
                    redirect(base_url());
                }
                $data = $this->site_common();
                $data['packages_arr'] = $this->common_model->getTableData('tenrealm_package', array('status' => '1'))->result_array();
                // $query = "SELECT *, COUNT(level) c FROM `tenrealm_global_profit` GROUP BY level ORDER BY `tenrealm_global_profit`.`profit` DESC;";
                // echo '<pre>';print_r($get_user = $this->db->query($query)->result());
                // $data['package_earnings'] = $this->com_m->
                $this->load->view('front/user/sponsor_income', $data);
            } catch (Exception $e) {
                return $this->catchMyError($e);
            }
        }


    function global_income_chart(){
        try {       
            if(!$user_id = $this->session->userdata('user_id'))
            {   
                $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
                redirect(base_url());
            }
            $data = $this->site_common();
            $prefix = get_prefix();
            $t1 = $prefix .`global_profit`;
            $t2 = $prefix .`global_profit`;
            $order_by = $prefix . `global_profit`.`profit`;
            $data['packages_arr'] = $this->com_m->getTableData('package', array('status' => '1'))->result_array();          
            // $query = "SELECT *, COUNT(level) c FROM ".$t1." GROUP BY level ORDER BY ".$order_by." DESC;";            
            $this->load->view('front/user/global_income', $data);
        } catch (Exception $e) {
            return $this->catchMyError($e);
        }
    }


    function display_global_income_chart(){
        // type  = 2x or 4x
        try {           
            if (!$this->input->is_ajax_request()) {
            throw new Exception('No direct script access allowed.', 401);
               exit('No direct script access allowed');
            }

            if(!$user_id = $this->session->userdata('user_id')){        
                throw new Exception('Authetication Failed.', 401);exit;
            }         
          $accommodation_start = 1; $accommodation_end = 10;
          $m_type = escape_str($this->input->post('t'));
          $charts = escape_str($this->input->post('charts'));
          $package_id = escape_str($this->input->post('p'));        
          $current_id = escape_str($this->input->post('c'));
          $unique_id = user_id_to_unique_id($user_id);
        // $get_user = $this->db->get_where('global_profit',['package_id' => $package_id, 'receiver_user_id' => $user_id, 'chart' => $chart])->result();
        // $get_user = $this->db->get_where('global_profit',['package_id' => $package_id, 'unique_id' => $unique_id, 'chart' => $charts])->result();    
          $get_user = $this->db->limit(10)->where('level >=', $accommodation_start)->where('level <=', $accommodation_end)->get_where('global_profit',['package_id' => $package_id, 'unique_id' => $unique_id, 'id >=' => decryptIt($current_id), 'chart_level' => $charts ])->result_array();
          // echo $this->db->last_query();exit;
              foreach ($get_user as $gpkey => $gpvalue) {
                    $package_id = $gpvalue['package_id'];
                    $level = $gpvalue['level'];
                    $admin_chart_price = global_farming_reduce_income($package_id, $level);
                    $get_user[$gpkey]['price'] = ($admin_chart_price['price']) ? $admin_chart_price['price'] : 0;
                    $get_user[$gpkey]['ap_upgrade'] = ($admin_chart_price['ap_upgrade']) ? $admin_chart_price['ap_upgrade'] : 'NILL';
                    $get_user[$gpkey]['rebirth'] = ($admin_chart_price['rebirth']) ? $admin_chart_price['rebirth'] : 'NILL';
                    $get_user[$gpkey]['sponsor'] = ($admin_chart_price['to_sponsor']) ? $admin_chart_price['to_sponsor'] : 'NILL';
              }           
            echo json_encode(['status'=> true, 'data' => CryptoJsAes::encrypt($get_user, $this->_encpassword) ]);exit;          
        } catch (Exception $e) {
            return $this->catchMyError($e);
        }
    }


    function display_global_income_migration_chart(){
        // type  = 2x or 4x
        try {           
            if (!$this->input->is_ajax_request()) {
            throw new Exception('No direct script access allowed.', 401);
               exit('No direct script access allowed');
            }

            if(!$user_id = $this->session->userdata('user_id')){        
                throw new Exception('Authetication Failed.', 401);exit;
            }         
          $accommodation_start = 1; $accommodation_end = 10;
          $m_type = escape_str($this->input->post('t'));
          $charts = escape_str($this->input->post('charts'));
          $package_id = escape_str($this->input->post('p'));        
          $current_id = escape_str($this->input->post('c'));
          $unique_id = user_id_to_unique_id($user_id);
          $get_user = $this->db->limit(10)->where('level >=', $accommodation_start)->where('level <=', $accommodation_end)->get_where('global_mi_profit',['package_id' => $package_id, 'unique_id' => $unique_id, 'id >=' => decryptIt($current_id), 'chart_level' => $charts ])->result_array();
          // echo $this->db->last_query();exit;
              foreach ($get_user as $gpkey => $gpvalue) {
                    $package_id = $gpvalue['package_id'];
                    $level = $gpvalue['level'];
                    $admin_chart_price = global_farming_reduce_income($package_id, $level);
                    $get_user[$gpkey]['price'] = ($admin_chart_price['price']) ? $admin_chart_price['price'] : 0;
                    $get_user[$gpkey]['ap_upgrade'] = ($admin_chart_price['ap_upgrade']) ? $admin_chart_price['ap_upgrade'] : 'NILL';
                    $get_user[$gpkey]['rebirth'] = ($admin_chart_price['rebirth']) ? $admin_chart_price['rebirth'] : 'NILL';
                    $get_user[$gpkey]['sponsor'] = ($admin_chart_price['to_sponsor']) ? $admin_chart_price['to_sponsor'] : 'NILL';
              }
            echo json_encode(['status'=> true, 'data' =>  CryptoJsAes::encrypt($get_user, $this->_encpassword) ]);
        } catch (Exception $e) {
            return $this->catchMyError($e);
        }
    }

        function display_sponsor_income_chart(){
        // type  = 2x or 4x
        try {           
            if (!$this->input->is_ajax_request()) {
            throw new Exception('No direct script access allowed.', 401);
               exit('No direct script access allowed');
            }

            if(!$user_id = $this->session->userdata('user_id')){        
                throw new Exception('Authetication Failed.', 401);exit;
            }         
          $accommodation_start = 1; $accommodation_end = 10;
          $m_type = escape_str($this->input->post('t'));
          $charts = escape_str($this->input->post('charts'));
          $package_id = escape_str($this->input->post('p'));        
          $current_id = escape_str($this->input->post('c'));
          $unique_id = user_id_to_unique_id($user_id);
          $get_user = $this->db->select('sponsor')->limit(10)->where('level >=', $accommodation_start)->where('level <=', $accommodation_end)->get_where('global_profit',['package_id' => $package_id, 'sponsor_user_id' => $user_id, 'id >=' => decryptIt($current_id), 'chart_level' => $charts ])->result();       
            echo json_encode(['status'=> true, 'data' => CryptoJsAes::encrypt($get_user, $this->_encpassword) ]);
        } catch (Exception $e) {
            return $this->catchMyError($e);
        }
    }



    function display_global_4x_income_chart(){
        // type  = 4x
        try {
        
          $this->via_valid_sess_and_ajax_user();
          $user_id = $this->session->userdata('user_id');

          $accommodation_start = 1; $accommodation_end = 10;
          $m_type = escape_str($this->input->post('t'));
          $charts = escape_str($this->input->post('charts'));
          $package_id = escape_str($this->input->post('p'));        
          $current_id = escape_str($this->input->post('c'));
          $unique_id = user_id_to_unique_id($user_id);      
          
          $get_user = $this->db->limit(10)->where('level >=', $accommodation_start)->where('level <=', $accommodation_end)->get_where('global_4x_profit',['package_id' => $package_id, 'unique_id' => $unique_id, 'id >=' => decryptIt($current_id), 'chart_level' => $charts ])->result_array();

         foreach ($get_user as $gpkey => $gpvalue) {
                $package_id = $gpvalue['package_id'];
                $level = $gpvalue['level'];
                $admin_chart_price = global_cultivation_income_chart($package_id, $level);
                $get_user[$gpkey]['price'] = ($admin_chart_price['price']) ? $admin_chart_price['price'] : 0;
                $get_user[$gpkey]['rebirth'] = ($admin_chart_price['rebirth']) ? $admin_chart_price['rebirth'] : 'NILL';
                $get_user[$gpkey]['sponsor'] = ($admin_chart_price['to_sponsor']) ? $admin_chart_price['to_sponsor'] : 'NILL';
          }
            echo json_encode(['status'=> true, 'data' => CryptoJsAes::encrypt($get_user, $this->_encpassword) ]);
        } catch (Exception $e) {
            return $this->catchMyError($e);
        }
    }




    function display_sponsor_4x_income_chart(){
        // type  = 4x
        try {
        
          $this->via_valid_sess_and_ajax_user();
          $user_id = $this->session->userdata('user_id');

          $accommodation_start = 1; $accommodation_end = 10;
          $m_type = escape_str($this->input->post('t'));
          $charts = escape_str($this->input->post('charts'));
          $package_id = escape_str($this->input->post('p'));        
          $current_id = escape_str($this->input->post('c'));
          // $unique_id = user_id_to_unique_id($user_id);         
          $get_user = $this->db->limit(10)->select('sponsor')->where('level >=', $accommodation_start)->where('level <=', $accommodation_end)->get_where('global_4x_profit',['package_id' => $package_id, 'sponsor_user_id' => $user_id, 'id >=' => decryptIt($current_id), 'chart_level' => $charts ])->result();        
            echo json_encode(['status'=> true, 'data' => CryptoJsAes::encrypt($get_user, $this->_encpassword) ]);
        } catch (Exception $e) {
            return $this->catchMyError($e);
        }
    }



    function display_directs_income_chart(){
        try {
            
            if(!$user_id = $this->session->userdata('user_id'))
            {   
                $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
                redirect(base_url());
            }
            $package_id = 3;
            $data = $this->site_common();
            $data['packages_arr'] = $this->com_m->getTableData('tenrealm_package', array('status' => '1'))->result_array();
            // $data['overall_direct_count'] = $this->com_m->get_row_counter('users', ['parent' => $user_id]);
            
            $condition = "`u`.`parent` = " . $user_id . " AND p.package_id = ". $package_id ." AND u.rebirth_status = '0' ";
            $groupby = "group by u.id";
            $allcount = $this->db->query("SELECT `u`.`id` FROM `tenrealm_users` as `u` JOIN `tenrealm_package_4x_payment` as `p` ON `p`.`user_id` = `u`.`id` WHERE " . $condition . $groupby)->num_rows();
            $data['overall_direct_count'] = $allcount;
            
            $this->load->view('front/user/directs_list', $data);
        } catch (Exception $e) {
            return $this->catchMyError($e);
        }
    }


    function display_directs_list($rowno=0){
        try {
                $d ='';
                $this->via_valid_sess_and_ajax_user();
                $user_id = $this->session->userdata('user_id');

                $this->load->library('pagination');
                $package_id = escape_str($this->input->get_post('package_id',true));
                
                $package_id = 3;

                $rowperpage = 8;
                $limit = "LIMIT $rowperpage" ;

                if($rowno != 0){
                  $rowno = ($rowno-1) * $rowperpage;
                  $limit = " LIMIT $rowno, $rowperpage" ;
                }

                $condition = "`u`.`parent` = " . $user_id . " AND p.package_id = ". $package_id ." AND u.rebirth_status = '0'  ";
                $groupby = "group by u.id";
                // $allcount = $this->db->join($table2, 'p.user_id = u.id', 'inner')->count_all($table1);
                $allcount = $this->db->query("SELECT `u`.`id` FROM `tenrealm_users` as `u` JOIN `tenrealm_package_4x_payment` as `p` ON `p`.`user_id` = `u`.`id` WHERE " . $condition . $groupby)->num_rows();      

                $users_record = $this->db->query("SELECT `u`.`id` as prime_id, `u`.`parent`, p.* FROM `tenrealm_users` as `u` JOIN `tenrealm_package_4x_payment` as `p` ON `p`.`user_id` = `u`.`id` WHERE ".$condition." ".$groupby." ". $limit . ";")->result_array();
                // echo $d = $this->db->last_query();               exit;

                if($allcount > 0){
                    
                    foreach ($users_record as $ukey => $uvalue) {                           
                        $from = $uvalue['prime_id'];
                        $name = ucfirst($this->com_m->get_row_val('users',['id' => $from], "tenrealm_fname"));
                        $users_record[$ukey]['id'] = encryptIt($from);
                        $users_record[$ukey]['name'] = ucfirst($name);
                        $users_record[$ukey]['short_name'] = substr(strtoupper($name),0,1);
                        // Check profile lame
                        $pp = $this->com_m->get_row_val('users',['id' => $from], "profile_picture");
                        // if(is_image($pp)){
                        if(($pp)){
                            $users_record[$ukey]['pp_status'] = 1;  
                        }else{
                            $users_record[$ukey]['pp_status'] = 0;  
                        }                       
                        $users_record[$ukey]['pp'] = $pp;
                        $users_record[$ukey]['unique_id'] = $this->com_m->get_row_val('users',['id' => $from], "unique_id");                
                    }
                }
                

                // echo '<pre>';print_r($users_record);exit;
          
                $config['base_url'] = base_url().'directs-list/'.$rowno.'/'.$package_id;
                // $config['base_url'] = current_url();
                $config['use_page_numbers'] = TRUE;
                $config['total_rows'] = $allcount;
                $config['per_page'] = $rowperpage;
         
                $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination justify-content-center mt-1">';
                $config['full_tag_close']   = '</ul></nav></div>';
                $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
                $config['num_tag_close']    = '</span></li>';
                $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
                $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
                $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
                $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
                $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
                $config['prev_tag_close']  = '</span></li>';
                $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
                $config['first_tag_close'] = '</span></li>';
                $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
                $config['last_tag_close']  = '</span></li>';
                $config['attributes'] = array('class' => 'deirect-pagination-cls');
                $this->pagination->initialize($config);
            
                // pageconfig($allcount,$base,$rowperpage);
                $data['pagination'] = $this->pagination->create_links();
                $data['result'] = $users_record;
                $data['row'] = $rowno;
                
            // echo json_encode(['status'=> true, 'data' => ($data) ]);exit;
            echo json_encode(['status'=> true, 'data' => CryptoJsAes::encrypt($data, $this->_encpassword) ]);exit;
            // echo json_encode(['status'=> true, 'data' => $data]);
            exit;
        } catch (Exception $e) {
            return $this->catchMyError($e);
        }
    }



    function display_directs_person_list(){
        try {
            
            $this->via_valid_sess_and_ajax_user();

            $user_package_table = 'package_4x_payment';
            $id = escape_str(decryptIt($this->input->post('id')));

            $data['packages_arr'] = $this->com_m->getTableData('package', array('status' => '1'))->result_array();
            $user_arr = $this->com_m->getTableData($user_package_table, array('user_id' => $id ), "package_id")->result_array();
            $d = $this->db->last_query();

            $uArr = [];
            foreach ($user_arr as $uskey => $usvalue) {
                $uArr[] = $usvalue['package_id'];
            }

            $data['user_packages_arr'] = $uArr;         
            $personal = $this->com_m->getTableData('users',['id' => $id])->result_array();
             foreach ($personal as $ukey => $uvalue) {  
                $from = $uvalue['id'];
                $fname = ucfirst(($uvalue['tenrealm_fname']) ? $uvalue['tenrealm_fname'] :'');
                $lname = ucfirst(($uvalue['tenrealm_lname']) ? $uvalue['tenrealm_lname'] :'');
                $personal['id'] = encryptIt($from);
                $personal['unique_id'] = $uvalue['unique_id'];
                $personal['name'] = ucfirst($fname.' '.$lname);
                $personal['fname'] = ucfirst($fname);
                $personal['email'] = getUserEmail($from);
                 $s1 = substr(strtoupper($fname),0,1);
                 $s2 = substr(strtoupper($lname),0,1);
                 $personal['short_name'] = $s1 . $s2;
                // Check profile lame
                $pp = $uvalue['profile_picture'];                               
                // if(is_image($pp)){
                if(($pp)){
                    $personal['pp_status'] = 1; 
                }else{
                    $personal['pp_status'] = 0; 
                }                       
                $personal['pp'] = $pp;              
                $pack_time = $this->com_m->getTableData($user_package_table,['user_id' => $id], "timestamp",'','','','',1,'ASC')->row('timestamp'); 
                $personal['date_of_joinings'] =  ($pack_time) ? timestamp_UTC_conversion($pack_time) : '';
                // $withdraw_cond = array('unique_id' => $unique_id, 'status' => 'Completed', 'user_status' => 'Completed');
                // $withdraw_package_payment = $this->com_m->getTableData('transactions', $withdraw_cond, "sum(fiat_amount) as wt")->row('wt');
                $personal['total_earning'] =  number_format(total_earning($id),2 ) ?? 0.00;
            }
                        
            $data['personal'] = $personal;
            // echo json_encode(['status'=> true, 'data' => $data, 'user_packages_arr' => $d]);
            echo json_encode(['status'=> true, 'data' => CryptoJsAes::encrypt($data, $this->_encpassword) ]);exit;
        } catch (Exception $e) {
            return $this->catchMyError($e);
        }

    }

    

    function display_directs_popup_list($rowno=0){
        try {
            
                $this->via_valid_sess_and_ajax_user();
                $this->load->library('pagination');
                $package_id = escape_str($this->input->get_post('package_id',true));
                $user_id = decryptIt(escape_str($this->input->get_post('id',true)));
                $rowperpage = 9;
                $limit = "LIMIT $rowperpage" ;

                if($rowno != 0){
                  $rowno = ($rowno-1) * $rowperpage;
                  $limit = " LIMIT $rowno, $rowperpage" ;
                }

                $condition = "`u`.`parent` = " . $user_id . " AND p.package_id = ". $package_id ." ";
                $groupby = "group by u.id";             
                $allcount = $this->db->query("SELECT `u`.`id` FROM `tenrealm_users` as `u` JOIN `tenrealm_package_payment` as `p` ON `p`.`user_id` = `u`.`id` WHERE " . $condition . $groupby)->num_rows();     

                $users_record = $this->db->query("SELECT `u`.`id` as prime_id, `u`.`parent`, p.* FROM `tenrealm_users` as `u` JOIN `tenrealm_package_payment` as `p` ON `p`.`user_id` = `u`.`id` WHERE ".$condition." ".$groupby." ". $limit . ";")->result_array();
                $d = $this->db->last_query();               

                if($allcount > 0){                  
                    foreach ($users_record as $ukey => $uvalue) {                           
                        $from = $uvalue['prime_id'];
                        $name = ucfirst($this->com_m->get_row_val('users',['id' => $from], "tenrealm_fname"));
                        $users_record[$ukey]['id'] = encryptIt($from);
                        $users_record[$ukey]['name'] = ucfirst($name);
                        $users_record[$ukey]['short_name'] = substr(strtoupper($name),0,1);
                        // Check profile lame
                        $pp = $this->com_m->get_row_val('users',['id' => $from], "profile_picture");
                        // if(is_image($pp)){
                        if(($pp)){
                            $users_record[$ukey]['pp_status'] = 1;  
                        }else{
                            $users_record[$ukey]['pp_status'] = 0;  
                        }                       
                        $users_record[$ukey]['pp'] = $pp;
                        $users_record[$ukey]['unique_id'] = $this->com_m->get_row_val('users',['id' => $from], "unique_id");                
                    }
                }
                
                $config['base_url'] = base_url().'display-direct-popup-list/'.$rowno.'/'.$package_id;
                $config['use_page_numbers'] = TRUE;
                $config['total_rows'] = $allcount;
                $config['per_page'] = $rowperpage;
                $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination justify-content-center mt-1">';
                $config['full_tag_close']   = '</ul></nav></div>';
                $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
                $config['num_tag_close']    = '</span></li>';
                $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
                $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
                $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
                $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
                $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
                $config['prev_tag_close']  = '</span></li>';
                $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
                $config['first_tag_close'] = '</span></li>';
                $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
                $config['last_tag_close']  = '</span></li>';                
                $config['attributes'] = array('class' => 'direct-popup-pagination');
                $this->pagination->initialize($config);         
                $data['pagination'] = $this->pagination->create_links();
                $data['result'] = $users_record;
                $data['row'] = $rowno;
                
            // echo json_encode(['status'=> true, 'data' => $data, 's' => $d]);
            echo json_encode(['status'=> true, 'data' => CryptoJsAes::encrypt($data, $this->_encpassword)]);exit;
            exit;
        } catch (Exception $e) {
            return $this->catchMyError($e);
        }
    }

        function display_auto_level_income_list($rowno = 0){
        try {           
            $this->via_valid_sess_and_ajax_user();
            $level_arr = [];
            $prefix = get_prefix();
            $user_id = $this->session->userdata('user_id');
            $user_level_income_table = 'top_level_segment';
            $top_level_segment_table = $prefix . 'global_4x_profit';
            $package_id = $id = escape_str(($this->input->get_post('id')));
            $level = escape_str(($this->input->get_post('level')));                 
            $this->load->library('pagination');
            $rowperpage = 9;        
            $allcount = $this->db->get_where($top_level_segment_table, array( 'receiver_user_id' => $user_id, 'package_id' => $id, 'level' => $level))->num_rows();         
            
            if($allcount > 0){
                    // if($rowno != 0){
                    //  $this->db->limit($rowperpage, $rowperpage * $rowno-1);
                    //  // $this->db->limit($rowno, $rowperpage);
                    // }else{
                    //  $this->db->limit($rowperpage);
                    // }
                    
                // $level_arr = $this->db->order_by('id', 'asc')->get_where($user_level_income_table, array('utype_TETS' => 2, 'user_id' => $user_id, 'package_id' => $id, 'level' => $level))->result_array(); 
                
                $limit = "LIMIT $rowperpage" ;
                if($rowno != 0){
                  $rowno = ($rowno-1) * $rowperpage;
                  $limit = " LIMIT $rowno, $rowperpage" ;
                }

                $select = " * ";
                $condition = "  `receiver_user_id` = ".$user_id." AND `package_id` = ".$id." AND `level` = ".$level." ";
                $query = "SELECT ".$select." FROM ".$top_level_segment_table." WHERE ".$condition." ORDER BY `id` ASC ". $limit;
                $level_arr = $this->db->query($query)->result_array();  
                // echo $this->db->last_query();exit;       
                foreach ($level_arr as $ukey => $uvalue) {                          
                    $from = $uvalue['sender_user_id'];
                    $name = ucfirst($this->com_m->get_row_val('users',['id' => $from], "tenrealm_fname"));
                    $level_arr[$ukey]['id'] = encryptIt($from);
                    $level_arr[$ukey]['name'] = ucfirst($name);
                    $level_arr[$ukey]['short_name'] = substr(strtoupper($name),0,1);
                    // Check profile lame
                    $pp = $this->com_m->get_row_val('users',['id' => $from], "profile_picture");
                    // if(is_image($pp)){
                    if(($pp)){
                        $level_arr[$ukey]['pp_status'] = 1; 
                    }else{
                        $level_arr[$ukey]['pp_status'] = 0; 
                    }                       
                    $level_arr[$ukey]['pp'] = $pp;
                    $level_arr[$ukey]['unique_id'] = $this->com_m->get_row_val('users',['id' => $from], "unique_id");
                }
            }
            $config['base_url'] = base_url().'level-income-list/'.$rowno.'/'.$package_id;
            $config['use_page_numbers'] = TRUE;
            $config['total_rows'] = $allcount;
            $config['per_page'] = $rowperpage;
            $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination justify-content-center mt-1">';
            $config['full_tag_close']   = '</ul></nav></div>';
            $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
            $config['num_tag_close']    = '</span></li>';
            $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
            $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
            $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
            $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['prev_tag_close']  = '</span></li>';
            $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
            $config['first_tag_close'] = '</span></li>';
            $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['last_tag_close']  = '</span></li>';                
            $config['attributes'] = array('class' => 'direct-popup-pagination');
            $this->pagination->initialize($config);         
            $data['pagination'] = $this->pagination->create_links();
            $data['result'] = $level_arr;
            $data['row'] = $rowno;
            // print_r($data);exit;
            echo json_encode(['status'=> true, 'data' => CryptoJsAes::encrypt($data, $this->_encpassword) ]);exit;
        } catch (Exception $e) {
            return $this->catchMyError($e);
        }
    }


    function display_level_income_list($rowno = 0){
        try {           
            $this->via_valid_sess_and_ajax_user();
            $level_arr = [];
            $user_id = $this->session->userdata('user_id');
            $user_level_income_table = 'top_level_segment';
            $top_level_segment_table = 'tenrealm_top_level_segment';
            $package_id = $id = escape_str(($this->input->get_post('id')));
            $level = escape_str(($this->input->get_post('level')));                 
            $this->load->library('pagination');
            $rowperpage = 9;        
            $allcount = $this->db->get_where($user_level_income_table, array( 'send_to' => $user_id, 'package_id' => $id, 'level' => $level))->num_rows();          
            
            if($allcount > 0){
                    // if($rowno != 0){
                    //  $this->db->limit($rowperpage, $rowperpage * $rowno-1);
                    //  // $this->db->limit($rowno, $rowperpage);
                    // }else{
                    //  $this->db->limit($rowperpage);
                    // }
                    
                // $level_arr = $this->db->order_by('id', 'asc')->get_where($user_level_income_table, array('utype_TETS' => 2, 'user_id' => $user_id, 'package_id' => $id, 'level' => $level))->result_array(); 
                
                $limit = "LIMIT $rowperpage" ;
                if($rowno != 0){
                  $rowno = ($rowno-1) * $rowperpage;
                  $limit = " LIMIT $rowno, $rowperpage" ;
                }

                $select = " * ";
                $condition = "  `send_to` = ".$user_id." AND `package_id` = ".$id." AND `level` = ".$level." ";
                $query = "SELECT ".$select." FROM ".$top_level_segment_table." WHERE ".$condition." ORDER BY `id` ASC ". $limit;
                $level_arr = $this->db->query($query)->result_array();  
                // echo $this->db->last_query();        
                foreach ($level_arr as $ukey => $uvalue) {                          
                    $from = $uvalue['send_from'];
                    $name = ucfirst($this->com_m->get_row_val('users',['id' => $from], "tenrealm_fname"));
                    $level_arr[$ukey]['id'] = encryptIt($from);
                    $level_arr[$ukey]['name'] = ucfirst($name);
                    $level_arr[$ukey]['short_name'] = substr(strtoupper($name),0,1);
                    // Check profile lame
                    $pp = $this->com_m->get_row_val('users',['id' => $from], "profile_picture");
                    // if(is_image($pp)){
                    if(($pp)){
                        $level_arr[$ukey]['pp_status'] = 1; 
                    }else{
                        $level_arr[$ukey]['pp_status'] = 0; 
                    }                       
                    $level_arr[$ukey]['pp'] = $pp;
                    $level_arr[$ukey]['unique_id'] = $this->com_m->get_row_val('users',['id' => $from], "unique_id");
                }
            }
            $config['base_url'] = base_url().'level-income-list/'.$rowno.'/'.$package_id;
            $config['use_page_numbers'] = TRUE;
            $config['total_rows'] = $allcount;
            $config['per_page'] = $rowperpage;
            $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination justify-content-center mt-1">';
            $config['full_tag_close']   = '</ul></nav></div>';
            $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
            $config['num_tag_close']    = '</span></li>';
            $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
            $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
            $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
            $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['prev_tag_close']  = '</span></li>';
            $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
            $config['first_tag_close'] = '</span></li>';
            $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['last_tag_close']  = '</span></li>';                
            $config['attributes'] = array('class' => 'direct-popup-pagination');
            $this->pagination->initialize($config);         
            $data['pagination'] = $this->pagination->create_links();
            $data['result'] = $level_arr;
            $data['row'] = $rowno;
            echo json_encode(['status'=> true, 'data' => CryptoJsAes::encrypt($data, $this->_encpassword) ]);exit;
        } catch (Exception $e) {
            return $this->catchMyError($e);
        }
    }


    function display_level_income_personal(){
        try {           
            $this->via_valid_sess_and_ajax_user();          
            $user_package_table = 'package_4x_payment';
            $id = escape_str(decryptIt($this->input->post('id')));

            $data['packages_arr'] = $this->com_m->getTableData('package', array('status' => '1'))->result_array();
            $user_arr = $this->com_m->getTableData($user_package_table, array('user_id' => $id ), "package_id")->result_array();            
            $uArr = [];
            foreach ($user_arr as $uskey => $usvalue) {
                $uArr[] = $usvalue['package_id'];
            }

            $data['user_packages_arr'] = $uArr;         
            $personal = $this->com_m->getTableData('users',['id' => $id])->result_array();
             foreach ($personal as $ukey => $uvalue) {  
                $from = $uvalue['id'];
                $fname = ucfirst(($uvalue['tenrealm_fname']) ? $uvalue['tenrealm_fname'] :'');
                $lname = ucfirst(($uvalue['tenrealm_lname']) ? $uvalue['tenrealm_lname'] :'');
                $personal['id'] = encryptIt($from);
                $personal['unique_id'] = $uvalue['unique_id'];
                $personal['name'] = ucfirst($fname.' '.$lname);
                $personal['fname'] = ucfirst($fname);
                $personal['email'] = getUserEmail($from);
                 $s1 = substr(strtoupper($fname),0,1);
                 $s2 = substr(strtoupper($lname),0,1);
                 $personal['short_name'] = $s1 . $s2;
                // Check profile lame
                $pp = $uvalue['profile_picture'];                               
                // if(is_image($pp)){
                if(($pp)){
                    $personal['pp_status'] = 1; 
                }else{
                    $personal['pp_status'] = 0; 
                }                       
                $personal['pp'] = $pp;              
                $pack_time = $this->com_m->getTableData($user_package_table,['user_id' => $id], "timestamp",'','','','',1,'ASC')->row('timestamp'); 
                $personal['date_of_joinings'] =  ($pack_time) ? timestamp_UTC_conversion($pack_time) : '';
                // $withdraw_cond = array('unique_id' => $unique_id, 'status' => 'Completed', 'user_status' => 'Completed');
                // $withdraw_package_payment = $this->com_m->getTableData('transactions', $withdraw_cond, "sum(fiat_amount) as wt")->row('wt');
                $personal['total_earning'] =  number_format(total_earning($id),2 ) ?? 0.00;
            }
                        
            $data['personal'] = $personal;
            echo json_encode(['status'=> true, 'data' => CryptoJsAes::encrypt($data, $this->_encpassword) ]);exit;
        } catch (Exception $e) {
            return $this->catchMyError($e);
        }
    }



    function reward(){
        try {           
        
            if(!$user_id = $this->session->userdata('user_id'))
            {   
                $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
                redirect(base_url());
            }
            
            $data = $this->site_common();
            $unique_id = user_id_to_unique_id($user_id);
            $cond = array('rewards_status' => '1', 'unique_id' => $unique_id);
            $xx2 = $this->common_model->getTableData('package_payment', $cond, "sum(rewards) as r1")->row('r1');
            $xx4 = $this->common_model->getTableData('package_4x_payment', $cond, "sum(rewards) as r2")->row('r2');         
            $data['packages_rewards'] = $xx2 + $xx4;            
            $cond = array('rewards_status' => '0', 'unique_id' => $unique_id);
            $xx2 = $this->common_model->getTableData('package_payment', $cond, "sum(rewards) as r1")->row('r1');
            $xx4 = $this->common_model->getTableData('package_4x_payment', $cond, "sum(rewards) as r2")->row('r2');
            $data['unclaimed_packages_rewards'] = $xx2 + $xx4;


            $data['online_bnbprice'] = (sprintf('%0.8f', $this->coin_price_conversion('USD','BNB')));
            $data['token_price'] = $data['site_common']['site_settings']->token_price;
            $data['bnb_address'] = $this->common_model->getTableData('users', array('id'=>$user_id))->row('beb_address');


            $this->load->view('front/user/rewards', $data);
        } catch (Exception $e) {
            return $this->catchMyError($e);
        }
    }



    function transactions(){
        try {           
        
            if(!$user_id = $this->session->userdata('user_id'))
            {   
                $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
                redirect(base_url());
            }

            $unique_id = user_id_to_unique_id($user_id);
            $data = $this->site_common();           
            $cond = array('user_id' => $user_id);

            $this->load->view('front/user/transactions', ($data));
        } catch (Exception $e) {
            return $this->catchMyError($e);
        }
    }

    function transactions_ajax() {
        try {           
        
            if(!$user_id = $this->session->userdata('user_id'))
            {   
                $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
                redirect(base_url());
            }
            $this->via_valid_sess_and_ajax_user();
            $unique_id = user_id_to_unique_id($user_id);
            // $cond = array('user_id' => $user_id, 'user_status' => 'Completed','status'=> 'Completed');
            $cond = array('user_id' => $user_id );
            $trans_select="unique_id, type,datetime as timestamp,local_transaction_id,status,'transaction' as access, price as pym";
            $income_select="timestamp,price,local_transaction_id,unique_id, user_id as from_id,'income' as access, direct_parent_income as pym";
            $x2_gp_select="profit,timestamp,local_transaction_id,unique_id,'x2_p' as access, profit as pym";
            $x2_gs_select="sponsor,timestamp,local_transaction_id,unique_id,'x2_s' as access, sponsor as pym";
            $x4_gp_select="profit,timestamp,local_transaction_id,unique_id,'x4_p' as access, profit as pym";
            $x4_gs_select="sponsor,timestamp,local_transaction_id,unique_id,'x4_s' as access, sponsor as pym";
            $already_activated_income_select="already_activated_income,timestamp,local_transaction_id,unique_id,'sys_auto_upgrade' as access, already_activated_income as pym";
            $a = $this->com_m->getTableData('top_level_segment', ['send_to' => $user_id ], $trans_select)->result_array();
            // echo my_last_query();exit;               
            $b = $this->db->select($income_select)->get_where('package_4x_payment', ['direct_parent' => $user_id])->result_array();
            // echo my_last_query();exit;
            // $c = $this->db->select($x2_gp_select)->get_where('global_profit', ['unique_id' => $unique_id])->result_array();
            // $d = $this->db->select($x2_gs_select)->get_where('global_profit', ['sponsor_user_id' => $user_id])->result_array();
            $e = $this->db->select($x4_gp_select)->get_where('global_4x_profit', ['unique_id' => $unique_id])->result_array();
            // $f = $this->db->select($x4_gs_select)->get_where('global_4x_profit', ['sponsor_user_id' => $user_id])->result_array();
            // $g = $this->db->select($already_activated_income_select)->get_where('package_payment', ['unique_id' => $unique_id, 'auto_upgrade' => '0', 'already_activated_income !=' => 0] )->result_array();         
            // echo $this->db->last_query();exit;
            $trans_merge = array_merge_recursive($a, $b, $e);           
            usort($trans_merge, function ($item1, $item2) { return $item2['timestamp'] <=> $item1['timestamp']; });         
            $all_transaction_arr['transaction_arr'] = array_values($trans_merge);           
            $v = $this->load->view('front/user/transaction_history_ajax', $all_transaction_arr, true);
            // echo json_encode(['status'=> true, 'data' => $v ]);exit;
            echo json_encode(['status'=> true, 'data' => CryptoJsAes::encrypt($v, $this->_encpassword) ]);exit;
        } catch (Exception $e) {
            return $this->catchMyError($e);
        }
    }


    function print_arr($arr, $param='', $param2=''){            
        if($param && $param2){
            foreach ($arr as $key => $value) {              
                echo $value[$param];echo '<br>';
                echo $value[$param2];echo '<br>';
            }
            return;
        }

        if($param){
            foreach ($arr as $key => $value) {              
                echo $value[$param];echo '<br>';                
            }
            return;
        }

        foreach ($arr as $key => $value) {
            print_r($value);echo '<br>';
        }
    }

    // function transactions_ajax_old_Del() {
    //  try {           
        
    //      if(!$user_id = $this->session->userdata('user_id'))
    //      {   
    //          $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
    //          redirect(base_url());
    //      }
    //      $unique_id = user_id_to_unique_id($user_id);
    //      // $data = $this->site_common();
    //      $trans = [];
    //      $cond = array('user_id' => $user_id, 'user_status' => 'Completed','status'=> 'Completed');
    //      $trans_select="unique_id,type,datetime,amount,local_transaction_id,status,unique_id as transaction";
    //      $income_select="level,timestamp,price,local_transaction_id,unique_id,unique_id as income";
    //      $x2_gp_select="profit,timestamp,local_transaction_id,unique_id,unique_id as x2_p";
    //      $x2_gs_select="sponsor,timestamp,local_transaction_id,unique_id,unique_id as x2_s";
    //      $x4_gp_select="profit,timestamp,local_transaction_id,unique_id,unique_id as x4_p";
    //      $x4_gs_select="timestamp,local_transaction_id,unique_id,unique_id as x4_s";
    //      $data['transactions_arr'] = $this->com_m->getTableData('transactions', $cond, $trans_select)->result_array();                       
    //      $data['packageIncome'] = $this->db->select($income_select)->get_where('package_level_income_payment', ['unique_id' => $unique_id,'utype' => '2'])->result_array();
    //      $data['xx2_profit'] = $this->db->select($x2_gp_select)->get_where('global_profit', ['unique_id' => $unique_id])->result_array();
    //      $data['xx2_sponsor'] = $this->db->select($x2_gs_select)->get_where('global_profit', ['sponsor_user_id' => $user_id])->result_array();
    //      $data['xx4_profit'] = $this->db->select($x4_gp_select)->get_where('global_4x_profit', ['unique_id' => $unique_id])->result_array();
    //      $data['xx4_sponsor'] = $this->db->select($x4_gs_select)->get_where('global_4x_profit', ['sponsor_user_id' => $user_id])->result_array();
    //      echo '<pre>';print_r($data);exit;
    //      $this->load->view('front/user/transaction_history_ajax', ($data));
    //  } catch (Exception $e) {
    //      return $this->catchMyError($e);
    //  }
    // }

    function transaction_details($local_transaction_id){
        try {           
        
            if(!$user_id = $this->session->userdata('user_id'))
            {   
                $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
                redirect(base_url());
            }
            $unique_id = user_id_to_unique_id($user_id);
            $data = $this->site_common();           
            
            $local_transaction_id = decryptIt($local_transaction_id);
            $cond = array('user_id' => $user_id, 'local_transaction_id' => $local_transaction_id);

            $data['transaction'] = $this->com_m->getTableData('transactions', $cond)->row();

            $data['dig_currency'] = $this->common_model->getTableData('currency', array('status' => 1,'type'=>'digital'), '', '', '', '', '', '', array('id', 'ASC'))->row();
            $data['coin_address'] = getAddress($user_id, $data['dig_currency']->id);
            // echo "<pre>";print_r($data['transaction']);die;
            $this->load->view('front/user/transaction_details', ($data));
        } catch (Exception $e) {
            return $this->catchMyError($e);
        }
    }

    // function transactions_old(){
    //  try {           
        
    //      if(!$user_id = $this->session->userdata('user_id'))
    //      {   
    //          $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
    //          redirect(base_url());
    //      }
    //      $unique_id = user_id_to_unique_id($user_id);
    //      $data = $this->site_common();           
    //      $cond = array('user_id' => $user_id);

    //      $data['transactions_arr'] = $this->com_m->getTableData('transactions', $cond)->result_array();                      
    //      $data['packageIncome'] = $this->db->select('*')->get_where('package_level_income_payment', ['unique_id' => $unique_id,'utype' => '2'])->result_array();
    //      $data['xx2_profit'] = $this->db->select('*')->get_where('global_profit', ['unique_id' => $unique_id])->result_array();
    //      $data['xx2_sponsor'] = $this->db->select('*')->get_where('global_profit', ['sponsor_user_id' => $user_id])->result_array();
    //      $data['xx4_profit'] = $this->db->select('*')->get_where('global_4x_profit', ['unique_id' => $unique_id])->result_array();
    //      $data['xx4_sponsor'] = $this->db->select('*')->get_where('global_4x_profit', ['sponsor_user_id' => $user_id])->result_array();

    //      $this->load->view('front/user/transactions', ($data));
    //  } catch (Exception $e) {
    //      return $this->catchMyError($e);
    //  }
    // }


    function get_past_transaction(){
        // Deposite & withdraw list
        try {
            
          $this->via_valid_sess_and_ajax_user();
          $user_id = $this->session->userdata('user_id');
          $user_id = 2037;
          $limit = escape_str($this->input->post('limit'));
          $start = escape_str($this->input->post('start'));

          $get_trans_over_all = $this->com_m->getTableData('transactions',['user_id' => $user_id],'','','','','','','',['trans_id', 'desc']);
          $get_trans = $this->com_m->getTableData('transactions',['user_id' => $user_id],'','','','',$start,$limit,['trans_id', 'desc']);
          $data['get_transactions_arr'] = $get_trans->result_array();
          // $data['get_transactions_over_all_count'] = $get_trans_over_all->result_ar();
            $get_transactions_view = $this->load->view('front/user/transaction_history_ajax', $data, true);
            echo json_encode(['status'=> true, 'data' => $get_transactions_view, 'over_all' => $get_transactions_over_all_count ]);exit;
        } catch (Exception $e) {
            return $this->catchMyError($e);
        }
    }


    // function transaction_search_filter(){
    //  try {

    //    $this->via_valid_sess_and_ajax_user();
    //    $user_id = $this->session->userdata('user_id');

    //    $limit = escape_str($this->input->post('limit'));
    //    $start = escape_str($this->input->post('start'));
    //    $keyword = escape_str($this->input->post('search'));  

    //    $table = 'transactions';
    //    $cond = ['user_id' => $user_id ];


    //    $condition = ['user_id' => $user_id ];
    //    $this->db->order_by("trans_id", "desc");
    //    if($keyword){
    //        $this->db->group_start();
    //        $this->db->or_where('unique_id', $keyword);
    //        $this->db->or_where('type', $keyword);
    //        $this->db->or_where('fiat_amount', $keyword);
    //        $this->db->group_end();
    //    }       
    //    $get_transactions_over_all_count = $this->db->get_where($table,$condition)->num_rows();
    //    // echo $this->db->last_query();exit;
          

    //    $this->db->order_by("trans_id", "desc");
    //    if($keyword){
    //        $this->db->group_start();
    //        $this->db->or_where('unique_id', $keyword);
    //        $this->db->or_where('type', $keyword);
    //        $this->db->or_where('fiat_amount', $keyword);
    //        $this->db->group_end();
    //    }       
    //    $this->db->limit($start, $limit);
    //    $get_trans = $this->db->get_where($table, $condition);
    //    // echo $this->db->last_query();exit;

    //       $data['get_transactions_arr'] = $get_trans->result_array();

    //       $get_transactions_view = $this->load->view('front/user/transaction_history_ajax', $data, true);
    //      echo json_encode(['status'=> true, 'data' => $get_transactions_view, 'over_all' => $get_transactions_over_all_count ]);exit;
    //  } catch (Exception $e) {
    //      return $this->catchMyError($e); 
    //  }
    // }


    // BY BALA 23-04-2022
    function wallet_transfer(){

        if(!$user_id = $this->session->userdata('user_id'))
        {   
            $this->session->set_flashdata('success', $this->lang->line('you are not logged in'));
            redirect(base_url());
        }
        
        $wallet_table = 'wallet_transfer';
        if($this->input->post()){
            $this->via_valid_sess_and_ajax_user();

            $this->db->trans_start();
            $to_unique_id=escape_str($this->input->post('user_id',true));
            $amount=escape_str($this->input->post('amount',true));
            $get_balance=get_pym_Balance($user_id);
            $get_balance_only=get_pym_Balance_only($user_id);
            $get_from_transfer = get_transfer_Balance($user_id);
            
            if(($amount <= 0)){
                echo json_encode(['status' => false, 'msg' => 'This field is required!.' ]);exit();
            }

            if(($this->input->post('type')==0) && ($get_balance <= 0)){
                echo json_encode(['status' => false, 'msg' => 'Insufficient Balance' ]);exit();
            }

            if($amount <= $get_from_transfer){
                // $update_from_balance=($get_balance - $amount);
                $update_from_transfer_balance=($get_from_transfer - $amount);
                $flag = 'transfer';
            }else if($amount >= $get_from_transfer){
                                          // 12-15  = -3
                                          // 20-(-3)= 23
                $from_transfer_balance = $get_from_transfer - $amount;                
                $update_from_transfer_balance=($get_balance_only - abs($from_transfer_balance));
                $flag = 'mainbalance';
            }            

            $to_user_id= unique_id_to_user_id($to_unique_id);                        
            $get_to_transfer = get_transfer_Balance($to_user_id);            
            $update_to_transfer_balance_pair=( $get_to_transfer + $amount );

            $data=array(
                'amount'=> $amount,
                'sender_id'=>$user_id,               
                'unique_id'=> user_id_to_unique_id($user_id),
                'receiver_id'=> $to_user_id,                
                'sender_previous_amount'=> $get_balance,
                'receiver_previous_amount'=> $get_to_transfer,
                'datetime'  => date('Y-m-d H:i:s'),              
                'timestamp' => time(),
                'send_fname'    => ($sname = user_id_to_fname($user_id)) ? $sname : '',
                'receive_fname' => ($rname = user_id_to_fname($to_user_id)) ? $rname : '',
                'ip_address' => get_client_ip(),
                'local_transaction_id' => generate_local_transaction_id()
            );

            if($this->input->post('type')==1){
                    // Receiver request
                $data['type']   = 'request';
                $result=$this->com_m->insertTableData($wallet_table, $data);
                $this->db->trans_complete();
                $msg = "Successfully amount requested!.";               
            }else{
                $data['type']   = 'send';
                $result=$this->com_m->insertTableData($wallet_table, $data);                
                if($flag == 'transfer'){
                    update_transfer_Balance($user_id, $update_from_transfer_balance);
                }else if($flag == 'mainbalance'){
                    $from_transfer_balance = $from_transfer_balance >= 0 ? $from_transfer_balance : 0;                    
                    update_transfer_Balance($user_id, $from_transfer_balance);
                    update_pym_Balance($user_id, $update_from_transfer_balance);
                }                   
                update_transfer_Balance($to_user_id, $update_to_transfer_balance_pair);
                $this->db->trans_complete(); 
                if($result){
                    $msg = "Successfully amount tranfered";
                }else{
                    $msg = "Transactions error";
                }
            }

            if($result){                 
                $bal = get_pym_Balance($user_id);               
                $history['peer_peer_trans_history_obj'] = $this->db->get_where($wallet_table,['id' => $result ])->result();
                $current_history = $this->load->view('front/user/transfer_history_ajax',$history, true);
                echo json_encode(['status' => true, 'balance' => $bal, 'format_balance' => number_format($bal, 2),'msg' => $msg, 'current_history' => $current_history ]);exit();
            }else{
                echo json_encode(['status' => false]);exit();
            }
            exit;
        }
        $data = $this->site_common();       
        $check_balance = $this->common_model->getTableData('wallet',array('user_id'=>$user_id))->row();
        $get_balance = $this->common_model->getTableData('wallet',array('user_id'=>$user_id))->row();
        $data['user_balance']=get_pym_Balance($user_id);
        // $data['peer_peer_trans_history_obj'] = $this->db->order_by('id','desc')->group_start()->or_where('sender_id', $user_id)->or_where('receiver_id', $user_id)->group_end()->get($wallet_table)->result();       
        $this->load->view('front/user/transfer',$data);
    }



    function transfer_ajax() {
        try {           
            $this->via_valid_sess_and_ajax_user();
            $user_id = $this->session->userdata('user_id'); 
            $wallet_table = 'wallet_transfer';      
            $tdata['peer_peer_trans_history_obj'] = $this->db->order_by('id','desc')->group_start()->or_where('sender_id', $user_id)->or_where('receiver_id', $user_id)->group_end()->get($wallet_table)->result();
            $v = $this->load->view('front/user/transfer_history_ajax', $tdata, true);
            echo json_encode(['status'=> true, 'data' => CryptoJsAes::encrypt($v, $this->_encpassword) ]);exit;
        } catch (Exception $e) {
            return $this->catchMyError($e);
        }
    }



    function get_user_transfer_detail(){
        try {    
            $dummyuserImg = dummyuserImg();
            $container_arr = array();
            $this->via_valid_sess_and_ajax_user();
            $user_id = $this->session->userdata('user_id');
            $this->form_validation->set_rules('user_id', 'reference code', 'trim|required|xss_clean');          
            if ($this->form_validation->run() == FALSE){
                $errors = validation_errors();
                echo json_encode(['status'=> false, 'msg' => $errors]);exit;
            }
            $user_reference_id = escape_str($this->input->post('user_id',true));            
            // check same id or not
            if(unique_id_to_user_id($user_reference_id) == $user_id){
                $output = ['status' => false, 'msg' => '<div class="error" >Same User ID!.</div>' ];
                echo json_encode($output);exit;
            }

            if(!$this->com_m->get_row_counter('users', array('unique_id' => $user_reference_id, 'verified' => '1'))){
                $output = ['status' => false, 'msg' => '<div class="error" >Inactivated User ID!.</div>' ];
                echo json_encode($output);exit;
            }
            if($pro = unique_id_to_user_id($user_reference_id,true)){
                $prefix = get_prefix();
                $fname = $pro[$prefix.'fname'];
                $lname = $pro[$prefix.'lname'];
                $pp    = $pro['profile_picture'];
                $container_arr['username'] = ($lname) ? $fname.' '. $lname : $fname;
                $container_arr['pp'] = ($pp) ? $pp : $dummyuserImg;
                if($container_arr){
                    $output = ['status' => true, 'data' => $container_arr ];
                    echo json_encode($output);exit;
                }
            }


            $output = ['status' => false, 'msg' => '<div class="error" >Invalid User ID!.</div>' ];
            echo json_encode($output);exit;
        } catch (Exception $e) {            
            return $this->catchMyError($e);
        }


    }

    function ci_info(){

        echo '<pre>';print_r($this->session->all_userdata());echo '<hr>';
        echo '<pre> PHP FUNCTION<br>';
        print_r(get_defined_functions());
        echo '<hr> GET ALL CI CLASS<br>';
        print_r(get_declared_classes());
        echo '<hr> GET ALL PHP VARIABLE <br>';
        print_r(get_defined_constants());
        echo '<hr> PRINT THIS KEY<br>';
        print_r($this);
        echo '<hr> DATABASE <hr>';
        $tables = $this->db->list_tables();
            foreach ($tables as $table)
            {
                    echo $table.'<br>';
            }
        echo '<hr> MY CONTROLLER';  
        $this->load->library('ControllerList');
        print_r($this->controllerlist->getControllers());
        echo '<hr>';
        $enc = $this->input->post_get('enc');
        if($enc){
            echo encryptIt($enc);
        }

        $dec = $this->input->post_get('dec');
        if($dec){
            echo decryptIt($dec);   
        }
    }



    function liveprice_update()
    {
        $headers = [
        'Accept:application/json',
        'x-api-key:r88Re4ve0tbEwViikHeVYKrHCUcXfHHJPBaj1ZY0Wg6a0EXRxfy98zR8fxwzraBt'
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://deep-index.moralis.io/api/v2/erc20/0x45FFdc0350b498D994b12E400705d10680dCA00E/price?chain=bsc");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        // curl_setopt($ch, CURLOPT_CAINFO,'/var/www/html/ixtoken/cert/bundlepaypeaks.crt');
        $response = curl_exec($ch);
        curl_close($ch);
        $data = json_decode($response); 

        if(!empty($data->nativePrice)) {

            $con_price = $data->nativePrice->value;
            $decimals = $data->nativePrice->decimals;
            $decimal_places = coin_decimal($decimals);
            $price = floatval($con_price) / floatval($decimal_places);
            echo $con_price.'<br>';
            echo $decimal_places.'<br>';
            // echo $price.'<br>';
            echo sprintf("%.9f", $price)."<br/>";
            $token_price = sprintf("%.9f", $price);
            echo $token_price."<br/>";
            $updateData = array('token_price' => $token_price);
            $this->common_model->updateTableData('site_settings', array('id'=>1), $updateData);
            die;
        }

    }   



function update_reward(){
    try {
        
        $this->via_valid_sess_and_ajax_user();
        $user_id = $this->session->userdata('user_id');
        $data = [];
        $unique_id = user_id_to_unique_id($user_id);
        $cond = array('rewards_status' => '1', 'unique_id' => $unique_id);
        
        $this->com_m->updateTableData('package_payment', $cond, ['rewards_status' => '0']);
        $this->com_m->updateTableData('package_4x_payment', $cond, ['rewards_status' => '0']);

        $xx2 = $this->common_model->getTableData('package_payment', $cond, "sum(rewards) as r1")->row('r1');
        $xx4 = $this->common_model->getTableData('package_4x_payment', $cond, "sum(rewards) as r2")->row('r2');         
        $data['packages_rewards'] = $x2 = $xx2 + $xx4;          
        $cond = array('rewards_status' => '0', 'unique_id' => $unique_id);
        $xx2 = $this->common_model->getTableData('package_payment', $cond, "sum(rewards) as r1")->row('r1');
        $xx4 = $this->common_model->getTableData('package_4x_payment', $cond, "sum(rewards) as r2")->row('r2');
        $data['unclaimed_packages_rewards'] = $x4 = $xx2 + $xx4;
        
        $data['total_rewards'] = $x4 + $x2;

        echo json_encode([ 'status' => true, 'data' => $data]);
    } catch (Exception $e) {
        return $this->catchMyError($e);
    }
}


  function signup_new(){
      
        $user_id=$this->session->userdata('user_id');
        if($user_id!="")
        {   
            front_redirect('dashboard', 'refresh');
        }


  
        if($ref = $this->input->get('ref',true)){   
            $user_id = unique_id_to_user_id($ref);      
            if($this->com_m->get_row_counter('users',['id' => $user_id, 'rebirth_status' => '0' ]) == 1){}else{
                $this->session->set_flashdata('error', 'Invalid reference id');
                redirect('signup','refresh');
            }   
        }
  
        $prefix=get_prefix();
        $data['site_common'] = site_common();       
        if($data['site_common']['site_settings']->newuser_reg_status==0){           
            front_redirect('/', 'refresh');
        }

        // echo 'IAMHERE';exit;

        if($ref = $this->input->get('ref',true)){    
         $user_id = unique_id_to_user_id($ref);      
         if($this->com_m->get_row_counter('package_4x_payment',['user_id' => $user_id ]) == 1){}else{
             $this->session->set_flashdata('error', 'Invalid reference id');
             redirect('register','refresh');
         }   
        }        

        $data['meta_content'] = $this->common_model->getTableData('meta_content',array('link'=>'signup'))->row();
        $newuser_reg_status = getSiteSettings('newuser_reg_status');
        $user_id = $this->session->userdata('user_id');
        if($user_id!="" || $newuser_reg_status==0)
        {               
            front_redirect('dashboard', 'refresh');
        }   

        if($this->input->post())
        {   
            try {

                // if($parent = $this->input->post('parent', true)!=REGISTER_VAR){
                //  $this->form_validation->set_rules('parent', 'Referal Code', 
                //              'trim|__is_available_referal_code['.$prefix.'users.unique_id]|xss_clean', 
                //              array('__is_available_referal_code' => 'The %s is invalid code 123'));  
                // }


                // $this->form_validation->set_rules('parent', 'Referal Code', 
                //              'trim|required|callback_valid_unique_id', 
                //              array('__is_available_referal_code' => 'The %s is invalid code 69867'));

                $this->form_validation->set_rules('first_name', 'Username', 'trim|required|xss_clean');
                $this->form_validation->set_rules('tenrealm_email', 'Email Address', 'trim|required|xss_clean');
                $this->form_validation->set_rules('tenrealm_password', 'Password', 'trim|required|xss_clean');
            //  $this->form_validation->set_rules('beb_address', 'Beb Address', 'trim|required|xss_clean');
                $this->form_validation->set_rules('phone', 'phone', 'trim|required|xss_clean');
                //$this->form_validation->set_rules('beb_address', 'Beb Address', 'trim|required|xss_clean');
                
                if ($this->form_validation->run())
                {                   
                    $email = $this->db->escape_str(lcfirst($this->input->post('tenrealm_email',TRUE)));
                    $password = $this->db->escape_str($this->input->post('tenrealm_password',TRUE));
                    $uname = $this->db->escape_str($this->input->post('first_name',TRUE));
                    // $check=checkSplitEmail($email);
                    
                    // $check1=$this->common_model->getTableData('users',array($prefix.'username'=>$uname));
                    // if($check)
                    // {                    
                    //  $this->session->set_flashdata('error',$this->lang->line('Entered Email Address Already Exists'));
                    //  front_redirect('signup', 'refresh');
                    // }
                    // else
                    // {    
                        // $this->db->trans_start();                    
                        // All constraint success
                        if(!$this->input->post('parent', true) OR $parent = $this->input->post('parent', true)==REGISTER_VAR){
                            // Without reference
                            $this->register_insert();
                        }else{

                            $beb_address = $this->db->escape_str($this->input->post('beb_address',TRUE));
                            // With referral
                            $this->register_insert();
                        }
                        // $this->db->trans_complete();
                        
                    // }
                }
            } catch (Exception $e) {
             // this will not catch DB related errors. But it will include them, because this is more general.                      
                $message = $e->getMessage();
                $search = 'Duplicate entry ';
                if(preg_match("/{$search}/i", $message)) {              
                    $this->register_insert();
                }               
                $this->session->set_flashdata('error',$e->getMessage());
                front_redirect(current_url(), 'refresh');
            }

        }

        $data['countries'] = $this->common_model->getTableData('countries')->result();
        $data['site_common'] = site_common();
        $data['action'] = front_url() . 'signup';   
        $this->load->view('front/emesh/signup', $data);

   }


  function signin(){
      
      
      
//$this->load->library('email');
//$config = Array(
              //  'protocol' => 'mail',
             //   'smtp_host' => 'smtp.googlemail.com',
            //    'smtp_port' => 587,
            //    'smtp_user' => 'alivejesusalive@gmail.com', // your email
            //    'smtp_pass' => 'Viva@123', // your password
            //    'smtp_timeout'=>20,
             //   'mailtype' => 'text',
             //   'charset' => 'iso-8859-1',
              //  'newline'=>"\r\n",
            //    'wordwrap' => TRUE
            //  );
 //$this->email->set_newline("\r\n"); 
 //$this->email->initialize($config);
 //$this->email->from('alivejesusalive@gmail.com');
 //$this->email->to('balabkcs7@gmail.com');
 //$this->email->subject('Email Test');
 //$this->email->message('Testing the email class.');  
// $this->email->send();
 // $this->email->print_debugger();

        $user_id=$this->session->userdata('user_id');
        if($user_id)
        {   
            front_redirect('dashboard');
        }
        $data['site_common'] = site_common();
        $static_content  = $this->common_model->getTableData('static_content',array('english_page'=>'home'))->result();
        $data['meta_content'] = $this->common_model->getTableData('meta_content',array('link'=>'login'))->row();
        $data['action'] = front_url() . 'login_user';       
        $this->load->view('front/emesh/signin', $data);

  }

  function widthdraw_history(){
 $user_id=$this->session->userdata('user_id');
 $data['result']  = $this->common_model->getTableData('deposit_verify',array('user_id'=>$user_id))->result();

$this->load->view('front/user/withdraw_history', $data);

  }



}