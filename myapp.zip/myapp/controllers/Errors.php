<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// Error controller
// This controller is used to manage the errors (404)
class Errors extends CI_Controller 
{

	function __construct() 
	{
	    parent::__construct(); 
        $this->load->model('common_model');
	} 

    // Main controller for the contact form
    function error404()
    {
        // Create your custom controller

        // Display page
        $this->output->set_status_header('404'); 
        // $this->load->view('templates/header');
        $data['site_common']  =   site_common();
        $this->load->view('errors/error404', $data);
        // $this->load->view('templates/footer');
        // echo $ci->output->get_output();
        // exit(4);
    }
}