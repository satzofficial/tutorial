<?php defined('BASEPATH') OR exit('No direct script access allowed');
class MY_Controller extends CI_Controller{
	public $outputData;

	public function __construct(){
		parent::__construct();
		$user_id=$this->session->userdata('user_id');
		 $this->load->model('user_model');
		// $currency_sym = array('LTC');
		// $whers_in = array('currency_symbol', $currency_sym);
		// $this->outputData['digital_currency'] = $this->common_model->getTableData('currency',array('type'=>'digital'),'','','','','','','','','',$whers_in)->result();
		// $bankwire = $this->common_model->getTableData('user_bank_details',array('user_id'=>$user_id))->row();

		// if(!empty($bankwire)) {
		// 	$this->outputData['bankwire'] = $bankwire;
		// }
		// $url = file_get_contents("https://min-api.cryptocompare.com/data/pricemulti?fsyms=BTC&tsyms=EUR&api_key=a2ae4b9817a848ef5d2311a115856baa97c65d15a8b3e41cb4abf2295ed4d1aa");
  //       $res = json_decode($url,true); 
  //       $this->outputData['tradepair_info'] = $this->common_model->getTableData('trade_pairs',array('id'=>7))->result();	
  //       $this->outputData['btc_makerfee'] = getfeedetails_buy(7);
  //       $this->outputData['btc_takerfee'] = getfeedetails_sell(7);
		// // print_r($res['BTC']['EUR']);die;
		// $this->outputData['btc_marketprice'] = $res['BTC']['EUR'];
	}


	function coin_price_conversion($from_coin_symbol='USD',$to_coin_symbol='LTC')
    {
        $url = "https://min-api.cryptocompare.com/data/price?fsym=".$from_coin_symbol."&tsyms=".$to_coin_symbol."&api_key=".CRYPTO_COMPARE_CURRENCY_CONVERSION_API;
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$result = curl_exec($ch);		
		$res = json_decode($result);		
		return ($res->$to_coin_symbol) ? $res->$to_coin_symbol : 0;
    }

	protected function secure_user_deposit(){
		$user_id=$this->session->userdata('user_id');		
		if(!$user_id)
		{	
			front_redirect('/', 'refresh');
		}
		$get_api_value_json_obj = json_decode(curl_get_contents(CURRENCY_MARKET_MAP_API));		
		if($get_api_value_json_obj){
			$data['usd'] = $get_api_value_json_obj->litecoin->usd;
			$data['usd_market_cap'] = $get_api_value_json_obj->litecoin->usd_market_cap;
			$data['usd_24h_vol'] = $get_api_value_json_obj->litecoin->usd_24h_vol;
			$data['usd_24h_change'] = $get_api_value_json_obj->litecoin->usd_24h_change;			
		}		

		// $data['current_pym_price'] = get_pym_Balance($user_id);
		$data['site_common'] = site_common();
		$data['users'] = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
		$this->load->view('front/user/payment', $data);		
	}

	protected function select_package(){				
		if(!$user_id=$this->session->userdata('user_id'))
		{	
			front_redirect('/', 'refresh');
		}
		$data['packages'] = $this->common_model->getTableData('package',array('status'=>1))->result_array();		
		$data['users'] = $this->common_model->getTableData('users',array('id'=>$user_id))->row();
		$data['site_common'] = site_common();
		$this->load->view('front/user/packages', $data);
	}
	


	protected function getCommissionLevel($current_node_id, $user_id, $current_package, $level){
		return getCommissionLevel($current_node_id, $user_id, $current_package, $level);
		// return getAutopull($current_node_id, $user_id);
		// rebirth4X($current_node_id, $current_package,  $auto_upgrade=0);
		// user_upline_team_level($current_node_id, $current_node_id, $level=1);
		// return true;
	}


	public function second_test_db()
	{
		
		$second_DB = $this->load->database('anotherdb', TRUE); 
		$query2 = $second_DB->get("tree_entry_lang");
		echo '<pre>';print_r($query2->result());
		exit;
	}

	function sendMail($to = '', $from_email = '', $from_name = '', $email_template = '',$special_vars = array(), $cc = '', $bcc = '', $type = 'html' ) 
	{
		try {
			
		// return true;
		// Loads the email library
		// $this->load->library(array('email'));
		$this->load->library('email');

		$emailConfig = $this->db->where('id', 1)->get('site_settings')->row(); // Fetch from DB
		//$admindetails = $this->db->where('id', 1)->get('users')->row(); // Fetch from DB		
		$smtp_host = decryptIt($emailConfig->smtp_host);// SMTP host URL
		$smtp_port = decryptIt($emailConfig->smtp_port);// SMTP port number
		$smtp_user = decryptIt($emailConfig->smtp_email);// SMTP email address
		$smtp_pass = decryptIt($emailConfig->smtp_password); //exit; // SMTP password	

		$special_vars['###COPYRIGHT###'] = $emailConfig->english_copy_right_text;
		$special_vars['###ADDRESS###'] = $emailConfig->english_address.','.$emailConfig->english_city.','.$emailConfig->english_state.','.$emailConfig->english_country.','.$emailConfig->english_zip;
		$special_vars['###SITEEMAIL###'] = $emailConfig->site_email;
		$special_vars['###SITELOGO###'] = getSiteLogo();
		$special_vars['###SITENAME###'] = $emailConfig->english_site_name;
		$special_vars['###SITELINK###'] = base_url();
		$special_vars['###ABOUTUS###'] = base_url().'home#about-bg';
		$special_vars['###PRIVACY###'] = base_url().'cms/privacy-policy';
		$special_vars['###TERMS###'] = base_url().'cms/terms-and-conditions';
		$special_vars['###CONTACTUS###'] = base_url().'contact_us';

		// echo "<pre>";print_r($special_vars);die; 
  
        /* Edited by Manimegs */
		if($emailConfig->facebooklink!='')
		{
			$fblink = $special_vars['###FACEBOOKLINK###'] = $emailConfig->facebooklink;
			$fbimag = $special_vars['###FACEBOOKIMAGE###'] = "https://res.cloudinary.com/spiegel/image/upload/v1605850139/intozvq0177rftxsbhob.png";

			$special_vars['<td>###FBMODEL###</td>'] = '<td class="img" width="55" style="font-size:0pt; line-height:0pt; text-align:left;"><a href="'.$fblink.'" target="_blank"><img width="34" height="34" border="0" alt="" src="'.$fbimag.'" /></a></td>';
		}
		else
	    {
	    	$special_vars['<td>###FBMODEL###</td>'] = '';
	    }
		if($emailConfig->twitterlink!='')
		{
			$twlink = $special_vars['###TWITTERLINK###'] = $emailConfig->twitterlink;
			$twimag = $special_vars['###TWITTERIMAGE###'] = "https://res.cloudinary.com/spiegel/image/upload/v1605850139/ly7jiql3qwkampbfkx3e.png";

			$special_vars['<td>###TWITMODEL###</td>'] = '<td class="img" width="55" style="font-size:0pt; line-height:0pt; text-align:left;"><a href="'.$twlink.'" target="_blank"><img width="34" height="34" border="0" alt="" src="'.$twimag.'" /></a></td>';
		}
		else
	    {
	    	$special_vars['<td>###TWITMODEL###</td>'] = '';
	    }
	    
	    if($emailConfig->telegramlink!='')
	    {
			$tellink = $special_vars['###TELEGRAMLINK###'] = $emailConfig->telegramlink;
			$telimag = $special_vars['###TELEGRAMIMAGE###'] = "https://res.cloudinary.com/spiegel/image/upload/v1605850139/tt6v6fgy5hoycn9uwp5f.png";

			$special_vars['<td>###TELEMODEL###</td>'] = '<td class="img" width="55" style="font-size:0pt; line-height:0pt; text-align:left;"><a href="'.$tellink.'" target="_blank"><img width="34" height="34" border="0" alt="" src="'.$telimag.'" /></a></td>';
	    }
	    else
	    {
	    	$special_vars['<td>###TELEMODEL###</td>'] = '';
	    }
	    if($emailConfig->googlelink!='')
	    {
			$goolink = $special_vars['###GOOGLELINK###'] = $emailConfig->googlelink;
			$gooimag = $special_vars['###GOOGLEIMAGE###'] = "https://res.cloudinary.com/spiegel/image/upload/v1605850140/nsneghfafa2wtygh23ca.png";

			$special_vars['<td>###GOOGLEMODEL###</td>'] = '<td class="img" width="55" style="font-size:0pt; line-height:0pt; text-align:left;"><a href="'.$goolink.'" target="_blank"><img width="34" height="34" border="0" alt="" src="'.$gooimag.'" /></a></td>';
	    }
	    else
	    {
	    	$special_vars['<td>###GOOGLEMODEL###</td>'] = '';
	    }
	    if($emailConfig->youtube_link!='')
	    {
			$youlink = $special_vars['###YOUTUBELINK###'] = $emailConfig->youtube_link;
			$youimag = $special_vars['###YOUTUBEIMAGE###'] = "https://res.cloudinary.com/spiegel/image/upload/v1605850140/rmageljnvvx7at2amdxd.png";

			$special_vars['<td>###YOUMODEL###</td>'] = '<td class="img" width="55" style="font-size:0pt; line-height:0pt; text-align:left;"><a href="'.$youlink.'" target="_blank"><img width="34" height="34" border="0" alt="" src="'.$youimag.'" /></a></td>';
	    }
	    else
	    {
	    	$special_vars['<td>###YOUMODEL###</td>'] = '';
	    }
	    
	    if($emailConfig->linkedin_link!='')
	    {
			$linklink = $special_vars['###LINKEDINLINK###'] = $emailConfig->linkedin_link;
			$linkimag = $special_vars['###LINKEDINIMAGE###'] = "https://res.cloudinary.com/spiegel/image/upload/v1605850139/araz3ba7rerveqymitvz.png";

			$special_vars['<td>###LINKMODEL###</td>'] = '<td class="img" width="55" style="font-size:0pt; line-height:0pt; text-align:left;"><a href="'.$linklink.'" target="_blank"><img width="34" height="34" border="0" alt="" src="'.$linkimag.'" /></a></td>';
	    }
	    else
	    {
	    	$special_vars['<td>###LINKMODEL###</td>'] = '';
	    }
	    
	    if($emailConfig->instagram_link!='')
	    {
			$instalink = $special_vars['###INSTAGRAMLINK###'] = $emailConfig->instagram_link;
			$instaimag = $special_vars['###INSTAGRAMIMAGE###'] = "https://res.cloudinary.com/spiegel/image/upload/v1605850139/ytwtj8ctbilacom93lxm.png";

			$special_vars['<td>###INSTAMODEL###</td>'] = '<td class="img" width="55" style="font-size:0pt; line-height:0pt; text-align:left;"><a href="'.$instalink.'" target="_blank"><img width="34" height="34" border="0" alt="" src="'.$instaimag.'" /></a></td>';
	    }
	    else
	    {
	    	$special_vars['<td>###INSTAMODEL###</td>'] = '';
	    }

	    if($emailConfig->pinterest_link!='')
	    {
			$pinlink = $special_vars['###PINTERESTNLINK###'] = $emailConfig->pinterest_link;
			$pinimag = $special_vars['###PINTERESTIMAGE###'] = "https://res.cloudinary.com/spiegel/image/upload/v1605850241/ak8m7vtewpmzj7bujhbt.png";

			$special_vars['<td>###PINMODEL###</td>'] = '<td class="img" width="55" style="font-size:0pt; line-height:0pt; text-align:left;"><a href="'.$pinlink.'" target="_blank"><img width="34" height="34" border="0" alt="" src="'.$pinimag.'" /></a></td>';
	    }
	    else
	    {
	    	$special_vars['<td>###PINMODEL###</td>'] = '';
	    }

	    if($emailConfig->dribble_link!='')
	    {
			$driblink = $special_vars['###DRIBBLELINK###'] = $emailConfig->dribble_link;
			$driblimag = $special_vars['###DRIBBLEIMAGE###'] = "https://res.cloudinary.com/spiegel/image/upload/v1605850140/xbsz5ghte4bkkg2kbyjp.png";
			$special_vars['<td>###DRIBMODEL###</td>'] = '<td class="img" width="55" style="font-size:0pt; line-height:0pt; text-align:left;"><a href="'.$driblink.'" target="_blank"><img width="34" height="34" border="0" alt="" src="'.$driblimag.'" /></a></td>';
	    }
	    else
	    {
	    	$special_vars['<td>###DRIBMODEL###</td>'] = '';
	    }
        
		$from_email = decryptIt($emailConfig->smtp_email);
		if($from_name == '')
		$from_name = $emailConfig->english_site_name;
		$this->email->clear();
		$config = array(
		'protocol' => 'smtp',
		'smtp_host' => $smtp_host,
		'smtp_port' => $smtp_port,
		'smtp_user' => trim($smtp_user),
		'smtp_pass' => trim($smtp_pass),
		'mailtype' => $type,
		'charset' => 'utf-8',
		// 'charset' => 'iso-8859-1',
		// 'smtp_crypto' => 'ssl',
		// 'smtp_crypto' => 'tls',
		);
		$config['crlf'] = "\r\n";
		$config['newline'] = "\r\n";
		$config['priority'] = 1;

		$config = Array(
                'protocol' => 'mail',
                'smtp_host' => 'smtp.googlemail.com',
                'smtp_port' => 587,
                'smtp_user' => 'alivejesusalive@gmail.com', // your email
                'smtp_pass' => 'Viva@123', // your password
                'smtp_timeout'=>20,
                'mailtype' => $type,
                'charset' => 'iso-8859-1',
                'newline'=>"\r\n",
                'wordwrap' => TRUE
              );

		// Email config initialize
		$this->email->initialize($config);
		$this->email->set_newline("\r\n");
		$this->email->set_mailtype("html");


		// $config = Array(
		//                 'protocol' => 'mail',
		//                 'smtp_host' => 'smtp.googlemail.com',
		//                 'smtp_port' => 587,
		//                 'smtp_user' => 'alivejesusalive@gmail.com', // your email
		//                 'smtp_pass' => 'Viva@123', // your password
		//                 'smtp_timeout'=>20,
		//                 'mailtype' => $type,
		//                 'charset' => 'iso-8859-1',
		//                 'newline'=>"\r\n",
		//                 'wordwrap' => TRUE
		//               );
		//  $this->email->set_newline("\r\n"); 
		//  $this->email->initialize($config);
		//  $this->email->from('alivejesusalive@gmail.com');
		//  $this->email->to('sakthi@mailinator.com');
		//  $this->email->subject('Email Test');
		 
		
		if ( ! empty($smtp_host) && ! empty($smtp_port) && ! empty($smtp_user) && ! empty($smtp_pass)) 
		{ 
			if(is_numeric($email_template))	
				$emailTemplate = $this->db->where('id', $email_template)->get('email_template');
			else
				$emailTemplate = $this->db->where('name', $email_template)->get('email_template');


			if ($emailTemplate->num_rows() > 0) 
			{
				$emailTemplate = $emailTemplate->row();
				// Subject
				
					$subject = strtr($emailTemplate->english_subject, $special_vars);
					$message = strtr($emailTemplate->english_template, $special_vars);
						
				$this->email->to($to);
				$this->email->from($from_email,$from_name);
				if ($cc != '') 
				{
					$this->email->cc($cc);
				}
				if ($bcc != '') 
				{	
					$this->email->bcc($bcc);
				} 

				$this->email->subject($subject);
				$this->email->message($message);
				// $send=$this->email->send();	


				 $send = $this->email->send();
				 
				if (!$send) 
				{   
					
					switch (ENVIRONMENT)
					{
						case 'development':
							echo "<pre>"; print_r($this->email->print_debugger());
							error_reporting(1);
							ini_set('display_errors', 1);
							return 'Email is not sending';
						break;

						case 'testing':
						case 'production':
							ini_set('display_errors', 1);
							if (version_compare(PHP_VERSION, '5.3', '>='))
							{
								error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED & ~E_STRICT & ~E_USER_NOTICE & ~E_USER_DEPRECATED);
							}
							else
							{
								error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_USER_NOTICE);
							}
						break;

						default:
							header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
							echo 'The application environment is not set correctly.';
							exit(1); // EXIT_ERROR
					} 	
					echo "<pre>"; print_r($this->email->print_debugger());				
					return false;
				} 
				else 
				{
				    // mail sent
					return true;
				}
				return true;
			} 
			else 
			{
				exit('Email template not configured please contact support team');
			}	 
		} 
		else 
		{ 
			exit('SMTP not configured please contact support team');
		}
	}catch (Exception $e) {
		return $this->catchMyError($e);
	}

	}

}