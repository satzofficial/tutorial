<?php

defined('BASEPATH') || exit('No direct script access allowed');

class MY_Router extends CI_Router {

    function _set_request ($seg = array(2,3,4,5,6,7))
    {
        // The str_replace() below goes through all our segments
        // and replaces the hyphens with underscores making it
        // possible to use hyphens in controllers, folder names and
        // function names
        // print_r(str_replace('-', '_', $seg));
        parent::_set_request(str_replace('-', '_', $seg));
    }

}

?>