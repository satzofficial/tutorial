<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.1/css/lightbox.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.1/js/lightbox-plus-jquery.min.js"></script>
<div class="page-content-wrapper">
    <div class="page-content">
        <?php 
        $prefix = 'tenrealm_';
        $error = $this->session->flashdata('error');
        if($error != '') {
            echo '<div class="note note-danger">
            <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$error.'</div>';
        }
        
        $success = $this->session->flashdata('success');
        if($success) {
            echo '<div class="note note-success">
            <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$success.'</div>';
        } 
        ?>
        <div class="page-head">
            <!-- begin page-header -->
            <div class="page-title">
                <h1><?php if($this->uri->segment(3)=='') { echo ""; } else if($this->uri->segment(3)=='level') { echo "Level"; } else if ($this->uri->segment(3)=='x2_profit') { echo '2X Profit'; } else if($this->uri->segment(3)=='x2_sponsor') { echo '2X Sponsor'; } else if($this->uri->segment(3)=='auto_upgrade') { echo 'Auto Upgrade'; } else if($this->uri->segment(3)=='x4_profit') { echo '4X Profit'; } else if($this->uri->segment(3)=='x4_sponsor') { echo '4X Sponsor'; } ?> Management </h1>
            </div>
        </div>

        <ul class="page-breadcrumb breadcrumb">
            <li>
                <a href="<?php echo admin_url();?>">Home</a>
                <i class="fa fa-circle"></i>
            </li>
            <li class="active"><a href="javascript:;">Income</a></li>
        </ul>
        <!-- begin row -->
        <div class="row">
            <div class="col-md-12">
                <!-- begin panel -->
                <div class="portlet light">
                    <div class="portlet-title">
                        <div class="caption">
                            <span class="caption-subject bold uppercase font-green-haze">
                            <?php if($this->uri->segment(3)=='') { echo ""; } else if($this->uri->segment(3)=='level') { echo "Level"; } else if ($this->uri->segment(3)=='x2_profit') { echo '2X Profit'; } else if($this->uri->segment(3)=='x2_sponsor') { echo '2X Sponsor'; } else if($this->uri->segment(3)=='auto_upgrade') { echo 'Auto Upgrade'; } else if($this->uri->segment(3)=='x4_profit') { echo '4X Profit'; } else if($this->uri->segment(3)=='x4_sponsor') { echo '4X Sponsor'; } ?> Management</span>
                        </div>
                        <div class="tools">
                            <a href="javascript:;" class="collapse">
                            </a>
                            <a href="#portlet-config" data-toggle="modal" class="config">
                            </a>
                            <a href="javascript:;" class="reload">
                            </a>
                            <a href="javascript:;" class="fullscreen">
                            </a>
                            <a href="javascript:;" class="remove">
                            </a>
                        </div>
                    </div>
                    <?php if($view=='level')
                    { ?>
                        <div class="portlet-body">
                            <div class="clearfix">
                            </div>
                            <br/><br/>
                            <div class="table-responsive">
                                <table id="level_income" class="table table-striped table-bordered" id="level_income">
                                    <thead>
                                        <tr>
                                            <th class="text-center">S.No</th>
                                            <th class="text-center">Transaction id</th>
                                            <th class="text-center">From</th>
                                            <th class="text-center">To</th>
                                            <th class="text-center">Package</th>
                                            <th class="text-center">PYM</th>
                                            <th class="text-center">Date & Time</th>
                                        </tr>
                                    </thead>
                                    <tbody> </tbody>
                                </table>
                                
                            </div>
                        </div>
                    <?php }
                    else if($view=='system'){ ?>
                        <div class="portlet-body">
                          <div class="clearfix">
                          </div>
                          <br/><br/>
                          <div class="table-responsive">
                            <table id="system_level" class="table table-striped table-bordered" id="system_level">
                                <thead>
                                    <tr>
                                        <th class="text-center">S.No</th>
                                        <th class="text-center">Transaction id</th>
                                        <th class="text-center">From</th>
                                        <th class="text-center">Package</th>
                                        <th class="text-center">PYM</th>
                                        <th class="text-center">Date & Time</th>
                                    </tr>
                                </thead>
                                <tbody> </tbody>
                            </table>
                        </div>
                    </div>
                <?php } else if($view=='x2_profit'){ ?>
                    <div class="portlet-body">
                        <div class="clearfix">
                        </div>
                        <br/><br/>
                        <div class="table-responsive">
                            <table id="x2_profit" class="table table-striped table-bordered" id="x2_profit">
                                <thead>
                                    <tr>
                                        <th class="text-center">S.No</th>
                                        <th class="text-center">Transaction id</th>
                                        <th class="text-center">Username</th>
                                        <th class="text-center">Level</th>
                                        <th class="text-center">Package</th>
                                        <th class="text-center">Profit</th>
                                        <th class="text-center">Date & Time</th>
                                    </tr>
                                </thead>
                                <tbody> </tbody>
                            </table>
                        </div>
                    </div>

                 <?php } else if($view=='x2_sponsor'){ ?>
                    <div class="portlet-body">
                        <div class="clearfix">
                        </div>
                        <br/><br/>
                        <div class="table-responsive">
                            <table id="x2_sponsor" class="table table-striped table-bordered" id="x2_sponsor">
                                <thead>
                                    <tr>
                                        <th class="text-center">S.No</th>
                                        <th class="text-center">Transaction id</th>
                                        <th class="text-center">Username</th>
                                        <th class="text-center">Level</th>
                                        <th class="text-center">Package</th>
                                        <th class="text-center">Sponsor</th>
                                        <th class="text-center">Date & Time</th>
                                    </tr>
                                </thead>
                                <tbody> </tbody>
                            </table>
                        </div>
                    </div>
                <?php } else if($view=='auto_upgrade'){ ?>
                    <div class="portlet-body">
                        <div class="clearfix">
                        </div>
                        <br/><br/>
                        <div class="table-responsive">
                            <table id="auto_upgrade" class="table table-striped table-bordered" id="auto_upgrade">
                                <thead>
                                    <tr>
                                        <th class="text-center">S.No</th>
                                        <th class="text-center">Transaction id</th>
                                        <th class="text-center">Username</th>
                                        <th class="text-center">Package</th>
                                        <th class="text-center">Amount</th>
                                        <th class="text-center">Date & Time</th>
                                    </tr>
                                </thead>
                                <tbody> </tbody>
                            </table>
                        </div>
                    </div>        
                <?php } else if($view=='x4_profit'){ ?>
                    <div class="portlet-body">
                        <div class="clearfix">
                        </div>
                        <br/><br/>
                        <div class="table-responsive">
                            <table id="x4_profit" class="table table-striped table-bordered" id="x4_profit">
                                <thead>
                                    <tr>
                                        <th class="text-center">S.No</th>
                                        <th class="text-center">Transaction id</th>
                                        <th class="text-center">Username</th>
                                        <th class="text-center">Level</th>
                                        <th class="text-center">Package</th>
                                        <th class="text-center">Profit</th>
                                        <th class="text-center">Date & Time</th>
                                    </tr>
                                </thead>
                                <tbody> </tbody>
                            </table>
                        </div>
                    </div>    
                <?php } else if($view=='x4_sponsor'){ ?>
                    <div class="portlet-body">
                        <div class="clearfix">
                        </div>
                        <br/><br/>
                        <div class="table-responsive">
                            <table id="x4_sponsor" class="table table-striped table-bordered" id="x4_sponsor">
                                <thead>
                                    <tr>
                                        <th class="text-center">S.No</th>
                                        <th class="text-center">Transaction id</th>
                                        <th class="text-center">Username</th>
                                        <th class="text-center">Level</th>
                                        <th class="text-center">Package</th>
                                        <th class="text-center">Sponsor</th>
                                        <th class="text-center">Date & Time</th>
                                    </tr>
                                </thead>
                                <tbody> </tbody>
                            </table>
                        </div>
                    </div>    
                <?php }elseif($view=='edit'){ ?>
                    <div class="portlet-body">
                        <?php $attributes=array('class'=>'form-horizontal','id'=>'user_edit');
                        echo form_open_multipart($action,$attributes); ?>
                        <fieldset>

                         <?php
                         if(isset($users->country) && !empty($users->country) && $users->country!=0){
                             ?>
                             <div class="form-group">
                                <label class="col-md-2 control-label">Country</label>
                                <div class="col-md-8 control-label text-left">
                                    <?php
                                    $country = get_countryname($users->country);
                                    echo $country->country_name; ?>
                                </div>
                            </div>
                            <?php
                        }
                        ?>

                        <div class="form-group">
                            <label class="col-md-2 control-label">Username</label>
                            <div class="col-md-8 control-label text-left">
                                <?php
                                $username = $prefix.'username';
                                echo $users->$username; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-2 control-label">Email</label>
                            <div class="col-md-8 control-label text-left">
                                <?php
                                $email = getUserEmail($users->id);
                                echo $email; ?>
                            </div>
                        </div>
                                    <div class="form-group">
                                        <div class="col-md-7 col-md-offset-5">
                                            <button type="submit" class="btn btn-sm btn-primary m-r-5">Submit</button>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                       <label class="col-md-2 control-label"></label>
                                       <div  class="col-md-8 control-label text-left">
                                        <?php if(!empty($bank_details)) { ?>
                                            <h4 >User Bank Details</h4>
                                            <?php foreach($bank_details as $bank){  ?>
                                                <h5><?php echo $bank->bank_name; ?></h5>
                                                Account Number : <?php echo $bank->bank_account_number; ?><br/>
                                                Account Name : <?php echo $bank->bank_account_name; ?><br/>
                                                Bank Swift code : <?php echo $bank->bank_swift; ?><br/>
                                                Bank City : <?php echo $bank->bank_city; ?><br/>
                                                Bank Postal Code : <?php echo $bank->bank_postalcode; ?><br/>
                                                Status : <?php if($bank->status=='0') { echo 'Deleted'; }else{ echo 'Active'; } ?><br/>
                                            <?php } } ?>
                                        </div>
                                    </div>   
                                </fieldset>
                            </form>
                        </div>
                    <?php } ?> 

                                            </div>
                                            <!-- end panel -->
                                        </div>
                                    </div>
                                    <!-- end row -->
                                </div>

                                                  
                        </div>
  <!-- end #content -->
  <!-- ================== BEGIN BASE JS ================== -->
  <script src="<?php echo admin_source();?>/plugins/jquery/jquery-1.9.1.min.js"></script>
  <script src="<?php echo admin_source();?>/plugins/jquery/jquery-migrate-1.1.0.min.js"></script>
  <script src="<?php echo admin_source();?>/plugins/jquery-ui/ui/minified/jquery-ui.min.js"></script>
  <script src="<?php echo admin_source();?>/plugins/bootstrap/js/bootstrap.min.js"></script>
   
    <script src="<?php echo admin_source();?>/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="<?php echo admin_source();?>/plugins/jquery-cookie/jquery.cookie.js"></script>
    <!-- ================== END BASE JS ================== -->
    <!-- ================== BEGIN PAGE LEVEL JS ================== -->
    <script src="<?php echo admin_source();?>/plugins/gritter/js/jquery.gritter.js"></script>
    <script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.min.js"></script>
    <script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.time.min.js"></script>
    <script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.resize.min.js"></script>

    <script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script> 
    <script src="https://cdn.datatables.net/responsive/2.2.6/js/dataTables.responsive.min.js"></script>
    
    <script src="<?php echo admin_source();?>/js/jquery.validate.min.js"></script>
    <script src="<?php echo admin_source();?>/js/apps.min.js"></script>
    <!-- ================== END PAGE LEVEL JS ================== -->
    <script>
        $(document).ready(function() {
            App.init();
        });
        
        
    </script>
    <script async
    src="https://www.googletagmanager.com/gtag/js?id=G-FDX8TJF8SG"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'G-FDX8TJF8SG');
    </script>
    <script>     
        var admin_url='<?php echo admin_url(); ?>';
        $(document).ready(function() {
            $('#level_income').DataTable( {
                "responsive" : true,
                "processing" : true,
                "pageLength" : 10,
                "serverSide": true,
                "order": [[0, "asc" ]],
                "searching": true,
                language: {
                    searchPlaceholder: "Search Transaction ID"
                },
                "ajax": admin_url+"income/level_ajax"
            });
            $('#system_level').DataTable( {
                "responsive" : true,
                "processing" : true,
                "pageLength" : 10,
                "serverSide": true,
                "order": [[0, "asc" ]],
                "searching": true,
                language: {
                    searchPlaceholder: "Search Transaction ID"
                },
                "ajax": admin_url+"income/system_ajax"
            });
            $('#x2_profit').DataTable( {
                "responsive" : true,
                "processing" : true,
                "pageLength" : 10,
                "serverSide": true,
                "order": [[0, "asc" ]],
                "searching": true,
                language: {
                    searchPlaceholder: "Search Transaction ID"
                },
                "ajax": admin_url+"income/x2_profit_ajax"
            });
            $('#x2_sponsor').DataTable( {
                "responsive" : true,
                "processing" : true,
                "pageLength" : 10,
                "serverSide": true,
                "order": [[0, "asc" ]],
                "searching": true,
                language: {
                    searchPlaceholder: "Search Transaction ID"
                },
                "ajax": admin_url+"income/x2_sponsor_ajax"
            });
            $('#auto_upgrade').DataTable( {
                "responsive" : true,
                "processing" : true,
                "pageLength" : 10,
                "serverSide": true,
                "order": [[0, "asc" ]],
                "searching": true,
                language: {
                    searchPlaceholder: "Search Transaction ID"
                },
                "ajax": admin_url+"income/auto_upgrade_ajax"
            });
            $('#x4_profit').DataTable( {
                "responsive" : true,
                "processing" : true,
                "pageLength" : 10,
                "serverSide": true,
                "order": [[0, "asc" ]],
                "searching": true,
                language: {
                    searchPlaceholder: "Search Transaction ID"
                },
                "ajax": admin_url+"income/x4_profit_ajax"
            });
            $('#x4_sponsor').DataTable( {
                "responsive" : true,
                "processing" : true,
                "pageLength" : 10,
                "serverSide": true,
                "order": [[0, "asc" ]],
                "searching": true,
                language: {
                    searchPlaceholder: "Search Transaction ID"
                },
                "ajax": admin_url+"income/x4_sponsor_ajax"
            });
            
        });
    </script>
    
    <style>
        .u_img{width:125px; height:125px; overflow:hidden; display:inline-block; float:left;}

        .u_img img{   height: auto;
            max-height: 100%;
            width: 100%;}


        </style>