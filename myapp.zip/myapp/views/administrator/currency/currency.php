<style>
    .editable-submit, .editable-cancel { margin: 5px; }
</style>
<!-- begin #content -->
<div class="page-content-wrapper">
    <div class="page-content">
        <?php 
        $error = $this->session->flashdata('error');
        if($error != '') {
            echo '<div class="note note-danger">
            <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$error.'</div>';
        }
        $success = $this->session->flashdata('success');
        if($success != '') {
            echo '<div class="note note-success">
            <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$success.'</div>';
        } 
        ?>
        <!-- begin page-header -->
        <div class="page-head">
            <!-- begin page-header -->
            <div class="page-title">
                <h1>Currency Management</h1>                     
            </div>
            <?php 
            if($view =='view_all'){
               ?>           
<!--                <div class="actions btn-set float-right">
                <a href="<?php echo admin_url().'currency/add';?>" data-placement="top" data-toggle="popover" data-content="Add New Static Content" class="btn btn-success poper" data-original-title="" title="">Add New</a>
            </div> -->
        <?php } ?>
    </div>
    <ul class="page-breadcrumb breadcrumb">
        <li>
            <a href="<?php echo admin_url();?>">Home</a>
            <i class="fa fa-circle"></i>
        </li>
        <li class="active"><a href="javascript:;">Currency</a></li>
    </ul>

    <!-- end page-header -->
    <!-- begin row -->
    <div class="row">
        <div class="col-md-12">
            <!-- begin panel -->
            <div class="portlet light">
                <div class="portlet-title">
                    <div class="caption">
                        <span class="caption-subject bold uppercase font-green-haze"><?=$title?></span>
                    </div>
                    <div class="tools">
                        <a href="javascript:;" class="collapse">
                        </a>
                        <a href="#portlet-config" data-toggle="modal" class="config">
                        </a>
                        <a href="javascript:;" class="reload">
                        </a>
                        <a href="javascript:;" class="fullscreen">
                        </a>
                        <a href="javascript:;" class="remove">
                        </a>
                    </div>
                </div>

                <?php //echo form_open(); echo form_close();?>
                <?php 
                if($view=='view_all'){ 
                    $this->load->view("administrator/currency/currency_list");
                }else if($view=='add'){ 
                    $this->load->view("administrator/currency/add_currency");
                }else{ 
                    $this->load->view("administrator/currency/edit_currency");
                } 
                ?>
            </div>
            <!-- end panel -->
        </div>
    </div>
    <!-- end row -->
</div>
</div>
<!-- end #content -->
<!-- ================== BEGIN BASE JS ================== -->
<script src="<?php echo admin_source();?>/plugins/jquery/jquery-1.9.1.min.js"></script>

<script src="<?php echo admin_source();?>/plugins/jquery/jquery-migrate-1.1.0.min.js"></script>
<script src="<?php echo admin_source();?>/plugins/jquery-ui/ui/minified/jquery-ui.min.js"></script>
<script src="<?php echo admin_source();?>/plugins/bootstrap/js/bootstrap.min.js"></script> 

<script src="<?php echo admin_source();?>/plugins/slimscroll/jquery.slimscroll.min.js"></script>
<script src="<?php echo admin_source();?>/plugins/jquery-cookie/jquery.cookie.js"></script>
<!-- ================== END BASE JS ================== -->
<!-- ================== BEGIN PAGE LEVEL JS ================== -->
<script src="<?php echo admin_source();?>/plugins/gritter/js/jquery.gritter.js"></script>
<script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.min.js"></script>
<script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.time.min.js"></script>
<script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.resize.min.js"></script>
<script src="<?php echo admin_source();?>/plugins/DataTables/js/jquery.dataTables.min.js"></script> 
<script src="<?php echo admin_source();?>/plugins/DataTables/js/dataTables.responsive.min.js"></script>

<script src="<?php echo admin_source();?>/js/jquery.validate.min.js"></script>
<script src="<?php echo admin_source();?>js/additional-methods.js"></script>
<script src="<?php echo admin_source();?>/js/apps.min.js"></script>
<script type="text/javascript" src="https://seantheme.com/color-admin/admin/assets/plugins/x-editable-bs4/dist/bootstrap4-editable/js/bootstrap-editable.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/js/bootstrap-select.min.js"></script>
<!-- ================== END PAGE LEVEL JS ================== -->
<script>
    var admin_url = "<?php echo admin_url(); ?>";
    $(document).ready(function() {
        if($('input[name="assets_types"]:radio').is(':checked')){
            var types = $("[name='assets_types']:checked").val();
            if(types ==0)
            {
                $(".contract_sec").show();
                $(".decimal_sec").show();
            }
            else
            {
                $(".contract_sec").hide();
                $(".decimal_sec").hide();
            }
        }
        $('input[name="assets_types"]:radio').change(function(){
           var type = $(this).val();
           if(type ==0)
           {
            $(".contract_sec").show();
            $(".decimal_sec").show();
        }
        else
        {
            $(".contract_sec").hide();
            $(".decimal_sec").hide();
        }
    });
    });

    $(document).ready(function() {
        $('.btn-submit').on('click', function(){


            $('#currency').validate({
                rules: {
                    currency_name: {
                        required: true,
                        remote: admin_url + "currency/name_exist"
                    },
                    currency_symbol: {
                        required: true,
                        remote: admin_url + "currency/symbol_exist"
                    },
           
            image: {
                required: true
            },
          
            min_withdraw_limit: {
                required: true,
                number: true,
            },
            max_withdraw_limit: {
                // required: true,
                number: true
            },
            withdraw_fees: {
                required: true,
                number: true,
            },
            deposit_fees: {
                // required: true,
                number: true,
            },
            maker_fee: {
                required: true,
                number: true,
            },
            taker_fee: {
                required: true,
                number: true,
            },
            withdraw_fees_type: {
                // required: true,
                // number: true,
            },
            contract_address:{
                required: true
            }
        },
         messages: {
            currency_name: {
                required: "This field is required",           
                remote: jQuery.validator.format("{0} is already taken")
            },
            currency_symbol: {
                required: "This field is required",           
                remote: jQuery.validator.format("{0} is already taken")
            },
        },
        highlight: function(element) {
            //$(element).parent().addClass('error')
        },
        unhighlight: function(element) {
            $(element).parent().removeClass('error')
        }
    });
        });
        $('.btn-submit').on('click', function(){
            $('#edit_currency').validate({
                rules: {
                    currency_name: {
                        required: true
                    },
                    currency_symbol: {
                        required: true
                    },            
        },
        highlight: function(element) {
            //$(element).parent().addClass('error')
        },
        unhighlight: function(element) {
            $(element).parent().removeClass('error')
        }
    });
        });
    });
</script>

<script>
   var admin_url='<?php echo admin_url(); ?>';    
   $(document).ready(function() {
    App.init();

    $(document).on('click','.cancel', function(){
      window.location.href= admin_url + 'currency';
  });


});

   var admin_url='<?php echo admin_url(); ?>';
   $(document).ready(function() {
    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';        

    $(document).on('click', '.sorting_my', function(e){
        $.fn.editable.defaults.mode = 'inline';
        $(this).editable();
    });

    $(document).on('click','.editable-submit',function(e, params) {
        var currency_id = $(this).parents("span").prev().data("pk");
        var newValue = $(this).parent('div').prev().children().val();
        $.ajax({
            url: admin_url+"currency/currency_text", 
            type: "POST",             
            data: {'currency_id':currency_id,'currency_text':newValue},    
            success: function(data) 
            {                       
                if(data==1)
                {
                        // window.location.href="https://bitcardexs.com/tenrealm_admin/currency";
                    }
                }
            });
    });

    $(document).on('click','.editable-cancel',function(e, params) {
        $(this).parents(".editableform").css("display",'none');

        $(this).parents(".editable-container").prev().css("display",'block');
    });
});

   var $j = jQuery.noConflict();
   $j('.datepicker').datepicker({
    format: 'dd/mm/yyyy'
});
   function change_dep_type(sel) {
    if (sel == 'fiat') {
        $('#deposit_seg').css('display', 'block');
    } else {
        $('#deposit_seg').css('display', 'none');
    }
}
</script>
<script async
src="https://www.googletagmanager.com/gtag/js?id=G-FDX8TJF8SG"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'G-FDX8TJF8SG');
</script>