<div class="portlet-body">
    <div class="table-responsive">
        <table id="data-table" class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th class="text-center">S.No</th>
                    <th class="text-center">Currency Name</th>
                    <th class="text-center">Currency Symbol</th>
                    <th class="text-center">Type</th>
                    <th class="text-center">Asset Type</th>
                    <th class="text-center">Sort Order</th>
                    <th class="text-center">Status</th>
                    <th class="text-center">Action</th>
                </tr>
            </thead>
            <tbody> 
            <?php
                if ($currency->num_rows() > 0) {
                    $i = 1;
                    foreach($currency->result() as $result) {
                        echo '<tr>';
                        echo '<td>' . $i . '</td>';
                        echo '<td>' . $result->currency_name .'</td>';
                        echo '<td>' . $result->currency_symbol .'</td>';
                        echo '<td>' . $result->type .'</td>';
                        echo '<td>'.$result->token_price.'</td>';
                        echo '<td>' . $result->sort_order .'</td>';
                        if ($result->status == 1) {
                            $status = '<label class="label label-info">Activated</label>';
                            $extra = array('title' => 'De-activate this currency');
                            $changeStatus = anchor(admin_url().'currency/status/' . $result->id . '/0','<i class="fa fa-unlock text-primary"></i>',$extra);
                        } else {
                            $status = '<label class="label label-danger">De-Activated</label>';
                            $extra = array('title' => 'Activate this currency');
                            $changeStatus = anchor(admin_url().'currency/status/' . $result->id . '/1','<i class="fa fa-lock text-primary"></i>',$extra);
                        }
                        echo '<td>'.$status.'</td>';
                        echo '<td>';
                        // echo $changeStatus . '&nbsp;&nbsp;&nbsp;';
                        echo '<a href="' . admin_url() . 'currency/edit/' . $result->id . '" title="Edit this currency"><i class="fa fa-pencil text-primary"></i></a>&nbsp;&nbsp;&nbsp;';
                        // echo '<a href="' . admin_url() . 'currency/delete/' . $result->id . '" title="Delete this currency"><i class="fa fa-trash-o text-danger"></i></a>&nbsp;&nbsp;&nbsp;';
                        echo '</td>';
                        echo '</tr>';
                        $i++;
                    }                   
                } else {
                    echo '<tr><td></td><td></td><td colspan="2" class="text-center">No currency added yet!</td><td></td><td></td><td></td><td></td></tr>';
                }
                ?>              
            </tbody>
        </table>
    </div>
</div>