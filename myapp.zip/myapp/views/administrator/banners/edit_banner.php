<div class="panel-body">
    <?php $attributes=array('class'=>'form-horizontal','id'=>'edit_banner');
				echo form_open_multipart($action,$attributes); ?>
    <fieldset>
        <div class="form-group">
            <label class="col-md-4 control-label">Position</label>
            <div class="col-md-4">
                <select id="position" name="position" class="form-control selectpicker" data-live-search="true">
                    <option <?php if($banners->position=='home'){echo 'selected';}?> value="home">Home</option>
                    <option <?php if($banners->position=='dashboard'){echo 'selected';}?> value="dashboard">Dashboard
                    </option>
                </select>
            </div>
        </div>


        <div class="form-group">
            <label class="col-md-4 control-label">Banner Name</label>
            <div class="col-md-4">
                <input type="text" name="banner_name" class="form-control" id="banner_name" value="<?php echo $banners->banner_name;?>"/>
            </div>
        </div>


        <div class="form-group">
            <label class="col-md-4 control-label">Image</label>
            <div class="col-md-4">
                <input type="file" name="image" id="image" />
                <?php $im = $banners->image; ?>
                <input type="hidden" name="oldimage" id="oldimage" value="<?php echo $banners->image; ?>" />
                <?php if($banners->image!='') { ?>
                <img src="<?php echo $im; ?>" style="width:65px;height:65px;" />
                <?php } ?>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-4 control-label">Mobile Image</label>
            <div class="col-md-4">
                <input type="file" name="mimage" id="mimage" />
                <?php $im = $banners->mobile_image; ?>
                <input type="hidden" name="moldimage" id="moldimage" value="<?php echo $banners->mobile_image; ?>" />
                <?php if(!empty(trim($banners->mobile_image))) { ?>
                <img src="<?php echo $im; ?>" style="width:65px;height:65px;" />
                <?php } ?>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-4 control-label">Link</label>
            <div class="col-md-4">
                <input type="text" name="link" id="link" class="form-control"
                    placeholder="Banner Link" value="<?php echo $banners->link;?>" />
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-4 control-label">Expiry date</label>
            <div class="col-md-4">
                <input type="text" name="expiry_date" class="datepicker form-control" id="expiry_date" value="<?php echo date("m/d/Y",strtotime($banners->expiry_date));?>"/>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-4 control-label">Status</label>
            <div class="col-md-4">
                <select id="status" name="status" class="form-control selectpicker" data-live-search="true">
                    <option <?php if($banners->status==1){echo 'selected';}?> value="1">Active</option>
                    <option <?php if($banners->status==0){echo 'selected';}?> value="0">De-active
                    </option>
                </select>
            </div>
        </div>


        <div class="form-group">
            <div class="col-md-8 col-md-offset-4">
                <button type="submit" class="btn btn-sm btn-primary m-r-5">Submit</button>
            </div>
        </div>
    </fieldset>
    <?php echo form_close(); ?>
</div>