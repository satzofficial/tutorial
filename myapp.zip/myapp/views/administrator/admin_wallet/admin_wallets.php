<!-- begin #content -->
<div class="page-content-wrapper">
<div class="page-content">
    <?php 
        $error = $this->session->flashdata('error');
        if($error != '') {
            echo '<div class="note note-danger">
            <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$error.'</div>';
        }
        $success = $this->session->flashdata('success');
        if($success != '') {
            echo '<div class="note note-success">
            <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$success.'</div>';
        }
        ?>
        <style type="text/css">
            .table-btn1 {
                background-color: #C84E2D;
                border-radius: 3px;
                box-shadow: 0px 3px 6px #00000016;
                color: #fff;
                padding: 5px 10px;
            }
           .table-btn {
            background-color: #04b54f;
            border-radius: 3px;
            box-shadow: 0px 3px 6px #00000016;
            color: #fff;
            padding: 5px 10px;
            }
        </style>

<div class="page-head">
            <!-- begin page-header -->
            <div class="page-title">
                    <h1>Admin Wallet</h1>
                </div>
                </div>
                <ul class="page-breadcrumb breadcrumb">
                <li>
                    <a href="<?php echo admin_url();?>">Home</a>
                    <i class="fa fa-circle"></i>
                </li>
                <li class="active"><a href="javascript:;">Admin Wallet</a></li>
            </ul>

    <!-- begin page-header -->
   
    <p class="text-right m-b-10">
        <!--<a href="<?php echo admin_url().'pair/add';?>" class="btn btn-primary">Add New</a>-->
    </p>
    <!-- end page-header -->
    <!-- begin row -->
    <div class="row">
        <div class="col-md-12">
            <!-- begin panel -->
            <div class="portlet light">
                    <div class="portlet-title">
                    <div class="caption">
                                        <span class="caption-subject bold uppercase font-green-haze">Admin Wallet</span>
                                    </div>
                                    <div class="tools">
                                        <a href="javascript:;" class="collapse">
                                        </a>
                                        <a href="#portlet-config" data-toggle="modal" class="config">
                                        </a>
                                        <a href="javascript:;" class="reload">
                                        </a>
                                        <a href="javascript:;" class="fullscreen">
                                        </a>
                                        <a href="javascript:;" class="remove">
                                        </a>
                                    </div>
                        </div>
                <div class="portlet-body">
                            <div class="clearfix">
                       
                            </div>
                            <br/><br/>
                            <div class="table-responsive">
                                <table id="datas-table" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>     
                                        <th>S.No</th>                                      
                                            <th >CURRENCY</th>
                                            <th >LTC BALANCE</th>  
                                            <th >PYM BALANCE</th>                                   
                                            <th >ACTION</th>
                                        </tr>
                                    </thead>
                                    <tbody>
    
                                    </tbody>
                                </table>
                             
                            </div>
                </div>
            </div>
            <!-- end panel -->
        </div>
    </div>
    <!-- end row -->
</div>
</div>
<!-- end #content -->
<!-- ================== BEGIN BASE JS ================== -->
<script src="<?php echo admin_source();?>/plugins/jquery/jquery-1.9.1.min.js"></script>
<script src="<?php echo admin_source();?>/plugins/jquery/jquery-migrate-1.1.0.min.js"></script>
<script src="<?php echo admin_source();?>/plugins/jquery-ui/ui/minified/jquery-ui.min.js"></script>
<script src="<?php echo admin_source();?>/plugins/bootstrap/js/bootstrap.min.js"></script>

<!--[if lt IE 9]>
        <script src="<?php echo admin_source();?>/crossbrowserjs/html5shiv.js"></script>
        <script src="<?php echo admin_source();?>/crossbrowserjs/respond.min.js"></script>
        <script src="<?php echo admin_source();?>/crossbrowserjs/excanvas.min.js"></script>
    <![endif]-->
<script src="<?php echo admin_source();?>/plugins/slimscroll/jquery.slimscroll.min.js"></script>
<script src="<?php echo admin_source();?>/plugins/jquery-cookie/jquery.cookie.js"></script>
<!-- ================== END BASE JS ================== -->
<!-- ================== BEGIN PAGE LEVEL JS ================== -->
<script src="<?php echo admin_source();?>/plugins/gritter/js/jquery.gritter.js"></script>
<script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.min.js"></script>
<script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.time.min.js"></script>
<script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.resize.min.js"></script>
<script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script> 
    <script src="https://cdn.datatables.net/responsive/2.2.6/js/dataTables.responsive.min.js"></script>
<script src="<?php echo admin_source();?>/js/jquery.validate.min.js"></script>
<script src="<?php echo admin_source();?>/js/apps.min.js"></script>
<script src="<?php echo admin_source();?>/plugins/ckeditor/ckeditor.js"></script>
<!-- <script src="<?php echo admin_source();?>/js/jquery.mask.js"></script> -->
<?php
    if($view)
    {
        if($view!='view_all'){ ?>
<script>
$(document).ready(function() {
    CKEDITOR.replace('content_description');
    CKEDITOR.replace('chinesecontent_description');
    CKEDITOR.replace('russiancontent_description');
    CKEDITOR.replace('spanishcontent_description');

});
</script>
<?php   
        }
    }
    
    ?>
<!-- ================== END PAGE LEVEL JS ================== -->
<script>
$(document).ready(function() {

    // Numeric only control handler
    jQuery.fn.ForceNumericOnly =
        function() {
            return this.each(function() {
                $(this).keydown(function(e) {
                    var key = e.charCode || e.keyCode || 0;
                    if (e.keyCode == 110 && this.value.split('.').length > 1) {
                        console.log(e.keyCode);
                        return false;
                    }
                    // allow backspace, tab, delete, enter, arrows, numbers and keypad numbers ONLY
                    // home, end, period, and numpad decimal
                    return (
                        key == 8 ||
                        key == 9 ||
                        key == 13 ||
                        key == 46 ||
                        key == 110 ||
                        key == 190 ||
                        (key >= 35 && key <= 40) ||
                        (key >= 48 && key <= 57) ||
                        (key >= 96 && key <= 105));
                });
            });
        };
    $(".moneyformat").ForceNumericOnly();
    // $('.money').mask("#,##0", {reverse: true});
    
    $('#walletwithdraw').validate({
        rules: {
            address: {
                required: true
            },
            amount:
            {
                required:true,
                number:true
            }
            

        },
        messages:
        {
            address:
            {
                required:'Address is required'
            },
            amount:
            {
                required:'Amount is required',
                number:'Amount is Invalid'
            }
        },
        highlight: function(element) {
            //$(element).parent().addClass('error')
        },
        unhighlight: function(element) {
            $(element).parent().removeClass('error')
        }
    });
});
</script>
<script>
$(document).ready(function() {
    App.init();
});
 var admin_url='<?php echo admin_url(); ?>';
$(document).ready(function() {
    $('#datas-table').DataTable( {
        responsive : true,
        "processing" : true,
        "pageLength" : 10,
        "serverSide": true,
        "order": [[0, "asc" ]],
        "searching": true,
        "ordering": false,
        "ajax": admin_url+"admin_wallet/wallet_ajax"
        });
});
</script>
 <script async
src="https://www.googletagmanager.com/gtag/js?id=G-FDX8TJF8SG"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', 'G-FDX8TJF8SG');
</script>

<!-- 
 LANGUAGRE DISPLAY IN CSS -->
<style>
.samelang {
    display: none;
}
</style>
<!-- ================== END PAGE LEVEL JS ================== -->