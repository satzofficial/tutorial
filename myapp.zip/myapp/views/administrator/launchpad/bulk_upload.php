<style href="https://cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.1/bootstrap-editable/css/bootstrap-editable.css" type="text/css"></style>
<!-- begin #content -->
<div id="content" class="content">
	<?php 
		$error = $this->session->flashdata('error');
		if($error != '') {
			echo '<div class="alert alert-danger">
			<button aria-hidden="true" data-dismiss="alert" class="close" type="button">&#10005;</button>'.$error.'</div>';
		}
		$success = $this->session->flashdata('success');
		if($success != '') {
			echo '<div class="alert alert-success">
			<button aria-hidden="true" data-dismiss="alert" class="close" type="button">&#10005;</button>'.$success.'</div>';
		} 
	?>
			<!-- begin breadcrumb -->
			<ol class="breadcrumb pull-right">
				<li><a href="<?php echo admin_url();?>">Home</a></li>
				<li class="active"><?php echo ucfirst($title); ?> </li>
			</ol>
			<!-- end breadcrumb -->
			<!-- begin page-header -->
			<h1 class="page-header"><?php echo ucfirst($title); ?> <!--<small>header small text goes here...</small>--></h1>
			<p class="text-right m-b-10"></p>
			<!-- end page-header -->
			<!-- begin row -->
			<div class="row">
				<div class="col-md-12">
			        <!-- begin panel -->
                    <div class="panel panel-inverse">
                        <div class="panel-heading">
                            <div class="panel-heading-btn">
                                <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
                                <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
                                <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-danger" data-click="panel-remove"><i class="fa fa-times"></i></a>
                            </div>
                            <h4 class="panel-title"><?php echo ucfirst($title); ?></h4>
                        </div>
					<?php if($view=='bulk_upload'){ ?>
                        <div class="panel-body">
                       	<?php $attributes=array('class'=>'form-horizontal','id'=>'site_settings');
				echo form_open_multipart($action,$attributes); ?>

                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Bulk Upload</label>
                                        <div class="col-md-4">
                                            <input type="file" name="bulk_upload" id="bulk_upload" accept=".csv" required />
                                            <div class="img_stre">
                                            <img src="<?php echo base_url(); ?>assets/admin/img/28842.png" class="img-responsive logo_im" style="height: 30px; width: 30px;"   />
                                            </div>

                                        </div>										
                                    </div>

                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Sample CSV File</label>
                                        <div class="col-md-4">
                                            <a class="btn btn-success" href="<?php echo base_url(); ?>assets/admin/sample_csv/Ixtoken_Launchpad_Application_Form.csv" download>Download</a>
                                        </div>										
                                    </div>

                                    <div class="form-group">
                                        <div class="col-md-8 col-md-offset-4">
                                            <button type="submit" class="btn btn-sm btn-primary m-r-5">Submit</button>
                                        </div>
                                    </div>
                                
                                <?php echo form_close(); ?>
                       	   
                        </div>
					<?php }else if($view=="list"){ ?>

						 <div class="panel-body">
                     
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered" id="buy">
                                    <thead>
                                        <tr>
                                        <th class="text-center">S.No</th>
                                        <th class="text-center">Email Address</th>
                                        <th class="text-center">Token Name</th>
                                        <th class="text-center">Total Sold</th>
                                        <th class="text-center">Total User Funds</th>
										<th class="text-center">Status</th>
										<th class="text-center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody style="text-align: center;">
									<?php
								if ($launchpadlist->num_rows() > 0) {
								 $i = 1; 
									foreach($launchpadlist->result() as $result) {

										$remaining_token = $this->common_model->customQuery("SELECT SUM(transfer_amount) as remaining_amount from ixtoken_transactions where token_symbol = '".$result->token_coin_symbol."' AND type = 'Launchwithdraw' AND status = 'Completed' ")->row();
                                       
										$btc_amount = $this->common_model->customQuery("SELECT SUM(amount) as btc_amount from ixtoken_transactions where token_symbol = '".$result->token_coin_symbol."' AND type = 'Launchwithdraw' AND status = 'Completed' AND currency_id = 1 ")->row();

										$eth_amount = $this->common_model->customQuery("SELECT SUM(amount) as eth_amount from ixtoken_transactions where token_symbol = '".$result->token_coin_symbol."' AND type = 'Launchwithdraw' AND status = 'Completed' AND currency_id = 2 ")->row();


										$bnb_amount = $this->common_model->customQuery("SELECT SUM(amount) as bnb_amount from ixtoken_transactions where token_symbol = '".$result->token_coin_symbol."' AND type = 'Launchwithdraw' AND status = 'Completed' AND currency_id = 11 ")->row();

										$usdt_amount = $this->common_model->customQuery("SELECT SUM(amount) as usdt_amount from ixtoken_transactions where token_symbol = '".$result->token_coin_symbol."' AND type = 'Launchwithdraw' AND status = 'Completed' AND currency_id = 3 ")->row();

										$tron_amount = $this->common_model->customQuery("SELECT SUM(amount) as tron_amount from ixtoken_transactions where token_symbol = '".$result->token_coin_symbol."' AND type = 'Launchwithdraw' AND status = 'Completed' AND currency_id = 17 ")->row();


										if($btc_amount->btc_amount !="" || $btc_amount->btc_amount != NULL || $btc_amount->btc_amount != 0)
										{
											$btc_amount = $btc_amount->btc_amount;
										}
										else
										{
											$btc_amount = 0;
										}

										if($eth_amount->eth_amount !="" || $eth_amount->eth_amount != NULL || $eth_amount->eth_amount != 0)
										{
											$eth_amount = $eth_amount->eth_amount;
										}
										else
										{
											$eth_amount = 0;
										}

										if($bnb_amount->bnb_amount !="" || $bnb_amount->bnb_amount != NULL || $bnb_amount->bnb_amount != 0)
										{
											$bnb_amount = $bnb_amount->bnb_amount;
										}
										else
										{
											$bnb_amount = 0;
										}


										if($usdt_amount->usdt_amount !="" || $usdt_amount->usdt_amount != NULL || $usdt_amount->usdt_amount != 0)
										{
											$usdt_amount = $usdt_amount->usdt_amount;
										}
										else
										{
											$usdt_amount = 0;
										}

										if($tron_amount->tron_amount !="" || $tron_amount->tron_amount != NULL || $tron_amount->tron_amount != 0)
										{
											$tron_amount = $tron_amount->tron_amount;
										}
										else
										{
											$tron_amount = 0;
										}

										//$from_currency_symbol = getcryptocurrency($result->from_currency_id);
										echo '<tr>';
										echo '<td>' . $i . '</td>';
										echo '<td>' . $result->username . '</td>';										
										echo '<td>' . $result->token_coin_symbol.'-'.$result->token_coin_fullname . '</td>';
										echo '<td>' . number_format($remaining_token->remaining_amount,2,'.','') . '</td>';
										echo '<td> BTC - '. trailingZeroes(numberFormatPrecision($btc_amount)) .'<br> ETH - '. trailingZeroes(numberFormatPrecision($eth_amount)) . '<br> BNB - '. trailingZeroes(numberFormatPrecision($bnb_amount)) . '<br> USDT - '. trailingZeroes(numberFormatPrecision($usdt_amount)) . '<br> TRX - '. trailingZeroes(numberFormatPrecision($tron_amount)) . '<br>
										</td>';
										if ($result->status == 1) {
                                            $status = '<label class="label label-info">Verified</label>';
                                            $extra = array('title' => 'De-activate this Launchpad');
                                            $changeStatus = anchor(admin_url().'launchpad/status/' . $result->launch_id . '/0','<i class="fa fa-unlock text-primary"></i>',$extra);
                                        } else {
                                            $status = '<label class="label label-danger">Unverified</label>';
                                            $extra = array('title' => 'Activate this Launchpad');
                                            $changeStatus = anchor(admin_url().'launchpad/status/' . $result->launch_id . '/1','<i class="fa fa-lock text-primary"></i>',$extra);
                                        }

										 echo '<td>'.$status.'</td>';
										 echo '<td>';
                                         echo $changeStatus . '&nbsp;&nbsp;&nbsp;';
                                        
                                       	echo '<a href="' . admin_url() . 'launchpad/view/' . $result->launch_id . '" title="View"><i class="fa fa-eye text-primary"></i></a>&nbsp;&nbsp;&nbsp;';
                                        echo '</td>';
										echo '</tr>';
										$i++;
									}					
								}
								else {
									echo '<tr>';
									echo '<td colspan="9">' . 'No Records Found!!' . '</td>';
									echo '</tr>';
								} 
								?>
                                    </tbody>
                                </table>
                              
                            </div>
                        </div>

					<?php }else if($view=="view"){ ?>
						<?php echo form_open_multipart(); $launchpads = $launchpad->id; form_close();?>
						<div class="panel-body">
                       <table id="banners" class="table table-striped table-bordered1 text-left" cellspacing="0" width="100%">
                       		<tr>
								<th class="text-right" style="width:200px;">Token Logo:</th>
								<td><div><img style="height: 10%;width: 10%;" src="<?php echo $launchpad->token_logo;?>" alt="image"><div> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Admin text</th>
								<td>
									<a href="javascript:;" id="launchpad_decription" data-type="text" data-pk="1" data-placement="right" data-placeholder="Required" data-title="Enter your Launchpad Decription"><?php echo $launchpad->launchpad_decription; ?></a>
								</td>
							</tr>
                       		<tr>
								<th class="text-right" style="width:200px;">Username:</th>
								<td><?php echo $launchpad->username; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Confirm FullName:</th>
								<td><?php echo $launchpad->confirm_fullname; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Confirm Position Project:</th>
								<td><?php echo $launchpad->confirm_position_project; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Reference Email:</th>
								<td><?php echo $launchpad->reference_email; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Project Name:</th>
								<td><?php echo $launchpad->project_name; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Token Coin Symbol:</th>
								<td><?php echo $launchpad->token_coin_symbol; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Token Coin FullName:</th>
								<td><?php echo $launchpad->token_coin_fullname; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Token Contract Address:</th>
								<td><?php echo $launchpad->token_contract_address; ?> </td>
							</tr>							
							<tr>
								<th class="text-right" style="width:200px;">Official Website:</th>
								<td><?php echo $launchpad->token_coin_fullname; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Permanent link to your whitepaper:</th>
								<td><?php echo $launchpad->whitepaper_link; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">What position is the Project in right now? (Current situation)</th>
								<td><?php echo $launchpad->project_position; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">History of Project (Past)</th>
								<td><?php echo $launchpad->history_project; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Detailed Roadmap and Milestones :</th>
								<td><?php echo $launchpad->detail_roadmap_milestone; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Long term vision of the Project and how you expect to get there (Future)</th>
								<td><?php echo $launchpad->long_term_vision_project; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Description of Token/Coin (Utility/Use Cases)</th>
								<td><?php echo $launchpad->description_token_coin; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Is your token/coin a security?</th>
								<td><?php echo $launchpad->token_coin_security; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">How many users (registered & active) do you currently have?</th>
								<td><?php echo $launchpad->current_users; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Community Members</th>
								<td><?php echo $launchpad->community_members; ?> </td>
							</tr>							
							<tr>
								<th class="text-right" style="width:200px;">Soft Cap</th>
								<td><?php echo $launchpad->soft_cap; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Hard Cap</th>
								<td><?php echo $launchpad->hard_cap; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Public Sale Conversion Price (e.g. 1 ETH = 1000 XX) </th>
								<td><?php echo $launchpad->sale_conversion_price; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">How much has been raised already, in each round? </th>
								<td><?php echo $launchpad->raised_round; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Countries Excluded? </th>
								<td><?php echo $launchpad->countries_excluded; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Bonus Structure (if any) </th>
								<td><?php echo $launchpad->bonus_structure; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">How much of the Token Sale would you like to allocate to Ixtoken Launchpad? </th>
								<td><?php echo $launchpad->token_sale; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Total Token Supply </th>
								<td><?php echo $launchpad->total_token_supply; ?> </td>
							</tr>
							<!-- <tr>
								<th class="text-right" style="width:200px;">Countries Excluded?Private/Pre/Public Sale Dates </th>
								<td><?php echo $launchpad->countries_excluded_sale_date; ?> </td>
							</tr> -->
							<tr>
								<th class="text-right" style="width:200px;">Bonus Structure (if any) </th>
								<td><?php echo $launchpad->private_pre_public_sale_Dates; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Start Date  </th>
								<td><?php echo $launchpad->start_date; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Expiry Date </th>
								<td><?php echo $launchpad->expire_date; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Ixtoken can publish any of the information you provided.</th>
								<td><?php echo $launchpad->publish_information_provided; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Ixtoken reserves the right to de-list your coin/token at any time, for any reason, solely at Ixtoken discretion, without refunds.</th>
								<td><?php echo $launchpad->ixtoken_reserves_without_refunds; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Please provide your name and title. </th>
								<td><?php echo $launchpad->provide_your_name_title; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Please provide Thank you for choosing Ixtoken! If there is anything else you would like to add, please feel free to do so below your name and title. </th>
								<td><?php echo $launchpad->provide_thank_you_for_choosing_ixtoken; ?> </td>
							</tr>
							
							<tr>
								<th class="text-right" style="width:200px;">Please provide a link to your GitHub repo</th>
								<td><?php echo $launchpad->telegram_link; ?> </td>
							</tr>

							<tr>
								<th class="text-right" style="width:200px;">Telegram Gorup Link</th>
								<td><?php echo $launchpad->fb_link; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Twitter Link</th>
								<td><?php echo $launchpad->twitter_link; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">LinkedIn link</th>
								<td><?php echo $launchpad->linkedin_link; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">reddit_link</th>
								<td><?php echo $launchpad->reddit_link; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Youtube Link</th>
								<td><?php echo $launchpad->youtube_link; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Medium Link</th>
								<td><?php echo $launchpad->medium_link; ?> </td>
							</tr>
							<tr>
								<th class="text-right" style="width:200px;">Github Link</th>
								<td><?php echo $launchpad->github_link; ?> </td>
							</tr>


                       </table>
                        </div>

				<?php	} else if($view=="launchpad_history"){ ?>
						 <div class="panel-body">
                     
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered" id="buy">
                                    <thead>
                                        <tr>
                                        <th class="text-center">S.No</th>
                                        <th class="text-center">Email Address</th>
                                        <th class="text-center">Token Name</th>
										<th class="text-center">Status</th>
										<th class="text-center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody style="text-align: center;">
									<?php
								
								if ($launchpad_history) {


								 $i = 1; 
									foreach($launchpad_history as $resultss) {
										
										echo '<tr>';
										echo '<td>' . $i . '</td>';
										echo '<td>' . $resultss->username . '</td>';										
										echo '<td>' . $resultss->token_symbol. '</td>';

										if ($resultss->status == "Completed") {
                                            $status = '<label class="label label-info">Verified</label>';
                                        }
                                        elseif ($resultss->status == "Cancelled") {
                                            $status = '<label class="label label-warning">Cancelled</label>';
                                        }
                                         else {
                                            $status = '<label class="label label-danger">Unverified</label>';
                                        }

										echo '<td>'.$status.'</td>';
										echo '<td>';
										echo '<a href="' . admin_url() . 'launchpad/launchpad_view/' . $resultss->trans_id . '" title="View"><i class="fa fa-eye text-primary"></i></a>&nbsp;&nbsp;&nbsp;';
										echo '</td>';
										echo '</tr>';
										$i++;
									}					
								}
								else {
									echo '<tr>';
									echo '<td colspan="9">' . 'No Records Found!!' . '</td>';
									echo '</tr>';
								} 
								?>
                                    </tbody>
                                </table>
                              
                            </div>
                        </div>

					<?php } else if($view=="launchpad_view"){ ?>

						<div class="panel-body">
                       <table id="banners" class="table table-striped table-bordered1 text-left" cellspacing="0" width="100%">
                       		<tr>
									<th class="text-right" style="width:200px;">Username:</th>
									<td><?php echo $launchpad_view->username; ?> </td>
									</tr>
									<tr>
									<th class="text-right" style="width:200px;">Amount:</th>
									<td><?php echo $launchpad_view->amount; ?> </td>
									</tr>
									<tr>
									<th class="text-right" style="width:200px;">Currency:</th>
									<td><?php echo $launchpad_view->currency_symbol; ?> </td>
									</tr>
									
									<tr>
									<th class="text-right" style="width:200px;">Transaction Id:</th>
									<td><?php if($launchpad_view->transaction_id!='') { echo $launchpad_view->transaction_id; } else { echo '------'; } ?> </td>
									</tr>
									<tr>
									<th class="text-right" style="width:200px;">Token Symbol:</th>
									<td><?php echo $launchpad_view->token_symbol; ?> </td>
									</tr>
									<tr>
									<th class="text-right" style="width:200px;">Transfer Amount:</th>
									<td><?php echo $launchpad_view->transfer_amount; ?> </td>
									</tr>
									<tr>
									<th class="text-right" style="width:200px;">User Status:</th>
									<td><?php echo $launchpad_view->user_status; ?> </td>
									</tr>
									<tr>
									<th class="text-right" style="width:200px;">Reqeusted On:</th>
									<td>	<?php echo gmdate("d-m-Y h:i:s", $launchpad_view->datetime); ?> </td>
									</tr>
									
                       </table>
                        </div>

				<?php	} ?>
                    </div>
                    <!-- end panel -->
                </div>
			</div>
			<!-- end row -->
		</div>
		<!-- end #content -->
<!-- ================== BEGIN BASE JS ================== -->
	<script src="<?php echo admin_source();?>/plugins/jquery/jquery-1.9.1.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/jquery/jquery-migrate-1.1.0.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/jquery-ui/ui/minified/jquery-ui.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/ckeditor/ckeditor.js"></script>
	
	<script src="<?php echo admin_source();?>/plugins/slimscroll/jquery.slimscroll.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/jquery-cookie/jquery.cookie.js"></script>
	<!-- ================== END BASE JS ================== -->
	<!-- ================== BEGIN PAGE LEVEL JS ================== -->
	<script src="<?php echo admin_source();?>/plugins/gritter/js/jquery.gritter.js"></script>
	<script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.time.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.resize.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/DataTables/js/jquery.dataTables.js"></script>
	<script src="<?php echo admin_source();?>/js/jquery.validate.min.js"></script>
	<script src="<?php echo admin_source();?>/js/apps.min.js"></script>
	
	<script src="<?php echo admin_source();?>/js/bootstrap-editable.min.js" type="text/javascript"></script>
	<!-- ================== END PAGE LEVEL JS ================== -->

	<script>
		$(document).ready(function() {
			App.init();
		});
		$(document).ready(function() {			
         	$.fn.dataTableExt.sErrMode = 'throw';
         	$('#buy').DataTable();
         	$('#sell').DataTable();         	
        });

		function search() {
    		var search = $('#search_string').val();
    		var url = '<?php echo admin_url(); ?>';
    		if(search!=''){
    		window.location.href=url+'trade_history/buy/?search_string='+search; }
    		else { window.location.href=url+'trade_history/buy'; }
		}

		function search1() {
    		var search1 = $('#search_string1').val();
    		var url1 = '<?php echo admin_url(); ?>';
    		if(search1!=''){
    		window.location.href=url1+'trade_history/sell/?search_string1='+search1; }
    		else { window.location.href=url1+'trade_history/sell'; }
		}
	</script>
	<script>
      (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      })(window,document,'script','<?php echo admin_source()."www.google-analytics.com/analytics.js";?>','ga');
      ga('create', 'UA-53034621-1', 'auto');
      ga('send', 'pageview');
    </script>
    <script type="text/javascript">
    	$(document).ready(function() {
    		var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';       	
         	$.fn.editable.defaults.mode = 'inline';
         	$('#launchpad_decription').editable();

     	    $('#launchpad_decription').on('save', function(e, params) {
		        var launchpad_decription = params.newValue;
	        	$.ajax({
					url: '<?php echo admin_url();?>'+"launchpad/launchpad_admin_text", 
					type: "POST",             
					data: {'launchpad_decription':launchpad_decription,'launchpad':"<?php echo $launchpad->launch_id;?>"},    
					success: function(data) 
					{						
						var url1 = '<?php echo admin_url(); ?>';
						window.location.href=url1+'launchpad/view/<?php echo $launchpad->launch_id;?>';
					}
				});
		    });
        });
    </script>