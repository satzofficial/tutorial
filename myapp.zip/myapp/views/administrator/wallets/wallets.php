<!-- begin #content -->
<style type="text/css">
            .table-btn1 {
                background-color: #C84E2D;
                border-radius: 3px;
                box-shadow: 0px 3px 6px #00000016;
                color: #fff;
                padding: 5px 10px;
            }
           .table-btn {
            background-color: #04b54f;
            border-radius: 3px;
            box-shadow: 0px 3px 6px #00000016;
            color: #fff;
            padding: 5px 10px;
            }
   .abtn 
   {
    font-size: 11px;
    border: 1px solid #C84E2D;
    padding: 5px 10px;
    border-radius: 3px;
    color: #000;

    }
    input[type="text"], input[type="text"]:active {
    border-radius: 3px;
    border: 0px; 
    height: 31px;
    box-shadow: 0px 3px 6px #00000016;
    background-color: #0b262e;
    color: #ffffff;
    /* padding: 6px; */
    font-size: 15px;
    flex-grow: 2; }

    .input-group-text 
    {
    display: flex;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    padding: .375rem .75rem;
    margin-bottom: 0;
    font-size: 15px;
    font-weight: 400;
    line-height: 1.5;
    color: #495057;
    text-align: center;
    white-space: nowrap;
    background-color: #e9ecef;
    border: 1px solid #ced4da;
    border-radius: .25rem;
    }
    .input-group{
        display: block;
    }
    input[type="text"], input[type="text"]:active {

    border-radius: 3px;
    border: 0px;
    height: 20px;
    background-color:#fff; 
    color: #555; 
    padding: 6px;
    font-size: 13px;
    flex-grow: 2;
    box-shadow:none !important;

    }
    .dash-card.admin-wallet 
    {
        max-width: 600px;
        margin: 0 auto;
        padding: 15px;
        background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 5px;

    }
    .dash-card.admin-wallet .admin-hd {
        padding: 15px;
    margin: 0;
    font-size: 20px;
    }
    .dash-card.admin-wallet .br-code img {
        width: 200px;
        height: 200px;
        margin: 0 auto;
    }
    .admin-wallet .input-group {
        position: relative;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    -webkit-box-align: stretch;
    -ms-flex-align: stretch;
    align-items: stretch;
    width: 100%;
    }
    .admin-wallet .input-group-append, .input-group-prepend {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    cursor: pointer;
}
.admin-wallet .input-group-append {
    margin-left: -1px;
}
.admin-wallet .input-group>.form-control {
    position: relative;
    -webkit-box-flex: 1;
    -ms-flex: 1 1 auto;
    flex: 1 1 auto;
    width: 1%;
    margin-bottom: 0;
}
.admin-wallet .input-group .form-control {
    border-radius: 3px;
    border: 0px;
    height: 30px;
    box-shadow: 0px 3px 6px #00000016;
    border: 1px solid #ced4da;
    color: #606471;
    /* padding: 6px; */
    font-size: 13px;
    flex-grow: 2;
    transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
}
.m-450 {
    max-width: 450px;
    margin: 0 auto;
}
.admin-wallet input[type="text"], input[type="text"] {
    border: 1px solid transparent;
    padding: 6px 12px;
}
.admin-wallet input[type="text"], input[type="text"]:active {
    border-radius: initial;
    border: 0;
    /* height: initial; */
    background-color: initial;
    color: initial;
    padding: 6px 12px;
    /* font-size: initial; */
    flex-grow: initial;
    box-shadow: none !important;
}
.admin-wallet input[type="text"], input[type="text"]:focus {
    padding: 6px 12px;
    border: 0;
    margin: 0;
    background: none;
}
.form-control[readonly]:focus {
    border: 1px solid transparent;
}
.form-control[readonly] {
    background: none;
}

    
        </style>
<div class="page-content-wrapper">
<div class="page-content">
			<?php 
		$error = $this->session->flashdata('error');
		if($error != '') {
			echo '<div class="note note-danger">
			<button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$error.'</div>';
		}
		$success = $this->session->flashdata('success');
		if($success != '') {
			echo '<div class="note note-success">
			<button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$success.'</div>';
		} 
		?>
			<div class="page-head">
			<!-- begin page-header -->
			<div class="page-title">
					<h1>Wallet Management </h1>
				</div>
                </div>
			<!-- begin breadcrumb -->
			<ul class="page-breadcrumb breadcrumb">
				<li>
					<a href="<?php echo admin_url();?>">Home</a>
					<i class="fa fa-circle"></i>
				</li>
				<li class="active"><a href="javascript:;">Wallet</a></li>
			</ul>
			<!-- end breadcrumb -->

			<!-- begin row -->
			<div class="row">
				<div class="col-md-12">
			        <!-- begin panel -->
                		<div class="portlet light">
					<div class="portlet-title">
									<div class="caption">
										<span class="caption-subject bold uppercase font-green-haze">Wallet Management</span>
									</div>
									<div class="tools">
										<a href="javascript:;" class="collapse">
										</a>
										<a href="#portlet-config" data-toggle="modal" class="config">
										</a>
										<a href="javascript:;" class="reload">
										</a>
										<a href="javascript:;" class="fullscreen">
										</a>
										<a href="javascript:;" class="remove">
										</a>
									</div>
								</div>
                        <?php if($view=='view_all'){ ?>
                        <div class="portlet-body">
	                        <div class="clearfix">
	                     
							</div>
							<br/><br/>
                            <div class="table-responsive">
                                <table id="wallet-data" class="table table-striped table-bordered" id="view_all">
                                    <thead>
                                        <tr>
                                            <th class="text-center">S.No</th>
											<th class="text-center">Username</th>
											<th class="text-center">Status</th>	
											<th class="text-center">View Balances</th>
											<th class="text-center">View Addresses</th>
											<th class="text-center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									<?php
								/*if ($users->num_rows() > 0) {
									 $i = 1; 
									foreach($users->result() as $user) {
										 if($user->usertype==1)
                                        {
                                            $usertype ="Personal";
                                            $username = 'tenrealm_username';
                                        }
                                        else 
                                        {
                                            $usertype ="Company";
                                            $username = 'company_name';
                                        }
                                        $username = 'tenrealm_username';
										$wallet_det = $this->common_model->getTableData("wallet",array('user_id'=>$user->id))->row();

										if($wallet_det->status==1)
										{
										
										echo '<tr>';
										echo '<td class="text-center">' . $i . '</td>';
										echo '<td class="text-center" title="'.$user->$username.'">' . character_limiter($user->$username, 20) . '</td>';
										
										if ($user->verified == 1) {
											$status = '<label class="label label-info">Activated</label>';
										} else {
											$status = '<label class="label label-danger">De-Activated</label>';
										}
										echo '<td class="text-center">'.$status.'</td>';
										
										echo '<td class="text-center">';
										echo '<a href="' . admin_url() . 'wallet/view/' . $user->id . '" title="View User Balance"><i class="fa fa-eye text-primary"></i></a>&nbsp;&nbsp;&nbsp;';
										echo '</td>';
										echo '<td class="text-center">';
										echo '<a href="' . admin_url() . 'wallet/view_address/' . $user->id . '" title="View User Crypto Address"><i class="fa fa-eye text-primary"></i></a>&nbsp;&nbsp;&nbsp;';
										echo '</td>';
										echo '<td class="text-center">';
										echo '<a href="' . admin_url() . 'wallet/delete/' . $user->id . '" title="Delete"><i class="fa fa-trash-o text-danger"></i></a>&nbsp;&nbsp;&nbsp;';
										echo '</td>';
										echo '</tr>';
										$i++;
									}
									}					
								} */
								?>
                                    </tbody>
                                </table>
                             
                            </div>
                        </div>
                        <?php }elseif($view=='view_wallet'){ ?>
                        <div class="portlet-body">
						<?php $attributes=array('class'=>'form-horizontal','id'=>'users');
				echo form_open_multipart('',$attributes); ?>
                                <fieldset style="margin-left: 335px;font-size: 14px;">
                                <?php 
								if(!empty($wallets->crypto_amount))
								{$fiat_amount=unserialize($wallets->crypto_amount);
								$crypto_amount=unserialize($wallets->crypto_amount);}

								//print_r($urid);
								?>
                              	<div class="form-group">
                                        <label class="col-md-2 control-label"><strong>Username</strong></label>
                                        <div class="col-md-6 control-label text-left">
										<?php
											$username = get_prefix().'username';
										 	echo $userdetails->$username; ?>
                                        </div>

                                </div>

                                <div class="form-group">
                                        <label class="col-md-2 control-label"><strong>Email</strong></label>
                                        <div class="col-md-6 control-label text-left">
										<?php
											$useremail = getUserEmail($urid);
										 	echo $useremail; ?>
                                        </div>

                                </div>
								
								<?php 
								if(!empty($crypto_amount)){
								foreach($crypto_amount as $keys => $values)
								{

								 ?>
								<?php 
								$id_inc1=1;
								foreach($values as $key1 => $value1)
								{
									if(isset($crypto_currency[$key1])){ 


										$cointotal = to_decimal($value1,8); 

										$symbol = $crypto_currency[$key1]; 

										$currencyDetails = $this->common_model->getTableData('currency', array('currency_symbol'=>$symbol,'status'=>1))->row(); 

										$currencyDetail = $currencyDetails->online_usdprice;

										$usd_total = $currencyDetail*$cointotal;
										$usdPrice = to_decimal($usd_total,2);

										?>
								        <div class="form-group">
                                        <label class="col-md-2 control-label"><strong><?php echo $crypto_currency[$key1]; ?>
                                        </strong></label>
                                        <div class="col-md-6 control-label text-left">
										<?php echo to_decimal($value1,8); ?> / <b><?=$usdPrice?> USD</b>
                                        </div>
                                       </div>
								<?php
								$id_inc1++;
								}
							}
								}}
								else 
									echo "<center>  ..Nil Balance..   </center>";
								?>
                                    
                                </fieldset>
                            </form>
                        </div>
					<?php } else { ?> 
						<div class="portlet-body">
							<?php $address=unserialize($wallets->address); ?>
						<!--new-wallet-design-->
						<div class="address-box dash-card admin-wallet">
									<div class="address-coin">
										<h2><span id="mycur_name"></span> Deposit Address</h2>
									</div>
									<form action="">
										<div class="form-group">
											<label for="exampleFormControlSelect1">Select Coin</label>
											<select onchange="change_currency(this.value)" class="form-control" id="exampleFormControlSelect1">
												<option value="0">Choose Currency</option>
									<?php 
									foreach($address as $key => $value)
									{ 
									 ?>
									 <option value="<?php echo $crypto_address[$key]; ?>/<?=$value?>"><?php echo $crypto_address[$key]; ?></option>
									<?php } ?>

												
											</select>
										</div>
										<div style="display:none" class="coin form-group">
											<div class="qr-img">
												<img src="https://bitcardexs.com/assets/admin/img/qr.png" alt="" class="img-responsive">
											</div>
										</div>
										<div style="display:none" class="coin form-group">
										<div class="input-group mb-3">
											<input id="crypto_address" type="text" class="myaddress form-control" placeholder="d58e278a7g5e427g87eg87b" aria-label="Recipient's username" aria-describedby="basic-addon2">
											<div class="input-group-append">
												<span onclick="copy_function()" class="input-group-text" id="basic-addon2">Copy</span>
											</div>
											</div>
										</div>
									</form>
								</div>


								<input type="hidden" id="getuser" value="<?=$userid?>"/>
								
                        </div>
					<?php } ?>
                    </div>
                    <!-- end panel -->
                </div>
			</div>
			<!-- end row -->
		</div>

	<div id="myModal" class="modal fade">
	<div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal"><span class="icon12 minia-icon-close"></span></button>
          <h3>Reason to reject</h3>
        </div>
        <div class="modal-body">
            <div class="paddingT15 paddingB15"> 
             <center><?php echo form_open(admin_url().'users/verify_level2_reject/'.$users->id.'/Rejected'); ?>
			<textarea name="reject_mail_content" class="form-control"></textarea>
			<br/>
			<button class="btn btn-small btn-danger" style='margin-left:20px;'>REJECT</button>
			<?php echo form_close(); ?></center>
            </div>
        </div>
        <div class="modal-footer">
          <a href="#" class="btn btn-default" data-dismiss="modal">Close</a>
        </div>
    </div>
    </div>
    </div>
	</div>
		<!-- end #content -->
<!-- ================== BEGIN BASE JS ================== -->
	<script src="<?php echo admin_source();?>/plugins/jquery/jquery-1.9.1.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/jquery/jquery-migrate-1.1.0.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/jquery-ui/ui/minified/jquery-ui.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/bootstrap/js/bootstrap.min.js"></script>
	<!--[if lt IE 9]>
		<script src="<?php echo admin_source();?>/crossbrowserjs/html5shiv.js"></script>
		<script src="<?php echo admin_source();?>/crossbrowserjs/respond.min.js"></script>
		<script src="<?php echo admin_source();?>/crossbrowserjs/excanvas.min.js"></script>
	<![endif]-->
	<script src="<?php echo admin_source();?>/plugins/slimscroll/jquery.slimscroll.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/jquery-cookie/jquery.cookie.js"></script>
	<!-- ================== END BASE JS ================== -->
	<!-- ================== BEGIN PAGE LEVEL JS ================== -->
	<script src="<?php echo admin_source();?>/plugins/gritter/js/jquery.gritter.js"></script>
	<script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.time.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.resize.min.js"></script>

	<script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script> 
	<script src="https://cdn.datatables.net/responsive/2.2.6/js/dataTables.responsive.min.js"></script>

	<script src="<?php echo admin_source();?>/js/apps.min.js"></script>
	<!-- ================== END PAGE LEVEL JS ================== -->
		<script>
			var admin_url='<?php echo admin_url(); ?>';
		$(document).ready(function() {
			App.init();
		});
		 $(document).ready(function() {
    $('#wallet-data').DataTable( {
    	"responsive" : true,
        "processing" : true,
        "pageLength" : 10,
        "serverSide": true,
        "order": [[0, "asc" ]],
        "searching": true,
        "ordering": false,
        "ajax": admin_url+"wallet/wallet_ajax"
    });
 });
    function change_currency(val)
    {
    	//alert(val);
    	if(val!=0)
    	{
	    	var userid = $("#getuser").val();
			var _this = val;
			var myvar = _this.split("/"); 	
			
			$.ajax({
					url: admin_url+"wallet/get_address/"+userid,
	                type: "POST",
	                data: "currency_symbol="+myvar[0]+"&address="+myvar[1],
	                success: function(data) {
	                	var result = JSON.parse(data);
	                	var imag = result.img;
	                	$(".coin").show();
	                	$(".qr-img").html('<img src="'+imag+'" alt="" class="img-responsive">');
	                	$(".myaddress").val(myvar[1]);
	                	$("#mycur_name").html(myvar[0]);
	                }
	            }); 
	    }
	    else
	    {
	    	$(".coin").hide();
	    }  
      }

function copy_function() {
  var copyText = document.getElementById("crypto_address");
  copyText.select();
  document.execCommand("COPY");
  $('.copy_but').html('COPIED');
} 
		
	</script>
	 <script async
src="https://www.googletagmanager.com/gtag/js?id=G-FDX8TJF8SG"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', 'G-FDX8TJF8SG');
</script>
