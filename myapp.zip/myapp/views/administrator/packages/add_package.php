<?php 
$method = $this->router->fetch_method();
?>
<!-- begin #content -->
<div class="page-content-wrapper">
  <div class="page-content">
    <?php         
    $prefix = get_prefix();
    $error = $this->session->flashdata('error');
    if($error != '') {
      echo '<div class="note note-danger">
      <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$error.'</div>';
    }

    $success = $this->session->flashdata('success');
    if($success) {
      echo '<div class="note note-success">
      <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$success.'</div>';
    } 
    ?>
    <div class="page-head">
      <!-- begin page-header -->
      <div class="page-title">
        <h1>Manage Package</h1>
      </div>
    </div>
    <ul class="page-breadcrumb breadcrumb">
      <li>
        <a href="<?php echo admin_url();?>">Home</a>
        <i class="fa fa-circle"></i>
      </li>
      <li>
        <a href="<?php echo admin_url().'package'; ?>">Manage Package</a>
        <i class="fa fa-circle"></i>
      </li>
      <li class="active"><a href="javascript:;"> <?php if($method == 'add') { echo 'Add';}else{ echo 'Edit';} ?> Package</a></li>
    </ul>
    <!-- begin row -->
    <div class="row">
      <div class="col-md-12">
        <!-- begin panel -->
        <div class="portlet light">
          <div class="portlet-title">
            <div class="caption">
              <span class="caption-subject bold uppercase font-green-haze">Manage Package</span>
            </div>
            <div class="tools">
              <a href="javascript:;" class="collapse">
              </a>
              <a href="#portlet-config" data-toggle="modal" class="config">
              </a>
              <a href="javascript:;" class="reload">
              </a>
              <a href="javascript:;" class="fullscreen">
              </a>
              <a href="javascript:;" class="remove">
              </a>
            </div>
          </div>

          <div class="portlet-body">
            <div class="clearfix">
            </div>
            <br/><br/>
            <div class="table-responsive">

              <div class="panel-body">
                <?php
                if(validation_errors()){
                  $error =  validation_errors();
                  echo '<div class="note note-danger">
                  <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$error.'</div>';
                }
                $attributes=array('class'=>'form-horizontal','id'=>'package');
                echo form_open($action,$attributes);
                ?>
                <fieldset>
                  <div class="form-group">
                    <label class="col-md-4 control-label">Package Name <em class="star">*</em></label>
                    <div class="col-md-4">
                      <input type="text" <?php if($method == 'add') { echo 'autofocus';} ?> name="package_name" id="package_name" class="form-control package_name"
                      value="<?php 
                      if($package_data['package_name']){
                        echo $package_data['package_name'];
                      }else if(set_value('package_name')){
                        echo set_value('package_name');
                      } ?>" />
                    </div>
                  </div>


                  <div class="form-group">
                    <label class="col-md-4 control-label">Direct Planter Income (PYM) <em class="star">*</em></label>
                    <div class="col-md-4">
                      <input type="text" name="income" id="income" class="form-control" value="<?php 
                      if($package_data['income']){
                        echo $package_data['income'];
                      }else if(set_value('income')){
                        echo set_value('income');
                      } ?>"/>
                    </div>
                  </div>
               

                  <div class="form-group">
                    <label class="col-md-4 control-label">System Income (PYM)  <em class="star">*</em></label>
                    <div class="col-md-4">
                      <input type="text" name="system_income" id="system_income" class="form-control" value="<?php 
                      if($package_data['system_income']){
                        echo $package_data['system_income'];
                      }else if(set_value('system_income')){
                        echo set_value('system_income');
                      } ?>" />
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-md-4 control-label">Status</label>
                    <div class="col-md-4">
                      <select data-live-search="true" id="status" name="status" class="form-control">
                        <?php 
                        if($method === 'edit'){
                          if($package_data['status']){
                            echo '<option value="1" selected >Active</option>';
                            echo '<option value="0">De-active</option>';
                          }else{
                            echo '<option value="1">Active</option>';
                            echo '<option value="0" selected >De-active</option>';
                          }
                        }else{
                        echo '<option value="1">Active</option>';
                        echo '<option value="0">De-active</option>';
                        } 
                        ?>                        
                      </select>
                    </div>
                  </div>


                  <div class="form-group">
                    <div class="col-md-12">
                      <button type="submit" class="btn green btn-submit float-right ">Submit</button>
                      <button type="button" class="btn btn-default float-left cancel">Back</button>                      
                    </div>
                  </div>
                </fieldset>
                <?php echo form_close(); ?>
              </div>
            </div>
          </div>                    
        </div>
        <!-- end panel -->
      </div>
    </div>
    <!-- end row -->
  </div>

  <div id="myModal" class="modal fade">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal"><span class="icon12 minia-icon-close"></span></button>
          <h3>Reason to reject</h3>
        </div>
        <div class="modal-body">
          <div class="paddingT15 paddingB15"> 
            <center><?php echo form_open(admin_url().'users/verify_photo1_reject/'.$users->id.'/2'); ?>
            <textarea name="reject_mail_content" class="form-control" required></textarea>
            <br/>
            <button class="btn btn-small btn-danger" style='margin-left:20px;'>REJECT</button>
            <?php echo form_close(); ?></center>
          </div>
        </div>
        <div class="modal-footer">
          <a href="#" class="btn btn-default" data-dismiss="modal">Close</a>
        </div>
      </div>
    </div>
  </div>
</div>


<script src="<?php echo admin_source();?>/plugins/jquery/jquery-1.9.1.min.js"></script>
<script src="<?php echo admin_source();?>/js/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
<script type="text/javascript">
   var admin_url='<?php echo admin_url(); ?>';    
    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';
    var csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
  $(document).ready(function() {

    var _pkname = $('#package_name');
      _pkname.keypress(function () {
        var _val = _pkname.val();
        var _txt = _val.charAt(0).toUpperCase() + _val.slice(1);
      _pkname.val(_txt);
  })


    $.validator.addMethod("greaterThan",
      function (value, element, param) {
        var $otherElement = $(param);
        return parseInt(value, 10) > parseInt($otherElement.val(), 10);
      });

    $(document).on('click','.cancel', function(){
      window.location.href= admin_url + 'package';
    });


$('#package').validate({ // initialize the plugin
  rules: {
    package_name: {
      required: true,
      maxlength: 255          
    },
    income: {
      required: true,      
      number:true
    }, 
    branch_income: {
      required: true,      
      number:true
    }, 
    farming_income: {
      required: true,      
      number:true
    }, 
    cultivation_income: {
      required: true,      
      number:true
    },
    system_income: {
      required: true,      
      number:true
    },
  },
  messages: {
    income:
    {
      // required: "Please enter your package price",
      number:"Please enter numbers Only"
    },
    branch_income:
    {
      // required: "Please enter your package price",
      number:"Please enter numbers Only"
    },
    forming_income:
    {
      // required: "Please enter your package price",
      number:"Please enter numbers Only"
    },
    cultivation_income:
    {
      // required: "Please enter your package price",
      number:"Please enter numbers Only"
    },
    system_income:
    {
      // required: "Please enter your package price",
      number:"Please enter numbers Only"
    }
  }

});
});

</script>
