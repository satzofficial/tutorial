
<!-- begin #content -->
<div class="page-content-wrapper">
    <div class="page-content">
        <?php         
        $prefix = get_prefix();
        $error = $this->session->flashdata('error');
        if($error != '') {
            echo '<div class="note note-danger">
            <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$error.'</div>';
        }

        $success = $this->session->flashdata('success');
        if($success) {
            echo '<div class="note note-success">
            <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$success.'</div>';
        } 
        ?>
        <div class="page-head">
            <!-- begin page-header -->
            <div class="page-title">
                <h1>Global Farming Income</h1>
            </div>
            <div class="actions btn-set float-right">
                <a href="<?php echo admin_url(); ?>package/add_gfi/<?php echo $id;?>" data-placement="top" data-toggle="popover" data-content="Add New Static Content" class="btn btn-success poper" data-original-title="" title="">Add New</a>
            </div>
        </div>
       
        <ul class="page-breadcrumb breadcrumb">
      <li>
        <a href="<?php echo admin_url();?>">Home</a>
        <i class="fa fa-circle"></i>
      </li>
      <li>
        <a href="<?php echo admin_url().'package'; ?>">Manage Package</a>
        <i class="fa fa-circle"></i>
      </li>
      <li class="active"><a href="javascript:;"> Global Farming Income</a></li>
    </ul>
        <!-- begin row -->
        <div class="row">
            <div class="col-md-12">
                <!-- begin panel -->
                <div class="portlet light">
                    <div class="portlet-title">
                        <div class="caption">
                            <span class="caption-subject bold uppercase font-green-haze">Global Farming Income</span>
                        </div>
                        <div class="tools">
                            <a href="javascript:;" class="collapse">
                            </a>
                            <a href="#portlet-config" data-toggle="modal" class="config">
                            </a>
                            <a href="javascript:;" class="reload">
                            </a>
                            <a href="javascript:;" class="fullscreen">
                            </a>
                            <a href="javascript:;" class="remove">
                            </a>
                        </div>
                    </div>

                    <div class="portlet-body">
                        <div class="clearfix">
                        </div>
                        <br/><br/>
                        <div class="table-responsive">
                            <table id="package-data" class="table table-striped table-bordered" id="view_all">
                                <thead>
                                    <tr>
                                        <th class="text-center">S.No</th>
                                        <th class="text-center">Price</th>
                                        <th class="text-center">User</th>
                                        <!-- <th class="text-center">Total</th>
                                        <th class="text-center">AP Upgrade</th>
                                        <th class="text-center">Rebirth</th>
                                        <th class="text-center">TO Sponsor</th>
                                        <th class="text-center">Profit</th> -->
                                        <th class="text-center">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    if($global_farming_income){                                        
                                        foreach ($global_farming_income as $pdkey => $pdvalue) {     
                                            $pdkey = $pdkey + 1;
                                            $row_values = '';
                                            $package_price = 0;
                                            echo '<tr>';
                                            
                                            $id = $pdvalue['id'];
                                            $package_id = $pdvalue['package_id'];
                                            
                                            
                                            if($pdvalue['price']){
                                                $row_values .= '<td>'. $pdkey.'</td>';
                                            }else{
                                                $row_values .= '<td></td>';
                                            }

                                            if($pdvalue['price']){
                                                $row_values .= '<td>'. $pdvalue['price'].'</td>';
                                            }else{
                                                $row_values .= '<td></td>';
                                            }

                                            if($pdvalue['user']){
                                                $row_values .= '<td>'. $pdvalue['user'] .'</td>';
                                            }else{
                                                $row_values .= '<td></td>';
                                            }


                                            // if($pdvalue['total']){                                                    
                                            //     $row_values .= '<td>'. $pdvalue['total'] .'</td>';
                                            // }else{
                                            //     $row_values .= '<td></td>';
                                            // }


                                            // if($pdvalue['ap_upgrade']){                                                    
                                            //     $row_values .= '<td>'. $pdvalue['ap_upgrade'] .'</td>';
                                            // }else{
                                            //     $row_values .= '<td>-</td>';
                                            // }

                                            // if($pdvalue['rebirth']){                                                    
                                            //     $row_values .= '<td>'. $pdvalue['rebirth'] .'</td>';
                                            // }else{
                                            //     $row_values .= '<td>-</td>';
                                            // }



                                            // if($pdvalue['to_sponsor']){                                                    
                                            //     $row_values .= '<td>'. $pdvalue['to_sponsor'] .'</td>';
                                            // }else{
                                            //     $row_values .= '<td>0.0</td>';
                                            // }


                                            // if($pdvalue['profit']){                                                    
                                            //     $row_values .= '<td>'. $pdvalue['profit'] .'</td>';
                                            // }else{
                                            //     $row_values .= '<td>0.00</td>';
                                            // }
                                            
                                            if($pdvalue['status']==1){
                                                $row_values .= '<td>';
                                                $row_values .= '<div class="btn-group"><a href="'.admin_url().'package/edit_gfi/'.$package_id .'/'.$id.'"><i class="fa fa-pencil fa-1.5x"></i></a>';
                                                // $row_values .= '<a href="javascript:;" class="lockme" id="'.$id.'"><i class="fa fa-lock fa-1.5x"></i></a>';
                                                $row_values .= '</div></td>';
                                            }else{
                                                $row_values .= '<td><a href="javascript:;" class="unlockme"  id="'.$id.'"><i class="fa fa-unlock fa-1.5x"></i></a></td>';
                                            }                                            


                                            echo $row_values;                                                
                                            echo '</tr>';
                                        }                                            
                                    }
                                    ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th colspan="1" style="text-align:right">Total:</th>
                                        <th colspan="3"></th>
                                        
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>                    
                </div>
                <!-- end panel -->
            </div>
        </div>
        <!-- end row -->
    </div>

</div>
<!-- end #content -->
<!-- ================== BEGIN BASE JS ================== -->
<script src="<?php echo admin_source();?>/plugins/jquery/jquery-1.9.1.min.js"></script>
<script src="<?php echo admin_source();?>/js/apps.min.js"></script>
<!-- ================== END PAGE LEVEL JS ================== -->
<script>
    $(document).ready(function() {
        App.init();
    });
</script>
<script>     
    var admin_url='<?php echo admin_url(); ?>';    
    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';
    var csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
    $(document).ready(function() {

        $('#package-data').DataTable( {
            "footerCallback": function ( row, data, start, end, display ) {
                var api = this.api();

            // Remove the formatting to get integer data for summation
            var intVal = function ( i ) {
                return typeof i === 'string' ?
                i.replace(/[\$,]/g, '')*1 :
                typeof i === 'number' ?
                i : 0;
            };

            // Total over all pages
            total = api
            .column( 1 )
            .data()
            .reduce( function (a, b) {
                return intVal(a) + intVal(b);
            }, 0 );

            // Total over this page
            pageTotal = api
            .column( 1, { page: 'current'} )
            .data()
            .reduce( function (a, b) {
                return intVal(a) + intVal(b);
            }, 0 );

            // Update footer
            $( api.column( 1 ).footer() ).html(
                // '$'+pageTotal +' ( $'+ total +' total)'
                '$'+ pageTotal.toFixed(2) 
            );
        },
             "responsive" : true,
            "processing" : true,
            // "pageLength" : 10,
            "order": [[0, "asc" ]],
            "searching": true,
    });



        $(document).on('click', '.lockme, .unlockme', function(){
            var _this = $(this);
            var lockId = _this.attr('id');    
            if(_this.hasClass('lockme')){
                var status = 0;
            }else{
                var status = 1;
            }      

            if (typeof(lockId) != 'undefined' && lockId != null) {                
                $.ajax({
                    url: admin_url + 'package/status',
                    type: 'POST',                    
                    data: {[csrfName]: csrfHash, status:status, id:lockId },                    
                    // data: {[csrfName]: csrfHash, status:status },                    
                    dataType: 'json',
                    success: function(result) {   
                       if (typeof(result) != 'undefined' && result != null && result.status == 'true') {         
                        window.location.reload(1);
                    }
                },
                error: jqueryErrorHandling,
            });                
            }
        });

    });



    function jqueryErrorHandling(xhr, status, exception) {
        var responseText;
        $("#dialog").html("");
        try {
            responseText = jQuery.parseJSON(xhr.statusText);
            $("#dialog").append("<div><b>" + status + " " + exception + "</b></div>");
            $("#dialog").append("<div><u>Exception</u>:<br /><br />" + responseText.ExceptionType + "</div>");
            $("#dialog").append("<div><u>StackTrace</u>:<br /><br />" + responseText.StackTrace + "</div>");
            $("#dialog").append("<div><u>Message</u>:<br /><br />" + responseText.Message + "</div>");
        } catch (e) {
            var errorMessage = xhr.statusText;
            $("#dialog").html(errorMessage);
            $("#dialog").dialog({
                title: "Exception Details",
                autoOpen: true,
                modal: true,
                width: 700,
                buttons: {
                    Close: function() {
                        $(this).dialog('close');
                    }
                }
            });
        }
    }
</script>

<style>
    .u_img{width:125px; height:125px; overflow:hidden; display:inline-block; float:left;}
    .u_img img{   height: auto;
        max-height: 100%;
        width: 100%;
    }
</style>