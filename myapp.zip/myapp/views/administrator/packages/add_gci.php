<?php 
$method = $this->router->fetch_method();
$back = admin_url().'package/global_cultivate_income/'.$package_id;
?>
<!-- begin #content -->
<div class="page-content-wrapper">
  <div class="page-content">
    <?php         
    $prefix = get_prefix();
    $error = $this->session->flashdata('error');
    if($error != '') {
      echo '<div class="note note-danger">
      <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$error.'</div>';
    }

    $success = $this->session->flashdata('success');
    if($success) {
      echo '<div class="note note-success">
      <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$success.'</div>';
    } 
    ?>
    <div class="page-head">
      <!-- begin page-header -->
      <div class="page-title">
        <h1>Manage Package</h1>
      </div>
    </div>

     <ul class="page-breadcrumb breadcrumb">
      <li>
        <a href="<?php echo admin_url();?>">Home</a>
        <i class="fa fa-circle"></i>
      </li>
      <li>
        <a href="<?php echo admin_url().'package'; ?>">Manage Package</a>
        <i class="fa fa-circle"></i>
      </li>
      <li>
        <a href="<?php echo $back; ?>">Global Cultivation Income</a>
        <i class="fa fa-circle"></i>
      </li>
       <li class="active"><a href="javascript:;"> <?php if($mode == 'add') { echo 'Add';}else{ echo 'Edit';} ?> Global Cultivation Income</a></li>
    </ul>

    <!-- begin row -->
    <div class="row">
      <div class="col-md-12">
        <!-- begin panel -->
        <div class="portlet light">
          <div class="portlet-title">
            <div class="caption">
              <span class="caption-subject bold uppercase font-green-haze">Global Cultivation Income</span>
            </div>
            <div class="tools">
              <a href="javascript:;" class="collapse">
              </a>
              <a href="#portlet-config" data-toggle="modal" class="config">
              </a>
              <a href="javascript:;" class="reload">
              </a>
              <a href="javascript:;" class="fullscreen">
              </a>
              <a href="javascript:;" class="remove">
              </a>
            </div>
          </div>

          <div class="portlet-body">
            <div class="clearfix">
            </div>
            <br/><br/>
            <div class="table-responsive">

              <div class="panel-body">
                <?php
                if(validation_errors()){
                  $error =  validation_errors();
                  echo '<div class="note note-danger">
                  <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$error.'</div>';
                }
                $attributes=array('class'=>'form-horizontal','id'=>'package');
                echo form_open($action,$attributes);
                ?>
                <fieldset>
                  <div class="form-group">
                    <label class="col-md-4 control-label">Price <em class="star">*</em></label>
                    <div class="col-md-4">
                      <div class="input-group">
                        <span class="input-group-addon">$</span>
                        <input type="text" name="price" autofocus id="price" class="form-control" value="<?php 
                        if($package_data['price']){
                          echo $package_data['price'];
                          }else if(set_value('price')){
                            echo set_value('price');
                          } ?>" />
                        </div>

                      </div>
                    </div>



                    <div class="form-group">
                      <label class="col-md-4 control-label">User <em class="star">*</em></label>
                      <div class="col-md-4">
                        <input type="text" name="user" id="user" class="form-control" value="<?php 
                        if($package_data['user']){
                          echo $package_data['user'];
                          }else if(set_value('user')){
                            echo set_value('user');
                          } ?>"/>
                        </div>
                      </div>


                      <div class="form-group">
                        <label class="col-md-4 control-label">Total <em class="star">*</em></label>
                        <div class="col-md-4">
                          <input type="text" name="total" id="total" class="form-control" value="<?php 
                          if($package_data['total']){
                            echo $package_data['total'];
                            }else if(set_value('total')){
                              echo set_value('total');
                            } ?>"/>
                          </div>
                        </div>


                      

                          <div class="form-group">
                            <label class="col-md-4 control-label">Rebirth <em class="star">*</em></label>
                            <div class="col-md-4">
                              <input type="text" name="rebirth" id="rebirth" class="form-control" value="<?php 
                              if($package_data['rebirth']){
                                echo $package_data['rebirth'];
                                }else if(set_value('rebirth')){
                                  echo set_value('rebirth');
                                } ?>"/>
                              </div>
                            </div>

                            <div class="form-group">
                              <label class="col-md-4 control-label">TO Sponsor <em class="star">*</em></label>
                              <div class="col-md-4">
                                <input type="text" name="to_sponsor" id="to_sponsor" class="form-control" value="<?php 
                                if($package_data['to_sponsor']){
                                  echo $package_data['to_sponsor'];
                                  }else if(set_value('to_sponsor')){
                                    echo set_value('to_sponsor');
                                  } ?>" />
                                </div>
                              </div>

                              <div class="form-group">
                                <label class="col-md-4 control-label">Profit <em class="star">*</em></label>
                                <div class="col-md-4">
                                  <input type="text" name="profit" id="profit" class="form-control" value="<?php 
                                  if($package_data['profit']){
                                    echo $package_data['profit'];
                                    }else if(set_value('profit')){
                                      echo set_value('profit');
                                    } ?>" />
                                  </div>
                                </div>


                                <div class="form-group">
                                  <div class="col-md-12">
                                    <button type="submit" class="btn green btn-submit float-right ">Submit</button>
                                    <button type="button" class="btn btn-default float-left cancel">Back</button>                      
                                  </div>
                                </div>
                              </fieldset>
                              <?php echo form_close(); ?>
                            </div>
                          </div>
                        </div>                    
                      </div>
                      <!-- end panel -->
                    </div>
                  </div>
                  <!-- end row -->
                </div>
           
              </div>

<script src="<?php echo admin_source();?>/plugins/jquery/jquery-1.9.1.min.js"></script>
<script src="<?php echo admin_source();?>/js/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
<script type="text/javascript">
  var admin_url='<?php echo admin_url(); ?>';    
  var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';
  var csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
  var package_id = '<?php echo $id; ?>';
  var back = "<?php echo $back; ?>";
  $(document).ready(function() {
    $.validator.addMethod("greaterThan",
      function (value, element, param) {
        var $otherElement = $(param);
        return parseInt(value, 10) > parseInt($otherElement.val(), 10);
      });

    $(document).on('click','.cancel', function(){
      window.location.href= back;
    });


  $('#package').validate({ // initialize the plugin
    rules: {
      price: {
        required: true,
        // maxlength: 255          
      },
      user: {
        required: true,      
        number:true
      }, 
      total: {
        required: true,      
        number:true
      }, 
      // ap_upgrade: {
      //   required: true,      
      //   number:true
      // }, 
      // rebirth: {
      //   required: true,      
      //   number:true
      // },
      to_sponsor: {
        required: true,      
        number:true
      },
      profit: {
        required: true,      
        number:true
      },
    },
    messages: {
      price:
      {
        number:"Please enter numbers Only"
      },
      user:
      {
        number:"Please enter numbers Only"
      },
      total:
      {
        number:"Please enter numbers Only"
      },
      // ap_upgrade:
      // {
      //   number:"Please enter numbers Only"
      // },
      // rebirth:
      // {
      //   number:"Please enter numbers Only"
      // },
      to_sponsor:
      {
        number:"Please enter numbers Only"
      },
      profit:
      {
        number:"Please enter numbers Only"
      },
    }

  });



  

  // Numeric only control handler
$.fn.ForceNumericOnly = function()
{
    return this.each(function()
    {
        $(this).keydown(function(e)
        {
            var key = e.charCode || e.keyCode || 0;
            // allow backspace, tab, delete, enter, arrows, numbers and keypad numbers ONLY
            // home, end, period, and numpad decimal
            return (
                key == 8 || 
                key == 9 ||
                key == 13 ||
                key == 46 ||
                key == 110 ||
                key == 190 ||
                (key >= 35 && key <= 40) ||
                (key >= 48 && key <= 57) ||
                (key >= 96 && key <= 105) ||
                (key >= 46 && this.value.split('.').length === 2));
        });
    });
};
var allInputs = $( "input" );
// $("#user").ForceNumericOnly();
// $("#ap_upgrade").ForceNumericOnly();
allInputs.ForceNumericOnly();



});
</script>