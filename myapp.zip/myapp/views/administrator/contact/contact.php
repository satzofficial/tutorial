<!-- begin #content -->
<div class="page-content-wrapper">
<div class="page-content">
	<?php 
		$error = $this->session->flashdata('error');
		if($error != '') {
			echo '<div class="note note-danger">
			<button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$error.'</div>';
		}
		$success = $this->session->flashdata('success');
		if($success != '') {
			echo '<div class="note note-success">
			<button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$success.'</div>';
		} 
	?>
				<!-- begin page-header -->
				<div class="page-head">
			<div class="page-title">
					<h1>Contact us</h1>
				</div>
                </div>
			<!-- end page-header -->
		<!-- begin breadcrumb -->
		<ul class="page-breadcrumb breadcrumb">
				<li>
					<a href="<?php echo admin_url();?>">Home</a>
					<i class="fa fa-circle"></i>
				</li>
				<li class="active"><a href="javascript:;">Contact Us</a></li>
			</ul>
		<!-- end breadcrumb -->

		<!-- begin row -->
		<div class="row">
			<div class="col-md-12">
		        <!-- begin panel -->
				<div class="portlet light">
					<div class="portlet-title">
                    <div class="caption">
						<span class="caption-subject bold uppercase font-green-haze">Contact Us</span>
					</div>
					<div class="tools">
						<a href="javascript:;" class="collapse">
						</a>
						<a href="#portlet-config" data-toggle="modal" class="config">
						</a>
						<a href="javascript:;" class="reload">
						</a>
						<a href="javascript:;" class="fullscreen">
						</a>
						<a href="javascript:;" class="remove">
						</a>
					</div>
                        </div>
					<?php 
						if($view=='view_all')
						{ 
					?>
                    		<div class="portlet-body">
                    	
                        		<div class="table-responsive">
                            		<table id="datas-table" class="table table-striped table-bordered">
			                            <thead>
			                                <tr>
			                                   	<th class="text-center">S.No</th>
												<th class="text-center">Date</th>
												<th class="text-center">Name</th>
												<th class="text-center">Email</th>
												<th class="text-center">Question / Inquiry </th>
												<th class="text-center">Status</th>
												<th class="text-center">Phone</th>
												
			                                </tr>
			                            </thead>
			                            <tbody style="text-align: center;">
										
			                        	</tbody>
			                        </table>
                            		
                       			</div>
                    		</div>
					<?php 
						} else { 
					?>
							<div class="portlet-body">
								<?php 
									$attributes=array('class'=>'form-horizontal','id'=>'contact');
									echo form_open_multipart($action,$attributes); 
								?>
			                        <fieldset>
			                        	<div class="form-group">
			                                <label class="col-md-2 control-label">User Name</label>
			                                <div class="col-md-8">
											<?php echo $contact->username; ?>
			                                </div>
			                            </div>
			                            <div class="form-group">
			                                <label class="col-md-2 control-label">Email</label>
			                                <div class="col-md-8">
											<?php echo $contact->email; ?>
			                                </div>
			                            </div>
			                        	<div class="form-group">
			                                <label class="col-md-2 control-label">Question / Inquiry </label>
			                                <div class="col-md-8">
											<?php echo $contact->subject; ?>
			                                </div>
			                            </div>
			                          
			                            <div class="form-group">
			                                <label class="col-md-2 control-label">Reply Message</label>
			                                <div class="col-md-8">
											<textarea class="form-control" id="content_description" name="content_description" rows="10"></textarea>
			                                </div>
			                            </div>
			                            <div class="form-group">
			                                <div class="col-md-7 col-md-offset-5">
			                                    <button type="submit" class="btn btn-sm btn-primary m-r-5">Send</button>
			                                </div>
			                            </div>
			                        </fieldset>
			                    </form>
			                </div>
					<?php } ?> 
                </div>
                <!-- end panel -->
            </div>
		</div>
		<!-- end row -->
	</div>
	</div>
	<!-- end #content -->
	<!-- ================== BEGIN BASE JS ================== -->

	<script src="<?php echo admin_source();?>plugins/jquery/jquery-1.9.1.min.js"></script>
	<script src="<?php echo admin_source();?>plugins/jquery/jquery-migrate-1.1.0.min.js"></script>
	<script src="<?php echo admin_source();?>plugins/jquery-ui/ui/minified/jquery-ui.min.js"></script>
	<script src="<?php echo admin_source();?>plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="<?php echo admin_source();?>plugins/ckeditor/ckeditor.js"></script>
	
	<script src="<?php echo admin_source();?>plugins/slimscroll/jquery.slimscroll.min.js"></script>
	<script src="<?php echo admin_source();?>plugins/jquery-cookie/jquery.cookie.js"></script>
	<!-- ================== END BASE JS ================== -->
	<!-- ================== BEGIN PAGE LEVEL JS ================== -->
	<script src="<?php echo admin_source();?>plugins/gritter/js/jquery.gritter.js"></script>
	<script src="<?php echo admin_source();?>plugins/flot/jquery.flot.min.js"></script>
	<script src="<?php echo admin_source();?>plugins/flot/jquery.flot.time.min.js"></script>
	<script src="<?php echo admin_source();?>plugins/flot/jquery.flot.resize.min.js"></script>

    <script src="<?php echo admin_source();?>/plugins/DataTables/js/jquery.dataTables.min.js"></script> 
    <script src="<?php echo admin_source();?>/plugins/DataTables/js/dataTables.responsive.min.js"></script>

	<script src="<?php echo admin_source();?>js/jquery.validate.min.js"></script>
	<script src="<?php echo admin_source();?>js/apps.min.js"></script>

	<!-- ================== END PAGE LEVEL JS ================== -->
	<script>
		$(document).ready(function(){
			App.init();

			var admin_url='<?php echo admin_url(); ?>';
		
$(document).ready(function() {
    $('#datas-table').DataTable( {
    	"responsive" : true,
        "processing" : true,
        "pageLength" : 10,
        "serverSide": true,
        "order": [[0, "asc" ]],
        "searching": true,
        "ajax": admin_url+"contact/contact_ajax"
    });
        });
      
			
			$('#contact').validate({
				rules: {
					content_description: {
						required: true
					},
				},
				highlight: function (element) {
					//$(element).parent().addClass('error')
				},
				unhighlight: function (element) {
					$(element).parent().removeClass('error')
				}
			});
		});	
	</script> 
<?php
	if($view)
	{
		if($view=='view_all'){
		}
		else
		{
			?>
	<script>

        $(document).ready(function() {
            CKEDITOR.replace('content_description');
        });
    </script>
		<?php 	
		}
	}
	
	?>
	<script>		

		
    </script>
     <script async
src="https://www.googletagmanager.com/gtag/js?id=G-FDX8TJF8SG"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', 'G-FDX8TJF8SG');
</script>