<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.1/css/lightbox.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.1/js/lightbox-plus-jquery.min.js"></script>
<div class="page-content-wrapper">
    <div class="page-content">
        <?php 
        $prefix = 'tenrealm_';
        $error = $this->session->flashdata('error');
        if($error != '') {
            echo '<div class="note note-danger">
            <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$error.'</div>';
        }
        
        $success = $this->session->flashdata('success');
        if($success) {
            echo '<div class="note note-success">
            <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$success.'</div>';
        } 
        ?>
        <div class="page-head">
            <!-- begin page-header -->
            <div class="page-title">
                <h1><?php if($this->uri->segment(2)=='') { echo ""; } else if($this->uri->segment(2)=='transfer') { echo "Transfer"; } ?> Management </h1>
            </div>
        </div>

        <ul class="page-breadcrumb breadcrumb">
            <li>
                <a href="<?php echo admin_url();?>">Home</a>
                <i class="fa fa-circle"></i>
            </li>
            <li class="active"><a href="javascript:;">Transfer</a></li>
        </ul>
        <!-- begin row -->
        <div class="row">
            <div class="col-md-12">
                <!-- begin panel -->
                <div class="portlet light">
                    <div class="portlet-title">
                        <div class="caption">
                            <span class="caption-subject bold uppercase font-green-haze">
                            <?php if($this->uri->segment(2)=='') { echo ""; } else if($this->uri->segment(2)=='transfer') { echo "Transfer"; } ?> Management</span>
                        </div>
                        <div class="tools">
                            <a href="javascript:;" class="collapse">
                            </a>
                            <a href="#portlet-config" data-toggle="modal" class="config">
                            </a>
                            <a href="javascript:;" class="reload">
                            </a>
                            <a href="javascript:;" class="fullscreen">
                            </a>
                            <a href="javascript:;" class="remove">
                            </a>
                        </div>
                    </div>
                    <?php if($view=='list')
                    { ?>
                        <div class="portlet-body">
                            <div class="clearfix">
                            </div>
                            <br/><br/>
                            <div class="table-responsive">
                                <table id="list-table" class="table table-striped table-bordered" id="list-table">
                                    <thead>
                                        <tr>
                                            <th class="text-center">S.No</th>
                                            <th class="text-center">Transaction id</th>
                                            <th class="text-center">Sender</th>
                                            <th class="text-center">Receiver</th>
                                            <th class="text-center">Amount</th>
                                            <th class="text-center">Type</th>
                                            <th class="text-center">Date & Time</th>
                                        </tr>
                                    </thead>
                                    <tbody> </tbody>
                                </table>
                                
                            </div>
                        </div>
                    <?php } ?>
                   
                   
                

                                            </div>
                                            <!-- end panel -->
                                        </div>
                                    </div>
                                    <!-- end row -->
                                </div>

                                                  
                        </div>
  <!-- end #content -->
  <!-- ================== BEGIN BASE JS ================== -->
  <script src="<?php echo admin_source();?>/plugins/jquery/jquery-1.9.1.min.js"></script>
  <script src="<?php echo admin_source();?>/plugins/jquery/jquery-migrate-1.1.0.min.js"></script>
  <script src="<?php echo admin_source();?>/plugins/jquery-ui/ui/minified/jquery-ui.min.js"></script>
  <script src="<?php echo admin_source();?>/plugins/bootstrap/js/bootstrap.min.js"></script>
   
    <script src="<?php echo admin_source();?>/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="<?php echo admin_source();?>/plugins/jquery-cookie/jquery.cookie.js"></script>
    <!-- ================== END BASE JS ================== -->
    <!-- ================== BEGIN PAGE LEVEL JS ================== -->
    <script src="<?php echo admin_source();?>/plugins/gritter/js/jquery.gritter.js"></script>
    <script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.min.js"></script>
    <script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.time.min.js"></script>
    <script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.resize.min.js"></script>

    <script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script> 
    <script src="https://cdn.datatables.net/responsive/2.2.6/js/dataTables.responsive.min.js"></script>
    
    <script src="<?php echo admin_source();?>/js/jquery.validate.min.js"></script>
    <script src="<?php echo admin_source();?>/js/apps.min.js"></script>
    <!-- ================== END PAGE LEVEL JS ================== -->
    <script>
        $(document).ready(function() {
            App.init();
        });
        
        
    </script>
    <script async
    src="https://www.googletagmanager.com/gtag/js?id=G-FDX8TJF8SG"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'G-FDX8TJF8SG');
    </script>
    <script>     
        var admin_url='<?php echo admin_url(); ?>';
        $(document).ready(function() {
            $('#list-table').DataTable( {
                "responsive" : true,
                "processing" : true,
                "pageLength" : 10,
                "serverSide": true,
                "order": [[0, "asc" ]],
                "searching": true,
                language: {
                    searchPlaceholder: "Search Transaction ID"
                },
                "ajax": admin_url+"transfer/transfer_ajax"
            });
            
        });
    </script>
    
    <style>
        .u_img{width:125px; height:125px; overflow:hidden; display:inline-block; float:left;}

        .u_img img{   height: auto;
            max-height: 100%;
            width: 100%;}


        </style>