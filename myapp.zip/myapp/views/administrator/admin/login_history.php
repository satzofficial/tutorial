<!-- begin #content -->
<div class="page-content-wrapper">
<div class="page-content">
			<?php 
		$error = $this->session->flashdata('error');
		if($error != '') {
			echo '<div class="note note-danger">
			<button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$error.'</div>';
		}
		$success = $this->session->flashdata('success');
		if($success != '') {
			echo '<div class="note note-success">
			<button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$success.'</div>';
		} 
		?>
			<!-- begin page-header -->
			<div class="page-head">
			<div class="page-title">
					<h1>Admin Login History </h1>
				</div>
                </div>
				<!-- end page-header -->
			<!-- begin breadcrumb -->
			<ul class="page-breadcrumb breadcrumb">
				<li>
					<a href="<?php echo admin_url();?>">Home</a>
					<i class="fa fa-circle"></i>
				</li>
				<li class="active"><a href="javascript:;">Admin Login History</a></li>
			</ul>
			<!-- end breadcrumb -->
			<!-- begin row -->
			<div class="row">
				<div class="col-md-12">
			        <!-- begin panel -->
						<div class="portlet light">
					<div class="portlet-title">
									<div class="caption">
										<span class="caption-subject bold uppercase font-green-haze">Admin Login History</span>
									</div>
									<div class="tools">
										<a href="javascript:;" class="collapse">
										</a>
										<a href="#portlet-config" data-toggle="modal" class="config">
										</a>
										<a href="javascript:;" class="reload">
										</a>
										<a href="javascript:;" class="fullscreen">
										</a>
										<a href="javascript:;" class="remove">
										</a>
									</div>
								</div>
					<?php if($view=='view_all'){ ?>
                        <div class="portlet-body">
                            <div class="table-responsive">
                                <table id="test_data" class="table table-striped table-bordered display responsive">
                                    <thead>
                                        <tr>
                                           <th class="text-center">S.No</th>
										<th class="text-center">Email Id</th>
										<th class="text-center">Ip Address</th>
										<th class="text-center">Browser</th>
										<th class="text-center">Activity</th>
										<th class="text-center">Date & Time</th>
                                        </tr>
                                    </thead>
                                   <!--  <tbody style="text-align: center;">
									<?php
								if ($login_history->num_rows() > 0) {
									$i = 1;
									foreach(array_reverse($login_history->result()) as $result) {
										echo '<tr>';
										echo '<td>' . $i . '</td>';
										echo '<td>' . decryptIt($result->admin_email) . '</td>';
										echo '<td>' . $result->ip_address . '</td>';
										echo '<td>' . $result->browser_name . '</td>';
										echo '<td>' . $result->activity . '</td>';
										echo '<td>' . gmdate("Y-m-d h:i:s", $result->date) . '</td>';
										echo '</tr>';
										$i++;
									}					
								} else {
									//echo '<tr><td></td><td></td><td colspan="2" class="text-center">No Login History added yet!</td><td></td><td></td></tr>';
								}
								?>
                                    </tbody> -->
                                </table>
                            </div>
                        </div>
					<?php } ?> 
                    </div>
                    <!-- end panel -->
                </div>
			</div>
			<!-- end row -->
		</div>
		</div>
		<!-- end #content -->
<!-- ================== BEGIN BASE JS ================== -->
	<script src="<?php echo admin_source();?>/plugins/jquery/jquery-1.9.1.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/jquery/jquery-migrate-1.1.0.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/jquery-ui/ui/minified/jquery-ui.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/ckeditor/ckeditor.js"></script>
	<!--[if lt IE 9]>
		<script src="<?php echo admin_source();?>/crossbrowserjs/html5shiv.js"></script>
		<script src="<?php echo admin_source();?>/crossbrowserjs/respond.min.js"></script>
		<script src="<?php echo admin_source();?>/crossbrowserjs/excanvas.min.js"></script>
	<![endif]-->
	<script src="<?php echo admin_source();?>/plugins/slimscroll/jquery.slimscroll.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/jquery-cookie/jquery.cookie.js"></script>
	<!-- ================== END BASE JS ================== -->
	<!-- ================== BEGIN PAGE LEVEL JS ================== -->
	<script src="<?php echo admin_source();?>/plugins/gritter/js/jquery.gritter.js"></script>
	<script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.time.min.js"></script>
	<script src="<?php echo admin_source();?>/plugins/flot/jquery.flot.resize.min.js"></script>
	
	<script src="<?php echo admin_source();?>/plugins/DataTables/js/jquery.dataTables.min.js"></script> 
    <script src="<?php echo admin_source();?>/plugins/DataTables/js/dataTables.responsive.min.js"></script>

	<script src="<?php echo admin_source();?>/js/jquery.validate.min.js"></script>
	<script src="<?php echo admin_source();?>/js/apps.min.js"></script>
	
	<!-- ================== END PAGE LEVEL JS ================== -->
	
	<script>
		$(document).ready(function() {
			App.init();
		});
	</script>

	 <script async
src="https://www.googletagmanager.com/gtag/js?id=G-FDX8TJF8SG"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', 'G-FDX8TJF8SG');
</script>
	<script>
     
	  var admin_url='<?php echo admin_url(); ?>';

$(document).ready(function() {
    $('#test_data').DataTable( {
    	responsive : true,
    	"processing" : true,
        "pageLength" : 10,
     	"serverSide": true,
     	"order": [[0, "asc" ]],
     	"searching": true,
     	"ajax": admin_url+"admin/login_history_ajax"

    } );

    

} );
    </script>
