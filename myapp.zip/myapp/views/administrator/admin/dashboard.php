<div class="page-content-wrapper">

    <div class="page-content">
    <?php 
    $error = $this->session->flashdata('error');
    if($error != '') {
      echo '<div class="note note-danger">
      <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$error.'</div>';
    }
    $success = $this->session->flashdata('success');
    if($success != '') {
      echo '<div class="note note-success">
      <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$success.'</div>';
    } 
    ?>
      <!-- BEGIN PAGE HEAD -->
      <div class="page-head">
        <!-- BEGIN PAGE TITLE -->
        <div class="page-title">
          <h1>Dashboard </h1>
        </div>
        <!-- END PAGE TITLE -->
        <!-- BEGIN PAGE TOOLBAR -->
      
        <!-- END PAGE TOOLBAR -->
      </div>
      <!-- END PAGE HEAD -->
      <!-- BEGIN PAGE BREADCRUMB -->
      <ul class="page-breadcrumb breadcrumb hide">
        <li>
          <a href="javascript:;">Home</a><i class="fa fa-circle"></i>
        </li>
        <li class="active">
           Dashboard
        </li>
      </ul>
      <!-- END PAGE BREADCRUMB -->
      <!-- BEGIN PAGE CONTENT INNER -->
      <div class="row margin-top-10">
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
          <div class="dashboard-stat2">
            <div class="display">
              <div class="number">
                <h3 class="font-green-sharp"><?php echo $num_users; ?></h3>
                <small>TOTAL USERS</small>
              </div>
              <div class="icon">
                <i class="icon-users"></i>
              </div>
            </div>
            <div class="stats-link">
            <a class="primary-link" href="<?php echo admin_url().'users';?>">View Detail <i class="fa fa-arrow-circle-o-right"></i></a>
          </div></div>
        </div>
        <!-- <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
          <div class="dashboard-stat2">
            <div class="display">
              <div class="number">
                <h3 class="font-red-haze"><?php echo $sell_orders; ?></h3>
                <small>SELL ORDERS</small>
              </div>
              <div class="icon">
                <i class="icon-target"></i>
              </div>
            </div>
            <div class="stats-link">
              <a href="<?php echo admin_url().'trade_history/sell';?>">View Detail <i class="fa fa-arrow-circle-o-right"></i></a>
            </div>
          </div>
        </div> -->
        <!-- <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
          <div class="dashboard-stat2">
            <div class="display">
              <div class="number">
                <h3 class="font-blue-sharp"><?php echo $buy_orders; ?></h3>
                <small>BUY ORDERS</small>
              </div>
              <div class="icon">
                <i class="icon-basket"></i>
              </div>
            </div>
            <div class="stats-link">
              <a href="<?php echo admin_url().'trade_history/buy';?>">View Detail <i class="fa fa-arrow-circle-o-right"></i></a>
            </div>
          </div>
        </div> -->

   <!--      <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
          <div class="dashboard-stat2">
            <div class="display">
              <div class="number">
                <h3 class="font-blue-sharp"><?php echo getAllCurrencyBalance(); ?></h3>
                <small>OVER ALL LTC </small>
              </div>
              <div class="icon">
                <i class="icon-basket"></i>
              </div>
            </div>
            <div class="stats-link">
              <a href="#">View Detail <i class="fa fa-arrow-circle-o-right"></i></a>
            </div>
          </div>
        </div> -->

        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
          <div class="dashboard-stat2">
            <div class="display">
              <div class="number">
                <h3 class="font-blue-sharp"><?php echo $over_all_pym; ?></h3>
                <small>OVER ALL EMD </small>
              </div>
              <div class="icon">
                <i class="icon-basket"></i>
              </div>
            </div>
            <div class="stats-link">
              <a href="#">View Detail <i class="fa fa-arrow-circle-o-right"></i></a>
            </div>
          </div>
        </div> 
     <!--    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
          <div class="dashboard-stat2">
            <div class="display">
              <div class="number">
                <h3 class="font-purple-soft"><?php echo $exchange_orders; ?></h3>
                <small>Deposit</small>
              </div>
              <div class="icon">
                <i class="icon-credit-card"></i>
              </div>
            </div>
            <div class="stats-link">
              <a href="<?php echo admin_url().'deposit/crypto_deposit';?>">View Detail <i class="fa fa-arrow-circle-o-right"></i></a>
            </div>
          </div>
        </div> -->
       <!--  <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
          <div class="dashboard-stat2">
            <div class="display">
              <div class="number">
                <h3 class="font-purple-soft"><?php echo $Widthraw_orders; ?></h3>
                <small>Widthraw</small>
              </div>
              <div class="icon">
                <i class="icon-credit-card"></i>
              </div>
            </div>
            <div class="stats-link">
              <a href="<?php echo admin_url().'withdraw/crypto_withdraw';?>">View Detail <i class="fa fa-arrow-circle-o-right"></i></a>
            </div>
          </div>
        </div> -->
      </div>
      <!-- <div class="row">
        <div class="col-md-12">
          <div class="portlet light">
            <div class="portlet-title">
              <div class="caption">
                <i class="icon-bar-chart font-green-haze"></i>
                <span class="caption-subject bold uppercase font-green-haze">Website Analytics </span>
                <span class="caption-helper">(Last 7 Days)</span>
              </div>
              <div class="tools">
                <a href="javascript:;" class="collapse">
                </a>
                <a href="#portlet-config" data-toggle="modal" class="config">
                </a>
                <a href="javascript:;" class="reload">
                </a>
                <a href="javascript:;" class="fullscreen">
                </a>
                <a href="javascript:;" class="remove">
                </a>
              </div>
            </div>
            <div class="portlet-body">
            <div id="website_analytics" class="chart" style="height: 400px;">
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-12">
          <div class="portlet light">
            <div class="portlet-title">
              <div class="caption">
                <i class="icon-bar-chart font-green-haze"></i>
                <span class="caption-subject bold uppercase font-green-haze">Visitors User Agent</span>
              </div>
              <div class="tools">
                <a href="javascript:;" class="collapse">
                </a>
                <a href="#portlet-config" data-toggle="modal" class="config">
                </a>
                <a href="javascript:;" class="reload">
                </a>
                <a href="javascript:;" class="fullscreen">
                </a>
                <a href="javascript:;" class="remove">
                </a>
              </div>
            </div>
            <div class="portlet-body">
              <div id="visitors_user_agent" class="chart" style="height:450px;">
              </div>
            </div>
          </div>
        </div>
      </div> -->
          <div style="display:none"  class="row">
        <div class="col-md-12">
          <!-- BEGIN EXAMPLE TABLE PORTLET-->
          <div class="portlet box blue-hoki">
            <div class="portlet-title">
              <div class="caption">
                <i class="fa fa-user"></i>Users Activity
              </div>
              <div class="tools">
              </div>
            </div>
            <div class="portlet-body">
    <table id="data-table" class="table table-bordered table-hover">
    <thead>
                                        <tr>
                                          <th>S.No</th>
                                            <th>Email</th>
                                            <th>Date & Time</th>
                                            <th>IP Address</th>
                                            <th>Activity</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                  <?php 
                  $a=1;
                  foreach($user_activity as $activity){ ?>
                                        <tr class="gradeX">
                                        <td><?php echo $a;?></td>
                                            <td><?php echo getUserEmail($activity->user_id); ?></td>
                                            <td><?php echo date('d-M-y H:i:s',$activity->date); ?></td>
                                            <td><?php echo $activity->ip_address; ?></td>
                                            <td><?php echo $activity->activity; ?></td>
                                        </tr>
                  <?php $a++;} ?>
                                    </tbody>
    </table>
            
      
          </div>
        
  
    
    
      
        </div>
      </div>
      <!-- END PAGE CONTENT INNER -->
    </div>
  </div>

<script>
  var chartdata='<?php echo json_encode($chartdata);?>';
  var sitevisits='<?php echo json_encode($sitevisits);?>';
  </script>

<!-- END PAGE LEVEL PLUGINS -->
<!-- BEGIN PAGE LEVEL SCRIPTS -->
<script src="<?php echo admin_source();?>plugins/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo admin_source();?>plugins/amcharts/amcharts/amcharts.js" type="text/javascript"></script>
<script src="<?php echo admin_source();?>plugins/amcharts/amcharts/serial.js" type="text/javascript"></script>
<script src="<?php echo admin_source();?>plugins/amcharts/amcharts/pie.js" type="text/javascript"></script>
<script src="<?php echo admin_source();?>pages/scripts/charts-amcharts.js"></script>
<script src="<?php echo admin_source();?>js/dashboard.min.js"></script>

<script>
jQuery(document).ready(function() {       
   ChartsAmcharts.init();
   $('#data-table').DataTable();
});
</script>