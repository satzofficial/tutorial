<?php 
    $this->load->view('front/common/header');
    $user_id = $this->session->userdata('user_id');

    $pairId = $pair_id;

    $token_chart = $this->common_model->customQuery("SELECT * FROM tenrealm_trade_pairs WHERE id='".$pairId."'")->row();

    if($token_chart->priceChangePercent>=0){
        $class1="clr-green";
        $b21 =  rtrim($token_chart->priceChangePercent,'0');
        if($b21!=0){
        $b21 = '+'.number_format(rtrim($b21,'.'),2).'%';
    }
    else{
        $b21 = '+0 '.'%';
    }
    $arrow = 'up';
    }
    else{
        $class1="clr-red";
        $b21 =  rtrim($token_chart->priceChangePercent,'0');
        $b21 = '-'.number_format(rtrim($b21,'.'),2).'%';
        $arrow = 'down';
    }

    $prefix = get_prefix();                                        
$url = $this->uri->segment(2);
$Exp = explode('_', $url);
$First_Currency = $Exp[0];
$Second_Currency = $Exp[1];

 $from_currency_id = $this->common_model->customQuery("select * from ".$prefix."currency where currency_symbol='".$Exp[0]."'")->row('id');
    $to_currency_id = $this->common_model->customQuery("select * from ".$prefix."currency where currency_symbol='".$Exp[1]."'")->row('id');

    $pair_details = $this->common_model->customQuery("select * from ".$prefix."trade_pairs where from_symbol_id='".$from_currency_id."' and to_symbol_id='".$to_currency_id."'")->row();
    $pair_ids = $pair_details->id;
    $from_currency_dets = getcryptocurrencydetail($from_currency_id);
    $to_currency_dets = getcryptocurrencydetail($to_currency_id);
    $exchange_type = 0;

    $basic_pairId = array(4,7,8,9,10);
    $to_cur_str = str_replace(',', '', $to_cur);
    $first_cur_str = str_replace(',', '', $from_cur);
                    

?>

<style type="text/css">    
.bs-tabs .nav-tabs { margin-bottom: 2px;
    background: #f4f4f4; }
    .bs-tabs .nav-tabs > li.active > a, .nav-tabs > li.active > a:focus, .nav-tabs > li.active > a:hover { border-width: 0; }
    .bs-tabs .nav-tabs > li > a { border: none; color: #000;padding: 10px 30px;       display: block;  background: #f4f4f4;}
        .bs-tabs .nav-tabs > li.active > a, .bs-tabs .nav-tabs > li > a:hover { border: none;  color: #000 !important; }
        .bs-tabs .nav-tabs > li > a::after { content: ""; height: 2px; position: absolute; width: 100%; left: 0px; bottom: -1px; transition: all 250ms ease 0s; transform: scale(0); }
    .bs-tabs .nav-tabs > li.active > a::after, .bs-tabs .nav-tabs > li:hover > a::after { transform: scale(1);  }
.bs-tabs .tab-nav > li > a::after {  color: #fff; }
.bs-tabs .tab-pane { padding: 15px 0; }
.bs-tabs .tab-content{padding:20px;     background: #f4f4f4;}
.bs-tabs .nav-tabs > li  {    /* width: 20%; */
    text-align: center;
    color: #000;

    margin-right: 2px;}
.bs-tabs .nav-tabs > li a.active  {
    background: #4699F2; color:#FFF !important;
}


@media all and (max-width:724px){
.bs-tabs .nav-tabs > li > a > span {display:none;}   
.bs-tabs .nav-tabs > li > a {padding: 5px 5px;}
}

 #chart-area, #widget-container, .tv-main-panel {background: #000;}
.chart-page .chart-container {border: black solid 0;}

div.table-responsive>div.dataTables_wrapper>div.row>div[class^="col-"]:first-child {
  margin-top:-25px;
}
.fees-col {
  color: #000 !important;
}

.price-label-txt { width: 0px; }
.total-txt { width: 0px; }

/* Loader */
.se-pre-con {
  position: fixed;
  left: 0px;
  top: 0px;
  width: 100%;
  height: 100%;
  z-index: 9999;
  background: url('<?=front_img()?>exchange-loader.gif') center no-repeat #0c0707;
  background-size: 10%;
  opacity: 0.6;
}
.trade-loader {
  position: fixed;
  left: 0px;
  top: 0px;
  width: 100%;
  height: 100%;
  z-index: 9999;
  background: url('<?=front_img()?>trade-loader.gif') center no-repeat #0c0707;
  background-size: 5%;
  opacity: 0.6;
}
/* Loader */

#instant_buy_price, #instant_sell_price {
  border: 0px;
}
.dataTables_scrollBody {
  height: 306px !important;
}
</style>

<div class="se-pre-con"></div>
<div class="trade-loader" style="display:none;"></div>
<main id="main" style=" margin-top:0;">
  <section class="main_body dark_mode" id="body">
    <div class="container-fluid tradeContainer">
      <div class="row no-gutters">
        <div class="col-lg-9">
          <div class="row no-gutters">
            <div class="col-lg-12">
              <div class="p-1">
              <input type="hidden" id="exchange_type" value="0">    
              <input type="hidden" id="sorting_type">    
              <?php $seg_pair = $this->uri->segment(2);?>  
                <div class="currency_details d-flex align-items-center justify-content-between mb-2">
                  <select class="currency_select selectpicker select_scroll" onchange="callCurrencyPair(value);">
                    <optgroup>
                  <?php if(isset($Site_Pairs) && !empty($Site_Pairs)){
                        foreach($Site_Pairs as $Site_Pairs_list){ ?>
                         
                      <option <?=(($Site_Pairs_list['pairurl']==$seg_pair)?'selected':'')?> value="<?=$Site_Pairs_list['pairurl'];?>"><?=$Site_Pairs_list['currency_pair']?></option>       
                      <?php }} ?>   
                    </optgroup>
                  </select>
                  <ul class="currency_status">
                    <li>
                      <h5>Last price <span class="text-green"><?php echo $token_chart->lastPrice;?></span></h5>
                    </li>
                    <li>
                      <?php if($token_chart->volume>=0){
                              $Cls='text-green';
                          } else { 
                              $Cls='text-red';
                          } ?>
                      <h5>24H Change <span id="change" class="<?php echo $Cls;?>"> <small><?php echo number_format($token_chart->priceChangePercent,2);?>%</small></span></h5> 

                    </li>
                    <li>
                      <h5>24H High <span id="high"><?php echo TrimTrailingZeroes($token_chart->change_high);?></span></h5>
                    </li>
                    <li>
                      <h5>24H Low <span id="low"><?php echo TrimTrailingZeroes($token_chart->change_low);?></span></h5>
                    </li>
                    <li>
                      <h5>24h Volume <span id="volume"><?php echo TrimTrailingZeroes($token_chart->volume);?></span></h5>
                    </li>
                  </ul>
                  <!-- <button type="button" class="dark_light_toggle" name="dark_light" onclick="toggleDarkLight()" title="Toggle dark/light mode"></button> --> 
                </div>
              </div>
            </div>
            <div class="col-lg-4">
              <div class="p-1">
                <div class="block">
                  <div class="block_head">
                    <h5>Sell Order</h5>
                  </div>
                  <div class="tab-content">    
                    <div id="buy_sell_order" class="tab-pane active">
                      <div class="table_trade" id="sell_order">
                        <div class="table_responsive">
                          <table id="sell_order_table_1" class="display nowrap api_sellorder_table" style="width:100%">
                            <thead>
                              <tr>
                                <th>Price</th>
                                <th>Amount</th>
                                <th>Total</th>
                              </tr>
                            </thead>
                            <tbody class="sell_order">
                              
                            </tbody>
                          </table>
                        </div>
                      </div>
                      <div class="price_stats">
                        <h4 class="text-green"><?php echo $token_chart->lastPrice;?> <small>€ <?php echo $token_chart->lastPrice;?></small> </h4>
                      </div>
                      <div class="block_head">
                        <h5>Buy Order</h5>
                      </div>
                      <div class="table_trade" id="buy_order">
                        <div class="table_responsive">
                          <table id="buy_order_table_1" class="display nowrap" style="width:100%">
                            <thead>
                              <tr>
                                <th>Price</th>
                                <th>Amount</th>
                                <th>Total</th>
                              </tr>
                            </thead>
                            <tbody class="buy_order">
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-8">
              <div class="p-1">
                <div class="block">
                  <div class="block_head">
                    <h5>Trade Chart</h5>
                  </div>
                  <div class="trade_candle_chart">
                    <div class="trade_candle_dark"> 
                      <!-- TradingView Widget BEGIN -->
                      <div class="tradingview-widget-container">
                        <div id="tradingview_3d8bd"></div>
                      </div>
                      <!-- TradingView Widget END --> 
                    </div>
                  </div>
                </div>
              </div>
              <?php if($Second_Currency=='EUR') {
                  $total_txt='in Euro'; 
                  $first_coin = ' in '.$First_Currency;  
              } else {
                $total_txt=''; 
                $first_coin = '';
              }  

              $checkPair = in_array((int)$pairId, $basic_pairId)?1:0;
               ?>

              <input type="hidden" id="sellratevalue" value="<?=$tradeInfo->sell_rate_value?>">
              <input type="hidden" id="buyratevalue" value="<?=$tradeInfo->buy_rate_value?>">
              <div class="p-1">
                <div class="block">
                  <div class="buy_sell_tab d-flex align-items-center">
                    <ul class="nav nav-tabs" role="tablist">
                      <li class="nav-item"> <a class="nav-link tradeaction <?=($checkPair==1)?'':'active'?>" data-ftrade="limit" data-toggle="tab" href="#limit"> Limit </a> </li>
                      <li class="nav-item"> <a class="nav-link tradeaction <?=($checkPair==1)?'active':''?>" data-ftrade="instant" data-toggle="tab" href="#market"> Market </a> </li>
                      <li class="nav-item"> <a class="nav-link tradeaction" data-ftrade="stop" data-toggle="tab" href="#stop"> Stop </a> </li>
                    </ul>
                  </div>
                  <div class="tab-content">
                    <input type="hidden" class="tradeactions" id="tradeactions" value="<?=($checkPair==1)?'instant':'limit'?>">
                    <div id="limit" class="tab-pane <?=($checkPair==1)?'':'active'?>">
                      <div class="buy_sell_block p-2">
                        <div class="row">
                          <div class="col-md-6">
                            <div class="buy_sell_block_inner"> 
                              <h4 class="d-flex">Buy <?php echo $First_Currency;?> <span class="ml-auto"> <span class="buy_bal"><?=$to_cur_str?> <?php echo $Second_Currency;?></span></span> </h4>
                              <div class="row">
                                <div class="col-md-12">
                                  <div class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                    <label class="total-txt">Amount <?=$first_coin?>:</label>
                                    <input type="number" class="form-control" name="limit_buy_amount" id="limit_buy_amount" onkeyup="calculation('buy','limit')" placeholder="">
                                  </div>
                                </div>
                                
                                <div class="col-md-12">
                                  <div class="input-group input_exchange_buy_sell align-items-center mb-1">
                                    <label></label>
                                    <ul class="buy_sell_percent d-flex flex-fill">
                                      <li><a href="javascript:void(0);" onclick="change_buytrade('buy','25','limit');">25%</a></li>
                                      <li><a href="javascript:void(0);" onclick="change_buytrade('buy','50','limit');">50%</a></li>
                                      <li><a href="javascript:void(0);" onclick="change_buytrade('buy','75','limit');">75%</a></li>
                                      <li><a href="javascript:void(0);" onclick="change_buytrade('buy','100','limit');">100%</a></li>
                                    </ul>
                                  </div>
                                </div>
                                <div class="col-md-12">
                                  <div class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                    <label class="price-label-txt">Price for coin:</label>
                                    <input type="number" class="form-control" name="limit_buy_price" id="limit_buy_price" onkeyup="calculation('buy','limit')" placeholder="">
                                  </div>
                                </div>
                                <div class="col-md-12">
                                  <div class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                    <label class="total-txt">Total <?=$total_txt?>:</label>
                                    <input type="number" class="form-control" placeholder="" name="limit_buy_tot" id="limit_buy_tot">
                                  </div>
                                </div>
                                <div class="col-md-12">
                                  <div class="total_fee mb-4"> <span class="fees-col">Fee <?php echo TrimTrailingZeroes($this->maker);?>% 
                                  <small class="fees-col" id="buy_limit_fees">0</small>
                                  </span> </div>
                                </div>
                                <div class="col-md-12">
                                  <div class="d-block">
                                    <?php
                                      if(isset($user_id) && !empty($user_id)){
                                      ?>
                                      <button type="button" class="btn-buy w-100" id="buy_btn" onclick="order_placed('buy','limit')" >Buy</button>
                                      <?php
                                    }
                                    else{ ?>
                                        <button type="button" id="buy_btn" class="btn-buy w-100" data-toggle="modal" data-target="#meLogin"><?=$this->lang->line('Login');?></button>
                                      <?php } ?>
                                    
                                    <input type="hidden" id="buy_order_type" name="buy_order_type" value="limit"/>
                                    <input type="hidden" name="current_currency" id="current_currency" value="<?php echo $Second_Currency; ?>">
                                    <input type="hidden" id="from_currency_value" name="from_currency_value" value="<?php echo str_replace(",","",$from_cur);?>">
                                    <input type="hidden" id="to_currency_value" name="to_currency_value" value="<?php echo str_replace(",","",$to_cur);?>">
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="buy_sell_block_inner">
                              <h4 class="d-flex">Sell <?php echo $First_Currency;?> <span class="ml-auto">  <span class="sell_bal"><?php echo $first_cur_str;?> <?=$First_Currency;?></span></h4>
                              <div class="row">
                                
                                <div class="col-md-12">
                                  <div class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                    <label class="total-txt">Amount <?=$first_coin?>:</label>
                                    <input type="number" class="form-control" name="limit_sell_amount" id="limit_sell_amount" onkeyup="calculation('sell','limit')" placeholder="">
                                  </div>
                                </div>
                                
                                <div class="col-md-12">
                                  <div class="input-group input_exchange_buy_sell align-items-center mb-1">
                                    <label></label>
                                    <ul class="buy_sell_percent d-flex flex-fill">
                                      <li><a href="javascript:void(0);" onclick="change_selltrade('sell','25','limit');">25%</a></li>
                                      <li><a href="javascript:void(0);" onclick="change_selltrade('sell','50','limit');">50%</a></li>
                                      <li><a href="javascript:void(0);" onclick="change_selltrade('sell','75','limit');">75%</a></li>
                                      <li><a href="javascript:void(0);" onclick="change_selltrade('sell','100','limit');">100%</a></li>
                                    </ul>
                                  </div>
                                </div>
                                <div class="col-md-12">
                                  <div class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                    <label class="price-label-txt">Price for coin:</label>
                                    <input type="number" class="form-control" name="limit_sell_price" id="limit_sell_price" onkeyup="calculation('sell','limit')" placeholder="">
                                  </div>
                                </div>
                                <div class="col-md-12">
                                  <div class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                    <label class="total-txt">Total <?=$total_txt?>:</label>
                                    <input type="number" class="form-control" name="limit_sell_tot" id="limit_sell_tot" placeholder="">
                                  </div>
                                </div>
                                <div class="col-md-12">
                                  <div class="total_fee mb-4"> <span class="fees-col">Fee <?php echo TrimTrailingZeroes($this->taker);?>%
                                    <small class="fees-col" id="sell_limit_fees">0</small>
                                  </small></span> </div>
                                </div>
                                <div class="col-md-12">
                                  <div class="d-block">
                                    <?php
                                      if(isset($user_id) && !empty($user_id)){
                                      ?>
                                      <button type="button" id="sell_btn" class="btn-sell w-100" onclick="order_placed('sell','limit')">Sell</button>
                                      <?php } else{ ?>
                                          <button type="button" class="btn-sell w-100" data-toggle="modal" data-target="#meLogin"><?=$this->lang->line('Login');?></button>

                                      <?php }?>
                                    <input type="hidden" id="sell_order_type" name="sell_order_type" value="limit"/>   
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div id="market" class="tab-pane <?=($checkPair==1)?'active':''?>">
                      <div class="buy_sell_block p-2">
                          <div class="row">
                              <div class="col-md-6">
                                  <div class="buy_sell_block_inner">
                                      <h4 class="d-flex">Buy <?php echo $First_Currency;?> <span class="ml-auto"> <span class="buy_bal"><?=$to_cur_str?> <?php echo $Second_Currency;?></span></span>
                                      </h4>
                                      <div class="row">
                                          <div class="col-md-12">
                                              <div class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1"> 
                                              <label class="total-txt">Amount <?=$total_txt?>:</label>
                                            <?php if(in_array($pairId, $basic_pairId)) {?>
                                                <input type="number" class="form-control" placeholder="" name="instant_buy_amount" id="instant_buy_amount" onkeyup="calculation_basic('buy','instant')">
                                              <?php } else {?>
                                                <input type="number" class="form-control" placeholder="" name="instant_buy_amount" id="instant_buy_amount" onkeyup="calculation('buy','instant')">
                                              <?php }?>
                                              </div>
                                            <?php if(in_array($pairId, $basic_pairId)) {?>  
                                              <span style="color:#e80303;margin-left:58px;" class="error-minimum-buy"></span>
                                            <?php }?>  
                                          </div>
                                      <?php if(!in_array($pairId, $basic_pairId)) {?>   
                                          <div class="col-md-12">
                                            <div class="input-group input_exchange_buy_sell align-items-center mb-1">
                                              <label></label>
                                              <ul class="buy_sell_percent d-flex flex-fill">
                                                <li><a href="javascript:void(0);" onclick="change_buytrade('buy','25','instant');">25%</a></li>
                                                <li><a href="javascript:void(0);" onclick="change_buytrade('buy','50','instant');">50%</a></li>
                                                <li><a href="javascript:void(0);" onclick="change_buytrade('buy','75','instant');">75%</a></li>
                                                <li><a href="javascript:void(0);" onclick="change_buytrade('buy','100','instant');">100%</a></li>
                                              </ul>
                                            </div>
                                          </div>
                                        <?php }?>  
                                          <div class="col-md-12">
                                            <div class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                              <label class="price-label-txt">Price for coin:</label>
                                              <input type="number" class="form-control" name="instant_buy_price" readonly="rr" id="instant_buy_price" onkeyup="calculation('buy','instant')" value="<?php echo $token_chart->lastPrice;?>">
                                              </div>
                                          </div>
                                          <div class="col-md-12">
                                              <div class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                              <label class="total-txt">Total <?=$first_coin?>:</label>
                                            <?php if(in_array($pairId, $basic_pairId)) {?>
                                                <input type="number" class="form-control" placeholder="" name="instant_buy_tot" id="instant_buy_tot" onkeyup="calculation_with_total('buy','instant')">
                                              <?php } else {?>
                                                <input type="number" class="form-control" placeholder="" name="instant_buy_tot" id="instant_buy_tot" onkeyup="calculation_with_total_advance('buy','instant')">
                                              <?php }?>  
                                              </div>
                                            
                                          </div>
                                          <div class="col-md-12">
                                              <div class="total_fee mb-4">
                                                <span class="fees-col">Fee <?php echo TrimTrailingZeroes($this->maker);?>%
                                                <small class="fees-col" id="buy_instant_fees">0</small></span>
                                              </div>
                                          </div>
                                          <div class="col-md-12">
                                              <div class="d-block">
                                                <?php
                                                if(isset($user_id) && !empty($user_id)){
                                                ?> 
                                                <button type="button" class="btn-buy w-100" id="buy_btn" onclick="order_placed('buy','instant')">Buy</button>
                                                <?php } else{ ?>
                                                <button type="button" class="btn-buy w-100" onclick="location.href = '<?php echo base_url();?>login';">Login</button>
                                                <?php } ?>
                                                <input type="hidden" id="buy_order_type" name="buy_order_type" value="instant"/>
                                              </div>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                    <div class="col-md-6">
                        <div class="buy_sell_block_inner">
                            <h4 class="d-flex">Sell <?php echo $First_Currency;?> <span class="ml-auto"> <span class="sell_bal"><?php echo $first_cur_str;?> <?=$First_Currency;?></span></h4>
                              <div class="row">

                                <div class="col-md-12">
                                  <div class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                      <label class="total-txt">Amount <?=$first_coin?>:</label>
                                    <?php if(in_array($pairId, $basic_pairId)) {?>
                                      <input type="number" class="form-control" name="instant_sell_amount" id="instant_sell_amount" onkeyup="calculation_basic('sell','instant')">
                                    <?php } else {?>
                                      <input type="number" class="form-control" name="instant_sell_amount" id="instant_sell_amount" onkeyup="calculation('sell','instant')">
                                    <?php }?>  
                                  </div>
                                </div>
                                <?php if(!in_array($pairId, $basic_pairId)) {?>   
                                  <div class="col-md-12">
                                    <div class="input-group input_exchange_buy_sell align-items-center mb-1">
                                      <label></label>
                                      <ul class="buy_sell_percent d-flex flex-fill">
                                           <li><a href="javascript:void(0);" onclick="change_selltrade('sell','25','instant');">25%</a></li>
                                          <li><a href="javascript:void(0);" onclick="change_selltrade('sell','50','instant');">50%</a></li>
                                          <li><a href="javascript:void(0);" onclick="change_selltrade('sell','75','instant');">75%</a></li>
                                          <li><a href="javascript:void(0);" onclick="change_selltrade('sell','100','instant');">100%</a></li>
                                      </ul>
                                    </div>
                                  </div>
                                <?php }?>  
                                  <div class="col-md-12">
                                    <div
                                        class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                        <label class="price-label-txt">Price for coin:</label>
                                        <input type="number" class="form-control" name="instant_sell_price" id="instant_sell_price" onkeyup="calculation('sell','instant')" readonly="rdr" value="<?php echo $token_chart->lastPrice;?>">
                                    </div>
                                  </div>
                                  <div class="col-md-12">
                                    <div class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                    <label class="total-txt">Total <?=$total_txt?>:</label>
                                    <?php if(in_array($pairId, $basic_pairId)) {?>
                                      <input type="number" class="form-control" placeholder="" name="instant_sell_tot" id="instant_sell_tot" onkeyup="calculation_with_total('sell','instant')">
                                    <?php } else {?>
                                      <input type="number" class="form-control" placeholder="" name="instant_sell_tot" id="instant_sell_tot" onkeyup="calculation_with_total_advance('sell','instant')">
                                    <?php }?> 
                                      </div>
                                    <?php if(in_array($pairId, $basic_pairId)) {?>  
                                      <span style="color:#e80303;margin-left:58px;" class="error-minimum-sell"></span>
                                    <?php }?>    
                                  </div>
                                  <div class="col-md-12">
                                    <div class="total_fee mb-4">
                                      <span class="fees-col">Fee <?php echo TrimTrailingZeroes($this->taker);?>%
                                        <small class="fees-col" id="sell_instant_fees">0</small></span>
                                  </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="d-block">
                                                <?php
                                                if(isset($user_id) && !empty($user_id)){
                                                ?>
                                                <button type="button" class="btn-sell w-100" id="sell_btn" onclick="order_placed('sell','instant')">Sell</button>
                                                <?php
                                            }
                                            else{
                                                ?>
                                                <button type="button" class="btn-sell w-100" onclick="location.href = '<?php echo base_url();?>login';">Login</button>
                                                <?php
                                            }
                                                ?>
                                                <input type="hidden" id="sell_order_type" name="sell_order_type" value="instant"/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                    <div id="stop" class="tab-pane">
                    <div class="buy_sell_block p-2">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="buy_sell_block_inner">
                                    <h4 class="d-flex">Buy <?php echo $First_Currency;?> <span class="ml-auto"> <span class="buy_bal"><?=$to_cur?> <?php echo $Second_Currency;?></span></span>
                                    </h4>
                                    <div class="row">

                                        <div class="col-md-12">
                                            <div class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                <label class="total-txt">Amount <?=$first_coin?>:</label>
                                                <input type="number" class="form-control" placeholder="" name="stop_buy_amount" id="stop_buy_amount" onkeyup="calculation('buy','stop')">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="input-group input_exchange_buy_sell align-items-center mb-1">
                                                <label></label>
                                                <ul class="buy_sell_percent d-flex flex-fill">
                                                    <li><a href="javascript:void(0);" onclick="change_buytrade('buy','25','stop');">25%</a></li>
                                                    <li><a href="javascript:void(0);" onclick="change_buytrade('buy','50','stop');">50%</a></li>
                                                    <li><a href="javascript:void(0);" onclick="change_buytrade('buy','75','stop');">75%</a></li>
                                                    <li><a href="javascript:void(0);" onclick="change_buytrade('buy','100','stop');">100%</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                <label class="price-label-txt">Price for coin:</label>
                                                <input type="number" class="form-control" placeholder="" name="stop_buy_price" id="stop_buy_price" onkeyup="calculation('buy','stop')">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                <label>Trigger Price :</label>
                                                <input type="number" class="form-control" placeholder="" name="stop_buy_tprice" id="stop_buy_tprice" onkeyup="calculation('buy','stop')">
                                            </div>
                                        </div>

                                        
                                        <div class="col-md-12">
                                            <div class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                <label class="total-txt">Total <?=$total_txt?>:</label>
                                                <input type="number" class="form-control" placeholder="" name="stop_buy_tot" id="stop_buy_tot">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="total_fee mb-4">
	                                            <span class="fees-col">Fee <?php echo TrimTrailingZeroes($this->maker);?>%
	                                            <small class="fees-col" id="buy_stop_fees">0</small></span>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="d-block">
                                                <?php
                                                if(isset($user_id) && !empty($user_id)){
                                                ?>
                                                <button type="button" id="buy_btn" class="btn-buy w-100" onclick="order_placed('buy','stop')">Buy</button>
                                                <?php
                                            }
                                            else{
                                                ?>
                                                <button type="button" class="btn-buy w-100" onclick="location.href = '<?php echo base_url();?>login';">Login</button>
                                                <?php
                                            }
                                                ?>
                                                <input type="hidden" id="buy_order_type" name="buy_order_type" value="stop"/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="buy_sell_block_inner">
                                    <h4 class="d-flex">Sell <?php echo $First_Currency;?> <span class="ml-auto"> <span class="sell_bal"><?=$from_cur?> <?php echo $First_Currency;?></span></h4>
                                        <div class="row">

                                            <div class="col-md-12">
                                                <div
                                                    class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                    <label class="total-txt">Amount <?=$first_coin?>:</label>
                                                    <input type="number" class="form-control" placeholder="" name="stop_sell_amount" id="stop_sell_amount" onkeyup="calculation('sell','stop')">
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                              <div
                                                  class="input-group input_exchange_buy_sell align-items-center mb-1">
                                                  <label></label>
                                                  <ul class="buy_sell_percent d-flex flex-fill">
                                                      <li><a href="javascript:void(0);" onclick="change_selltrade('sell','25','stop');">25%</a></li>
                                                      <li><a href="javascript:void(0);" onclick="change_selltrade('sell','50','stop');">50%</a></li>
                                                      <li><a href="javascript:void(0);" onclick="change_selltrade('sell','75','stop');">75%</a></li>
                                                      <li><a href="javascript:void(0);" onclick="change_selltrade('sell','100','stop');">100%</a></li>
                                                  </ul>
                                              </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div
                                                    class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                    <label class="price-label-txt">Price for coin:</label>
                                                    <input type="number" class="form-control" placeholder="" name="stop_sell_price" id="stop_sell_price" onkeyup="calculation('sell','stop')">
                                                </div>
                                            </div>

                                            <div class="col-md-12">
                                                <div
                                                    class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                    <label>Trigger Price :</label>
                                                    <input type="number" class="form-control" placeholder="" name="stop_sell_tprice" id="stop_sell_tprice" onkeyup="calculation('sell','stop')">
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-12">
                                                <div
                                                    class="input-group input_exchange input_exchange_buy_sell align-items-center mb-1">
                                                    <label class="total-txt">Total <?=$total_txt?>:</label>
                                                    <input type="number" class="form-control" name="stop_sell_tot" id="stop_sell_tot" placeholder="">
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="total_fee mb-4">
                                                    <span class="fees-col">Fee <?php echo TrimTrailingZeroes($this->taker);?>%
                                                      <small class="fees-col" id="sell_stop_fees">0</small></span>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="d-block">
                                    <?php
                                    if(isset($user_id) && !empty($user_id)){
                                    ?>
                                    <button type="button" id="sell_btn" class="btn-sell w-100" onclick="order_placed('sell','stop')">Sell</button>
                                    <?php
                                }
                                else{
                                    ?>
                                    <button type="button" class="btn-sell w-100" onclick="location.href = '<?php echo base_url();?>login';">Login</button>
                                    <?php
                                }
                                    ?>
                                    <input type="hidden" id="buy_order_type" name="buy_order_type" value="stop"/>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="p-1">
            <div class="block">
              <div class="block_head">
                <h5>Pairs</h5>
              </div>
              <div class="block_top d-flex align-items-center">
                <div class="input-group input_exchange input_exchange_pair">
                  <div class="input-group-prepend"> <span class="input-group-text"><i class="fa fa-search search_currency_pair_btn"></i></span> </div>
                  <input type="text" class="form-control search_currency_pair" placeholder="Search">
                </div>
              </div>

              <div class="block_tab d-flex align-items-center">
                <ul class="nav nav-tabs" role="tablist">
                  <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#favourite_pair"> <i class="fa fa-star"></i> </a> </li>
                  
                  <?php if(count($currencies)>0) { foreach($currencies as $cur) { ?>
                    <li class="nav-item">
                        <a style="font-weight:bold;color:#000" class="nav-link" id="pills-<?php echo $cur->currency_symbol;?>-tab" data-toggle="tab" href="#<?php echo $cur->currency_symbol.'_pair';?>" aria-controls="pills-<?php echo $cur->currency_symbol;?>" aria-selected="true"><?php echo $cur->currency_symbol;?></a>
                    </li>
                  <?php } } ?>
                </ul>
              </div>
              <div class="tab-content">
                <div id="favourite_pair" class="tab-pane active" >
                  <div class="table_trade">
                    <div class="table_responsive">
                      <table id="pair_favourite" class="display nowrap" style="width:100%;">
                        <thead>
                          <tr>
                            <th>Pair</th>
                            <th>Price</th>
                            <th>Change</th>
                          </tr>
                        </thead>
                        <tbody style="height: 235px !important">
                          <?php
                              if(isset($Site_Pairs) && !empty($Site_Pairs)){
                                foreach($Site_Pairs as $Site_Pairs_list){ ?>
                                  <tr onclick="window.location='<?=base_url();?>trade/<?php echo $Site_Pairs_list['pairurl'];?>'" style="cursor: pointer;" id="<?=$Site_Pairs_list['currency_pair']?>">
                                  <td><a href="javascript:void(0)"><i class="fa fa-star"></i></a>
                                    <?=$Site_Pairs_list['currency_pair']?></td>
                                  <td><?=TrimTrailingZeroes($Site_Pairs_list['price']);?></td>
                                  <?php
                                      if($Site_Pairs_list['change']>=0){
                                          ?>
                                          <td class="text-green"><?php $b2 =  rtrim($Site_Pairs_list['change'],'0');
                                          if($Site_Pairs_list['change']!=0){
                                          echo '+'.number_format(rtrim($b2,'.'),2);
                                      }
                                      else{
                                          echo '+0';
                                      }
                                          ?>%</td>
                                          <?php
                                      }
                                      else{
                                          ?>
                                          <td class="text-red"><?php $b2 = rtrim($Site_Pairs_list['change'],'0');
                                          echo number_format(rtrim($b2,'.'),2);?>%</td>
                                          <?php
                                      }
                                  ?>
                                </tr>
                                    <?php
                                  }
                              } ?>

                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>

              <?php if(count($allcurrencies)>0) { foreach($allcurrencies as $cur) { ?>  
                <div id="<?php echo $cur->currency_symbol.'_pair';?>" class="tab-pane">
                  <div class="table_trade">
                    <div class="table_responsive">
                      <table  id="pair_<?php echo $cur->currency_symbol;?>" class="display nowrap" style="width:100%">
                        <thead>
                          <tr>
                            <th>Pair</th>
                            <th>Price</th>
                            <th>Change</th>
                          </tr>
                        </thead>
                        <tbody>
                          
                        <?php
            $pair_currencys = $this->common_model->customQuery("select * from tenrealm_trade_pairs where status='1' and (from_symbol_id = ".$cur->id." or to_symbol_id = ".$cur->id.") order by id DESC")->result();
            if(count($pair_currencys)>0)
            {
                foreach($pair_currencys as $pair)
                {
                     $from_currency_det = getcryptocurrencydetail($pair->from_symbol_id);
                     $to_currency_det = getcryptocurrencydetail($pair->to_symbol_id);
                     $firstcur_image =  $from_currency_det->image;
                     $pair_id = $pair->id;

                     $pairname = $from_currency_det->currency_symbol."/".$to_currency_det->currency_symbol;
                     $pairurl = $from_currency_det->currency_symbol."_".$to_currency_det->currency_symbol;

                     $price = ($pair->lastPrice!='')?$pair->lastPrice:'0.000';
                     $change = ($pair->priceChangePercent!='')?$pair->priceChangePercent:'0.000';

                     if($change>=0)
                     {

                        $class= "text-green";
                        if($change==0){
                            $changePR = '+0'.'%';
                        }
                        else{
                        $b2 =  rtrim($change,'0');
                        $changePR = '+'.number_format(rtrim($b2,'.'),2).'%';
                    }
                    }
                    else
                    {
                        $class= "text-red";
                        $b2 =  rtrim($change,'0');
                        $changePR = number_format(rtrim($b2,'.'),2).'%';

                    }
                ?>
                    <tr onclick="window.location='<?=base_url();?>trade/<?php echo $pairurl?>'" style="cursor: pointer;">
                        <td><a href="javascript:void(0)"><i class="fa fa-star"></i></a><?php echo $from_currency_det->currency_symbol.' / '.$to_currency_det->currency_symbol;?></td>
                        <td><?=$price?></td>
                        <td class="<?=$class?>"><?=$changePR?></td>
                    </tr>
    <?php       }
            }
             ?>  
                          
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              <?php }}?>  

              </div>
            </div>
          </div>
          <div class="p-1">
            <div class="block">
              <div class="block_head">
                <h5>Trade History</h5>
              </div>
              <div class="table_trade">
                <div class="table_responsive">
                  <table id="trade_history" class="display nowrap" style="width:100%">
                    <thead>
                      <tr>
                        <th>Price</th>
                        <th>Amount</th>
                        <th>Type</th>
                      </tr>
                    </thead>
                    <tbody class="market_trade"> </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

          <!-- <div class="p-1">
            <div class="block">
              <div class="block_head">
                <h5>Trade History</h5>
              </div>
              <div class="table_trade">
                <div class="table_responsive">
                  <table id="trade_history" class="display nowrap" style="width:100%">
                    <thead>
                      <tr>
                        <th>Price</th>
                        <th>Amount</th>
                        <th>Total</th>
                      </tr>
                    </thead>
                    <tbody class="basic_market_trade"> </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div> -->


        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="p-1">
            <div class="block">
              <div class="block_head">
                <ul class="nav nav-tabs current-userorder" role="tablist">
                  <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#tab_open_order"> Open Order </a> </li>
                  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#tab_trade_history"> Trade History </a> </li>
                </ul>  
              </div>
              <div class="tab-content">
                <div id="tab_open_order" class="tab-pane active">
                  <div class="table_trade open-ord">
                    <div class="table table-responsive">
                      <table id="open_order" class="display nowrap" style="width:100%">
                        <thead>
                          <tr>
                            <th class="date_openorder">Date</th>
                            <th>Type</th>
                            <th>Pair</th>
                            <th>Order Type</th>
                            <th>Amount</th>
                            <th>Price</th>
                            <th>Total</th>
                            <th>Cancel</th>
                          </tr>
                        </thead>
                        <tbody class="open_orders"></tbody>
                      </table>
                    </div>
                  </div>
                </div>
              	<div id="tab_trade_history" class="tab-pane">
                  <div class="table_trade open-ord">
                    <div class="table table-responsive">
                      <table id="trade_history_tab" class="display nowrap" style="width:100%">
                        <thead>
                          <tr>
                            <th class="date-width">Date</th>
                            <th>Type</th>
                            <th>Pair</th>
                            <th>Amount</th>
                            <th>Price</th>
                            <th>Total</th>
                            <th>Status</th>
                          </tr>
                        </thead>
                        <tbody class="transactionhistory"></tbody>
                      </table>
                    </div>
                  </div>
                </div>
                
                
            </div>


            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</main>
    

<?php  
$this->load->view('front/common/basic_footer'); 
$this->load->view('front/trade/trade_footer');

?>


<script type="text/javascript">
function callCurrencyPair($val) {
  window.location='<?=base_url();?>trade/'+$val;
}

$(function() {

  $('.search_currency_pair_btn').click(function() {
      pair = $('.search_currency_pair').val();
      FilterCurrencyPair(pair);
  });

  $('.search_currency_pair').keypress(function(e) { 
    var key = e.which;
    if (key == 13) {
      pair = $(this).val();
      FilterCurrencyPair(pair);      
    }
  });

function FilterCurrencyPair(pair) {
  if(pair!='') {
    $('#pair_favourite> tbody  > tr').each(function(index, tr) { 
      trId = $(tr).attr('id');
      if(trId==pair) {
        $(tr).show();
      } else {
        $(tr).hide();
      }
    });
  } else {
    $('#pair_favourite> tbody  > tr').each(function(index, tr) { 
        $(tr).show();      
    });
  }
}

});



</script>