<?php $this->load->view('front/trade/trade_header'); 
 
    $prefix = get_prefix();
    $user_id = $this->session->userdata('user_id');
    $from_currency_id = $this->common_model->customQuery("select * from ".$prefix."currency where currency_symbol='".$pair[0]."'")->row('id');
    $to_currency_id = $this->common_model->customQuery("select * from ".$prefix."currency where currency_symbol='".$pair[1]."'")->row('id');

    $pair_details = $this->common_model->customQuery("select * from ".$prefix."trade_pairs where from_symbol_id='".$from_currency_id."' and to_symbol_id='".$to_currency_id."'")->row();
    $pair_ids = $pair_details->id;
    $from_currency_dets = getcryptocurrencydetail($from_currency_id);
    $to_currency_dets = getcryptocurrencydetail($to_currency_id);
    $trading_prices = tradeprices($pair_ids);
    $high_prices = highprices($pair_ids);
    $low_prices = lowprices($pair_ids);
    $volumes = volumes($pair_ids);
    $volumes_usd = volumes_usd($pair_ids);
    
    if ($this->user_id != 0) 
    { 
      $from_curs = to_decimal($this->user_balance[$pair_details->from_symbol_id], 8);
      $to_curs = to_decimal($this->user_balance[$pair_details->to_symbol_id], 8);
       $from_cur = ($from_curs>0)?$from_curs:"0.00";
       $to_cur = ($to_curs>0)?$to_curs:"0.00";
    } else {
      $from_cur = 0;
      $to_cur = 0;
    }
    $checkbot = checkbot($pair_ids);
    $history_class = ($checkbot==1)?'bot_history':'transactionhistory';
?>
    <section class="mb-2 exchangeSec">
        <div class="container containerLg">
            <div class="row">
                <div class="col-lg-12">
                    <div class="owl-carousel coinPairCarousel">
     <?php if(count($top_pairs)>0) 
           { 
            foreach($top_pairs as $pair) 
            {  
             $from_currency_det = getcryptocurrencydetail($pair->from_symbol_id);
             $to_currency_det = getcryptocurrencydetail($pair->to_symbol_id);
             $curr_pair = $First_Currency.$Second_Currency;
             $pairname = $from_currency_det->currency_symbol.$to_currency_det->currency_symbol;
             if($to_currency_det->currency_symbol=="USD")
             {
              $format = 2;
             }
             else
             {
              $format = 8;
             }
             $last_price = tradeprices($pair->id);
             $firstcur_image =  $from_currency_det->image;
             if($from_currency_det->id==$pair->from_symbol_id && $to_currency_det->id==$pair->to_symbol_id) 
             {
                $detailer = $this->common_model->getTableData("currency",array('id'=>$pair->to_symbol_id))->row();
               
    ?>
                        <div>
                            <h5><a style="color:#fff" href="<?php echo base_url();?>trade/<?php echo $from_currency_det->currency_symbol.'_'.$to_currency_det->currency_symbol;?>"><?php echo $from_currency_det->currency_symbol.' - '.$to_currency_det->currency_symbol;?></a></h5>
                            <p><?php //echo ($detailer->usd_cap>0)?$detailer->usd_cap:'0.00';

                            echo trailingZeroes(numberFormatPrecision($last_price));?></p>
                        </div>
     
<?php } } }  ?>                   
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="container containerLg">
        <div class="row">
            <div class="col-md-3 pr-md-2">
                <div class="coinpairFilter">
                    <div class="input-group">
                        <input type="text" class="form-control" id="mysearchs" placeholder="Search Currency" aria-label="Search" aria-describedby="basic-addon1">
                        <div class="input-group-append">
                            <a href="javascript:;" class="input-group-text" id="basic-addon1"><span class="fas fa-search"></span></a>
                        </div>
                    </div>
                </div>
                 <div class="grayBdrBox">
                  
                    <div class="trade-tab">

                        <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
  <li class="nav-item">
    <a class="nav-link active" id="pills-all-tab" data-toggle="pill" href="#pills-all" role="tab" aria-controls="pills-all" aria-selected="true">All</a>
  </li>
  <?php if(count($currencies)>0) { foreach($currencies as $cur) { ?>
  <li class="nav-item">
    <a class="nav-link" id="pills-<?php echo $cur->currency_symbol;?>-tab" data-toggle="pill" href="#pills-<?php echo $cur->currency_symbol;?>" role="tab" aria-controls="pills-<?php echo $cur->currency_symbol;?>" aria-selected="false"><?php echo $cur->currency_symbol;?></a>
  </li>
 <?php } } ?>
</ul>
<p id="coinPairsLists"></p>
<div class="tab-content" id="pills-tabContent">
  <div class="tab-pane fade show active" id="pills-all" role="tabpanel" aria-labelledby="pills-all-tab">
  <ul class="coinPairsList pairres" id="coinPairsList">                   
  </ul>
  </div>
  <?php if(count($allcurrencies)>0) { foreach($allcurrencies as $cur) { ?>
  <div class="tab-pane fade" id="pills-<?php echo $cur->currency_symbol;?>" role="tabpanel" aria-labelledby="pills-<?php echo $cur->currency_symbol;?>-tab">
   <ul class="coinPairsList pairres_tab" id="coinPairsList">
   <?php 
   $pair_currencys = $this->common_model->customQuery("select * from ixtoken_trade_pairs where status='1' and from_symbol_id = ".$cur->id." or to_symbol_id = ".$cur->id." order by id DESC")->result();
   if(count($pair_currencys)>0) 
          { 
            foreach($pair_currencys as $pair) 
            {  
             $from_currency_det = getcryptocurrencydetail($pair->from_symbol_id);
             $to_currency_det = getcryptocurrencydetail($pair->to_symbol_id);
             $curr_pair = $First_Currency.$Second_Currency;
             $pairname = $from_currency_det->currency_symbol.$to_currency_det->currency_symbol;
             $firstcur_image =  $from_currency_det->image;
             $pair_id = $pair->id;
             $trading_price = tradeprices($pair_id);
             $high_price = highprices($pair_id);
                $low_price = lowprices($pair_id);
                $to_curr_det = getcryptocurrencydetail($to_currency_id);
                $trading_usdprice = $trading_price * $to_curr_det->online_usdprice;
                $price_24hr = pricechanges($pair_id);
                if($price_24hr>=0)
                {
                    $price_sym = "+";
                }
                $price_24hrusd = $price_24hr * $to_curr_det->online_usdprice;

                $volume = volumes($pair_id);
                $usermal = $this->db->where('id', $user_id)->get($prefix.'users')->result();
                $First_Currency = $First_Currency;
                if ($First_Currency == 'USD') {
                  $num_format1 = 2;
                } else {
                  $num_format1 = 6;
                }
                $Second_Currency = $Second_Currency;
                if ($Second_Currency == 'USD') {
                  $num_format2 = 2;
                } else {
                  $num_format2 = 6;
                }
                if ($this->user_id != 0) {  
                  $from_curs = to_decimal($this->user_balance[$pair_details->from_symbol_id], 8);
                  $to_curs = to_decimal($this->user_balance[$pair_details->to_symbol_id], 8);
                  $from_cur = ($from_curs>0)?$from_curs:"0.000";
                  $to_cur = ($to_curs>0)?$to_curs:"0.000";
                } else {
                  $from_cur = 0;
                  $to_cur = 0;
                }
                //print_r($to_cur);
                $coin_name = strtolower($fromcurrency_details->currency_name);
                $to_curr_symbol = strtolower($Second_Currency);
                $price_24hr = pricechanges($pair_id);
                $change_24hrs = pricechangepercents($pair_id);
                if($price_24hr>0)
                {
                    $price_sym = "+";
                    $percent_class = 'text-green';
                    $price_24hr = $price_24hr;
                }
                else if($price_24hr==0)
                {
                    $price_sym = "";
                    $percent_class ="";
                    $price_24hr = '0.00';
                }
                else
                {
                    $price_sym = "";
                    $percent_class = 'text-red';
                    $price_24hr = $price_24hr;
                }
                $price_24hrs = $price_sym.$price_24hr;
                $trading_price = tradeprices($pair_id);
             if($from_currency_det->id==$pair->from_symbol_id && $to_currency_det->id==$pair->to_symbol_id) 
             {
                $detailer = $this->common_model->getTableData("currency",array('id'=>$pair->to_symbol_id))->row();
    ?>
                        <li class="slide-link <?php echo strtolower($from_currency_det->currency_symbol);?> <?php echo strtolower($to_currency_det->currency_symbol);?> <?php echo $from_currency_det->currency_symbol;?> <?php echo $to_currency_det->currency_symbol;?>">
                            <div class="">
                                <a href="<?=base_url();?>trade/<?=$from_currency_det->currency_symbol.'_'.$to_currency_det->currency_symbol;?>"><h6><?php echo $from_currency_det->currency_symbol.' / '.$to_currency_det->currency_symbol;?></h6></a>
                                <h6><?php echo trailingZeroes(numberFormatPrecision($trading_price)); ?></h6>
                            </div>
                            <div>
                                <p>24h Change</p>
                                <p><span class="<?=$percent_class?>"><?php echo trailingZeroes(numberFormatPrecision($price_24hrs,4));?></span>  (<span class="<?=$percent_class?>"><?php echo number_format($change_24hrs,2).'%';?></span>)</p>
                            </div>
                            <div>
                                <p>24h Volume</p>
                                <p><?php echo trailingZeroes(numberFormatPrecision($volume)); ?> <?php echo $to_currency_det->currency_symbol;?></p>
                            </div>
                        </li>
    <?php } } } else {  ?>  
                   <li class="slide-link">
                    <div>
                      No pairs found
                    </div>
                   </li>
    <?php } ?>                      
                    </ul>

  </div>
<?php } } ?>
 <!--  <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">...</div>
  <div class="tab-pane fade" id="pills-usdt" role="tabpanel" aria-labelledby="pills-usdt-tab">...</div>
  <div class="tab-pane fade" id="pills-tarm" role="tabpanel" aria-labelledby="pills-tarm-tab">...</div>
  <div class="tab-pane fade" id="pills-usd" role="tabpanel" aria-labelledby="pills-usd-tab">...</div> -->


</div>
</div>
</div>
</div>
            <div class="col-md-9 pl-md-0">
                <div class="selectedPairDet grayBdrBox d-lg-flex justify-content-between">
                    <div class="media align-items-center">
                        <img height="32" width="32" src="<?=$from_currency_dets->image?>" class="mr-3" alt="...">
                        <div class="media-body">
                            <h5><?=$First_Currency?> - <?=$Second_Currency?></h5>
                            <p class="mb-0"><?=$from_currency_dets->currency_name?></p>
                        </div>
                    </div>
                    <div>
                        <p>Last Price</p>
                        <h6 class="trade_price"><?php echo trailingZeroes(numberFormatPrecision($trading_prices)); ?></h6>
                    </div>
                    <div>
                        <p>Volume <?=$First_Currency?></p>
                        <h6 class="trade_volume"><?php echo trailingZeroes(numberFormatPrecision($volumes,8)); ?></h6>
                    </div>
                    <div>
                        <p>Volume USD</p>
                        <h6 class="trade_volume_usd"><?php echo trailingZeroes(numberFormatPrecision($volumes_usd,8)); ?></h6>
                    </div>
                    <div>
                        <p>24H High</p>
                        <h6 class="trade_highprice"><?=trailingZeroes(numberFormatPrecision($high_prices))?></h6>
                    </div>
                    <div>
                        <p>24H Low</p>
                        <h6 class="trade_lowprice"><?=trailingZeroes(numberFormatPrecision($low_prices))?></h6>
                    </div>
                </div>
                <div class="tradinChart">
                    <!-- TradingView Widget BEGIN -->
                    <div id="tradingview_254d3" class="tradingview-widget-container">                       
                    </div>
                    <!-- TradingView Widget END -->
                </div>
            </div>
        </div>
        <div class="row mt-2">
            <div class="col-lg-6 pr-md-2">
                <div class="grayBdrBox buySellTbl d-lg-flex h-100">
                    <div class="buyOrdersTbl">
                        <h4 class="exchTitle">Buy Orders</h4>
                        <table class="table mb-0 table-bordered">
                            <thead>
                                <tr>
                                    <th>Price (<?php echo $to_currency_dets->currency_symbol;?>)</th>
                                    <th>Amount (<?php echo $from_currency_dets->currency_symbol;?>)</th>
                                    <th>Total (<?php echo $to_currency_dets->currency_symbol;?>)</th>
                                    <tr>
                            </thead>
                            <tbody class="buy_order odrTblScroll">
                          

                        </tbody>
                        </table>
                    </div>
                    <div class="sellOrdersTbl">
                        <h4 class="exchTitle">Sell Orders</h4>
                        <table class="table mb-0 table-bordered">
                            <thead>
                                <tr>
                                    <th>Price (<?php echo $to_currency_dets->currency_symbol;?>)</th>
                                    <th>Amount (<?php echo $from_currency_dets->currency_symbol;?>)</th>
                                    <th>Total (<?php echo $to_currency_dets->currency_symbol;?>)</th>
                                    <tr>
                            </thead>
                            <tbody class="sell_order odrTblScroll1">
                                                                   
                                                    
                        </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 pl-md-0">
                <div class="grayBdrBox h-100 py-2 buySellSec">
                    <ul class="nav nav-pills mb-2 justify-content-center navTabs" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <a class="nav-link active" id="pills-limit-tab" data-toggle="pill" href="#pills-limit" role="tab" aria-controls="pills-limit" aria-selected="true">LIMIT</a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" id="pills-market-tab" data-toggle="pill" href="#pills-market" role="tab" aria-controls="pills-market" aria-selected="false">MARKET</a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" id="pills-stopLimit-tab" data-toggle="pill" href="#pills-stopLimit" role="tab" aria-controls="pills-stopLimit" aria-selected="false">STOP-LIMIT</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-limit" role="tabpanel" aria-labelledby="pills-limit-tab">
                            <div class="d-lg-flex h-100">
                                <div class="buySellBox">
                                    <h4 class="exchTitle text-left">Buy <?=$First_Currency?> <span style="float: right;font-size: 12px;color: #0ca7b2;" class="text-right buy_bal"><?php echo $to_cur;?> <?=$Second_Currency?></span>
                                    </h4>
                                    <form id="buylimit limit_buy" autocomplete="off" class="boxed">
                                         <input type="hidden" name="buy_order_limit" id="buy_order_limit" value="limit">
                                         <input type="hidden" name="buy_order_type" id="buy_order_type" value="limit">
                                         <input type="hidden" name="current_currency" id="current_currency" value="<?php echo $Second_Currency; ?>">
                                         <input type="hidden" id="currency_value" name="currency_value" value="<?=$to_cur?>">
                                         <input type="hidden" class="market_prices" id="market_prices" name="">

                                         <div id="buystatus" style="display: none;"></div>
                                         <div id="buylimitmsg"></div>
                                         <div class="form-group">
                                            <label for="">Amount to Buy</label>
                                            <div class="input-group mb-3">
                                                <input type="number" name="buy_amount" id="buy_amount" onKeyUp="calculation('buy','limit');" class="form-control" placeholder="0.00000000" step="<?php echo($First_Currency=='TARM')?1:'.01';?>" min="0">
                                                <div class="input-group-append">
                                                    <span class="input-group-text" id="basic-addon1"><?=$First_Currency?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Price</label>
                                            <div class="input-group mb-3">
                                                <input type="number" name="buy_price" id="buy_price" onKeyUp="calculation('buy','limit');" class="form-control" placeholder="0.00000000" step="<?php echo($Second_Currency=='TARM')?1:'.01';?>" min="0">
                                                <div class="input-group-append">
                                                    <span class="input-group-text" id="basic-addon1"><?=$Second_Currency?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="btn-group btn-group-toggle justify-content-between" data-toggle="buttons">
                                                <label class="btn btn-secondary">                   
                                                  <input type="radio" name="options" onchange="change_buytrade('limit','buy','25');" id="option1" checked> 25%
                                                </label>
                                                <label class="btn btn-secondary">
                                                  <input type="radio" onchange="change_buytrade('limit','buy','50');" name="options" id="option2"> 50%
                                                </label>
                                                <label class="btn btn-secondary">
                                                  <input type="radio" onchange="change_buytrade('limit','buy','75');" name="options" id="option3"> 75%
                                                </label>
                                                <label class="btn btn-secondary">
                                                  <input type="radio" onchange="change_buytrade('limit','buy','100');" name="options" id="option3"> 100%
                                                </label>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Total</label>
                                            <div class="input-group mb-3">
                                                <input type="number" name="buy_tot" id="buy_tot" class="form-control" placeholder="0.00000000" aria-label="" aria-describedby="basic-addon1">
                                                <input type="hidden" name="buy_fee_tot" id="buy_fee_tot">
                                                <div class="input-group-append">
                                                    <span class="input-group-text" id="basic-addon1"><?=$Second_Currency?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label for="" class="mb-1">Price per <?=$First_Currency?></label>
                                                    <p id="mbuy_totfee">0.00000000</p>
                                                </div>
                                                <div class="col-md-6 text-md-right">
                                                    <label for="" class="mb-1">Fees</label>
                                                    <p id="buyfees"><?php echo number_format($this->taker,1, '.', ''); ?>% <?=$First_Currency?></p>
                                                </div>
                                            </div>
                                        </div>
                                        
                    <div class="alert_content d-flex">

                        <div id="alert_err_buy" class="alert_err_buy">
                            <span id="error_msg_buy" class="t-red error error_msg_buy"></span>
                        </div>
                        <div id="alert_succ_buy" class="alert_succ_buy">
                            <span id="success_msg_buy" class="t-green success_msg_buy"></span>
                        </div>
                     </div>
                     
                    <?php if($user_id!=''){ ?>
                        <div class="form-group text-center">
                            <button type="button"
                        class="btn btnMd btnRounded btnGreen" id="buy_btn" onClick="order_placed('buy','limit');">BUY</button>
                        </div>
                    <?php } else { ?>
                        <button type="button"
                        class="btn btnMd btnRounded btnGreen site-btn green-btn  buybutton" onClick="location.href='<?php echo base_url();?>login';">BUY</button>
                    
                <?php } ?>
                                        
                                    </form>
                                </div>
                                <div class="buySellBox">
                                    <h4 class="exchTitle text-left">Sell <?=$First_Currency?> <span style="    float: right;font-size: 12px;color: #0ca7b2;" class="text-right sell_bal"><?php echo $from_cur;?> <?=$First_Currency?></span>
                                    </h4>
                                    <form id="sellimit limit_sell" action="">
                                         <input type="hidden" name="sell_order_limit" id="sell_order_limit" value="limit">
                                         <input type="hidden" name="sell_order_type" id="sell_order_type" value="limit">
                                         <input type="hidden" name="current_currency" id="scurrent_currency" value="<?php echo $First_Currency; ?>">
                                         <input type="hidden" id="scurrency_value" name="currency_value" value="<?=$from_cur?>">
                                         <input type="hidden" class="sell_pricesm" id="sell_pricesm" name="">
                                         <div id="sellstatus" style="display: none;"></div>
                                         <div id="selllimitmsg"></div>

                                        <div class="form-group">
                                            <label for="">Amount to Sell</label>
                                            <div class="input-group mb-3">
                                                <input type="number" class="form-control" placeholder="0.00000000" name="sell_amount" id="sell_amount" onKeyUp="calculation('sell','limit');" step="<?php echo($First_Currency=='TARM')?1:'.01';?>" min="0">
                                                <div class="input-group-append">
                                                    <span class="input-group-text" id="basic-addon1"><?=$First_Currency?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Price</label>
                                            <div class="input-group mb-3">
                                                <input type="number" name="sell_price" id="sell_price" onKeyUp="calculation('sell','limit');"  class="form-control" placeholder="0.00000000" step="<?php echo($Second_Currency=='TARM')?1:'.01';?>" min="0">
                                                <div class="input-group-append">
                                                    <span class="input-group-text" id="basic-addon1"><?=$Second_Currency?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="btn-group btn-group-toggle justify-content-between" data-toggle="buttons">
                                                <label class="btn btn-secondary">                   
                                                  <input type="radio" name="options" onchange="change_selltrade('limit','sell','25');" id="option1" checked> 25%
                                                </label>
                                                <label class="btn btn-secondary">
                                                  <input type="radio" onchange="change_selltrade('limit','sell','50');" name="options" id="option2"> 50%
                                                </label>
                                                <label class="btn btn-secondary">
                                                  <input type="radio" onchange="change_selltrade('limit','sell','75');" name="options" id="option3"> 75%
                                                </label>
                                                <label class="btn btn-secondary">
                                                  <input type="radio" onchange="change_selltrade('limit','sell','100');" name="options" id="option3"> 100%
                                                </label>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Total</label>
                                            <div class="input-group mb-3">
                                                <input type="text" class="form-control" placeholder="0.00000000" name="sell_tot" id="sell_tot">
                                                <input type="hidden" name="sell_fee_tot" id="sell_fee_tot">
                                                <div class="input-group-append">
                                                    <span class="input-group-text" id="basic-addon1"><?=$Second_Currency?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label for="" class="mb-1">Price per <?=$Second_Currency?></label>
                                                    <p id="msell_totfee">0.00000000</p>
                                                </div>
                                                <div class="col-md-6 text-md-right">
                                                    <label for="" class="mb-1">Fees</label>
                                                    <p id="sellfees"><?php echo number_format($this->maker,1, '.', ''); ?>% <?=$Second_Currency?></p>
                                                </div>
                                            </div>
                                        </div>

                            <div class="alert_content d-flex">
                                <div id="alert_err_sell" class="alert_err_sell">
                                <span id="error_msg_sell" class="t-red error error_msg_sell"></span>
                                </div>

                                <div id="alert_succ_sell" class="alert_succ_sell">
                                <span id="success_msg_sell" class="t-green success_msg_sell"></span>
                                </div>
                            </div>
                    <?php if($user_id!=''){ ?>
                        <div class="form-group text-center">
                            <button type="button"
                        class="btn btnMd btnRounded btnRed" id="sell_btn" onClick="order_placed('sell','limit');">SELL</button>
                        </div>
                    <?php } else { ?>
                        <button type="button"
                        class="btn btnMd btnRounded btnRed buybutton" onClick="location.href='<?php echo base_url();?>login';">SELL</button>
                    
                <?php } ?>

                                        
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="pills-market" role="tabpanel" aria-labelledby="pills-market-tab">
                            <div class="d-lg-flex h-100">
                                <div class="buySellBox">
                                    <h4 class="exchTitle text-left">Buy <?=$First_Currency?> <span style="float: right;font-size: 12px;color: #0ca7b2;" class="text-right buy_bal"><?php echo $to_cur;?> <?=$Second_Currency?></span>
                                    </h4>
                                    <form id="buymarket market_buy" action="">
                                        <input type="hidden" name="buy_order_instant" id="buy_order_instant" value="instant">
                                          <input type="hidden" name="buy_order_type" id="buy_order_type" value="instant">
                                        <input type="hidden" name="current_currency" id="current_currency" value="<?php echo $Second_Currency; ?>">
                                        <input type="hidden" id="currency_value" name="currency_value" value="<?=$to_cur?>">
                                                                                
                                        <div id="buymarketstatus" style="display: none;"></div>
                                        <div id="buymarketmsg"></div>
                                        <div class="form-group">
                                            <label for="">Amount to Buy</label>
                                            <div class="input-group mb-3">
                                                <input type="number" name="buy_amounts" id="buy_amounts" class="form-control" placeholder="0.00000000" onKeyUp="calculation('buy','instant');" step="<?php echo($First_Currency=='TARM')?1:'.01';?>" min="0">
                                                <div class="input-group-append">
                                                    <span class="input-group-text" id="basic-addon1"><?=$First_Currency?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Price </label>
                                            <div class="input-group mb-3">
                                                <input type="number" name="buy_prices" id="buy_prices" onKeyUp="calculation('buy','instant');" class="instant_price form-control" placeholder="0.00000000" step="<?php echo($Second_Currency=='TARM')?1:'.01';?>" min="0" readonly>
                                                <div class="input-group-append">
                                                    <span class="input-group-text" id="basic-addon1"><?=$Second_Currency?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="btn-group btn-group-toggle justify-content-between" data-toggle="buttons">
                                                <label class="btn btn-secondary">                   
                                                  <input type="radio" name="options" onchange="change_buytrade('instant','buy','25');" id="option1" checked> 25%
                                                </label>
                                                <label class="btn btn-secondary">
                                                  <input type="radio" onchange="change_buytrade('instant','buy','50');" name="options" id="option2"> 50%
                                                </label>
                                                <label class="btn btn-secondary">
                                                  <input type="radio" onchange="change_buytrade('instant','buy','75');" name="options" id="option3"> 75%
                                                </label>
                                                <label class="btn btn-secondary">
                                                  <input type="radio" onchange="change_buytrade('instant','buy','100');" name="options" id="option3"> 100%
                                                </label>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Total</label>
                                            <div class="input-group mb-3">
                                                <input type="number" name="buy_tots" id="buy_tots" class="form-control" placeholder="0.00000000">
                                                <input type="hidden" name="buy_fee_tots" id="buy_fee_tots" value="">
                                                <div class="input-group-append">
                                                    <span class="input-group-text" id="basic-addon1"><?=$Second_Currency?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label for="" class="mb-1">Price per <?=$First_Currency?></label>
                                                    <p id="mbuy_totfees">0.00000000</p>
                                                </div>
                                                <div class="col-md-6 text-md-right">
                                                    <label for="" class="mb-1">Fees</label>
                                                    <p id="sellfees"><?php echo number_format($this->taker,1, '.', ''); ?>% <?=$First_Currency?></p>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="alert_content d-flex">
                                             <div id="alert_err_buy" class="alert_err_buy">
                                                <span id="error_msg_buy" class="t-red error error_msg_buy"></span>
                                            </div>
                                            <div id="alert_errs_buy" class="alert_errs_buy">
                                                <span id="error_msgs_buy" class="t-red error error_msgs_buy"></span>
                                            </div>
                                            <div id="alert_succ_buy" class="alert_succ_buy">
                                                <span id="success_msg_buy" class="t-green success_msg_buy"></span>
                                            </div>
                                            <div id="alert_succs_buy" class="alert_succs_buy">
                                                <span id="success_msgs_buy" class="t-green success_msgs_buy"></span>
                                            </div>
                                        </div>
                <?php if($user_id!=''){ ?>
                        <div class="form-group text-center">
                            <button type="button"
                        class="btn btnMd btnRounded btnGreen" id="buy_btn" onClick="order_placed('buy','instant');">BUY</button>
                        </div>
                    <?php } else { ?>
                        <button type="button"
                        class="btn btnMd btnRounded btnGreen site-btn green-btn  buybutton" onClick="location.href='<?php echo base_url();?>login';">BUY</button>
                    
                <?php } ?>
                                        
                                    </form>
                                </div>
                                <div class="buySellBox">
                                    <h4 class="exchTitle text-left">Sell <?php echo $First_Currency; ?> <span style="float: right;font-size: 12px;color: #0ca7b2;" class="text-right sell_bal"><?php echo $from_cur;?> <?=$First_Currency?></span>
                                    </h4>
                                    <form id="sellmarket market_sell" action="">
                                        <input type="hidden" name="sell_order_instant" id="sell_order_instant" value="instant">
                                         <input type="hidden" name="sell_order_type" id="sell_order_type" value="instant">
                                         <input type="hidden" name="current_currency" id="scurrent_currency" value="<?php echo $First_Currency; ?>">
                                         <input type="hidden" id="scurrency_value" name="currency_value" value="<?=$from_cur?>">
                                         <input type="hidden" class="sell_pricesm" id="sell_pricesn" name="">
                                         <div id="sellstatus" style="display: none;"></div>
                                         <div id="sellinstantmsg"></div>
                                        <div class="form-group">
                                            <label for="">Amount to Sell</label>
                                            <div class="input-group mb-3">
                                                <input type="number" class="form-control" placeholder="0.00000000" name="sell_amounts" id="sell_amounts" onKeyUp="calculation('sell','instant');" step="<?php echo($First_Currency=='TARM')?1:'.01';?>" min="0">
                                                <div class="input-group-append">
                                                    <span class="input-group-text" id="basic-addon1"><?php echo $First_Currency; ?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Price</label>
                                            <div class="input-group mb-3">
                                                <input type="text" class="instant_price form-control" name="sell_prices" id="sell_prices" onKeyUp="calculation('sell','instant');" placeholder="0.00000000" step="<?php echo($Second_Currency=='TARM')?1:'.01';?>" min="0" readonly>
                                                <div class="input-group-append">
                                                    <span class="input-group-text" id="basic-addon1"><?php echo $Second_Currency;?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="btn-group btn-group-toggle justify-content-between" data-toggle="buttons">
                                                <label class="btn btn-secondary">                   
                                                  <input type="radio" name="options" onchange="change_selltrade('instant','sell','25');" id="option1" checked> 25%
                                                </label>
                                                <label class="btn btn-secondary">
                                                  <input type="radio" onchange="change_selltrade('instant','sell','50');" name="options" id="option2"> 50%
                                                </label>
                                                <label class="btn btn-secondary">
                                                  <input type="radio" onchange="change_selltrade('instant','sell','75');" name="options" id="option3"> 75%
                                                </label>
                                                <label class="btn btn-secondary">
                                                  <input type="radio" onchange="change_selltrade('instant','sell','100');" name="options" id="option3"> 100%
                                                </label>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Total</label>
                                            <div class="input-group mb-3">
                                                <input type="text" class="form-control" placeholder="0.00000000" name="sell_tots" id="sell_tots">
                                                <input type="hidden" name="sell_fee_tots" id="sell_fee_tots">
                                                <div class="input-group-append">
                                                    <span class="input-group-text" id="basic-addon1"><?=$Second_Currency?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label for="" class="mb-1">Price per <?=$Second_Currency?></label>
                                                    <p id="msell_totfees">0.00000000</p>
                                                </div>
                                                <div class="col-md-6 text-md-right">
                                                    <label for="" class="mb-1">Fees</label>
                                                    <p id="sellfees"><?php echo number_format($this->maker,1, '.', ''); ?>% <?=$Second_Currency?></p>
                                                </div>
                                            </div>
                                        </div>

                    <div class="alert_content d-flex">
                        <div id="alert_err_sell" class="alert_err_sell">
<span id="error_msg_sell" class="t-red error error_msg_sell"></span>
</div>


<div id="alert_succ_sell" class="alert_succ_sell">
<span id="success_msg_sell" class="t-green success_msg_sell"></span>
</div>
                        <div id="alert_errs_sell">
                            <span id="error_msgs_sell" class="t-red"></span>
                        </div>
                        <div id="alert_succs_sell">
                            <span id="success_msgs_sell" class="t-green success_msgs_sell"></span>
                        </div>
                    </div>
                    <?php if($user_id!=''){ ?>
                        <div class="form-group text-center">
                            <button type="button"
                        class="btn btnMd btnRounded btnRed sellbutton"  id="sell_btn" onClick="order_placed('sell','instant');">SELL</button>
                        </div>
                    <?php } else { ?>
                        <button type="button"
                        class="btn btnMd btnRounded btnRed sellbutton" onClick="location.href='<?php echo base_url();?>login';">SELL</button>
                    
                <?php } ?>
                                        
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="pills-stopLimit" role="tabpanel" aria-labelledby="pills-stopLimit-tab">
                            <div class="d-lg-flex h-100">
                                <div class="buySellBox">
                                    <h4 class="exchTitle text-left">Buy <?=$First_Currency?> <span style="float: right;font-size: 12px;color: #0ca7b2;" class="text-right buy_bal"><?php echo $to_cur;?> <?=$Second_Currency?></span>
                                    </h4>
                                    <form action="">
                                        <input type="hidden" name="buy_order_stop" id="buy_order_stop" value="stop">
                                         <input type="hidden" name="buy_order_type" id="buy_order_type" value="stop">
                                         <input type="hidden" name="current_currency" id="scurrent_currency" value="<?php echo $First_Currency; ?>">
                                         <input type="hidden" id="scurrency_value" name="currency_value" value="<?=$from_cur?>">
                                         <input type="hidden" class="sell_pricesst" id="sell_pricesst" name="">
                                         <div id="sellstatus" style="display: none;"></div>
                                         <div id="sellstopmsg"></div>
                                        <div class="form-group">
                                            <label for="">Amount to Buy</label>
                                            <div class="input-group mb-3">
                                                <input type="number" class="form-control" name="buy_amountss" id="buy_amountss" onKeyUp="calculation('buy','stop');" placeholder="0.00000000" step="<?php echo($First_Currency=='TARM')?1:'.01';?>" min="0">
                                                <div class="input-group-append">
                                                    <span class="input-group-text" id="basic-addon1"><?=$First_Currency?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Price</label>
                                            <div class="input-group mb-3">
                                                <input type="number" name="buy_pricess" id="buy_pricess" class="form-control" placeholder="0.00000000" onKeyUp="calculation('buy','stop');" step="<?php echo($Second_Currency=='TARM')?1:'.01';?>" min="0">
                                                <div class="input-group-append">
                                                    <span class="input-group-text" id="basic-addon1"><?=$Second_Currency?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="btn-group btn-group-toggle justify-content-between" data-toggle="buttons">
                                                <label class="btn btn-secondary">                   
                                                  <input type="radio" name="options" onchange="change_buytrade('stop','buy','25');" id="option1" checked> 25%
                                                </label>
                                                <label class="btn btn-secondary">
                                                  <input type="radio" onchange="change_buytrade('stop','buy','50');" name="options" id="option2"> 50%
                                                </label>
                                                <label class="btn btn-secondary">
                                                  <input type="radio" onchange="change_buytrade('stop','buy','75');" name="options" id="option3"> 75%
                                                </label>
                                                <label class="btn btn-secondary">
                                                  <input type="radio" onchange="change_buytrade('stop','buy','100');" name="options" id="option3"> 100%
                                                </label>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Trigger Price</label>
                                            <div class="input-group mb-3">
                                                <input type="number" name="buy_limit" id="buy_limit" class="form-control" placeholder="0.00000000" onKeyUp="calculation('buy','stop');" step="<?php echo($Second_Currency=='TARM')?1:'.01';?>" min="0">
                                                <div class="input-group-append">
                                                    <span class="input-group-text" id="basic-addon1"><?=$Second_Currency?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Total</label>
                                            <div class="input-group mb-3">
                                                <input type="number" class="form-control" placeholder="0.00000000" name="buy_totss" id="buy_totss">
                                                <input type="hidden" name="buy_fee_totss" id="buy_fee_totss">
                                                <div class="input-group-append">
                                                    <span class="input-group-text" id="basic-addon1"><?=$Second_Currency?></span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label for="" class="mb-1">Price per <?=$First_Currency?></label>
                                                    <p id="mbuy_totfeess">0.00000000</p>
                                                </div>
                                                <div class="col-md-6 text-md-right">
                                                    <label for="" class="mb-1">Fees</label>
                                                    <p id="buyfeess"><?php echo number_format($this->taker,1, '.', ''); ?>% <?=$First_Currency?></p>
                                                </div>
                                            </div>
                                        </div>

                    <div class="alert_content d-flex">
                        <div id="alert_err_buy" class="alert_err_buy">
<span id="error_msg_buy" class="t-red error error_msg_buy"></span>
</div>


<div id="alert_succ_buy" class="alert_succ_buy">
<span id="success_msg_buy" class="t-green success_msg_buy"></span>
</div>
                        <div id="alert_errss_buy">
                            <span id="error_msgss_buy" class="t-red"></span>
                        </div>
                        <div id="alert_succss_buy">
                            <span id="success_msgss_buy" class="t-green success_msgss_buy"></span>
                        </div>
                    </div>
                    <?php if($user_id!=''){ ?>
                        <div class="form-group text-center">
                            <button type="button"
                        class="btn btnMd btnRounded btnGreen buybutton" id="buy_btn" onClick="order_placed('buy','stop');">BUY</button>
                        </div>
                    <?php } else { ?>
                        <button type="button"
                        class="btn btnMd btnRounded btnGreen buybutton" onClick="location.href='<?php echo base_url();?>login';">BUY</button>
                    
                <?php } ?>
                                        
                                    </form>
                                </div>
                                <div class="buySellBox">
                                    <h4 class="exchTitle text-left">Sell <?=$First_Currency?> <span style="float: right;font-size: 12px;color: #0ca7b2;" class="text-right sell_bal"><?php echo $from_cur;?> <?=$First_Currency?></span></h4>
                                    <form action="">
                                        <input type="hidden" name="sell_order_stop" id="sell_order_stop" value="stop">
                                         <input type="hidden" name="sell_order_type" id="sell_order_type" value="stop">
                                         <input type="hidden" name="current_currency" id="scurrent_currency" value="<?php echo $First_Currency; ?>">
                                         <input type="hidden" id="scurrency_value" name="currency_value" value="<?=$from_cur?>">
                                         <input type="hidden" class="sell_pricessu" id="sell_pricessu" name="">
                                         <div id="sellstatus" style="display: none;"></div>
                                         <div id="sellstopmsg"></div>
                                        <div class="form-group">
                                            <label for="">Amount to Sell</label>
                                            <div class="input-group mb-3">
                                                <input type="number" class="form-control" placeholder="0.00000000" name="sell_amountss" id="sell_amountss" onKeyUp="calculation('sell','stop');" step="<?php echo($First_Currency=='TARM')?1:'.01';?>" min="0">
                                                <div class="input-group-append">
                                                    <span class="input-group-text" id="basic-addon1"><?=$First_Currency?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Price</label>
                                            <div class="input-group mb-3">
                                                <input type="number" name="sell_pricess" id="sell_pricess" class="form-control" placeholder="0.00000000" onKeyUp="calculation('sell','stop');" step="<?php echo($Second_Currency=='TARM')?1:'.01';?>" min="0">
                                                <div class="input-group-append">
                                                    <span class="input-group-text" id="basic-addon1"><?=$Second_Currency?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="btn-group btn-group-toggle justify-content-between" data-toggle="buttons">
                                                <label class="btn btn-secondary">                   
                                                  <input type="radio" name="options" onchange="change_selltrade('stop','sell','25');" id="option1" checked> 25%
                                                </label>
                                                <label class="btn btn-secondary">
                                                  <input type="radio" onchange="change_selltrade('stop','sell','50');" name="options" id="option2"> 50%
                                                </label>
                                                <label class="btn btn-secondary">
                                                  <input type="radio" onchange="change_selltrade('stop','sell','75');" name="options" id="option3"> 75%
                                                </label>
                                                <label class="btn btn-secondary">
                                                  <input type="radio" onchange="change_selltrade('stop','sell','100');" name="options" id="option3"> 100%
                                                </label>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Trigger Price</label>
                                            <div class="input-group mb-3">
                                                <input type="number" name="sell_limit" id="sell_limit" class="form-control" placeholder="0.00000000" onKeyUp="calculation('sell','stop');" step="<?php echo($Second_Currency=='TARM')?1:'.01';?>" min="0">
                                                <div class="input-group-append">
                                                    <span class="input-group-text" id="basic-addon1"><?=$Second_Currency?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Total</label>
                                            <div class="input-group mb-3">
                                                <input type="number" class="form-control" placeholder="0.00000000" name="sell_totss" id="sell_totss">
                                                <input type="hidden" name="sell_fee_totss" id="sell_fee_totss">
                                                <div class="input-group-append">
                                                    <span class="input-group-text" id="basic-addon1"><?=$Second_Currency?></span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label for="" class="mb-1">Price per <?=$Second_Currency?></label>
                                                    <p id="msell_totfeess">0.00000000</p>
                                                </div>
                                                <div class="col-md-6 text-md-right">
                                                    <label for="" class="mb-1">Fees</label>
                                                    <p id="sellfeess"><?php echo number_format($this->maker,1, '.', ''); ?>% <?=$Second_Currency?></p>
                                                </div>
                                            </div>
                                        </div>

                    <div class="alert_content d-flex">
                       
                        <div id="alert_err_sell" class="alert_err_sell">
<span id="error_msg_sell" class="t-red error error_msg_sell"></span>
</div>


<div id="alert_succ_sell" class="alert_succ_sell">
<span id="success_msg_sell" class="t-green success_msg_sell"></span>
</div>
                        <div id="alert_errss_sell">
                            <span id="error_msgss_sell" class="t-red"></span>
                        </div>
                        <div id="alert_succss_sell">
                            <span id="success_msgss_sell" class="t-green success_msgss_sell"></span>
                        </div>
                    </div>
                    <?php if($user_id!=''){ ?>
                        <div class="form-group text-center">
                            <button type="button"
                        class="btn btnMd btnRounded btnRed sellbutton" id="sell_btn" onClick="order_placed('sell','stop');">SELL</button>
                        </div>
                    <?php } else { ?>
                        <button type="button"
                        class="btn btnMd btnRounded btnRed sellbutton" onClick="location.href='<?php echo base_url();?>login';">SELL</button>
                    
                <?php } ?>
                                        
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php
            $user_id = $this->session->userdata('user_id'); 
            if(!empty($user_id))
            { 
    ?>
        <div class="row mt-2 mb-2">
            <div class="col-lg-12">
                <div class="">
                    <ul class="nav nav-tabs navTabUi" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <a class="nav-link active" id="openOrders-tab" data-toggle="tab" href="#openOrders" role="tab" aria-controls="openOrders" aria-selected="true">OPEN ORDERS</a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" id="tradeHistory-tab" data-toggle="tab" href="#tradeHistory" role="tab" aria-controls="tradeHistory" aria-selected="false">TRADE HISTORY</a>
                        </li>

                        
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="openOrders" role="tabpanel" aria-labelledby="openOrders-tab">
                            <div class="navTabsTbl openOdrsTbl table-responsive">
                                <table class="table mb-0 table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Type</th>
                                            <th>OrderType</th>
                                            <th>Pair</th>
                                            <th>Amount</th>
                                            <th>Price</th>
                                            <th>Total</th>
                                            <th><span onclick="cancelAll();" style="cursor:pointer;">Cancel All</span></th>                                            
                                    </thead>
                                    <tbody class="open_orders opnOdrTblScroll">
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tradeHistory" role="tabpanel" aria-labelledby="tradeHistory-tab">
                            <div class="navTabsTbl openOdrsTbl tradeHisTbl table-responsive">
                                <table class="table mb-0 table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Type</th>
                                            <th>Pair</th>
                                            <th>Amount</th>
                                            <th>Price</th>
                                            <th>Total</th>
                                            <th><input type="checkbox" name="showme" value="uncheck" id="showme"/> Show My Orders</th>
                                            <tr>
                                    </thead>
                                    <tbody class="<?php echo $history_class;?> tradeHistoryTblScroll">

                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    <?php } ?>
    </div>

<?php $this->load->view('front/trade/trade_footer'); ?>