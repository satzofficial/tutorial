<?php 
$site_common = site_common();
$copy_right = $site_common['site_settings']->copy_right_text;
$from_currency_id = $this->common_model->customQuery("select * from ixtoken_currency where currency_symbol='".$pair[0]."'")->row('id');
$to_currency_id = $this->common_model->customQuery("select * from ixtoken_currency where currency_symbol='".$pair[1]."'")->row('id');
if ($this->user_id != 0) {
  $from_cur = to_decimal($this->user_balance[$pair_details->from_symbol_id], 8);
  $to_cur = to_decimal($this->user_balance[$pair_details->to_symbol_id], 8);
} else {
  $from_cur = 0;
  $to_cur = 0;
}
?>
</body>
<!--jquery-->
<script src="<?=base_url();?>assets/front/inner/js/jquery-3.4.1.min.js"></script>

<!--popper-->
<script src="<?=base_url();?>assets/front/inner/js/popper.min.js"></script>
<!--bootstrap-->
<script src="<?=base_url();?>assets/front/inner/js/bootstrap.min.js"></script>


<!--bootstrap-select-->
<script src="<?=base_url();?>assets/front/inner/js/bootstrap-select.min.js"></script>
<script>
    $('selectpicker').selectpicker();
</script>

<!--dark-light-toggle-->
<script>
    function toggleDarkLight() {
        var body = document.getElementById("body");
        var currentClass = body.className;
        body.className = currentClass == "trade_advance light_mode" ? "trade_advance dark_mode" : "trade_advance light_mode";
    }
</script>

<!--datatables-->
<script type="text/javascript" src="https://cdn.datatables.net/w/bs4/dt-1.10.18/datatables.min.js"></script>
<script>
    $(document).ready(function () {
        $('#open_order_advance').DataTable({
            "scrollY": 'calc(100vh - 514px)',
            "responsive": true,
            "scrollCollapse": true,
            "scrollX": true,
            "paging": false,
            "info": false,
            "searching": false,
            "language": {
                "decimal": ",",
                "thousands": "."
            }
        });
        $('#active_trade_order_advance').DataTable({
            "scrollY": 'calc(100vh - 514px)',
            "responsive": true,
            "scrollCollapse": true,
            "scrollX": true,
            "paging": false,
            "info": false,
            "searching": false,
            "language": {
                "decimal": ",",
                "thousands": "."
            }
        });
        $('#stop_limit_order_advance').DataTable({
            "scrollY": 'calc(100vh - 514px)',
            "responsive": true,
            "scrollCollapse": true,
            "scrollX": true,
            "paging": false,
            "info": false,
            "searching": false,
            "language": {
                "decimal": ",",
                "thousands": "."
            }
        });
        $('#buy_order_table_advance_1').DataTable({
            "scrollX": true,
            "paging": false,
            "info": false,
            "ordering": false,
            "searching": false,
            "language": {
                "decimal": ",",
                "thousands": "."
            }
        });
        $('#sell_order_table_advance_1').DataTable({
            "scrollX": true,
            "paging": false,
            "info": false,
            "ordering": false,
            "searching": false,
            "language": {
                "decimal": ",",
                "thousands": "."
            }
        });
        $('#buy_order_table_advance_2').DataTable({
            "scrollY": 'calc(100vh - 471px)',
            "scrollCollapse": true,
            "scrollX": true,
            "paging": false,
            "info": false,
            "searching": false,
            "language": {
                "decimal": ",",
                "thousands": "."
            }
        });
        $('#sell_order_table_advance_2').DataTable({
            "scrollY": 'calc(100vh - 471px)',
            "scrollCollapse": true,
            "scrollX": true,
            "paging": false,
            "info": false,
            "searching": false,
            "language": {
                "decimal": ",",
                "thousands": "."
            }
        });
        $('#trade_history_advance').DataTable({
            "scrollY": 'calc(100vh - 410px)',
            "scrollCollapse": true,
            "scrollX": true,
            "paging": false,
            "info": false,
            "searching": false,
            "language": {
                "decimal": ",",
                "thousands": "."
            }
        });

    });
</script>
<script>
    $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
        $($.fn.dataTable.tables(true)).DataTable()
            .columns.adjust();
    });

    function change_pair(url)
    { 
      var reurl="trade/pro";
      var front_url = "<?php echo base_url();?>";
      location.href = front_url+reurl+'/'+url;
    }
</script>

<script>
      var user_id='<?php echo $this->user_id; ?>';
      var base_url='<?php echo base_url(); ?>';
      var front_url='<?php echo front_url(); ?>';
      var coinchairs_userid = "<?php echo $this->user_id; ?>";
      var from_currency = "<?php echo $from_cur; ?>";
      var to_currency = "<?php echo $to_cur; ?>";
      var maker_fee = "<?php echo $this->maker; ?>";
      var taker_fee = "<?php echo $this->taker; ?>";
      var pair = "<?php echo implode('_',$pair); ?>";
      var pair_id = "<?php echo $pair_details->id; ?>";
      var current_buy_price = "<?php echo number_format($this->marketprice,8); ?>";
      var current_sell_price = "<?php echo number_format($this->marketprice,8); ?>";
      var minimum_trade_amount = "<?php echo $this->minimum_trade_amount; ?>";
      var lastmarketprice = "<?php echo $this->lastmarketprice; ?>";
      var dummyimg='<?php echo dummyuserImg(); ?>';
      var pagetype='<?php echo $pagetype; ?>';
      var first_id              = "<?php echo isset($pair[0])?currency_id($pair[0]):''; ?>";
      var second_id              = "<?php echo isset($pair[1])?currency_id($pair[1]):''; ?>";
      var port                  = "<?php echo $port; ?>";
      var host                  = "<?php echo $host; ?>";
      var date                  = "<?php echo date('Y-m-d H:i:s') ?>";
      var First_Currency = "<?php echo $First_Currency;?>";
      var Second_Currency = "<?php echo $Second_Currency;?>";
      var from_id = "<?php echo $from_currency_id; ?>";
      var to_id = "<?php echo $to_currency_id; ?>";
      var formt = 8;
      
      var wsurl = 'ws://http://legalcoin.spiegeltech.site/ws/';
      var ws = new WebSocket(wsurl);
      console.log(ws);
      $("#buy_prices").val(current_buy_price);
      $("#sell_prices").val(current_sell_price);

      var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';
      console.log(csrfName);
      $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
              if (options.type.toLowerCase() == 'post') {
                  options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
                  if (options.data.charAt(0) == '&') {
                      options.data = options.data.substr(1);
                  }
              }
          });

      $( document ).ajaxComplete(function( event, xhr, settings ) {
        if (settings.type.toLowerCase() == 'post') {
          $.ajax({
              url: front_url+"get_csrf_token", 
              type: "GET",
              cache: false,             
              processData: false,      
              success: function(data) {
                console.log("CSRF Token");
                console.log(data);
                $("input[name="+csrfName+"]").val(data);
              }
            });
          }
      });

    $("#volume_pair").click(function(){
     $(".volume_pairs").show();
     $(".volume_val").show();
     $(".change_pairs").hide();
     $(".change_val").hide();

    });


    $("#change_pair").click(function(){     
     $(".change_pairs").show();
     $(".change_val").show();
     $(".volume_pairs").hide();
     $(".volume_val").hide();

    });
    $(".select_decimal").change(function(){
    var decimal = $(this).val();
    if(decimal==3)
    {
      $(".decimal_3").show();
      $(".decimal_4").hide();
      $(".decimal_5").hide();
      $(".decimal_6").hide();
    }
    else if(decimal==4)
    {
      $(".decimal_3").hide();
      $(".decimal_4").show();
      $(".decimal_5").hide();
      $(".decimal_6").hide();
    }
    else if(decimal==5)
    {
      $(".decimal_3").hide();
      $(".decimal_4").hide();
      $(".decimal_5").show();
      $(".decimal_6").hide();
    }
    else if(decimal==6)
    {
      $(".decimal_3").hide();
      $(".decimal_4").hide();
      $(".decimal_5").hide();
      $(".decimal_6").show();
    }
    
    });


    function check_user_login()
  {
    if(user_id==''||user_id==undefined||user_id==0)
    {
      window.location.href = base_url;
      return false;
    }
    return true;
  }

  function change_buytrade(thiss,typre,orderrtype,percrens)
  {
     //alert(maker_fee);
     $(".one .btn.btn-sm.cus-value-btn").removeClass("live-click");
     $(thiss).addClass("live-click");
     if(typre == 'limit') { var a = ''; }
     else if(typre == 'instant') { var a = 's'; }
     else { var a = 'ss'; } 
     var marketprice = $("#buy_prices").val();
     var current_currency = $("#current_currency").val();
     if(current_currency == 'USD') { var format = 2;}
     else { var format = 8;}
     var balance = $("#currency_value").val();
     var total = ((percrens/100)*balance).toFixed(format);
     $("#buy_tot"+a).val(total); // APPEND TOTAL
     $("#mbuy_tot"+a).text(total);
     var amount_calc = total/marketprice;
     var trade_fee = maker_fee/100;
     var fee_calc = parseFloat(amount_calc * trade_fee).toFixed(format);
     $("#buy_fee_tot"+a).val(fee_calc);
     $("#mbuy_totfee"+a).text(fee_calc);
     var amount_calculation = ((total/marketprice)-trade_fee).toFixed(format);
     if(user_id==''||user_id==undefined||user_id==0 || balance=='' || balance==undefined || balance==0)
     {
     amount_calculation = 0;
     total = 0;
     trade_fee = 0;
     }
     $("#buy_price"+a).val(marketprice);
     $('#buy_amount'+a).val(amount_calculation); // APPEND AMOUNT
  }

  function change_selltrade(thiss,typre,orderrtype,percrens)
  {
    //lert(taker_fee);
     $(".two .btn.btn-sm.cus-value-btn").removeClass("live-click");
     $(thiss).addClass("live-click");
     if(typre == 'limit') { var a = ''; }
     else if(typre == 'instant') { var a = 's'; }
     else { var a = 'ss'; } 
     var marketprice = $("#sell_prices").val();
     var current_currency = $("#scurrent_currency").val();
     if(current_currency == 'USD') { var format = 2;}
     else { var format = 8;}
     var balance = $("#scurrency_value").val();
     var amount = ((percrens/100)*balance).toFixed(format);
     $('#sell_amount'+a).val(amount); // APPEND AMOUNT
     
     var trade_fee = taker_fee/100;
     var total_calc = amount*marketprice;
     var fee_calc = parseFloat(total_calc * trade_fee).toFixed(format);
     $("#sell_fee_tot"+a).val(fee_calc);
     $("#msell_totfee"+a).text(fee_calc);
     var total_calculation = ((amount*marketprice)-trade_fee).toFixed(format);
     if(user_id==''||user_id==undefined||user_id==0 || balance=='' || balance==undefined || balance==0)
     {
     total_calculation = 0;
     amount = 0;
     trade_fee = 0;
     }
     
     $("#sell_price"+a).val(marketprice);
     $("#sell_tot"+a).val(total_calculation); // APPEND TOTAL
     $("#msell_tot"+a).text(parseFloat(total_calculation).toFixed(format));
  }


  function calculation(a,ordertype)
    {      
        var order_type  = $('#'+a+'_order_'+ordertype).val();
        if(order_type=='instant') // market
        {
            var amount      = $("#"+a+"_amounts").val();
            var buy_price   = $('#buy_prices').val();
            var sell_price  = $('#sell_prices').val();
            if(a=='buy')
            { 
              if(buy_price!='' && amount!='')
              {
                  var maker_fee = "<?php echo $this->maker; ?>";
                  var taker_fee = "<?php echo $this->taker; ?>";

                  var tot   = (parseFloat(amount)*parseFloat(current_buy_price)).toFixed(8);
                  var fees  = (parseFloat((parseFloat(amount)*parseFloat(current_buy_price)*maker_fee/100))).toFixed(8);
                  var n = tot.toString();
                  var n1 = fees.toString();
                  if(tot>0)
                  {
                      var tot = (parseFloat(tot)+parseFloat(fees)).toFixed(8);
                  }
                  else
                  {
                      var tot = 0;
                  }
                  if(amount!="" && amount!=0 && !isNaN(amount)&&n.indexOf("e")==-1&&n1.indexOf("e")==-1)
                  {

                      $('#buy_tots').val(tot);  
                      $('#buy_fee_tots').val(fees);
                      $('#mbuy_tots').text(tot);  
                      $('#mbuy_totfees').text(fees);
                  }
                  else
                  {
                      if(n.indexOf("e")>-1||n1.indexOf("e")>-1)
                      {
                          $('#alert_err_'+a).show();
                          $('#error_msg_'+a).html('Please enter valid amount and price');
                          setTimeout(function(){
                              $('#alert_err_'+a).hide();
                          }, 3000);
                          return false;

                      }
                      $('#buy_tots').val(0);
                      $('#buy_fee_tots').val(0);
                      $('#mbuy_tots').text(0);  
                      $('#mbuy_totfees').text(0);
                      $('#buy_prices').val(0);
                      $('#buy_amounts').val(0);
                  }
              }
              else
              {
                $('#buy_tots').val(0);
                $('#buy_fee_tots').val(0);
                $('#mbuy_tots').text(0);  
                $('#mbuy_totfees').text(0);
              }
            }
            else
            {
              if(sell_price!='' && amount!='')
              {
                     var maker_fee = "<?php echo $this->maker; ?>";
                     var taker_fee = "<?php echo $this->taker; ?>";

                      var tot   = (parseFloat(amount)*parseFloat(current_sell_price)).toFixed(8);
                      var fees = (parseFloat((parseFloat(amount)*parseFloat(current_sell_price)*taker_fee/100))).toFixed(8);
                    
                      var n = tot.toString();
                      var n1 = fees.toString();
                      if(tot>0)
                      {
                          var tot = (parseFloat(tot)-parseFloat(fees)).toFixed(8);
                      }
                      else
                      {
                          var tot = 0;
                      }
                      if(amount!="" && amount!=0 && !isNaN(amount)&&n.indexOf("e")==-1&&n1.indexOf("e")==-1)
                      {
                          $('#sell_tots').val(tot); 
                          $('#sell_fee_tots').val(fees);
                          $('#msell_tots').text(tot);  
                          $('#msell_totfees').text(fees);
                      }
                      else
                      {
                          if(n.indexOf("e")>-1||n1.indexOf("e")>-1)
                          {
                              $('#alert_err_'+a).show();
                              $('#error_msg_'+a).html('Please enter valid amount and price');
                              setTimeout(function(){
                                  $('#alert_err_'+a).hide();
                              }, 3000);
                              return false;
                          }
                          $('#sell_tots').val(0);
                          $('#sell_fee_tots').val(0);
                          $('#msell_tots').text(0);  
                          $('#msell_totfees').text(0);
                      }
              }
              else
              {
                $('#sell_tots').val(0);
                $('#sell_fee_tots').val(0);
                $('#msell_tots').text(tot);  
                $('#msell_totfees').text(fees);
              }
            }
        }
        else if(order_type=='limit') // limit
        {
            var amount      = $("#"+a+"_amount").val();
            var buy_price   = $('#buy_price').val();
            var sell_price  = $('#sell_price').val();
            if(a=='buy')
            {
              if(buy_price!='' && amount!='')
              {
                    var maker_fee = "<?php echo $this->maker; ?>";
                    var taker_fee = "<?php echo $this->taker; ?>";

                    var tot   = (parseFloat(amount)*parseFloat(buy_price)).toFixed(8);
                    var fees  = (parseFloat((parseFloat(amount)*parseFloat(buy_price)*maker_fee/100))).toFixed(8);
                    var n = tot.toString();
                    var n1 = fees.toString();
                    if(tot>0)
                    {
                        var tot = (parseFloat(tot)+parseFloat(fees)).toFixed(8);
                    }
                    else
                    {
                        var tot = 0;
                    }
                    if(amount!="" && amount!=0 && !isNaN(amount)&&n.indexOf("e")==-1&&n1.indexOf("e")==-1)
                    {

                        $('#buy_tot').val(tot);  
                        $('#buy_fee_tot').val(fees);
                        $('#mbuy_tot').text(tot);  
                        $('#mbuy_totfee').text(fees);
                    }
                    else
                    {
                        if(n.indexOf("e")>-1||n1.indexOf("e")>-1)
                        {
                            $('#alert_err_'+a).show();
                            $('#error_msg_'+a).html('Please enter valid amount and price');
                            setTimeout(function(){
                                $('#alert_err_'+a).hide();
                            }, 3000);
                            return false;

                        }
                        $('#buy_tot').val(0);
                        $('#buy_fee_tot').val(0);
                        $('#mbuy_tot').text(0);  
                        $('#mbuy_totfee').text(0);
                        $('#buy_price').val(0);
                        $('#buy_amount').val(0);
                    }
              }
              else
              {
                $('#buy_tot').val(0);
                $('#buy_fee_tot').val(0);
                $('#mbuy_tot').text(0);  
                $('#mbuy_totfee').text(0);
              }
            }
            else
            {
              if(sell_price!='' && amount!='')
              {
                     var maker_fee = "<?php echo $this->maker; ?>";
                     var taker_fee = "<?php echo $this->taker; ?>";

                      var tot   = (parseFloat(amount)*parseFloat(sell_price)).toFixed(8);
                      var fees = (parseFloat((parseFloat(amount)*parseFloat(sell_price)*taker_fee/100))).toFixed(8);
                    
                      var n = tot.toString();
                      var n1 = fees.toString();
                      if(tot>0)
                      {
                          var tot = (parseFloat(tot)-parseFloat(fees)).toFixed(8);
                      }
                      else
                      {
                          var tot = 0;
                      }
                      if(amount!="" && amount!=0 && !isNaN(amount)&&n.indexOf("e")==-1&&n1.indexOf("e")==-1)
                      {
                          $('#sell_tot').val(tot); 
                          $('#sell_fee_tot').val(fees);
                          $('#msell_tot').text(tot);  
                          $('#msell_totfee').text(fees);
                      }
                      else
                      {
                          if(n.indexOf("e")>-1||n1.indexOf("e")>-1)
                          {
                              $('#alert_err_'+a).show();
                              $('#error_msg_'+a).html('Please enter valid amount and price');
                              setTimeout(function(){
                                  $('#alert_err_'+a).hide();
                              }, 3000);
                              return false;
                          }
                          $('#sell_tot').val(0);
                          $('#sell_fee_tot').val(0);
                          $('#msell_tot').text(0);  
                          $('#msell_totfee').text(0);
                      }
              }
              else
              {
                $('#sell_tot').val(0);
                $('#sell_fee_tot').val(0);
                $('#msell_tot').text(tot);  
                $('#msell_totfee').text(fees);
              }
            }
        }
        else // Stop limit
        {
            var amount      = $("#"+a+"_amountss").val();
            var buy_price   = $('#buy_pricess').val();
            var sell_price  = $('#sell_pricess').val();
            if(a=='buy')
            { 
              if(buy_price!='' && amount!='' && buy_price!=0 && amount!=0 && !isNaN(buy_price) && !isNaN(amount))
              {
                      var maker_fee = "<?php echo $this->maker; ?>";
                      var taker_fee = "<?php echo $this->taker; ?>";
                      var tot   = (parseFloat(amount)*parseFloat(buy_price)).toFixed(8);
                      var fees  = (parseFloat((parseFloat(amount)*parseFloat(buy_price)*maker_fee/100))).toFixed(8);
                      var n = tot.toString();
                      var n1 = fees.toString();
                    if(tot>0)
                    {
                        var tot = (parseFloat(tot)+parseFloat(fees)).toFixed(8);
                    }
                    else
                    {
                        var tot = 0;
                    }
                    if(amount!="" && buy_price!="" && amount!=0 && buy_price!=0&&!isNaN(amount)&&n.indexOf("e")==-1&&n1.indexOf("e")==-1)
                    {
                        $('#buy_totss').val(tot);  
                        $('#buy_fee_totss').val(fees);
                        $('#mbuy_totss').text(tot);  
                        $('#mbuy_totfeess').text(fees);
                    }
                    else
                    {
                        if(n.indexOf("e")>-1||n1.indexOf("e")>-1)
                        {
                            $('#alert_err_'+a).show();
                            $('#error_msg_'+a).html('Please enter valid amount and price');
                            //$('.sellbutton,.buybutton').prop('disabled', true);
                            setTimeout(function(){
                                $('#alert_err_'+a).hide();
                            }, 3000);
                            return false;
                        }
                    }
              }
              else
              {
                $('#buy_totss').val("");
                $('#buy_fee_totss').val("");
                $('#mbuy_totss').text(0);  
                $('#mbuy_totfeess').text(0);
              }
            }
            else
            { 
              if(sell_price!='' && amount!='' && sell_price!=0 && amount!=0 && !isNaN(sell_price) && !isNaN(amount))
              {
                      var maker_fee = "<?php echo $this->maker; ?>";
                      var taker_fee = "<?php echo $this->taker; ?>";
                      var tot   = (parseFloat(amount)*parseFloat(sell_price)).toFixed(8);
                      var fees = (parseFloat((parseFloat(amount)*parseFloat(sell_price)*taker_fee/100))).toFixed(8);
                      var n = tot.toString();
                      var n1 = fees.toString();
                      if(tot>0)
                      {
                      var tot = (parseFloat(tot)-parseFloat(fees)).toFixed(8);
                      }
                      else
                      {
                      var tot = 0;
                      }
                      if(amount!="" && sell_price!="" && amount!="" && sell_price!=""&&!isNaN(amount)&&n.indexOf("e")==-1&&n1.indexOf("e")==-1)
                      {
                      $('#sell_totss').val(tot); 
                      $('#sell_fee_totss').val(fees);
                      $('#msell_totss').text(tot);  
                      $('#msell_totfeess').text(fees);
                      }
                      else
                      {
                      if(n.indexOf("e")>-1||n1.indexOf("e")>-1)
                      {
                      $('#alert_err_'+a).show();
                      $('#error_msg_'+a).html('Please enter valid amount and price');
                      setTimeout(function(){
                      $('#alert_err_'+a).hide();
                      }, 3000);
                      return false;
                      }

                      $('#sell_totss').val(0);
                      $('#sell_fee_totss').val(0);
                      $('#msell_totss').text(0);  
                      $('#msell_totfeess').text(0);
                      $('#sell_pricess').val(0);
                      $('#sell_amountss').val(0);
                      }
              }
              else
              {
                $('#sell_totss').val("");
                $('#sell_fee_totss').val("");
                $('#msell_totss').text(0);  
                $('#msell_totfeess').text(0);
              }
            }
        }
    }

    function order_placed(a,ordertype)
    {  
        var logincheck=check_user_login();
        if(logincheck)
        {
          if(ordertype=="limit") // limit
          {            
            $('#alert_err_'+a).hide();
            $('#alert_succ_'+a).hide();
            var c     =   $("#"+a+"_amount").val();
            var p = $("#"+a+"_price").val();
            d = $("#"+a+"_tot").val();
            if(isNaN(c) || isNaN(d))
            {
                $('#alert_err_'+a).show();
                $('#error_msg_'+a).html("Please enter valid amount and price");
                setTimeout(function(){
                $('#alert_err_'+a).hide();
                }, 3000);
               
                return false;
            }
            else if(c=="" || d=="")
            {
                $('#alert_err_'+a).show();
                $('#error_msg_'+a).html("Please enter valid amount and price"); 
                $('#error_msg_'+a).show();

                setTimeout(function(){
                  $('#alert_err_'+a).hide();
                }, 3000);
                return false;
            }
            else if(c<=0 || d<=0)
            {
                $('#alert_err_'+a).show();
                $('#error_msg_'+a).html("Minimum trade amount is "+ parseFloat(minimum_trade_amount)); 
                $('#error_msg_'+a).show();

                setTimeout(function(){
                  $('#alert_err_'+a).hide();
                }, 3000);
          
                return false;
            }
            if(p=="" || c=="")
            {
              $("#"+a+"_amount").val("");
              $("#"+a+"_price").val("");
              $("#"+a+"_tot").val("");
            }
            return order_confirm(a,ordertype);
          }
          else if(ordertype=="instant") // market
          {

              $('#alert_errs_'+a).hide();
              $('#alert_succs_'+a).hide();

              var c     =   $("#"+a+"_amounts").val();
              d = $("#"+a+"_tots").val(); 
              if(isNaN(c) || isNaN(d))
              {
                  $('#alert_errs_'+a).show();
                  $('#error_msgs_'+a).html("Please enter valid amount and price"); 
                  setTimeout(function(){
                  $('#alert_errs_'+a).hide();
                  }, 3000);
                 
                  return false;
              }
              else if(c=="" || d=="")
              {
                  $('#alert_errs_'+a).show();
                  $('#error_msgs_'+a).html("Please enter valid amount and price"); 
                  $('#error_msgs_'+a).show();

                  setTimeout(function(){
                    $('#alert_errs_'+a).hide();
                  }, 3000);
                  return false;
              }
              else if(c<=0 || d<=0)
              {
                  $('#alert_errs_'+a).show();
                  $('#error_msgs_'+a).html("Minimum trade amount is "+ parseFloat(minimum_trade_amount)); 
                  $('#error_msgs_'+a).show();

                  setTimeout(function(){
                    $('#alert_errs_'+a).hide();
                  }, 3000);
                  return false;
              }
              return order_confirm(a,ordertype);
          }
          else // Stop limit
          {
              $('#alert_errss_'+a).hide();
              $('#alert_succss_'+a).hide();

              var c     =   $("#"+a+"_amountss").val(); 
              d = $("#"+a+"_totss").val(); 
              var pri = $("#"+a+"_pricess").val();
              var limit_price = $("#"+a+"_limit").val();
              if(isNaN(c) || isNaN(d))
              {
                  $('#alert_errss_'+a).show();
                  $('#error_msgss_'+a).html("Please enter valid amount and price");
                  setTimeout(function(){
                  $('#alert_errss_'+a).hide();
                  }, 3000);
                 
                  return false;
              }
              else if(c=="" || d=="")
              {
                  $('#alert_errss_'+a).show();
                  $('#error_msgss_'+a).html("Please enter valid amount and price");
                  $('#error_msgss_'+a).show();

                  setTimeout(function(){
                    $('#alert_errss_'+a).hide();
                  }, 3000);
                  return false;
              }
              else if(c<=0 || d<=0)
              {
                  $('#alert_errss_'+a).show();
                  $('#error_msgss_'+a).html("Minimum trade amount is "+ parseFloat(minimum_trade_amount));
                  $('#error_msgss_'+a).show();

                  setTimeout(function(){
                    $('#alert_errss_'+a).hide();
                  }, 3000);
                  return false;
              }
              else if((c!="" || c>=0 || d!="" || d>=0) && limit_price=="" || limit_price<=0)
              {
                  $('#alert_errss_'+a).show();
                  $('#error_msgss_'+a).html('Please enter limit price'); 
                  $('#error_msgss_'+a).show();
                  setTimeout(function(){
                    $('#alert_errss_'+a).hide();
                  }, 3000);
                  return false;
              }
              return order_confirm(a,ordertype);
          }
        }   
    }


    function order_confirm(a,ordertype)
    {

        if(ordertype=='limit') // limit
        {
          var c = $("#"+a+"_amount").val();
          var d = $("#"+a+"_price").val();
          var multiply  = parseFloat(c)*parseFloat(d);
          if(a=="buy")
          {
            var fees      = parseFloat(multiply)*maker_fee/100;
            if(multiply>0)
            {
              var tot = multiply+fees;
            }
            else
            {
              var tot = 0;
            }
          }
          else
          {
            var fees      = parseFloat(multiply)*taker_fee/100;
             if(multiply>0)
            {
              var tot = multiply-fees;
            }
            else
            {
              var tot = 0;
            } 
          }
          if(parseFloat(tot) < parseFloat(minimum_trade_amount)){
            $('#alert_err_'+a).show();
                $('#error_msg_'+a).html("Minimum trade amount is "+ parseFloat(minimum_trade_amount));
                setTimeout(function(){
                    $('#alert_err_'+a).hide();
                }, 3000);
                return false;
          }
          var mul = parseFloat(tot);
          if(a=="buy")
          {
             if(mul > to_currency)
              { 
                  $('#alert_err_'+a).show();
                  $('#error_msg_'+a).html("Insufficient balance");
                  setTimeout(function(){
                      $('#alert_err_'+a).hide();
                  }, 3000);
                  return false;
              }
              else
              {
                return executeOrder('buy','limit');
              }
          }
          else
          {    
            if(from_currency < parseFloat(c))
            {
                $('#alert_err_'+a).show();
                $('#error_msg_'+a).html("Insufficient balance");
                setTimeout(function(){
                    $('#alert_err_'+a).hide();
                }, 3000);
                return false;
            }
            else
            {
              return executeOrder('sell','limit');
            }
          }

        }
        else if(ordertype=='instant') // market
        {
          var c = $("#"+a+"_amounts").val();
          var d = $("#"+a+"_prices").val();
          var multiply  = parseFloat(c)*parseFloat(d);
          if(a=="buy")
          {
            var fees      = parseFloat(multiply)*maker_fee/100;
            if(multiply>0)
            {
              var tot = multiply+fees;
            }
            else
            {
              var tot = 0;
            }
          }
          else
          {
            var fees      = parseFloat(multiply)*taker_fee/100;
             if(multiply>0)
            {
              var tot = multiply-fees;
            }
            else
            {
              var tot = 0;
            } 
          }
          if(parseFloat(tot) < parseFloat(minimum_trade_amount)){
            $('#alert_err_'+a).show();
                $('#error_msg_'+a).html("Minimum trade amount is "+ parseFloat(minimum_trade_amount));
                setTimeout(function(){
                    $('#alert_err_'+a).hide();
                }, 3000);
                return false;
          }
          var mul = parseFloat(tot);
          if(a=="buy")
          {
             if(mul > to_currency)
              { 
                  $('#alert_err_'+a).show();
                  $('#error_msg_'+a).html("Insufficient balance");
                  setTimeout(function(){
                      $('#alert_err_'+a).hide();
                  }, 3000);
                  return false;
              }
              else
              {
                return executeOrder('buy','instant');
              }
          }
          else
          {    
            if(from_currency < parseFloat(c))
            {
                $('#alert_err_'+a).show();
                $('#error_msg_'+a).html("Insufficient balance");
                setTimeout(function(){
                    $('#alert_err_'+a).hide();
                }, 3000);
                return false;
            }
            else
            {
              return executeOrder('sell','instant');
            }
          }
        }
        else // Stop limit
        {
          var c = $("#"+a+"_amountss").val();
          var d = $("#"+a+"_pricess").val();
          var  l = $("#"+a+"_limit").val();
          var multiply  = parseFloat(c)*parseFloat(d);
          if(a=="buy")
          {
            if(parseFloat(d)==parseFloat(current_buy_price))
            {
                $('#alert_errss_'+a).show();
                $('#error_msgss_'+a).html('Stop price not same as market price');
                setTimeout(function(){
                $('#alert_errss_'+a).hide();
                        }, 3000);
              
                return false;
            }
            else if(parseFloat(d)!=parseFloat(current_buy_price)) 
            {
            
               if(parseFloat(l)==parseFloat(current_buy_price))
              {
                $('#alert_errss_'+a).show();
                $('#error_msgss_'+a).html('Limit price not same as market price');
                setTimeout(function(){
                $('#alert_errss_'+a).hide();
                        }, 3000);
              
                return false;
              }
            
            }
            else
            {
            var fees      = parseFloat(multiply)*maker_fee/100;
            if(multiply>0)
            {
              var tot = multiply+fees;
            }
            else
            {
              var tot = 0;
            }
            }
          }
          else
          {
            if(parseFloat(d)==parseFloat(current_buy_price))
            {
              $('#alert_errss_'+a).show();
                        $('#error_msgss_'+a).html('Stop price not same as market price');
                        setTimeout(function(){
                        $('#alert_errss_'+a).hide();
                        }, 3000);
                       
                        return false;
            }
            else if(parseFloat(d)!=parseFloat(current_buy_price)) 
            {
               if(parseFloat(l)==parseFloat(current_buy_price))
              {
                $('#alert_errss_'+a).show();
                $('#error_msgss_'+a).html('Limit price not same as market price');
                setTimeout(function(){
                $('#alert_errss_'+a).hide();
                        }, 3000);
              
                return false;
              }
            
            }
            else
            {
            var fees      = parseFloat(multiply)*taker_fee/100;
             if(multiply>0)
            {
              var tot = multiply-fees;
            }
            else
            {
              var tot = 0;
            }
            }
          }
          if(parseFloat(tot) < parseFloat(minimum_trade_amount)){
            $('#alert_err_'+a).show();
                $('#error_msg_'+a).html("Minimum trade amount is "+ parseFloat(minimum_trade_amount));
                setTimeout(function(){
                    $('#alert_err_'+a).hide();
                }, 3000);
                return false;
          }
          var mul = parseFloat(tot);
          if(a=="buy")
          {
             if(mul > to_currency)
              { 
                  $('#alert_err_'+a).show();
                  $('#error_msg_'+a).html("Insufficient balance");
                  setTimeout(function(){
                      $('#alert_err_'+a).hide();
                  }, 3000);
                  return false;
              }
              else
              {
                return executeOrder('buy','stop');
              }
          }
          else
          {    
            if(from_currency < parseFloat(c))
            {
                $('#alert_err_'+a).show();
                $('#error_msg_'+a).html("Insufficient balance");
                setTimeout(function(){
                    $('#alert_err_'+a).hide();
                }, 3000);
                return false;
            }
            else
            {
              return executeOrder('sell','stop');
            }
          }
        }        
    }


    function executeOrder(a,ordertype)
    {
      if(ordertype=='limit') // limit
      {
          var amount = $("#"+a+"_amount").val();
          var price = $("#"+a+"_price").val();
          var total = $("#"+a+"_tot").val();
          if(a =='buy')
          {
            var fee=maker_fee;
          }
          else
          {
            var fee=taker_fee;
          }
          var loan_rate=0;         
          var param = {  
          path: "execute_order",
          amount: amount,
          price:price,
          limit_price:limit_price,
          total:total,
          fee:fee,
          ordertype:ordertype,
          pair:pair,
          pair_id:pair_id,
          type:a,
          loan_rate:loan_rate,
          pagetype:pagetype,
          user_id:'<?php echo $this->session->userdata('user_id');?>'
         };
         ws.send(JSON.stringify(param));
      }
      else if(ordertype=='instant') // market
      {
          var amount = $("#"+a+"_amounts").val();
          var price = $("#"+a+"_prices").val();
          var total = $("#"+a+"_tots").val();
          if(a =='buy')
          {
            var fee=maker_fee;
          }
          else
          {
            var fee=taker_fee;
          }
          var loan_rate=0;
          var param = {  
          path: "execute_order",
          amount: amount,
          price:price,
          limit_price:limit_price,
          total:total,
          fee:fee,
          ordertype:ordertype,
          pair:pair,
          pair_id:pair_id,
          type:a,
          loan_rate:loan_rate,
          pagetype:pagetype,
          user_id:'<?php echo $this->session->userdata('user_id');?>'
         };
         ws.send(JSON.stringify(param));
      }
      else // Stop limit
      {
          var amount = $("#"+a+"_amountss").val();
          var price = $("#"+a+"_pricess").val();
          var total = $("#"+a+"_totss").val();
          var limit_price = $("#"+a+"_limit").val();
          if(a =='buy')
          {
            var fee=maker_fee;
          }
          else
          {
            var fee=taker_fee;
          }
          var loan_rate=0;
          var param = {  
          path: "execute_order",
          amount: amount,
          price:price,
          limit_price:limit_price,
          total:total,
          fee:fee,
          ordertype:ordertype,
          pair:pair,
          pair_id:pair_id,
          type:a,
          loan_rate:loan_rate,
          pagetype:pagetype,
          user_id:'<?php echo $this->session->userdata('user_id');?>'
         };
         ws.send(JSON.stringify(param));
      }
    }

    function cancel_order(tradeid)
    {
        if(confirm('<?php echo "Are you sure you want to cancel this order?"?>'))
        {          
           var param = {  
            path: "close_active_order",
            tradeid: tradeid,
            pair_id:pair_id,
            user_id:user_id
           };
           ws.send(JSON.stringify(param));
      }
    }
    var decimal_value = $(".select_decimal").val();
    if(decimal_value==3)
    {
      $(".decimal_3").show();
      $(".decimal_4").hide();
      $(".decimal_5").hide();
      $(".decimal_6").hide();
    }
    else if(decimal_value==4)
    {
      $(".decimal_3").hide();
      $(".decimal_4").show();
      $(".decimal_5").hide();
      $(".decimal_6").hide();
    }
    else if(decimal_value==5)
    {
      $(".decimal_3").hide();
      $(".decimal_4").hide();
      $(".decimal_5").show();
      $(".decimal_6").hide();
    }
    else if(decimal_value==6)
    {
      $(".decimal_3").hide();
      $(".decimal_4").hide();
      $(".decimal_5").hide();
      $(".decimal_6").show();
    }

   function load_design(decimal)
    { 
        if(decimal==undefined)
        {
          decimal = 8;
        }
        else
        {
          decimal = decimal;
        }
         var decimalpoints=decimal;
         var decimal=decimal;

        //Call WEB SOCKET
       var param = {  
        path: "trade_integration",
        pair_id: pair_id,
        user_id:user_id,
        pagetype:pagetype,
        pair:pair
       };
       ws.send(JSON.stringify(param));     
    }
    ws.onopen = function(event) 
      { 
        console.log("connected websocket....");             
        load_design();
      }

      ws.onmessage = function(event) 
      {
          var browsername=navigator ? navigator.userAgent.toLowerCase() : "other";
          var resp = browsername.split(" "); 
          var lengthbrowser=resp.length;
          var getname=resp[lengthbrowser-1];
          var res1 = getname.split("/"); 
          if(res1[1]!='safari')
          {
            console.API;
            if (typeof console._commandLineAPI !== 'undefined') {
            console.API = console._commandLineAPI; //chrome
            } else if (typeof console._inspectorCommandLineAPI !== 'undefined') {
            console.API = console._inspectorCommandLineAPI; //Safari
            } else if (typeof console.clear !== 'undefined') {
            console.API = console;
            }
            //  console.API.clear();
          }

          var res = event.data;
          var designs=JSON.parse(res);
          console.log(designs);
          var from_balance = designs.from_currency;
          var to_balance = designs.to_currency; //console.log(to_balance);
          var from_symbol = designs.from_symbol;
          var to_symbol = designs.to_symbol;
          var formt1 = formt;
          var pair_active = from_symbol+"/"+to_symbol;
            /** Update the balance from web socket response **/
          var userlogid = "<?php echo $this->user_id; ?>";
          $(".sell_bal").html(from_balance+" "+from_symbol);
          $(".buy_bal").html(to_balance+" "+to_symbol);

          if (designs.web_trade == "1" && designs.web_trade != '') 
          {
              var decimalpoints = "<?php echo $this->decimal_format; ?>";
              var decimal = "<?php echo $this->decimal_format; ?>";
              var current_trade=designs.current_trade;
              var transactionhistory=designs.transactionhistory;
              var buyResult=designs.buyResult;
              var sellResult=designs.sellResult;
              var api_buyResult=designs.api_buyResult;
              var api_sellResult=designs.api_sellResult;
              var api_activeorderResult=designs.api_activeorderResult;
              var api_cancelorderResult=designs.api_cancelorderResult;
              var api_historyorderResult=designs.api_historyorderResult;
              var api_stoporderResult=designs.api_stoporderResult;

              var pairs=designs.pairs;
              from_currency=designs.from_currency;
              to_currency=designs.to_currency;
              coinchairs_userid=designs.coinchairs_userid;
              current_buy_price=designs.current_buy_price;
              current_sell_price=designs.current_sell_price;
              lastmarketprice=designs.lastmarketprice;
              var from_bal = "<?php echo $from_cur;?>";
              var to_bal = "<?php echo $to_cur;?>";

              if(transactionhistory!=0&&transactionhistory.length>0)
              {
                var transaction_length=transactionhistory.length;
                var historys='';
                for(count = 0; count < transaction_length; count++)
                {
                  if(transactionhistory[count].trade_id!='' && transactionhistory[count].trade_id)
                  {
                    var time3 = transactionhistory[count].tradetime;
                    var type3 = (transactionhistory[count].Type).charAt(0).toUpperCase()+transactionhistory[count].Type.slice(1);
                    var price3 = transactionhistory[count].Price;
                    var amount3 = transactionhistory[count].Amount;
                    var fee3 = transactionhistory[count].Fee;
                    var total3  = transactionhistory[count].Total;
                    var status3 = transactionhistory[count].status.charAt(0).toUpperCase()+transactionhistory[count].status.slice(1);

                      var times3 = time3;
                      var hist_clr = "";
                      if(type3=="Buy")
                      {
                        hist_clr = "text-green";
                      }
                      else
                      {
                        hist_clr = "text-red";
                      }

                      historys=historys+'<tr><td class='+hist_clr+'>'+parseFloat(price3).toFixed(6)+'</td><td>'+parseFloat(amount3).toFixed(3)+'</td><td>'+time3+'</td></tr>';
                  }
                  else
                  {    
                      var askAmount=transactionhistory[count].askAmount;
                      var buyer_trade_id=transactionhistory[count].buyer_trade_id;
                      var buy_userId = transactionhistory[count].buyerUserid;
                      var sell_userId = transactionhistory[count].sellerUserid;
                      var seller_trade_id=transactionhistory[count].seller_trade_id;
                      var filledAmount=transactionhistory[count].filledAmount;
                      filledAmount=parseFloat(filledAmount).toFixed(decimalpoints);

                      if(buy_userId==user_id)
                      {
                        var type1="Buy";
                        var askPrice=transactionhistory[count].buyaskPrice;
                        askPrice=parseFloat(askPrice).toFixed(decimalpoints);
                        var sellaskPrice=transactionhistory[count].sellaskPrice;
                        sellaskPrice=parseFloat(sellaskPrice).toFixed(decimalpoints);
                        var orderTime1=transactionhistory[count].buyertime;
                        var orderTime2=transactionhistory[count].sellertime;
                        var buyerfee = transactionhistory[count].buyerfee;
                        var sellerfee = transactionhistory[count].sellerfee;
                        var buyertotal = transactionhistory[count].buyertotal;
                        var sellertotal = transactionhistory[count].sellertotal;
                        var time1 = orderTime1;
                         historys=historys+'<tr><td class="text-green">'+parseFloat(askPrice).toFixed(6)+'</td><td>'+parseFloat(filledAmount).toFixed(3)+'</td><td>'+time1+'</td></tr>';
                        
                      }
                      else if(sell_userId==user_id)
                      {
                        var type1="Sell";
                        var askPrice=transactionhistory[count].sellaskPrice;
                        askPrice=parseFloat(askPrice).toFixed(decimalpoints);
                        var sellaskPrice=transactionhistory[count].buyaskPrice;
                        sellaskPrice=parseFloat(sellaskPrice).toFixed(decimalpoints);
                        var orderTime1=transactionhistory[count].buyertime;
                        var orderTime2=transactionhistory[count].sellertime;
                        var buyerfee = transactionhistory[count].buyerfee;
                        var sellerfee = transactionhistory[count].sellerfee;
                        var buyertotal = transactionhistory[count].buyertotal;
                        var sellertotal = transactionhistory[count].sellertotal;
                        var time2 = orderTime2;

                        historys=historys+'<tr><td class="text-red">'+parseFloat(askPrice).toFixed(6)+'</td><td>'+parseFloat(filledAmount).toFixed(3)+'</td><td>'+time2+'</td></tr>';
        
                      }                    
                  }
                }
                $('.transactionhistory').html(historys);
              }
              else 
              {              
                $('.transactionhistory').html('<tr><td colspan="7">No Trade History Found</td></tr>');
              }          

              var orders1=[];          
              if(orders1.length!=0||sellResult.length>0)
              {
                  var sellres_length=sellResult.length;
                  var order_table='';
                  for(count = 0; count < sellres_length; count++)
                  {
                    var activefilledAmount=sellResult[count].totalamount;
                    var activePrice=sellResult[count].Price;
                    var Fee=sellResult[count].Fee;
                    activePrice=(parseFloat(activePrice)).toFixed(decimal);
                    var activeAmount  = sellResult[count].Amount;
                    if(activefilledAmount)
                    {
                      activefilledAmount = activeAmount-activefilledAmount;
                    }
                    else
                    {
                      activefilledAmount = activeAmount;
                    }
                    activefilledAmount=(parseFloat(activefilledAmount)).toFixed(decimalpoints);

                    var activeCalcTotal = parseFloat(activefilledAmount*activePrice) + parseFloat(Fee);
                       activeCalcTotal=(parseFloat(activeCalcTotal)).toFixed(decimalpoints);
                    
                    var click="return cancel_order('"+sellResult[count].trade_id+"')";
                    var type="'buy'";
                    order_table+='<tr onclick="placeorder('+type+','+parseFloat(activePrice).toFixed(decimalpoints)+','+parseFloat(activefilledAmount).toFixed(decimalpoints)+')"><td class="text-green">'+parseFloat(activePrice).toFixed(decimal)+'</td><td>'+parseFloat(activefilledAmount).toFixed(3)+'</td><td>'+parseFloat(activeCalcTotal).toFixed(8)+'</td></tr>';

                   }
              }
              else
              {
                var order_table='';
                if(api_sellResult.length>0)
                {
                  for(var counts=0; counts < api_sellResult.length; counts++)
                  {
                    var type="'buy'";
                    var width1 ="";
                    order_table+='<tr onclick="placeorder('+type+','+parseFloat(api_sellResult[counts]['price'])+','+parseFloat(api_sellResult[counts]['quantity'])+')"><td class="text-green">'+parseFloat(api_sellResult[counts]['price']).toFixed(decimal)+'</td><td>'+parseFloat(api_sellResult[counts]['quantity']).toFixed(3)+'</td><td>'+(parseFloat(api_buyResult[counts]['quantity'])*parseFloat(api_sellResult[counts]['price']).toFixed(decimal)).toFixed(8)+'</td></tr>';

                  }
                }
              }
              $('.sell_order').html(order_table);
              var orders=[];
              if(orders.length!=0||buyResult.length>0)
              {
                  var buyres_length=buyResult.length;
                  var order_table1='';
                  for(count = 0; count < buyres_length; count++)
                  {
                    var activefilledAmount=buyResult[count].totalamount;
                    var activePrice=buyResult[count].Price;
                    var Fee=buyResult[count].Fee;
                    activePrice=(parseFloat(activePrice)).toFixed(decimal);
                    var activeAmount  = buyResult[count].Amount;
                    if(activefilledAmount)
                    {
                      activefilledAmount = activeAmount-activefilledAmount;
                    }
                    else
                    {
                      activefilledAmount = activeAmount;
                    }
                    activefilledAmount=(parseFloat(activefilledAmount)).toFixed(decimalpoints);

                    var activeCalcTotal = parseFloat(activefilledAmount*activePrice) + parseFloat(Fee);
                       activeCalcTotal=(parseFloat(activeCalcTotal)).toFixed(decimalpoints);
                    
                    var click="return cancel_order('"+buyResult[count].trade_id+"')";
                    var type="'sell'";
                    
                    order_table1+='<tr onclick="placeorder('+type+','+parseFloat(activePrice).toFixed(decimalpoints)+','+parseFloat(activefilledAmount).toFixed(decimalpoints)+')"><td class="text-red">'+parseFloat(activePrice).toFixed(decimal)+'</td><td>'+parseFloat(activefilledAmount).toFixed(3)+'</td><td>'+parseFloat(activeCalcTotal).toFixed(8)+'</td></tr>';

                  }
              }
              else
              { 
                var order_table1 ='';
                if(api_buyResult.length>0)
                {
                 
                  for(var count = 0; count < api_buyResult.length; count++)
                  {
                    
                    var type="'sell'";

                    var buy_totl = (parseFloat(api_buyResult[count]['quantity'])*parseFloat(api_buyResult[count]['price'])).toFixed(8)
                    var width = "";
                      //alert(buy_totl);
                     order_table1+='<tr onclick="placeorder('+type+','+parseFloat(api_buyResult[count]['price'])+','+parseFloat(api_buyResult[count]['quantity'])+')"><td class="text-red">'+parseFloat(api_buyResult[count]['price']).toFixed(decimal)+'</td><td>'+parseFloat(api_buyResult[count]['quantity']).toFixed(3)+'</td><td>'+(parseFloat(api_buyResult[count]['quantity'])*parseFloat(api_buyResult[count]['price']).toFixed(decimal)).toFixed(8)+'</td></tr>';

                    
                    } 
                }
              }          
              $('.buy_order').html(order_table1);    

              var open_orders=designs.open_orders;
              var cancel_orders=designs.cancel_orders;
              var limit_orders = designs.open_orders_limit;
              var market_orders = designs.open_orders_market;
              var stop_orders=designs.open_orders_stop;
              var decimalpoints = 8;

              if(open_orders!=0&&open_orders.length>0)
              {
                  var open_length=open_orders.length;
                  var open_orders_text='';
                  for(count = 0; count < open_length; count++)
                  {
                    var activefilledAmount=open_orders[count].totalamount;
                    var activePrice=open_orders[count].Price;
                    var Fee=parseFloat(open_orders[count].Fee).toFixed(decimalpoints);
                    activePrice=(parseFloat(activePrice)).toFixed(decimalpoints);
                    var activeAmount  = open_orders[count].Amount;
                    if(activefilledAmount)
                    {
                      activefilledAmount = activeAmount-activefilledAmount;
                    }
                    else
                    {
                      activefilledAmount = activeAmount;
                    }
                    activefilledAmount=(parseFloat(activefilledAmount)).toFixed(decimalpoints);
                    

                    var click="return cancel_order('"+open_orders[count].trade_id+"')";
                    var odr_type = open_orders[count].Type;
                    var odr_status = open_orders[count].status;
                    //alert(odr_type);
                    var odr_color = '';
                    if(odr_type=='buy')
                    {
                      odr_color = 'text-green';
                      var activeCalcTotal = parseFloat(activefilledAmount*activePrice) + parseFloat(Fee);
                       activeCalcTotal=(parseFloat(activeCalcTotal)).toFixed(decimalpoints);
                    }
                    else
                    {
                      odr_color = 'text-red';
                      var activeCalcTotal = parseFloat(activefilledAmount*activePrice) - parseFloat(Fee);
                     activeCalcTotal=(parseFloat(activeCalcTotal)).toFixed(decimalpoints);
                    }
                    if(odr_status=="partially")
                    {
                      var style_st = "display:none";
                    }
                    else
                    {
                      var style_st = "display:block";
                    }
                    var time = open_orders[count].trade_time;
                    var click="return cancel_order('"+open_orders[count].trade_id+"')";
                    var pair_symbol = open_orders[count].pair_symbol;                
                    var ordtypes = open_orders[count].ordertype;
                    if(ordtypes == 'limit') var ordtype = 'Limit';
                    else if(ordtypes == 'stop') var ordtype = 'Stop Order';
                    else if(ordtypes == 'instant') var ordtype = 'Market';
                    else var ordtype = '-';

                    if(pair_active==pair_symbol) var myclass = 'currentpair';
                    else var myclass = 'differpair';
                    
                     open_orders_text=open_orders_text+'<tr class="'+myclass+'"><td>'+time+'</td><td>'+pair_symbol+'</td><td class='+odr_color+'>'+open_orders[count].Type+'</td><td>'+ordtype+'</td><td>'+activePrice+'</td><td>'+activefilledAmount+'</td><td>'+activeCalcTotal+'</td><td><a class="text-red" href="javascript:void(0);" style="'+style_st+'"><i class="fa fa-times" onclick="'+click+'"></i></a></td></tr>';

                  }
                  $('.open_orders').html(open_orders_text);
              }
              else
              {             
                 $('.open_orders').html('tr><td colspan="7">No Active Orders Found</td></tr>');             
              }
              if(limit_orders!=0&&limit_orders.length>0)
              {
                  var limit_length=limit_orders.length;
                  var limit_orders_text='';
                  for(count = 0; count < limit_length; count++)
                  {
                    var activefilledAmount=limit_orders[count].totalamount;
                    var activePrice=limit_orders[count].Price;
                    var Fee=parseFloat(limit_orders[count].Fee).toFixed(decimalpoints);
                    activePrice=(parseFloat(activePrice)).toFixed(decimalpoints);
                    var activeAmount  = limit_orders[count].Amount;
                    if(activefilledAmount)
                    {
                      activefilledAmount = activeAmount-activefilledAmount;
                    }
                    else
                    {
                      activefilledAmount = activeAmount;
                    }
                    activefilledAmount=(parseFloat(activefilledAmount)).toFixed(decimalpoints);
                    

                    var click="return cancel_order('"+limit_orders[count].trade_id+"')";
                    var odr_type = limit_orders[count].Type;
                    var odr_status = limit_orders[count].status;
                    //alert(odr_type);
                    var odr_color = '';
                    if(odr_type=='buy')
                    {
                      odr_color = 'text-green';
                      var activeCalcTotal = parseFloat(activefilledAmount*activePrice) + parseFloat(Fee);
                       activeCalcTotal=(parseFloat(activeCalcTotal)).toFixed(decimalpoints);
                    }
                    else
                    {
                      odr_color = 'text-red';
                      var activeCalcTotal = parseFloat(activefilledAmount*activePrice) - parseFloat(Fee);
                     activeCalcTotal=(parseFloat(activeCalcTotal)).toFixed(decimalpoints);
                    }
                    if(odr_status=="partially")
                    {
                      var style_st = "display:none";
                    }
                    else
                    {
                      var style_st = "display:block";
                    }
                    var time = limit_orders[count].trade_time;
                    var click="return cancel_order('"+limit_orders[count].trade_id+"')";
                    var pair_symbol = limit_orders[count].pair_symbol;                
                    var ordtypes = limit_orders[count].ordertype;
                    if(ordtypes == 'limit') var ordtype = 'Limit';
                    else if(ordtypes == 'stop') var ordtype = 'Stop Order';
                    else if(ordtypes == 'instant') var ordtype = 'Market';
                    else var ordtype = '-';

                    if(pair_active==pair_symbol) var myclass = 'currentpair';
                    else var myclass = 'differpair';
                    
                     limit_orders_text=limit_orders_text+'<tr class="'+myclass+'"><td>'+time+'</td><td>'+pair_symbol+'</td><td class='+odr_color+'>'+open_orders[count].Type+'</td><td>'+ordtype+'</td><td>'+activePrice+'</td><td>'+activefilledAmount+'</td><td>'+activeCalcTotal+'</td><td><a class="text-red" href="javascript:void(0);" style="'+style_st+'"><i class="fa fa-times" onclick="'+click+'"></i></a></td></tr>';

                  }
                  $('.limit_orders').html(limit_orders_text);
              }
              else
              {             
                 $('.limit_orders').html('tr><td colspan="7">No Limit Orders Found</td></tr>');             
              }
              if(market_orders!=0&&market_orders.length>0)
              {
                  var market_length=market_orders.length;
                  var market_orders_text='';
                  for(count = 0; count < market_length; count++)
                  {
                    var activefilledAmount=market_orders[count].totalamount;
                    var activePrice=market_orders[count].Price;
                    var Fee=parseFloat(market_orders[count].Fee).toFixed(decimalpoints);
                    activePrice=(parseFloat(activePrice)).toFixed(decimalpoints);
                    var activeAmount  = market_orders[count].Amount;
                    if(activefilledAmount)
                    {
                      activefilledAmount = activeAmount-activefilledAmount;
                    }
                    else
                    {
                      activefilledAmount = activeAmount;
                    }
                    activefilledAmount=(parseFloat(activefilledAmount)).toFixed(decimalpoints);
                    

                    var click="return cancel_order('"+market_orders[count].trade_id+"')";
                    var odr_type = market_orders[count].Type;
                    var odr_status = market_orders[count].status;
                    //alert(odr_type);
                    var odr_color = '';
                    if(odr_type=='buy')
                    {
                      odr_color = 'text-green';
                      var activeCalcTotal = parseFloat(activefilledAmount*activePrice) + parseFloat(Fee);
                       activeCalcTotal=(parseFloat(activeCalcTotal)).toFixed(decimalpoints);
                    }
                    else
                    {
                      odr_color = 'text-red';
                      var activeCalcTotal = parseFloat(activefilledAmount*activePrice) - parseFloat(Fee);
                     activeCalcTotal=(parseFloat(activeCalcTotal)).toFixed(decimalpoints);
                    }
                    if(odr_status=="partially")
                    {
                      var style_st = "display:none";
                    }
                    else
                    {
                      var style_st = "display:block";
                    }
                    var time = market_orders[count].trade_time;
                    var click="return cancel_order('"+market_orders[count].trade_id+"')";
                    var pair_symbol = market_orders[count].pair_symbol;                
                    var ordtypes = market_orders[count].ordertype;
                    if(ordtypes == 'limit') var ordtype = 'Limit';
                    else if(ordtypes == 'stop') var ordtype = 'Stop Order';
                    else if(ordtypes == 'instant') var ordtype = 'Market';
                    else var ordtype = '-';

                    if(pair_active==pair_symbol) var myclass = 'currentpair';
                    else var myclass = 'differpair';
                    
                     market_orders_text=market_orders_text+'<tr class="'+myclass+'"><td>'+time+'</td><td>'+pair_symbol+'</td><td class='+odr_color+'>'+open_orders[count].Type+'</td><td>'+ordtype+'</td><td>'+activePrice+'</td><td>'+activefilledAmount+'</td><td>'+activeCalcTotal+'</td><td><a class="text-red" href="javascript:void(0);" style="'+style_st+'"><i class="fa fa-times" onclick="'+click+'"></i></a></td></tr>';

                  }
                  $('.market_orders').html(market_orders_text);
              }
              else
              {             
                 $('.market_orders').html('tr><td colspan="7">No Market Orders Found</td></tr>');             
              }
              if(cancel_orders!=0&&cancel_orders.length>0)
              {
                  var cancel_length=cancel_orders.length;
                  var cancel_orders_text='';
                  for(count = 0; count < cancel_length; count++)
                  {
                    var activePrice=cancel_orders[count].Price;
                    var Fee=(parseFloat(cancel_orders[count].Fee)).toFixed(decimalpoints);
                    activePrice=(parseFloat(activePrice)).toFixed(decimalpoints);
                    var activeAmount  = cancel_orders[count].Amount;
                    var activefilledAmount=cancel_orders[count].totalamount;
                    if(activefilledAmount)
                    {
                      activefilledAmount = activeAmount-activefilledAmount;
                    }
                    else
                    {
                      activefilledAmount = activeAmount;
                    }
                    activefilledAmount=(parseFloat(activefilledAmount)).toFixed(decimalpoints);
                    var activeCalcTotal = parseFloat(activefilledAmount*activePrice) + parseFloat(Fee);
                    activeCalcTotal=(parseFloat(activeCalcTotal)).toFixed(decimalpoints);

                    cancel_orders_text=cancel_orders_text+'<tr><td>'+cancel_orders[count].Type+'</td><td>'+cancel_orders[count].tradetime+'</td><td>'+activefilledAmount+'</td><td>'+activePrice+'</td><td>'+Fee+'</td><td>'+activeCalcTotal+'</td><td><?php echo $this->lang->line("Cancelled");?></td></tr>';
                  }
                  $('.cancel_orders tbody .mCustomScrollBox .mCSB_container').html(cancel_orders_text);
              }
              else
              {            
                 $('.cancel_orders tbody .mCustomScrollBox .mCSB_container').html('<tr id="nocancelorder"><td colspan="6" class="text-center"><?php echo $this->lang->line("No cancel orders available");?>!</td></tr>');
              }
              if(stop_orders!=0&&stop_orders.length>0)
              {
                  var stop_length=stop_orders.length;
                  var stop_orders_text='';
                  for(count = 0; count < stop_length; count++)
                  {
                    var activePrice=stop_orders[count].Price;
                    var Fee=parseFloat(stop_orders[count].Fee).toFixed(decimalpoints);
                    activePrice=(parseFloat(activePrice)).toFixed(decimalpoints);
                    var activeAmount  = stop_orders[count].Amount;
                    var activefilledAmount=activeAmount;
                    activefilledAmount=(parseFloat(activefilledAmount)).toFixed(decimalpoints);
                    var click="return cancel_order('"+stop_orders[count].trade_id+"')";

                    var sodr_type = stop_orders[count].Type;
                    var sodr_color = '';
                    if(sodr_type=='buy')
                    {
                      sodr_color = 'text-green';
                      var activeCalcTotal = parseFloat(activefilledAmount*activePrice) + parseFloat(Fee);
                       activeCalcTotal=(parseFloat(activeCalcTotal)).toFixed(decimalpoints);
                    }
                    else
                    {
                      sodr_color = 'text-red';
                      var activeCalcTotal = parseFloat(activefilledAmount*activePrice) - parseFloat(Fee);
                     activeCalcTotal=(parseFloat(activeCalcTotal)).toFixed(decimalpoints);
                    }
                    var stp_time = stop_orders[count].tradetime;

                    stop_orders_text=stop_orders_text+'<tr><td class='+sodr_color+'>'+stop_orders[count].Type+'</td><td>'+stp_time+'</td><td>'+activefilledAmount+'</td><td>'+activePrice+'</td><td>'+parseFloat(Fee).toFixed(4)+'</td><td>'+activeCalcTotal+'</td><td><a class="a_tag" href="javascript:void(0);" onclick="'+click+'">Cancel</a></td></tr>';
                  }
                  $('.stop_orders').html(stop_orders_text);
              }
              else
              {
                $('.stop_orders').html('<tr"><td colspan="7">No stop limit orders found!</td></tr>');
              }

                $('#buy_order_table_1').DataTable({
                  "scrollY": 300,
                  "scrollX": true,
                  "paging": false,
                  "info": false,
                  "searching": false,
                  "language": {
                      "decimal": ",",
                      "thousands": "."
                  },
                  "destroy": true
                });
                $('#sell_order_table_1').DataTable({
                    "scrollY": 300,
                    "scrollX": true,
                    "paging": false,
                    "info": false,
                    "searching": false,
                    "language": {
                        "decimal": ",",
                        "thousands": "."
                    },
                    "destroy": true
                });
                $('#buy_order_table_2').DataTable({
                    "scrollY": 625,
                    "scrollX": true,
                    "paging": false,
                    "info": false,
                    "searching": false,
                    "language": {
                        "decimal": ",",
                        "thousands": "."
                    },
                    "destroy": true
                });
                $('#sell_order_table_2').DataTable({
                    "scrollY": 625,
                    "scrollX": true,
                    "paging": false,
                    "info": false,
                    "searching": false,
                    "language": {
                        "decimal": ",",
                        "thousands": "."
                    },
                    "destroy": true
                });
                /*$('#open_order').DataTable({
                  "scrollY": 200,
                  "scrollX": true,
                  "paging": false,
                  "info": false,
                  "searching": false,
                  "language": {
                      "decimal": ",",
                      "thousands": "."
                  },
                  "destroy": true
                });*/
                $('#trade_history').DataTable({
                  "scrollY": 280,
                  "scrollX": true,
                  "paging": false,
                  "info": false,
                  "searching": false,
                  "language": {
                      "decimal": ",",
                      "thousands": "."
                  },
                  "destroy": true
                });
          }
          else if(designs.web_trade == "2" && designs.web_trade != '')
          {

              var reslts = res.replace(/(\r\n|\n|\r)/gm,"");
              var res1 = JSON.parse(reslts);
              if(res1.result==1)
              {
                  cancelsuccess();
                  if(res1.type=='buy')
                  {
                      var balamount_buy=parseFloat((res1.second_balance)).toFixed(8);
                      $('#cls_'+res1.to_symbol).html(balamount_buy);
                      $('#buy_bal').text(balamount_buy);
                      $("#buy_bals").text(balamount_buy);
                      $("#buy_balss").text(balamount_buy); 
                  }
                  else
                  {
                      var balamount_sell=parseFloat((res1.first_balance)).toFixed(8);
                      $('#cls_'+res1.from_symbol).html(balamount_sell);
                      $('#sell_bal').text(balamount_sell);
                      $("#sell_bals").text(balamount_sell);
                      $("#sell_balss").text(balamount_sell);
                  }
              }
              else
              {
                  cancelerror();
              } 
          }
          else 
          {
              var reslts = res.replace(/(\r\n|\n|\r)/gm,"");
              var res1 = JSON.parse(reslts);
              var a = res1.type;
              if(res1.status == "balance")
              { 
                $('#alert_err_'+a).show();
                $('#error_msg_'+a).html('Insufficient balance');
                return false;
              }
              else if(res1.status == "minimum_amount")
              { 
                $('#alert_err_'+a).show();
                $('#error_msg_'+a).html("Minimum trade amount is "+ parseFloat(minimum_trade_amount));
                setTimeout(function(){
                    $('#alert_err_'+a).hide();
                }, 3000);
                return false;
              }
              else if(res1.status == "login")
              { 
                location.reload();
                $('#alert_err_'+a).show();
                $('#error_msg_'+a).html('Login to your account');
                setTimeout(function(){
                    $('#alert_err_'+a).hide();
                }, 3000);
              }
              else if(res1.status == "success")
              {                 
                  $('#alert_succ_'+a).show();
                  $('#success_msg_'+a).html('Your order has been placed');
                  setTimeout(function(){
                  $('#alert_succ_'+a).hide();
                  }, 3000);
              }
              else
              {
                $('#alert_err_'+a).show();
                $('#error_msg_'+a).html(res);
                 setTimeout(function(){
                $('#alert_err_'+a).hide();
                }, 3000);
              }
              $("#"+a+"_amount").val('');
              $("#"+a+"_price").val('');
              $("#"+a+"_tot").val('');
              $("#"+a+"_fee_tot").val('');
          }
      }
      ws.onerror = function(event){
        var Data = JSON.parse(event);
        //console.log("MANIMEGS => "+Data);
        $("#htmlerror").show(); 
        $("#htmlerror").html(Data.status); 
      };
      ws.onclose = function(event){
           $("#loader").hide();
      };      
      setInterval(function () {
        var decimal_sel = $(".select_decimal").val();
             load_design(decimal_sel);
          },3000);

     
</script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8.17.1/dist/sweetalert2.all.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@8.17.1/dist/sweetalert2.min.css">
 <script>
  function checking() {
 Swal.fire({
    html: '<h2>Please Login or Register</h2>',
    timer: 3000,
  });
}
function cancelsuccess()
{
  Swal.fire({
    html: '<h2>Order Cancelled Successfully</h2>',
    timer: 3000,
  });
}

function cancelerror()
{
  Swal.fire({
    html: '<h2>Error occured while cancel order</h2>',
    timer: 3000,
  });
}
$(".select_open_order").on('change',function(){
        var select_value = $(this).val(); 
        if(select_value == 'cancell_all')
        {
            Swal.fire({
            title: 'Are you sure to delete all?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                deleteall();
                return false;   
            })
        }
        else 
        {
            $(".dis_orders").hide();
            var title = select_value.replace("_"," ");
            $(".dis_title").html(title);
            $("."+select_value).show();
        }
      });

    $(".hides_pairs").on('click',function(){
        if($("input[type=checkbox]").is(":checked"))
        {    
            $(".differpair").hide();         
            $(".currentpair").show();
        }
        else
        {
           $(".differpair").show();         
           $(".currentpair").show(); 
        }
    });

    function deleteall()
    {
         $.ajax({
                url: base_url+'close_allactive_order',
                type: 'POST', 
                success: function(data)
                {
                    var res = jQuery.parseJSON(data);
                    if(res.result==1)
                    {   
                        $('.cancel_err_msg').hide();
                        $('.cancel_succ_msg').show();                         
                        setTimeout(function(){
                          $('.cancel_succ_msg').hide();
                         }, 3000);
                         if(res.type=='buy')
                          {
                              var balamount_buy=parseFloat((res.second_balance)).toFixed(8);
                              $('#cls_'+res.to_symbol).html(balamount_buy);
                          }
                          else
                          {
                              var balamount_sell=parseFloat((res.first_balance)).toFixed(8);
                              $('#cls_'+res.from_symbol).html(balamount_sell);
                          }      
                    }
                    else
                    {
                        $('.cancel_succ_msg').hide();
                        $('.cancel_err_msg').show(); 
                          setTimeout(function(){
                              $('.cancel_err_msg').hide();
                        }, 3000);
                    }
                }
            });
    }
</script>


</html>