<!-- JavaScript Libraries -->
<script src="<?=front_js()?>lib/jquery/jquery.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?=front_js()?>lib/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?=front_js()?>lib/easing/easing.min.js"></script>
<script src="<?=front_js()?>lib/wow/wow.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<script src="https://unpkg.com/splitting/dist/splitting.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/2.1.3/TweenMax.min.js"></script>
<!-- Template Main Javascript File -->
<script src="<?=front_js()?>/main.js"></script>
<!-- <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script> -->
<script src="<?=front_js()?>popper.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?=front_js()?>bootstrap.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<!-- <script src="<?=front_js()?>owl.carousel.min.js?v=<?php echo date('Ymdhis'); ?>"></script> -->
<script src="<?=front_js()?>aos.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?=front_js()?>jquery.validate.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script type="text/javascript" src="<?=front_js()?>dataTables.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script type="text/javascript" src="<?=front_js()?>datatables.bootstrap4.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?=front_js()?>bootstrap-dropdownhover.min.js"></script>
<!-- Template Main Javascript File -->
<script type="text/javascript" src="<?=front_js()?>dataTables.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script type="text/javascript" src="<?=front_js()?>datatables.bootstrap4.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script type="text/javascript">
    $(document).ready(function() 
    {
        var oTable = $('#example').DataTable(
        {
            "paging": false,
            "ordering": false,
            "info": false,
            "bSort": false,
            //"searching": false
        });
        $('#example-search-input').keyup(function(){
            oTable.search($(this).val()).draw() ;
        });
    });
</script>
<script>
    AOS.init();
</script>
<script type="text/javascript">        
    $(".lang_switch").on('change',function(){
        var selct_lang = $(this).val(); 
        window.location.href="<?php echo base_url()?>switchLang/"+selct_lang;
    });
</script>
<script src="<?=front_js()?>toastr.min.js?v=<?php echo date('Ymdhis'); ?>"></script> 
<script type="text/javascript">
    var base_url    = '<?php echo base_url();?>';
    var front_url   = '<?php echo front_url();?>';
    var user_id     = '<?php echo $user_id;?>';
    var ip_address  = '<?php echo $ip_address;?>';
    var get_os      = '<?php echo $get_os;?>';
    var csrfName    = '<?php echo $this->security->get_csrf_token_name(); ?>';
    $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
        if (options.type.toLowerCase() == 'post') {
            options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
            if (options.data.charAt(0) == '&') {
                options.data = options.data.substr(1);
            }
        }
    });
    $( document ).ajaxComplete(function( event, xhr, settings ) {
        if (settings.type.toLowerCase() == 'post') {
            $.ajax({
                url: front_url+"get_csrf_token", 
                type: "GET",
                cache: false,             
                processData: false,      
                success: function(data) {
                  var dataaa = $.trim(data);
                     $("input[name="+csrfName+"]").val(dataaa);
                }
            });
        }
    });

    /*$(document).ready(function(){
      $.ajax({
              url: base_url+"get_pair_home", 
              type: "POST", 
              csrf_token : csrfName,            
              data: "page='home'",     
              success: function(data) 
              {
                console.log(data);
              }
          });
    });*/
</script>
<script>
    toastr.options = { "closeButton": true, "timeOut": "34000", }
</script> 
<?php 
    if($this->session->flashdata('success')!= '')
    { 
?>   
        <script> toastr.success("<?php echo $this->session->flashdata('success');?>"); </script>
<?php
    } 
    if($this->session->flashdata('fiatsuccess')!= '')
    { 
?>   
                <script> toastr.success("<?php echo $this->session->flashdata('fiatsuccess');?>"); </script>
<?php 
    } 
    if($this->session->flashdata('info')!= '')
    { 
?>   
                <script> toastr.info("<?php echo $this->session->flashdata('info');?>"); </script>
<?php 
    } 
    if($this->session->flashdata('warning')!= '')
    { 
?>   
            <script> toastr.warning("<?php echo $this->session->flashdata('warning');?>"); </script>
<?php 
    } 
    if($this->session->flashdata('error')!= '')
    { 
?>   
        <script> toastr.error("<?php echo $this->session->flashdata('error');?>"); </script>
<?php
    }  
    if($this->session->flashdata('fiaterror')!= '')
    { 
?>   
            <script> toastr.error("<?php echo $this->session->flashdata('fiaterror');?>"); </script>
<?php 
    } 
?>
<script type="text/javascript">
    $(document).ready(function(e){
        $(document).on('click','#eye', function(e){
            if($("#register_password").attr('type') == "password")
            {
                $("#register_password").attr('type', 'text');
                $(this).removeClass('class="fa fa-eye-slash');
                $(this).addClass('class="fa fa-eye');
            }
            else
            {
                $("#register_password").attr('type', 'password');
                $(this).removeClass('class="fa fa-eye');
                $(this).addClass('class="fa fa-eye-slash');
            }
        });
        $(document).on('click','#eye1', function(e){
            if($("#register_cpassword").attr('type') == "password")
            {
                $("#register_cpassword").attr('type', 'text');
                $(this).removeClass('class="fa fa-eye-slash');
                $(this).addClass('class="fa fa-eye');
            }
            else
            {
                $("#register_cpassword").attr('type', 'password');
                $(this).removeClass('class="fa fa-eye');
                $(this).addClass('class="fa fa-eye-slash');
            }
        });
        $.validator.addMethod('ZipChecker', function() 
        {}, 'Invalid zip code');
        $.validator.addMethod("lettersonly", function(value) {
            return (/^[a-zA-Z\s]*$/.test(value));
        });

        $('#register_user').validate(
        {
            rules: {
                register_email: {
                    required: true,
                    email: true,
                remote: {
                        url: front_url+'email_exist',
                        type: "post",
                        csrf_token : csrfName,
                        data: {
                            email: function() {
                                return $( "#register_email" ).val();
                            }
                        }
                    }
                },
                register_uname: {
                    required: true,
                    minlength:2,
                    maxlength:25,
                    remote: {
                        url: front_url+'username_exist',
                        type: "post",
                        csrf_token : csrfName,
                        data: {
                            username: function() {
                            return $( "#register_uname" ).val();
                            }
                        }
                    }
                },
                register_password: {
                    required: true,
                    minlength: 8
                },
                register_cpassword: {
                    required: true,
                    equalTo : "#register_password"
                },
                terms: {
                    required:true
                }
            },
            messages: {

                register_uname: {
                    required:"Please enter username",
                    minlength:"Please enter minimum 2 Characters",
                    maxlength:"Please enter not more than 25 Characters",
                    remote: "Entered username already exists"
                },
                register_email: {
                    required:"Please enter email address",
                    email: "Please enter valid email address",
                    remote: "Entered email address already exists"
                },
                register_password: {
                    required: "Please enter password",
                    minlength: "Minimum 8 characters, including UPPER / lower case with numbers & special characters"
                },
                register_cpassword: {
                    required: "Please enter confirm password",
                    equalTo : "Please enter same password"
                },
                terms: {
                    required:"Please select terms & conditions"
                }
            },
            invalidHandler: function(form, validator) {
                if(!validator.numberOfInvalids())
                {
                    return;
                }
                else
                {
                    var error_element=validator.errorList[0].element;
                    error_element.focus();
                }
            },
            highlight: function (element) {
                //$(element).parent().addClass('error')
            },
            unhighlight: function (element) {
              $(element).parent().removeClass('error')
            },
            submitHandler: function(form) 
            {
                if($("#terms").prop('checked') != true)
                {
                    $("#terms_error").html("Please select terms & conditions");
                    return false;
                }
                else
                {
                          var $form = $(form);
                          //alert("ddd")
                          form.submit();
                }
            }
        });
    });

    $(".myclicks").on('click',function(){
        if($(".myclicks").prop('checked') == true)
        {
            $(".hiderow").hide();
            $(".showrow").show();
        }
        else
        {
            $(".hiderow").show();
            $(".showrow").show();
        }
    })
    
          
    $('#verification_form').validate({
        rules: {
            firstname: {
              required: true
            },
            lastname: {
              required: true
            },
            address: {
              required: true
            },
            city: {
              required: true,
              lettersonly: true
            },
            state: {
              required: true,
              lettersonly: true
            },
            postal_code: {
                required: true,
                number: true,
                maxlength: 7,
                ZipChecker: function(element) {
                    values=$("#postal_code").val();
                    if( values =="0" || values =="00" || values =="000" || values =="0000" || values =="00000"  || values =="000000"   || values =="0000000" )
                    {
                        return true;
                    }
                }
            },
            phone: {
              required: true
            }
        },
        messages: {
            firstname: {
              required: "<?php echo $this->lang->line('Please enter first name')?>"
            },
            lastname: {
              required: "<?php echo $this->lang->line('Please enter last name')?>"
            },
            address: {
              required: "<?php echo $this->lang->line('Please enter address')?>"
            },
            city: {
              required: "<?php echo $this->lang->line('Please enter city')?>",
              lettersonly: "<?php echo $this->lang->line('Please enter letters only')?>"
            },
            state: {
              required: "<?php echo $this->lang->line('Please enter state')?>",
              lettersonly: "<?php echo $this->lang->line('Please enter letters only')?>"
            },
            postal_code: {
              required: "<?php echo $this->lang->line('Please enter postal code')?>"
            },
            phone: {
              required: "<?php echo $this->lang->line('Please enter phone number')?>"
            }
        }
    });

    $('#change_password').validate({
        rules: {
            oldpass: {
              required: true,
              remote: {
                    url: front_url+'oldpassword_exist',
                    type: "post",
                    csrf_token : csrfName,
                    data: {
                        oldpass: function() {
                        return $( "#oldpass" ).val();
                        }
                    }
                }
            },
           newpass: {
              required: true
            },
            confirmpass: {
              required: true,
              equalTo : "#newpass"
            },
        },
        messages: {
            oldpass: {
              required: "<?php echo $this->lang->line('Please enter Old Password')?>",
               remote: "<?php echo $this->lang->line('Invalid Old Password')?>"
            },
            newpass: {
              required: "<?php echo $this->lang->line('Please enter New Password')?>"
            },
            confirmpass: {
              required: "<?php echo $this->lang->line('Please enter Confirm Password')?>",
              equalTo : "<?php echo $this->lang->line('Confirm Password not matches with New Password')?>"
            },
        }
    });
    $('#security').validate({
        rules: {
            code: {
                required: true,
                number: true,
                minlength: 6,
            }
        },
        messages: {
            code: {
                required: '<span style="color:red"><?php echo $this->lang->line('Please enter  code')?></span>',
                number: '<span style="color:red"><?php echo $this->lang->line('Please enter valid code')?></span>',
                minlength:'<span style="color:red"><?php echo $this->lang->line('Please 6 digit valid code')?></span>',
            },
        }
    });
    $('#instant').validate({
        rules: {

            send_amount: {
                required: true

            },
            received_currency: {
                required: true,
            }
        },
        messages: {
            send_amount: {
                required: 'Enter is Amount'
            },
            received_currency: {
                required: 'Currency is required',
               
            }
        },
        submitHandler: function(form) {
            form.submit();
        }
    });
 </script>