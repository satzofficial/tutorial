<?php 
    $sitelan = $this->session->userdata('site_lang'); 
    $this->load->view('front/common/header'); 
    $user_id=$this->session->userdata('user_id');

    $name = $sitelan."_name";
    $heading = $sitelan."_heading";
    $content = $sitelan."_content";
?>
    <!-- <section class="hero-sec">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6">
                    <div class="hero-content">
                        <h1><?=$about_content->$name?></h1>
                        <?=$about_content->$content?>
                        <?php if(empty($user_id))
                              { ?>    
                        <a href="<?=base_url()?>signup" class="main-btn-reg">Register</a>
                        <?php } else { ?>
                            <a href="<?=base_url()?>dashboard" class="main-btn-reg">Register</a>
                        <?php } ?>
                    </div>
                    <?php if(count($news)>0) { ?>
                    <div class="hero-carousel">
                        <div class="owl-carousel">
                        <?php foreach($news as $row){ ?>
                            <div>
                                <div class="hero-carousel-box">
                                    <h3><?=$row->$heading?></h3>
                                    <p><?=$row->$content?></p>
                                    <a href="<?=$row->link?>"><?=$row->link_text?> <span><i class="fas fa-arrow-right"></i></span> </a>
                                </div>
                            </div>
                        <?php } ?>
                        </div>
                    </div>
                    <?php } ?>
                </div>
                <div class="col-lg-6">
                    <div class="hero-img">
                        <img src="<?=front_img();?>hero-img.png" class="img-fluid" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section> -->
     <section id="hero">
        <div class="container hero-container">
            <div class="row">
                <div class="col-md-10 m-auto">
                    <h1><?=$home_content->$name?></h1>
                    <h5><?=$home_content->$content?></h5>                    
                    <?php 
                        if(empty($user_id))
                        { 
                    ?>    
                            <a class="banner_btn btn" href="<?=base_url()?>signup">Get Started</a>
                    <?php 
                        } 
                        else 
                        { 
                    ?>
                            <a class="banner_btn btn" href="<?=base_url()?>dashboard">Get Started</a>
                    <?php 
                        } 
                    ?>
                    <img src="<?=front_img()?>banner_img.svg" class="img-fluid" alt="Banner Image">
                </div>
            </div>
        </div>
    </section>
    <main id="main">
        <?php 
            if(count($currency)>0) 
            { 
        ?>
                <section class="table_div">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="market-table">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Last Price</th>
                                                    <th>24H Change</th>
                                                    <th>24H High</th>
                                                    <th>24H Low</th>
                                                    <th>Volume</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                    if(count($pairs)>0) 
                                                    { 
                                                        foreach($pairs as $pair_details) 
                                                        { 
                                                            $from_currency = $this->common_model->getTableData('currency',array('id' => $pair_details->from_symbol_id))->row();
                                                            $to_currency = $this->common_model->getTableData('currency',array('id' => $pair_details->to_symbol_id))->row();
                                                            $pair_symbol = $from_currency->currency_symbol.'/'.$to_currency->currency_symbol;
                                                            $pair_url = $from_currency->currency_symbol.'_'.$to_currency->currency_symbol;
                                                            $currency = getcryptocurrencydetail($from_currency->id);

                                                ?>
                                                            <tr>
                                                                <td>
                                                                    <img src="<?=$currency->image?>" alt=""  class="table-cryp"> 
                                                                    <a class="mylink" href="<?=base_url();?>trade/<?=$pair_url?>"><?=$pair_symbol?></a>
                                                                    </td>
                                                                <td><?=(!empty($pair_details->lastPrice))?$pair_details->lastPrice:0?> </td>
                                                                <td>
                                                                    <span class="<?php echo($pair_details->priceChangePercent>0)?'grn':'rdn';?>">
                                                                        <?=(!empty($pair_details->priceChangePercent))?$pair_details->priceChangePercent:0?>%
                                                                    </span>
                                                                </td>
                                                                <td><?=(!empty($pair_details->change_high))?$pair_details->change_high:0?></td>
                                                                <td><?=(!empty($pair_details->change_low))?$pair_details->change_low:0?></td>
                                                                <td><?=(!empty($pair_details->volume))?$pair_details->volume:0?></td>
                                                            </tr>
                                                <?php 
                                                        } 
                                                    } 
                                                ?>
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
        <?php
            }
        ?>
        <!--========================== About Section ============================-->
        <section id="about_section">
            <div class="container">
                <div class="row pb-5">
                    <div class="col-xl-8 m-auto">
                        <div class="section_heading">
                            <h1>About Us</h1>
                           <?=trim($about_us->english_content)?> 
                        </div>
                    </div>
                </div>
                <div class="row align-items-center">

                    <div class="col-md-5 wow fadeInUp" data-wow-delay="0.2s" style="visibility: hidden; animation-delay: 0.2s; animation-name: none;">
                        <div class="rotate_img">
                            <img class="circle_img img-fluid" src="<?=front_img()?>circle.svg">

                        </div>
                    </div>
                    <div class="col-md-7">
                        <h3 class="sub_title">Highlights:-</h3>
                        <?=trim($highlights->english_content)?>
                    </div>
                </div>
            </div>
        </section>
        <!-- #About -->
        <!--========================== Features Section ============================-->
        <section id="features">
            <div class="container wow fadeIn" style="visibility: hidden; animation-name: none;">
                <div class="row pt-5">
                    <div class="col-xl-7 m-auto">
                        <div class="section_heading">
                            <h1>Features</h1>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center align-items-center d-flex">
                    <div class="col-lg-4 col-md-6 mb-2 wow fadeInUp" data-wow-delay="0.2s" style="visibility: hidden; animation-delay: 0.2s; animation-name: none;">
                        <div class="feature_box">
                            <img src="<?=$affiliate_program->image?>" class="mb-4 img-fluid" alt="Affiliate Program">
                            <div class="">
                                <h2 class="mt-0"><?=$affiliate_program->$name?></h2>
                                <p><?=$affiliate_program->$content?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mb-2 wow fadeInUp" data-wow-delay="0.4s" style="visibility: hidden; animation-delay: 0.4s; animation-name: none;">
                        <div class="feature_box">
                            <img src="<?=$fast_and_user_friendly->image?>" class="mb-4 img-fluid" alt="Fast &amp; User Friendly">
                            <div class="">
                                <h2 class="mt-0"><?=$fast_and_user_friendly->$name?></h2>
                                <p><?=$fast_and_user_friendly->$content?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mb-2 wow fadeInUp" data-wow-delay="0.6s" style="visibility: hidden; animation-delay: 0.6s; animation-name: none;">
                        <div class="feature_box">
                            <img src="<?=$hot_wallet->image?>" class="mb-4 img-fluid" alt="Hot Wallet">
                            <div class="">
                                <h2 class="mt-0"><?=$hot_wallet->$name?></h2>
                                <p><?=$hot_wallet->$content?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mb-2 wow fadeInUp" data-wow-delay="1.4s" style="visibility: hidden; animation-delay: 1.4s; animation-name: none;">
                        <div class="feature_box">
                            <img src="<?=$prompt_support->image?>" class="mb-4 img-fluid" alt="Prompt Support">
                            <div class="">
                                <h2 class="mt-0"><?=$prompt_support->$name?></h2>
                                <p><?=$prompt_support->$content?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mb-2 wow fadeInUp" data-wow-delay="1.6s" style="visibility: hidden; animation-delay: 1.6s; animation-name: none;">
                        <div class="feature_box">
                            <img src="<?=$lending_service->image?>" class="mb-4 img-fluid" alt="Lending Service">
                            <div class="">
                                <h2 class="mt-0"><?=$lending_service->$name?></h2>
                                <p> <?=$lending_service->$content?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mb-2 wow fadeInUp" data-wow-delay="1.8s" style="visibility: hidden; animation-delay: 1.8s; animation-name: none;">
                        <div class="feature_box">
                            <img src="<?=$advanced_trading_features->image?>" class="mb-4 img-fluid" alt="Advanced Trading Features">
                            <div class="">
                                <h2 class="mt-0"><?=$advanced_trading_features->$name?></h2>
                                <p><?=$advanced_trading_features->$content?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>       
        <section id="join">
            <div class="container">
                <div class="join-container justify-content-center">
                    <div class="row">
                        <div class="col-xl-7 m-auto">
                            <div class="section_heading">
                                <h1>What is IXToken exchange</h1>
                                <?=$what_is->$content?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-7  order-lg-1 order-1 wow fadeInLeft">
                            <img src="<?=front_img()?>site-img.png" class="img-fluid" alt="">
                            <div class="dots dots_1"></div>
                            <div class="dots dots_2"></div>
                        </div>
                        <div class="col-lg-5 content order-lg-2 order-2">
                            <?=$ixtoken->$content?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="dots dots_3"></div>
        </section>
         <!--========================== Subscribe Section ============================-->
        <?php $this->load->view('front/common/subscribe'); ?>
        <!-- #Subscribe -->
        <!--========================== Join Us Section ============================-->
       
        <!-- #Join Us -->
         <!-- #Features -->
        <section class="join-now">
            <div class="container">
                <div class="row mt-5 pt-5">
                    <div class="col-xl-7 m-auto">
                        <div class="section_heading">
                            <h1>Join Now</h1>
                            <p>Take your first steps to Becoming a Cryptoiner Today</p>
                        </div>
                    </div>
                </div>
                <div class="row text-center">
                    <div class="col-md-3">
                        <div class="highlights_div">
                            <img src="<?=front_img()?>quick_deposit.svg" class="mb-3 img-fluid">
                            <?=$join_us[0]->$content?>
                            <img class="hover-shape-1 hover-shape img-fluid" src="<?=front_img()?>shape-one.svg" alt="Shape One">
                            <img class="hover-shape-2 hover-shape img-fluid" src="<?=front_img()?>shape-two.svg" alt="Shape Two">
                            <img class="hover-shape-3 hover-shape img-fluid" src="<?=front_img()?>shape-three.svg" alt="Shape Three">
                            <img class="hover-shape-4 hover-shape img-fluid" src="<?=front_img()?>shape-four.svg" alt="Shape Four">
                            <img class="hover-shape-5 hover-shape img-fluid" src="<?=front_img()?>shape-five.svg" alt="Shape Five">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="highlights_div">
                            <img src="<?=front_img()?>fast_buying.svg" class="mb-3 img-fluid">
                            <?=$join_us[1]->$content?>
                            <img class="hover-shape-1 hover-shape img-fluid" src="<?=front_img()?>shape-one.svg" alt="Shape One">
                            <img class="hover-shape-2 hover-shape img-fluid" src="<?=front_img()?>shape-two.svg" alt="Shape Two">
                            <img class="hover-shape-3 hover-shape img-fluid" src="<?=front_img()?>shape-three.svg" alt="Shape Three">
                            <img class="hover-shape-4 hover-shape img-fluid" src="<?=front_img()?>shape-four.svg" alt="Shape Four">
                            <img class="hover-shape-5 hover-shape img-fluid" src="<?=front_img()?>shape-five.svg" alt="Shape Five">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="highlights_div">
                            <img src="<?=front_img()?>trading_option.svg" class="mb-3 img-fluid">
                            <?=$join_us[2]->$content?>
                            <img class="hover-shape-1 hover-shape img-fluid" src="<?=front_img()?>shape-one.svg" alt="Shape One">
                            <img class="hover-shape-2 hover-shape img-fluid" src="<?=front_img()?>shape-two.svg" alt="Shape Two">
                            <img class="hover-shape-3 hover-shape img-fluid" src="<?=front_img()?>shape-three.svg" alt="Shape Three">
                            <img class="hover-shape-4 hover-shape img-fluid" src="<?=front_img()?>shape-four.svg" alt="Shape Four">
                            <img class="hover-shape-5 hover-shape img-fluid" src="<?=front_img()?>shape-five.svg" alt="Shape Five">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="highlights_div">
                            <img src="<?=front_img()?>services.svg" class="mb-3 img-fluid">
                            <?=$join_us[3]->$content?>
                            <img class="hover-shape-1 hover-shape img-fluid" src="<?=front_img()?>shape-one.svg" alt="Shape One">
                            <img class="hover-shape-2 hover-shape img-fluid" src="<?=front_img()?>shape-two.svg" alt="Shape Two">
                            <img class="hover-shape-3 hover-shape img-fluid" src="<?=front_img()?>shape-three.svg" alt="Shape Three">
                            <img class="hover-shape-4 hover-shape img-fluid" src="<?=front_img()?>shape-four.svg" alt="Shape Four">
                            <img class="hover-shape-5 hover-shape img-fluid" src="<?=front_img()?>shape-five.svg" alt="Shape Five">
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $this->load->view('front/common/footer'); ?>
<?php $this->load->view('front/common/scripts'); ?>
</body>
</html>