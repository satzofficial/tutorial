<script src="<?=front_js()?>lib/jquery/jquery.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?=front_js()?>lib/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?=front_js()?>lib/easing/easing.min.js"></script>
<script src="<?=front_js()?>lib/wow/wow.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<script src="https://unpkg.com/splitting/dist/splitting.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/2.1.3/TweenMax.min.js"></script>
<!-- Template Main Javascript File -->
<script src="<?=front_js()?>/main.js"></script>
<!-- <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script> -->
<script src="<?=front_js()?>popper.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?=front_js()?>bootstrap.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<!-- <script src="<?=front_js()?>owl.carousel.min.js?v=<?php echo date('Ymdhis'); ?>"></script> -->
<script src="<?=front_js()?>aos.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?=front_js()?>jquery.validate.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script type="text/javascript" src="<?=front_js()?>dataTables.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script type="text/javascript" src="<?=front_js()?>datatables.bootstrap4.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?=front_js()?>bootstrap-dropdownhover.min.js"></script>
<!-- Template Main Javascript File -->
<script type="text/javascript" src="<?=front_js()?>dataTables.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script type="text/javascript" src="<?=front_js()?>datatables.bootstrap4.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?=front_js()?>toastr.min.js?v=<?php echo date('Ymdhis'); ?>"></script> 
<script>
    toastr.options = { "closeButton": true, "timeOut": "34000", }
</script> 
<?php 
    if($this->session->flashdata('success')!= '')
    { 
?>   
    <script> toastr.success("<?php echo $this->session->flashdata('success');?>"); </script>
<?php
    } 
    if($this->session->flashdata('fiatsuccess')!= '')
    { 
?>   
        <script> toastr.success("<?php echo $this->session->flashdata('fiatsuccess');?>"); </script>
<?php 
    } 
    if($this->session->flashdata('info')!= '')
    { 
?>   
		<script> toastr.info("<?php echo $this->session->flashdata('info');?>"); </script>
<?php 
    } 
    if($this->session->flashdata('warning')!= '')
    { 
?>   
        <script> toastr.warning("<?php echo $this->session->flashdata('warning');?>"); </script>
<?php 
    } 
    if($this->session->flashdata('error')!= '')
    { 
?>   
        <script> toastr.error("<?php echo $this->session->flashdata('error');?>"); </script>
<?php
    }  
    if($this->session->flashdata('fiaterror')!= '')
    { 
?>   
        <script> toastr.error("<?php echo $this->session->flashdata('fiaterror');?>"); </script>
<?php 
    } 
?>