    <?php include 'header.php';  ?>

    <!-- banner-section start -->
    <section class="banner-section">
        <div class="overlay">
            <div class="banner-content d-flex align-items-center">
                <div class="container">
                    <div class="row justify-content-start">
                        <div class="col-lg-7 col-md-10">
                            <div class="main-content">
                                <div class="top-area section-text justify-content-center">
                                    <h4 class="sub-title">Simple. Transparent. Secure</h4>
                                    <h1 class="title">A Quantumized Distribution of Wealth </h1>
                                  </div>
                                <div class="bottom-area">
                                    <a href="<?php echo $base_url_var.'register'; ?>" class="cmn-btn">Get Started</a>
                                    <a href="<?php echo $base_url_var.'contact-us'; ?>" class="cmn-btn second">Get in touch</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- banner-section end -->

    <!-- Features In start -->
    <section class="features-section">
        <div class="overlay pt-120">
            <div class="container wow fadeInUp">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="top-section">
                            <span class="head-icon d-flex justify-content-center align-items-center">
                                <img src="<?php echo $assets_url_var; ?>images/reward.png" width="48px" alt="icon">
                            </span>
                            <h2 id="about_us" class="title">Reward Based Endowing Decentralized Platform</h2>
                            <p>Our users stay informed in real time with everything that’s happening on his account:
                                payments, transfer, advice. Get visibility on our users flows to anticipate their
                                needs.</p>
            
                        </div>
                    </div>
                    <div class="col-lg-6 text-end">
                        <div class="img-area">
                            <img src="<?php echo $assets_url_var; ?>images/account-banner.png" alt="image">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Features In end -->

    <!-- Features In start -->
    <section class="features-section second">
        <div class="overlay pt-120 pb-120">
            <div class="container wow fadeInUp">
                <div class="row">
                    <div class="col-lg-6 text-start cus-ord">
                        <div class="img-area">
                            <img src="<?php echo $assets_url_var; ?>images/feature-item-2.png" alt="image">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="top-section">
                            <span class="head-icon d-flex justify-content-center align-items-center">
                                <img src="<?php echo $assets_url_var; ?>images/icon/sheled.png" alt="icon">
                            </span>
                            <h5 class="sub-title">Safe Investments</h5>
                            <h2 class="title">The Better Way to Save & Invest</h2>
                            <p>Ten Realm helps over 10 million users achieve their financial goals by helping them save and invest with ease. Put that extra cash to use without risk with our World First Time Loop technology.
                            </p>
                            <ul class="list">
                                <li class="list-item d-flex align-items-center">
                                    <span class="check d-flex align-items-center justify-content-center">
                                        <img src="<?php echo $assets_url_var; ?>images/icon/check.png" alt="icon">
                                    </span>
                                    <span>Profitable to invest and Handy to manage</span>
                                </li>
                                <li class="list-item d-flex align-items-center ">
                                    <span class="check d-flex align-items-center justify-content-center">
                                        <img src="<?php echo $assets_url_var; ?>images/icon/check.png" alt="icon">
                                    </span>
                                    <span>Highest Returns on your investments</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Features In end -->

    <!-- Card In start -->
    <section class="card-section">
        <div class="overlay pt-120 pb-120">
            <div class="container wow fadeInUp">
                <div class="row justify-content-end">
                    <div class="col-lg-6">
                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="credit-tab" data-bs-toggle="tab"
                                    data-bs-target="#credit" type="button" role="tab" aria-controls="credit"
                                    aria-selected="true">Galaxy Pass</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="debit-tab" data-bs-toggle="tab" data-bs-target="#debit"
                                    type="button" role="tab" aria-controls="debit" aria-selected="false">Universal Pass</button>
                            </li>
                        </ul>
                        <div class="pb-120">
                            <div class="tab-content marg" >
                            <div class="tab-pane fade show active" id="credit" role="tabpanel"
                            aria-labelledby="credit-tab">
                            <div class="card-carousel-index">
                                <div class="single">
                                    <div class="thumb">
                                        <img src="<?php echo $assets_url_var; ?>images/card-img-1.png" alt="image">
                                    </div>
                                    <div class="button-area text-center">
                                        <a href="<?php echo $base_url_var.'register'; ?>" class="cmn-btn">Get Started Now</a>
                                    </div>
                                </div>
                                <div class="single">
                                    <div class="thumb">
                                        <img src="<?php echo $assets_url_var; ?>images/card-img-2.png" alt="image">
                                    </div>
                                    <div class="button-area text-center">
                                        <a href="<?php echo $base_url_var.'register'; ?>" class="cmn-btn">Get Started Now</a>
                                    </div>
                                </div>
                                <div class="single">
                                    <div class="thumb">
                                        <img src="<?php echo $assets_url_var; ?>images/card-img-3.png" alt="image">
                                    </div>
                                    <div class="button-area text-center">
                                        <a href="<?php echo $base_url_var.'register'; ?>" class="cmn-btn">Get Started Now</a>
                                    </div>
                                </div>
                   
                            </div>
                        </div>

                    <div class="tab-pane fade" id="debit" role="tabpanel" aria-labelledby="debit-tab">

                                <div class="card-carousel-index">
                                    <div class="single">
                                        <div class="thumb">
                                            <img src="<?php echo $assets_url_var; ?>images/card-img-4.png" alt="image">
                                        </div>
                                        <div class="button-area text-center">
                                            <a href="<?php echo $base_url_var.'register'; ?>" class="cmn-btn">Get Started Now</a>
                                        </div>
                                    </div>
                                    <div class="single">
                                        <div class="thumb">
                                            <img src="<?php echo $assets_url_var; ?>images/card-img-5.png" alt="image">
                                        </div>
                                        <div class="button-area text-center">
                                            <a href="<?php echo $base_url_var.'register'; ?>" class="cmn-btn">Get Started Now</a>
                                        </div>
                                    </div>
                                    <div class="single">
                                        <div class="thumb">
                                            <img src="<?php echo $assets_url_var; ?>images/card-img-6.png" alt="image">
                                        </div>
                                        <div class="button-area text-center">
                                            <a href="<?php echo $base_url_var.'register'; ?>" class="cmn-btn">Get Started Now</a>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>


                    </div>
                    <div class="col-lg-6">
                        <div class="section-header">
                            <h5 class="sub-title">Boost your Earnings with right choice</h5>
                            <h2 class="title">Access Endless Possibilities with Royal Pass</h2>
                        </div>                        
                    </div>
                </div>

        </div>
    </section>
    <!-- Card In end -->

    <!-- Get Start In start -->
    <section class="get-start wow fadeInUp">
        <div class="overlay">
            <div class="container">
                <div class="col-12">
                    <div class="get-content">
                        <div class="section-text">
                            <h3 class="title">Ready to get started?</h3>
                            <p>It only takes a few minutes to Register.</p>
                        </div>
                        <a href="<?php echo $base_url_var.'register'; ?>" class="cmn-btn">Get Started</a>
                        <img src="<?php echo $assets_url_var; ?>images/get-start.png" alt="images">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Get Start In end -->

<?php include 'footer.php'; ?>