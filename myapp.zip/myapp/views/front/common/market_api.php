 <?php $this->load->view('front/common/header'); ?>
 <style type="text/css">
     .mydecor { 
     font-size: 12px !important;
    font-style: oblique !important; }
 </style>
<?php $settings = $site_common['site_settings']; 
    $user_id=$this->session->userdata('user_id');
    $sitelan = $this->session->userdata('site_lang');
    $heading = $sitelan."_heading";
    $meta_description = $sitelan."_meta_description";
    $meta_keywords = $sitelan."_meta_keywords";
    $title = "Ixtoken - Rest API";
    $copy_right_text = $sitelan."_copy_right_text";
    $fdescription = $sitelan."_description";
    $fquestion = $sitelan."_question";
?>

				
					 <div class="sidebar-api">
                       <a href="#public-api">Public API</a>
					   <a id="api-ll" href="#socket-api">Ticker List</a>
					   <a id="api-ll" href="#socket-api">Ticker Info</a>
					   <a id="api-ll" href="#socket-api">Order Book</a>
					   <a id="api-ll" href="#socket-api">Trade History</a>

                       <a href="#socket-api">Socket API</a>
					   <a id="api-ll" href="#socket-api">Socket Order Book</a>
					   <a id="api-ll" href="#socket-api">Socket Trade History</a>

                       <a href="#private-api">Private API</a>
					   <a id="api-ll" href="#socket-api">Login</a>
					   <a id="api-ll" href="#socket-api">Request ID</a>
					   <a id="api-ll" href="#socket-api">Create Order </a>
					   <a id="api-ll" href="#socket-api">Socket Trade History</a>
					   <a id="api-ll" href="#socket-api">Socket Order Book</a>
					   <a id="api-ll" href="#socket-api">Socket Trade History</a>

                     </div>
                 
				
				
				
						<div class="div-api">
                        <h4 class="cmsTitle">Ixtoken - Rest API</h4>

                        <p>Ixtoken provides API solutions for automated trading based on needs of individuals and institutions.</p><br/>
                        
                           
                        <h4 style="font-size: 19px;"><b>Summary :</b> </h4><br/>
                         <p>The summary api is to provide an overview of market data for all tickers and all market pairs on the exchange.</p><br/>
                        <div class="pre-divv">
                          <p><pre style="margin: 0;"><i class="fa fa-circle"></i> 200 OK</pre></p>
                          <p><pre style="background-color: #3d434a;padding: 20px 0px 25px 50px;"><font color="#fff">--request GET \  </font><code>https://ixtoken.io/api/v1/all</code><br/><br/><code>Sample response :
[
  {

    "trading_pairs":"BTC_USDT",
    "last_price":"19368.54",
    "lowest_ask":"19370.38",
    "highest_bid":"19370.38",
    "base_volume":"37139.931405",
    "quote_volume":"712246578.4507665",
    "price_change_percent_24h":"0.72",
    "highest_price_24h":"19420.91",
    "lowest_price_24h":"18857"
  }

   {
    "trading_pairs":"ETH_USDT",
    "last_price":"599.72",
    "lowest_ask":"599.71",
    "highest_bid":"599.71",
    "base_volume":"535363.34975",
    "quote_volume":"318358003.6454193",
    "price_change_percent_24h":"-0.2",
    "highest_price_24h":"604",
    "lowest_price_24h":"583"
  }
]
                               </code>
                              </pre></p>
                            </div>
                            <br/><br/>

                           
                        


                            <h4 style="font-size: 19px;"><b>Assets :</b> </h4>
                        <p>The assets api is to provide a detailed summary for each currency available on the exchange</p><br/>

                        <div id="socket-api" class="pre-divv">
                          <p><pre style="margin: 0;"><i class="fa fa-circle"></i> 200 OK</pre></p>
                          <p><pre style="background-color: #3d434a;padding: 20px 0px 25px 50px;"><font color="#fff">--request GET \  </font><code>https://ixtoken.io/api/v1/assets</code><br/><br/><code><br/><br/>Sample response :

   {
    "BTC":
    {
    "name":"bitcoin",
    "unified_cryptoasset_id":"1",
    "can_withdraw":"true",
    "can_deposit":"true",
    "min_withdraw":"0.0012",
    "max_withdraw":"2",
    "maker_fee":"0.14",
    "taker_fee":"0.18"
  },
  "ETH":
  {
    "name":"ethereum",
    "unified_cryptoasset_id":"2",
    "can_withdraw":"true",
    "can_deposit":"true",
    "min_withdraw":"0.02",
    "max_withdraw":"5",
    "maker_fee":"0.12",
    "taker_fee":"0.16"
  }
}

                               </code>
                              </pre></p>
                            </div>
                            <br/><br/>

                            <h4 style="font-size: 19px;"><b>Ticker :</b> </h4>
                        <p>The ticker api is to provide a 24-hour pricing and volume summary for each market pair available on the exchange.</p><br/>

                        <div class="pre-divv">
                          <p><pre style="margin: 0;"><i class="fa fa-circle"></i> 200 OK</pre></p>
                          <p><pre style="background-color: #3d434a;padding: 20px 0px 25px 50px;"><font color="#fff">--request GET \  </font><code>https://ixtoken.io/api/v1/ticker</code><br/><br/><code><br/><br/>Sample response :

   {
    "TARM_BTC":
    {
      "base_id":"5",
      "quote_id":"1",
      "last_price":"0.00000065",
      "base_volume":"2300",
      "quote_volume":"0.000644",
      "isFrozen":"1"
    },
    "TARM_USD":
    {
      "base_id":"5",
      "quote_id":"6",
      "last_price":"0.01464",
      "base_volume":"225069",
      "quote_volume":"675.207",
      "isFrozen":"1"
    }
  }

                               </code>
                              </pre></p>
                            </div>
                            <br/><br/>


                            <h4 style="font-size: 19px;"><b>Order Book :</b> </h4>
                        <p>Adjusted based on the limit</p><br/>

                        <div class="pre-divv">
                          <p><pre style="margin: 0;"><i class="fa fa-circle"></i> 200 OK</pre></p>
                          <p><pre style="background-color: #3d434a;padding: 20px 0px 25px 50px;"><font color="#fff">--request GET \  </font><code>https://ixtoken.io/api/v1/orderbook/market_pair?limit=<10></code><code> <br><font color="#fff">--parameter:</font> <font color="#fff"><b>market_pair : </b> ETH_BTC , </font><font color="#fff"> <b>Limit : </b> 5, 10, 20, 50, 100,500,1000,5000</font><br/><br/>Sample response :

   {

  "timestamp":1607328329,
   "bids":[["0.0309","24.211"],["0.030901","15.627"],["0.030902","17.442"],["0.030903","10.873"],["0.030904","7"],["0.030905","24.1"],["0.030906","16.216"],["0.030907","6.5"],["0.030908","1"],["0.030909","6.467"]],
   "asks":[["0.030949","0.05"],["0.030948","1.977"],["0.030947","1.5"],["0.030946","7.729"],["0.030945","15.714"],["0.030944","7.351"],["0.03094","38.666"],["0.030939","11.61"],["0.030938","1.035"],["0.030937","1.5"]]
  }

                               </code>
                              </pre></p>
                            </div>
                            <br/><br/>

                            <h4 style="font-size: 19px;"><b>Trades :</b> </h4>
                        <p>The trades endpoint is to return data on all recently completed trades for a given market pair</p><br/>

                        <div class="pre-divv">
                          <p><pre style="margin: 0;"><i class="fa fa-circle"></i> 200 OK</pre></p>
                          <p><pre style="background-color: #3d434a;padding: 20px 0px 25px 50px;"><font color="#fff">--request GET \  </font><code>https://ixtoken.io/api/v1/trades/market_pair</code><code> <br> <font color="#fff">--parameter:</font> <font color="#fff"><b>market_pair : </b> TARM_ETH</font>
                            <br/><br/>Sample response :

  [
  {
  "trade_id":"1",
  "price":"0.00003",
  "base_volume":"100",
  "quote_volume":"0.003",
  "timestamp":1606242843,
  "type":"sell"
 },
 {
  "trade_id":"2",
  "price":"0.00003",
  "base_volume":"100",
  "quote_volume":"0.003",
  "timestamp":1606242843,
  "type":"buy"
}
]

                               </code>
                              </pre></p>
                            </div>
                            <br/><br/>                
                            </div>
                    


