<?php 
    $this->load->view('front/common/header');
   $settings = $site_common['site_settings']; 
    $user_id=$this->session->userdata('user_id');
    $sitelan = $this->session->userdata('site_lang');
    $heading = $sitelan."_heading";
    $meta_description = $sitelan."_meta_description";
    $meta_keywords = $sitelan."_meta_keywords";
    $title = $sitelan."_title";
    $copy_right_text = $sitelan."_copy_right_text";
    $fdescription = $sitelan."_description";
    $fquestion = $sitelan."_question";
    $lang_id = $this->session->userdata('site_lang');
?>

<!-- breadcrumb -->
<div class="me-breadcrumb">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="me-breadcrumb-box">
            <h1>FAQ</h1>
            <p><a href="<?php echo base_url();?>">Home</a>Faq</p>
          </div>
        </div>
      </div>
    </div>
</div>

  <!-- faq -->
<div class="me-faq-single me-padder-top">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="me-faq-box">
            <div class="accordion" id="accordionExample">
            <?php if(isset($faq) && !empty($faq)){ $i=0;
                    foreach($faq as $list_faq){ $i++;

                ?>  
              <div class="me-faq-list">
                <p class="me-faq-head <?=($i==1)?'me-faq-open':''?>" data-toggle="collapse" data-target="#me-faq-<?=$i?>"> <?php echo $list_faq->$fquestion;?> <button><span></span></button>
                </p>
                <div id="me-faq-<?=$i?>" class="collapse <?=($i==1)?'show':''?>" data-parent="#accordionExample">
                  <div class="card-body"> <?php echo $list_faq->$fdescription;?> </div>
                </div>
              </div>

            <?php }}?>  

            </div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="me-faq-img"> <img src="<?php echo front_img();?>faq.png" class="img-fluid" alt="image"/> </div>
        </div>
      </div>
    </div>
</div>


    <!--========================== Banner Section ============================-->
    
    <?php 
    $this->load->view('front/common/footer');
    ?>