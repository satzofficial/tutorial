<?php if(count($news)>0)
      { ?>
<div class="container">
<div class="row">
<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
<div class="news-update-box">
	<div class="news-update-text-box">
		 <p>News &amp; Updates</p>
	</div>
	<p class="new-update-text text-white">
		<?php
			foreach($news as $newsupdates)
			{ ?>
				<marquee behavior="scroll"><?=$newsupdates->english_content?></marquee>

	<?php	} ?>
	</p>

</div>

</div>
</div>
</div>
<?php	} ?>