<!DOCTYPE html>
<html class="no-js" lang="en">
<?php
// echo '<pre>';print_r($site_common['site_settings']);exit;
$favicon  =  ($site_common['site_settings']->site_favicon) ? $site_common['site_settings']->site_favicon :'';
$english_site_name  =  ($site_common['site_settings']->english_site_name) ? $site_common['site_settings']->english_site_name :'';
$sitelogo = ($site_common['site_settings']->site_logo) ? $site_common['site_settings']->site_logo :'';
$site_email = ($site_common['site_settings']->site_email) ? $site_common['site_settings']->site_email :'';
$assets_url_var = base_url('assets/front/');
$base_url_var = base_url();
$csrf_name = $this->security->get_csrf_token_name(); // for the name
$csrf_token = $this->security->get_csrf_hash();  // for the value
$class = $this->router->fetch_class();
$method = $this->router->fetch_method();
    ?>
    <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <meta name="<?php echo $csrf_name ?>" content="<?php echo $csrf_token; ?>">
      <title><?php echo $english_site_name; ?></title>
      <link rel="shortcut icon" href="<?php echo $favicon; ?>" type="image/x-icon">
      <link rel="stylesheet" href="<?php echo $assets_url_var; ?>css/bootstrap.min.css?v=<?php echo date('Ymdhis'); ?>">
      <link rel="stylesheet" href="<?php echo $assets_url_var; ?>css/fontawesome.min.css?v=<?php echo date('Ymdhis'); ?>">
      <link rel="stylesheet" href="<?php echo $assets_url_var; ?>css/jquery-ui.css?v=<?php echo date('Ymdhis'); ?>">
      <link rel="stylesheet" href="<?php echo $assets_url_var; ?>css/plugin/nice-select.css?v=<?php echo date('Ymdhis'); ?>">
      <link rel="stylesheet" href="<?php echo $assets_url_var; ?>css/plugin/slick.css?v=<?php echo date('Ymdhis'); ?>">
      <link rel="stylesheet" href="<?php echo $assets_url_var; ?>css/arafat-font.css?v=<?php echo date('Ymdhis'); ?>">
      <link rel="stylesheet" href="<?php echo $assets_url_var; ?>css/plugin/animate.css?v=<?php echo date('Ymdhis'); ?>">
      <link rel="stylesheet" href="<?php echo $assets_url_var; ?>css/style.css?v=<?php echo date('Ymdhis'); ?>">
      <style type="text/css">
        .error{ color:red; }
      </style>
    </head>
<body>
  <!-- start preloader -->
  <!-- <div class="preloader" id="preloader"></div> -->
  <!-- end preloader -->

  <!-- Scroll To Top Start-->
  <a href="javascript:void(0)" class="scrollToTop"><i class="fas fa-angle-double-up"></i></a>
  <!-- Scroll To Top End -->
    <?php 
    $method1_arr = array("/", "index", "home", "forgot_user", "contact_us");
    $method2_arr = array("signup", "login");
    if(in_array($method, $method1_arr, TRUE)){
      ?>
              <!-- header-section start -->
              
            <!-- header-section end -->
          <?php }else if(in_array($method, $method2_arr, TRUE)){
            ?>
            <!-- header-section start -->
            <header class="header-section register">
              <div class="overlay">
                <div class="container">
                  <div class="row d-flex header-area">
                    <nav class="navbar d-flex justify-content-between navbar-expand-lg navbar-dark">
                      <a class="navbar-brand" href="<?php echo $base_url_var; ?>">
                        <img src="<?php echo $sitelogo; ?>" style="width: 100px;" class="logo" alt="logo">
                      </a>
                      <div class="d-flex align-items-center justify-content-end">
                        <ul class="navbar-nav">
                          <li class="nav-item">
                            Already have account
                          </li>
                        </ul>
                        <div class="right-area header-action d-flex align-items-center">
                          <?php if($method === 'login'){ ?>
                            <a href="<?php echo $base_url_var.'register'; ?>" class="cmn-btn">Register</a>
                          <?php }elseif($method === 'signup'){ ?>
                            <a href="<?php echo $base_url_var.'login'; ?>" class="cmn-btn">Login Now</a>
                          <?php } ?>
                        </div>
                      </div>
                    </nav>
                  </div>
                </div>
              </div>
            </header>
     <!-- header-section end -->
<?php }  ?>
