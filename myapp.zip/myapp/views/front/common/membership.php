<?php 
    $this->load->view('front/common/header');
   $settings = $site_common['site_settings']; 
    $user_id=$this->session->userdata('user_id');
    $sitelan = $this->session->userdata('site_lang');
    $heading = $sitelan."_heading";
    $meta_description = $sitelan."_meta_description";
    $meta_keywords = $sitelan."_meta_keywords";
    $title = $sitelan."_title";
    $copy_right_text = $sitelan."_copy_right_text";
    $fdescription = $sitelan."_description";
    $fquestion = $sitelan."_question";
?>

<!-- breadcrumb -->
<div class="me-breadcrumb">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="me-breadcrumb-box">
            <h1>Price</h1>
            <p><a href="<?php echo base_url();?>">Home</a>Price</p>
          </div>
        </div>
      </div>
    </div>
</div>

 


<div class="me-investment-single me-padder-top">
    <div class="container">
      <div class="row">
      <?php if(isset($membership) && !empty($membership)){    $i=0;
            foreach($membership as $value){
                $i++;
        ?>  

        <div class="col-lg-4 col-md-6">
          <div class="me-plans-box">
            <div class="me-plan-header">
              <h1 class="me-plan-title"><?=$value->plan_name?></h1>
              <!-- <div class="me-plan-price">$29.<sup>99</sup></div> -->
              <div class="me-plan-price">$<?=$value->plan_price?></div>
              <?php if($value->plan_duration==1) $dur = 'Monthly';
                    else if($value->plan_duration==2) $dur = 'Half-Yearly';
                    else if($value->plan_duration==3) $dur = 'Yearly';
              ?>
              <div class="me-plan-duration"><?=$dur?></div>
            </div>
            <div class="me-plan-body">
              <?=$value->description?>
            </div>
            <div class="me-plan-footer">
              <button class="me-btn">purchase plan</button>
            </div>
            <div class="me-plan-shape"> </div>
          </div>
        </div>
    <?php }}?>
        
      </div>
    </div>
</div>            


<!-- Testimonial -->
    <div class="me-testimonial me-padder-top-less me-padder-bottom">
        <div class="container">
            <div class="me-heading2">
                <h4><?php echo $home_banner7->english_content;?></h4>
                <h1><?php echo $home_banner7->english_name;?></h1>
            </div>
            <div class="row">
                <div class="col-md-5">
                    <div class="me-testimonial-user">
                        <img src="<?php echo front_img();?>user.jpg" class="img-fluid" alt="image" title="John Doe"/>
                        <img src="<?php echo front_img();?>user2.jpg" class="img-fluid" alt="image" title="John Doe"/>
                        <img src="<?php echo front_img();?>user3.jpg" class="img-fluid" alt="image" title="John Doe"/>
                        <img src="<?php echo front_img();?>user4.jpg" class="img-fluid" alt="image" title="Joolie Desuza"/>
                        <img src="<?php echo front_img();?>user5.jpg" class="img-fluid" alt="image" title="Joolie Desuza"/>
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="me-testimonial-slider">
                        <div class="me-testimonial-box-shape">
                        </div>
                        <div class="me-testimonial-slider-box">
                            <div class="swiper-container">
                                <div class="swiper-wrapper">
                                <?php if(isset($testimonials) && !empty($testimonials)){
                                        foreach($testimonials as $testimonials_info){ ?>    
                                    <div class="swiper-slide">
                                        <div class="me-testimonial-data">
                                            <p><?=$testimonials_info->english_comments?></p>
                                            <h4><?=$testimonials_info->english_name?></h4>
                                            <h6><?=$testimonials_info->english_position?></h6>
                                        </div>
                                    </div>
                                <?php }}?>    
                                   
                                </div>
                            </div>
                        </div>
                        <!-- Add Arrows -->
                        <div class="me-testimonial-button">
                            <div class="swiper-button-next"></div>
                            <div class="swiper-button-prev"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    


    <!--========================== Banner Section ============================-->
    
    <?php 
    $this->load->view('front/common/footer');
    ?>