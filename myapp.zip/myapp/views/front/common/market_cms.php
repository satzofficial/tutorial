<?php $this->load->view('front/common/header'); ?>
<section class="innerWrapper">
    <div class="container">
        <div class="row">
                <div class="col-lg-4">
                    <div class="trade-plate">


<div class="table-responsive style="display:flex;">
	<table class="table table-striped table-bordered" id="example" style="width:100%">
		<thead>
			<tr>
				<th style="text-align: center;">
					Coin/Token</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td style="font-size: 18px;font-weight: 500;text-align: left;padding-left: 60px;">
					<img class="img-fluid" src="https://res.cloudinary.com/dgg2qsjov/image/upload/v1603776558/uploads/currency/bxvnhb9jcdgfkf8qn3vo.svg" style="width: 20px;" /> Bitcoin (<a href="https://ixtoken.io/market/btc">BTC</a>)</td>
			</tr>
			<tr>
				<td style="font-size: 18px;font-weight: 500;text-align: left;padding-left: 60px;">
					<img class="img-fluid " src="https://res.cloudinary.com/dgg2qsjov/image/upload/v1603776589/uploads/currency/wz8qf2cqycqo8bilrqto.svg" style="width: 20px;" /> Ethereum (<a href="https://ixtoken.io/market/eth">ETH</a>)</td>
			</tr>
			<tr>
				<td style="font-size: 18px;font-weight: 500;text-align: left;padding-left: 60px;">
					<img class="img-fluid " src="https://res.cloudinary.com/dgg2qsjov/image/upload/v1603776618/uploads/currency/a4ydpbhjwrdfy9ikyzv3.svg" style="width: 20px;" /> Tether (<a href="https://ixtoken.io/market/usdt">USDT</a>)</td>
			</tr>
			<tr>
				<td style="font-size: 18px;font-weight: 500;text-align: left;padding-left: 60px;">
					<img class="img-fluid " src="https://res.cloudinary.com/dgg2qsjov/image/upload/v1606118136/uploads/currency/efr0dnhuggvsapa2vlup.png" style="width: 20px;" /> Armtoken (<a href="https://ixtoken.io/market/tarm">TARM</a>)</td>
			</tr>
			<tr>
				<td style="font-size: 18px;font-weight: 500;text-align: left;padding-left: 60px;">
					<img class="img-fluid " src="https://res.cloudinary.com/dgg2qsjov/image/upload/v1605597802/uploads/currency/bknjpakjs7auehsqylqs.png" style="width: 20px;" />Binance (<a href="https://ixtoken.io/market/bnb">BNB</a>)</td>
			</tr>
			<tr>
				<td style="font-size: 18px;font-weight: 500;text-align: left;padding-left: 60px;">
					<img class="img-fluid " src="https://res.cloudinary.com/dgg2qsjov/image/upload/v1607197007/uploads/currency/sxkbu8qecxlbxfc8t79w.png" style="width: 20px;" />Tron (<a href="https://ixtoken.io/market/trx">TRX</a>)</td>
			</tr>
			<tr>
				<td style="font-size: 18px;font-weight: 500;text-align: left;padding-left: 60px;">
					<img class="img-fluid " src="https://res.cloudinary.com/dgg2qsjov/image/upload/v1605603414/uploads/currency/biumkvpunlcqefhou63z.png" style="width: 20px;" />Uniswap (<a href="https://ixtoken.io/market/uni">UNI</a>)</td>
			</tr>
			<tr>
				<td style="font-size: 18px;font-weight: 500;text-align: left;padding-left: 60px;">
					<img class="img-fluid " src="https://res.cloudinary.com/dgg2qsjov/image/upload/v1606118686/uploads/currency/b11dbwgzxaezlv9lrn9f.png" style="width: 20px;" /> Arpa Chain (<a href="https://ixtoken.io/market/arpa">ARPA</a>)</td>
			</tr>
			<tr>
				<td style="font-size: 18px;font-weight: 500;text-align: left;padding-left: 60px;">
					<img class="img-fluid " src="https://res.cloudinary.com/dgg2qsjov/image/upload/v1606118702/uploads/currency/udy9ayfvkbclni9s3rlf.png" style="width: 20px;" /> Chain Link (<a href="https://ixtoken.io/market/link">LINK</a>)</td>
</td>
			</tr>
			<tr>
				<td style="font-size: 18px;font-weight: 500;text-align: left;padding-left: 60px;">
					<img class="img-fluid " src="https://res.cloudinary.com/dgg2qsjov/image/upload/v1607199095/uploads/currency/a0ngxtza6th8j8jqon7a.png" style="width: 20px;" /> Binance USD (<a href="https://ixtoken.io/market/busd">BUSD</a>)</td>
</td>
			</tr>
			<tr>
				<td style="font-size: 18px;font-weight: 500;text-align: left;padding-left: 60px;">
					<img class="img-fluid " src="https://res.cloudinary.com/dgg2qsjov/image/upload/v1606118671/uploads/currency/tbirhotw2nhyyof5st8k.png" style="width: 20px;" /> JUST (<a href="https://ixtoken.io/market/jst">JST</a>)</td>
</td>
			</tr>
			<tr>
				<td style="font-size: 18px;font-weight: 500;text-align: left;padding-left: 60px;">
					<img class="img-fluid " src="https://res.cloudinary.com/dgg2qsjov/image/upload/v1606994193/uploads/currency/rjmshac0yaqyfx9vjhg1.png" style="width: 20px;" /> YFIDAPP (<a href="https://ixtoken.io/market/yfid">YFID</a>)</td>
</td>
			</tr>
			<tr>
				<td style="font-size: 18px;font-weight: 500;text-align: left;padding-left: 60px;">
					<img class="img-fluid " src="https://res.cloudinary.com/dgg2qsjov/image/upload/v1607540778/uploads/currency/o4uuvy12dcaieh9k4ypu.png" style="width: 20px;" /> Spurtplus(<a href="https://ixtoken.io/market/spu">SPU+</a>)</td>
			</tr>
			<tr>
				<td style="font-size: 18px;font-weight: 500;text-align: left;padding-left: 60px;">
					<img class="img-fluid " src="https://res.cloudinary.com/dgg2qsjov/image/upload/v1607176062/uploads/currency/eiudla8y9supykenp4kr.png" style="width: 20px;" /> Icoin (<a href="https://ixtoken.io/market/icon">ICON</a>)</td>
</td>
			</tr>
			<tr>
				<td style="font-size: 18px;font-weight: 500;text-align: left;padding-left: 60px;">
					<img class="img-fluid " src="https://res.cloudinary.com/dgg2qsjov/image/upload/v1608459604/uploads/currency/p3tjs5lj82giqrgnclif.png" style="width: 20px;" /> Employment Coin (<a href="https://ixtoken.io/market/ec2">EC2</a>)</td>
</td>
			</tr>
		</tbody>
	</table>
</div>



                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="trade-plat-content">


            <div class="col-lg-12">
                <div><br></div>
								  <div>
                    <center><h4 class="cmsTitle"><?php echo $cms->title;?></h4></center>
                  <?php echo $cms->content_description;?>

                </div>
            </div>
        </div>
    </div>
</section>
<?php $this->load->view('front/common/footer'); ?>
<?php $this->load->view('front/common/scripts'); ?>

