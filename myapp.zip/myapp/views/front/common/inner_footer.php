<?php 
$settings = $site_common['site_settings'];       
$copy_right_text = ($settings->english_copy_right_text) ? $settings->english_copy_right_text :'';
?>
     <footer class="footer footer-transparent d-print-none ">
      <div class="container">
        <div class="row">
          <div class="col-12 col-lg-auto mt-3 mt-lg-0 ">
            <ul class="list-inline list-inline-dots mb-0">
              <li class="list-inline-item"><?php echo $copy_right_text; ?></li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
    </div>
</div>

<!-- Libs JS -->
<script src="<?php echo $assets_url_var; ?>js/jquery.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var; ?>js/jquery-ui/jquery-ui.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<!-- <script src="<?php echo $assets_url_var; ?>js/bootstrap.min.js?v=<?php echo date('Ymdhis'); ?>"></script> -->
<script src="<?php echo $assets_url_var; ?>js/fontawesome.js?v=<?php echo date('Ymdhis'); ?>"></script>

<script src="<?php echo $assets_url_var;?>dist/libs/apexcharts/dist/apexcharts.min.js?v=<?php echo date('Ymdhis'); ?>"></script> 
<!-- tenrealm Core --> 
<script src="<?php echo $assets_url_var;?>dist/js/tenrealm.min.js?v=<?php echo date('Ymdhis'); ?>"></script>

<script src="<?php echo $assets_url_var;?>js/jquery.validate.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var;?>js/additional-methods.js?v=<?php echo date('Ymdhis'); ?>"></script>

<script src="<?php echo $assets_url_var;?>js/cryptojs-aes.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var;?>js/cryptojs-aes-format.js?v=<?php echo date('Ymdhis'); ?>"></script>

<script>
  var baseURL = "<?php echo base_url(); ?>";
  var csrf_name = $csrf_name = "<?php  echo $this->security->get_csrf_token_name(); ?>"; // for the name
  var csrf_token = $csrf_token = "<?php  echo $this->security->get_csrf_hash(); ?>";  // for the value
  var avatarImage = "<?php echo $dummy_user; ?>";
  var DecryptPassword = "<?php echo $this->_encpassword; ?>";
  
  $(document).ready(function() {

      $.fn.displayDecryptData = function(data){
        return CryptoJSAesJson.decrypt(data, DecryptPassword);
      }
    
      $('.copy-coinprice').tooltip();
  
     document.getElementById("copy_top_header").addEventListener("click", copy_password);
    function copy_password(e) {
      e.preventDefault();
      e.stopPropagation();

      var copyText = document.getElementById("copy_top_header");
      var textArea = document.createElement("textarea");

      document.body.appendChild(textArea);
      textArea.value = copyText.textContent;
      my_textarea = textArea;
      my_textarea.onfocus = function () {
       my_textarea.select();
       my_textarea.onfocus = undefined;
     } 
     // my_textarea.focus();
     // my_textarea.focus();
     my_textarea.select();
     document.execCommand("Copy");    
     textArea.remove();    
     document.getElementById("show_copied_to_clipboard").style.display = "flex";
     setTimeout(function() {
      var loader = document.getElementById("show_copied_to_clipboard");
      loader.style.transition = '.5s';
      // loader.style.opacity = '0';
      loader.style.visibility = 'none';
      loader.style.display = 'none';
    }, 1250);

   }
   });
</script>
<script>
// document.addEventListener("contextmenu", function(event){   event.preventDefault(); }, false);
// document.addEventListener('contextmenu', event => event.preventDefault());
// document.onkeydown = function(e) {
//   if(event.keyCode == 123) {
//      return false;
//   }
//   if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
//      return false;
//   }
//   if(e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) {
//      return false;
//   }
//   if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
//      return false;
//   }
//   if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
//      return false;
//   }
//   if(e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)){
//   return false;
//   }
// }

// $(document).keydown(function(e){     if(e.which === 123){ return false; } }); 

// // Disable right-click
// document.addEventListener('contextmenu', (e) => e.preventDefault());

// function ctrlShiftKey(e, keyCode) {
//   return e.ctrlKey && e.shiftKey && e.keyCode === keyCode.charCodeAt(0);
// }

// document.onkeydown = (e) => {
//   // Disable F12, Ctrl + Shift + I, Ctrl + Shift + J, Ctrl + U
//   if (
//     event.keyCode === 123 ||
//     ctrlShiftKey(e, 'I') ||
//     ctrlShiftKey(e, 'J') ||
//     ctrlShiftKey(e, 'C') ||
//     (e.ctrlKey && e.keyCode === 'U'.charCodeAt(0))
//   )
//     return false;
// };


// function ctrlShiftKey(e,t){return e.ctrlKey&&e.shiftKey&&e.keyCode===t.charCodeAt(0)}document.addEventListener("contextmenu",e=>e.preventDefault()),document.onkeydown=(e=>{if(123===event.keyCode||ctrlShiftKey(e,"I")||ctrlShiftKey(e,"J")||ctrlShiftKey(e,"C")||e.ctrlKey&&e.keyCode==="U".charCodeAt(0))return!1});

// Here #element is the id of element you want to hide
</script>