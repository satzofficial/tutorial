<section id="subscribe_sec">
    <div class="container">
        <div class="row">
            <div class="col-xl-7 m-auto">
                <div class="section_heading mb-4">
                    <h1>Subscribe Our Mailing List</h1>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 m-auto wow fadeInUp" data-wow-delay="0.2s">
                <div class="subscribe_form">
                    <?php
                        $action = base_url().'reg_subscribe';
                        $attributes = array('id'=>'reg_dsubscribe', "autocomplete"=>"off", "class"=>"auth_form","method"=>"post", "method"=>"post",  "autocomplete"=>"off"); 
                        echo form_open_multipart($action,$attributes);
                    ?>
                        <div class="form-group text-left">
                            <div class="pos_relative">
                                <input type="email" class="form-control input_anim" id="email" placeholder="Enter Your Email Address" name="email_detail" required="">
                                <span class="focus-border"><i></i></span>
                            </div>
                        </div>
                        <div class="text-center mt-3 mb-2"><button class="subscribe_btn" type="submit" name="emails_detail" value="Subscribe Now">Subscribe</button></div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
