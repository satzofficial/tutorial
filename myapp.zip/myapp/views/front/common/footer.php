<?php
$settings = $site_common['site_settings']; 
$class = $this->router->fetch_class();
$method = $this->router->fetch_method();

// $home_content = $this->common_model->getTableData('static_content',array('slug'=>'home_content'))->row();
// $sitelan = $this->session->userdata('site_lang');
// $copy_right_text = $sitelan."_copy_right_text";

$copy_right_text = ($settings->english_copy_right_text) ? $settings->english_copy_right_text :'';
// $content =  $sitelan."_content";
// $address = $sitelan."_address";
// $city = $sitelan."_city";
// $state = $sitelan."_state";
// $zip = $sitelan."_zip";
// $contact = $sitelan."_contactno";
?>
<!-- Footer Area Start -->
<div class="footer-section" style="display:none">
    <div class="container pt-120">
        <div class="row cus-mar pt-120 pb-120 justify-content-between wow fadeInUp">
            <div class="col-xl-6 col-lg-6 col-md-6 col-6">
                <div class="footer-box">
                    <a href="<?php echo $base_url_var; ?>" class="logo">
                        <img src="<?php echo $sitelogo; ?>" style="width: 100px;" alt="logo">
                    </a>
                    <p>A Time loop to survive in Modern World</p>
                    <div class="social-link d-flex align-items-center">
                        <a target="_blank" href="https://twitter.com/ten_realm"><i class="fab fa-twitter"></i></a>
                        <a target="_blank" href="https://www.youtube.com/channel/UCWSgnQuQuAZQNFzefNA4HEw"><i class="fab fa-youtube"></i></a>
                        <a target="_blank" href="https://www.instagram.com/tenrealm2022/"><i class="fab fa-instagram"></i></a>
                        <a target="_blank" href="https://t.me/tenrealm"><i class="fab fa-telegram"></i></a>
                    </div>

                </div>
            </div>

            <div class="col-xl-4 col-4">
                <div class="footer-box">
                    <h5>Support</h5>
                    <ul class="footer-link">
                        <li><a href="mailto:<?php echo $site_email; ?>"><span class="__cf_email__" data-cfemail=""><?php echo $site_email; ?></span></a></li>
                    </ul>                        
                </div>
                <div class="footer-box">
                    <ul class="footer-link">
                        <li><a href="<?php echo base_url('assets/tenrealm.mp4'); ?>" download ><span >Tenrealm Video</span></a></li>
                        <li><a href="<?php echo base_url('assets/tenrealm.pdf'); ?>" target="_blank" ><span >Tenrealm PDF</span></a></li>
                    </ul>                        
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="footer-bottom">
                    <div class="left">
                        <p> <?php echo $settings->english_copy_right_text; ?>
                        </p>
                    </div>
                    <div class="right">
                        <a href="#" class="cus-bor">Privacy </a>
                        <a href="#">Terms &amp; Condition </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php 

if($method == 'signup'){ ?>
    <div class="img-area">
        <img src="<?php echo $assets_url_var; ?>images/footer-Illu-left.png" class="left" alt="Images">
        <img src="<?php echo $assets_url_var; ?>images/footer-Illu-right.png" class="right" alt="Images">
    </div>
  <?php } ?>
</div>
<!-- Footer Area End -->

<!--==================================================================-->
<script src="<?php echo $assets_url_var; ?>js/jquery.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var; ?>js/jquery-ui.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var; ?>js/bootstrap.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var; ?>js/fontawesome.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var; ?>js/plugin/slick.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var; ?>js/waypoint.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var; ?>js/plugin/jquery.nice-select.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var; ?>js/wow.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<!--<script src="<?php echo $assets_url_var; ?>js/plugin/plugin.js?v=<?php echo date('Ymdhis'); ?>"></script>-->
<script src="<?php echo $assets_url_var; ?>js/main.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var; ?>js/main_1.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var;?>js/jquery.validate.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var;?>js/additional-methods.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script>
      // Slick in multiple tabs
    //   $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
    //     $('.slick-slider').resize();
    // });
</script>
<!-- <div id="notification" class="mdl-js-snackbar mdl-snackbar"> <div class="mdl-snackbar__text"></div> <button class="mdl-snackbar__action" type="button"></button> </div> -->

<?php if ($home_page_msg = $this->session->flashdata('home_page_info_msg')) { ?>
<link href="<?php echo $assets_url_var;?>css/toastr.css" rel="stylesheet"/>
<script src="<?php echo $assets_url_var;?>js/toastr.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
   
   var homePageMsg = "<?php echo $home_page_msg; ?>";
//success toast
    $.fn.totaster = (function(msg, type){
        if(msg =='') {return;}
        toastr.options = {
          "closeButton": true,
          "debug": true,
          "newestOnTop": false,
          "progressBar": true,
          "positionClass": "toast-top-right",
          "preventDuplicates": false,
          // "showDuration": "500",
          // "hideDuration": "1000000",
          // "timeOut": "5000",
          "extendedTimeOut": "1000",
          "showEasing": "swing",
          "hideEasing": "linear",
          // "showMethod": "fadeIn",
          // "hideMethod": "fadeOut"        
        }
        toastr[type](msg, "Tenrealm");
    });
    $.fn.totaster(homePageMsg, 'info');
    
  });
</script>
<?php } ?>
