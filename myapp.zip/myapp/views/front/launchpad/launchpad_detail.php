<?php $sitelan = $this->session->userdata('site_lang');
       $this->load->view('front/common/inner_header');
      $user_id=$this->session->userdata('user_id');
      $name = $sitelan."_name";
      $heading = $sitelan."_heading";
      $content = $sitelan."_content";
?>
<style type="text/css">
    .launch_text .progress-box{
        min-height: 140px;
    }
    .myclass:link { color: #ffffff}
    .myclass:hover { color: #0cb6c2; background-color: white; border-radius: 8px; padding:5px; }
</style>
<div class="launch-sec">
    <div class="space"></div>
    <section class="launch-hero">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="launch-hero-inner text-center">
                        <div class="space"></div>
                        <div class="spaceTwenty"></div>
                        <h2>Ixtoken Launchpad</h2>
                        <div class="spaceSmall"></div>
                        <p>A token launch platform for transformative projects</p>
                        <div class="spaceSmall"></div>
                        <a href="https://docs.google.com/forms/d/e/1FAIpQLScHK3sWkl4_E6iG9LMy7G7QqntFWeU1thvE0N8GUpCmEjjkAA/viewform" class="launch-btn">Apply to Launchpad</a>
                        <div class="space"></div>
                        <div class="spaceTwenty"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="space"></div>
    </section>
    <section class="progress-sec">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <p class="progress-text">Ongoing</p>
                </div>
            </div>
            <div class="row">
                <?php 

                    
                    // echo "<pre>";
                    // print_r($responseData);
                    //print_r($responseData[0]->current_price);
                    if (count($activetoken) > 0) 
                    {
                        $i = 1; 
                        foreach($activetoken as $result) 
                        {                
                            /*$url = file_get_contents("https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=".$result->token_coin_fullname);
                            $responseData = json_decode($url); */
                            $api_key = getSiteSettings('cryptocompare_apikey');
                            $url = "https://min-api.cryptocompare.com/data/price?fsym=ETH&tsyms=USD&api_key=".$api_key;
                            $chs = curl_init();
                            curl_setopt($chs, CURLOPT_URL, $url);
                            curl_setopt($chs, CURLOPT_RETURNTRANSFER, 1);
                            $result1 = curl_exec($chs);
                            $responseData = json_decode($result1);
                            $usd_rate = $responseData->USD;              
                            $sales = $this->common_model->getTableData("transactions", array("token_symbol" => $result->token_coin_symbol, "type" => "Launchwithdraw","status"=>"Completed"))->row();
                            $sale_amount = $sales->transfer_amount;
                            $total_token = $result->token_sale;
                            $rewards = ($sale_amount/$total_token) * 100;
                            $rewards = number_format($rewards,2);
                            $single_token_value = $result->single_token_value;
                            $token_usd_rate = $usd_rate * $single_token_value;

                            $sold_token = $this->common_model->customQuery("SELECT SUM(transfer_amount) as sold_amount from ixtoken_transactions where token_symbol = '".$result->token_coin_symbol."' AND type = 'Launchwithdraw' AND status = 'Completed' ")->row();
                            $remaining_token = $total_token - $sold_token->sold_amount;

                            $rem_percent = ($sold_token->sold_amount/$total_token) * 100;


                ?>
                            <div class="col-lg-4"  >
                                <div class="progress-box mobile-mar-b-15" >
                                    <span class="progress-label">Ongoing</span>
                                    <div class="space"></div>
                                    <div class="spaceTwenty"></div>
                                    <div class="text-center">                                          
                                        <?php
                                            $img_url = front_img()."progress-img.svg";
                                            if(!empty(trim($result->token_logo)))
                                            {
                                                $img_url = $result->token_logo;
                                        ?>
                                                <style type="text/css">
                                                    .token-img {
                                                        width: 64px;
                                                         height: 64px;
                                                </style>
                                        <?php
                                            }
                                        ?>
                                        <img src="<?=$img_url?>" class="token-img">
                                    </div>
                                    <div class="spaceTwenty"></div>
                                    <h3 class="text-center"><?= $result->token_coin_fullname .'&nbsp'.$result->token_coin_symbol ?></h3>
                                    <div class="spaceTwenty"></div>
                                    <?php
                                        if(!empty(trim($result->launchpad_decription)))
                                        {
                                    ?>
                                        <h5 class="text-center">
                                            <?=ucwords($result->launchpad_decription)?>
                                            <!-- IEO purchase 
                                            <span id="token_symbol"><?php echo "ETH"; ?></span>, Earn <span id="token_symbol"><?php echo $result->token_coin_symbol; ?></span> -->
                                        </h5>
                                    <?php
                                        }
                                    ?>
                                    <div class="spaceTwenty"></div>
                                    <a href="<?php echo base_url(); ?>launchpad_buy/<?= $result->token_coin_symbol; ?>" class="progress-box-btn">Purchase</a>
                                    <div class="spaceTwenty"></div>
                                    <?php
                                            if(!empty($responseData))
                                            {
                                               
                                        ?>
                                    <div class="d-flex justify-content-between reward-text">
                                        
                                            <span style="width: 100%;" class="text-center"><?php echo '1 ' . $result->token_coin_symbol ?>
                                            - <?=number_format((float)$token_usd_rate,2)?> USD</span> 
                                        
                                    </div>
                                    <?php 
                                            }
                                        ?>
                                    <div class="spaceTwenty"></div>
                                    <?php
                                        $tot_diff =date_diff(date_create($result->start_date),date_create(date('Y-m-d')));
                                        $current_diff =date_diff(date_create($result->start_date),date_create($result->expire_date));

                                        $process = ($current_diff/$tot_diff) * 100;
                                       //echo $rewards.'%';
                                        echo trailingZeroes(numberFormatPrecision($sold_token->sold_amount));
                                    ?>
                                    <div class="reward-progress">
                                        <div class="progress" style="height: 10px;">
                                            
                                          <div class="progress-bar" role="progressbar" style="width: <?=trailingZeroes(numberFormatPrecision($rewards))?>%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>                                     
                                        </div>
                                    </div>
                                    <div class="spaceTwenty"></div>
                                    <div class="d-flex justify-content-between reward-text">
                                        <span>IEO Period:</span>
                                        <span>
                                            <?php
                                              $diff =date_diff(date_create($result->start_date),date_create($result->expire_date));
                                              echo $diff->format("%R%a days");
                                            ?>
                                        </span>
                                    </div>
                                    <div class="spaceTwenty"></div>
                                    <div class="d-flex justify-content-between reward-text">
                                        <span>IEO Start Time:</span>
                                        <span><?= date('Y-m-d', strtotime($result->start_date)) ?></span>
                                    </div>
                                    <div class="spaceTwenty"></div>
                                    <div class="d-flex justify-content-between reward-text">
                                        <span>IEO End Time:</span>
                                        <span><?= date('Y-m-d', strtotime($result->expire_date)) ?></span>
                                    </div>
                                </div>
                            </div>
                <?php 
                        }
                    }else {
                        echo '<div>';
                        echo '<span style="margin-left: 30px;">' . 'No Records Found!!' . '</span>';
                        echo '</div>';
                    } 
                ?>
            </div>
            <div class="row mt-3">
                <div class="col-lg-12">
                    <p class="progress-text">Upcoiming IEO</p>
                </div>
            </div>
            <div class="row">
                <?php
                    if (count($upcoming) > 0) 
                    {
                        $i = 1; 
                        foreach($upcoming as $result_upcoming) 
                        {
                ?>
                            <div class="col-lg-4">
                                <div class="progress-box mobile-mar-b-15 pad-0">
                                    <span class="progress-label complete">Upcoming</span>
                                    <div class="space"></div>
                                    <div class="spaceTwenty"></div>
                                    <div class="text-center">
                                        <?php
                                            $img_url = front_img()."progress-img.svg";
                                            if(!empty(trim($result_upcoming->token_logo)))
                                            {
                                                $img_url = $result_upcoming->token_logo;
                                        ?>
                                                <style type="text/css">
                                                    .token-img {
                                                        width: 64px;
                                                         height: 64px;
                                                </style>
                                        <?php
                                            }
                                        ?>
                                        <img src="<?=$img_url?>" class="token-img">
                                    </div>
                                    <div class="spaceTwenty"></div>
                                    <div class="progress-body">
                                        <h3 class="text-left pb-2"><?= $result_upcoming->token_coin_fullname .'&nbsp'.$result_upcoming->token_coin_symbol ?></h3>
                                        <div class="spacesmall"></div>
                                         <?php
                                        if(!empty(trim($result_upcoming->launchpad_decription)))
                                        {
                                    ?>
                                        <h5 class="text-left"><?=ucwords($result_upcoming->launchpad_decription)?></h5>
                                        <?php
                                        }
                                    ?>
                                        <div class="spaceTwenty"></div>
                                        <div class="d-flex justify-content-between reward-text">
                                            <span>Session Supply</span>
                                            <span><?=$result_upcoming->token_sale?></span>
                                        </div>
                                        <div class="spaceTwenty"></div>
                                        <div class="d-flex justify-content-between reward-text">
										    <span>Start time</span>
                                            <b><span><?= date('Y-m-d  H:i:s', strtotime($result_upcoming->start_date)) ?></span></b>
                                        </div>
                                        <div class="d-flex justify-content-between reward-text">
                                            <span>End time</span>
                                           <b> <span><?= date('Y-m-d  H:i:s', strtotime($result_upcoming->expire_date)) ?></span></b>
                                        </div>
                                    </div>
                                </div>
                            </div>
                <?php 
                        }
                    }else {
                        echo '<div>';
                        echo '<span style="margin-left: 30px;">' . 'No Records Found!!' . '</span>';
                        echo '</div>';
                    }
                ?>
            </div>
            <div class="row mt-3">
                <div class="col-lg-12">
                    <p class="progress-text">Ended IEO</p>
                </div>
            </div>
            <div class="row">
                <?php
                    if (count($expiredtoken) > 0) 
                    {
                        $i = 1; 
                        foreach($expiredtoken as $result_exipred) 
                        {
                           $sales = $this->common_model->customQuery("SELECT SUM(transfer_amount) as remaining_amount from ixtoken_transactions where token_symbol = '".$result_exipred->token_coin_symbol."' AND type = 'Launchwithdraw' AND status = 'Completed' ")->row();
                          
                            $sale_amount = $sales->remaining_amount;
                            $total_token = $result_exipred->token_sale;
                            $rewards = ($sale_amount/$total_token) * 100;
                            $rewards = number_format($rewards,2);
                ?>
                            <div class="col-lg-4">
                                <div class="progress-box mobile-mar-b-15 pad-0">
                                    <span class="progress-label complete">Ended</span>
                                    <div class="space"></div>
                                    <div class="spaceTwenty"></div>
                                    <div class="text-center">
                                        <?php
                                            $img_url = front_img()."progress-img.svg";
                                            if(!empty(trim($result_exipred->token_logo)))
                                            {
                                                $img_url = $result_exipred->token_logo;
                                        ?>
                                                <style type="text/css">
                                                    .token-img {
                                                        width: 64px;
                                                         height: 64px;
                                                </style>
                                        <?php
                                            }
                                        ?>
                                        <img src="<?=$img_url?>" class="token-img">
                                    </div>
                                    <div class="spaceTwenty"></div>
                                    <div class="progress-body">
                                        <h3 class="text-left pb-2"><?= $result_exipred->token_coin_fullname .'&nbsp'.$result_exipred->token_coin_symbol ?></h3>
                                        <div class="spacesmall"></div>
                                         <?php
                                        if(!empty(trim($result_exipred->launchpad_decription)))
                                        {
                                    ?>
                                        <h5 class="text-left"><?=ucwords($result_exipred->launchpad_decription)?></h5>
                                        <?php
                                        }
                                    ?>
                                        <div class="spaceTwenty"></div>
                                        <div class="d-flex justify-content-between reward-text">
                                            <span>Session Supply</span>
                                            <span><?=$result_exipred->token_sale?></span>
                                        </div>
                                        <div class="spaceTwenty"></div>
                                        <?php echo $rewards.'%'; ?>
                                        <div class="reward-progress">
                                        <div class="progress" style="height: 10px;">
                                            
                                            <div class="progress-bar" role="progressbar" style="width: <?=$rewards?>%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                       </div>
                                        <div class="spaceTwenty"></div>
                                        <div class="d-flex justify-content-between reward-text">
                                            <span>End time</span>
                                            <span><?= date('Y-m-d', strtotime($result_exipred->expire_date)) ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                <?php 
                        }
                    }else {
                        echo '<div>';
                        echo '<span style="margin-left: 30px;">' . 'No Records Found!!' . '</span>';
                        echo '</div>';
                    }
                ?>
            </div>
        </div>
    </section>
    <br/>
</div>
  <?php $this->load->view('front/common/footer'); ?>
 <?php $this->load->view('front/common/scripts'); ?>
</body>
</html>