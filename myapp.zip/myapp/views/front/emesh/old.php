<!DOCTYPE html>
<?php

// echo '<pre>';print_r($site_common['site_settings']);exit;
$favicon  =  ($site_common['site_settings']->site_favicon) ? $site_common['site_settings']->site_favicon :'';
$english_site_name  =  ($site_common['site_settings']->english_site_name) ? $site_common['site_settings']->english_site_name :'';
$sitelogo = ($site_common['site_settings']->site_logo) ? $site_common['site_settings']->site_logo :'';
$site_email = ($site_common['site_settings']->site_email) ? $site_common['site_settings']->site_email :'';
$assets_url_var = base_url('assets/front/');
$base_url_var = base_url();
$csrf_name = $this->security->get_csrf_token_name(); // for the name
$csrf_token = $this->security->get_csrf_hash();  // for the value
$class = $this->router->fetch_class();
$method = $this->router->fetch_method();
    ?>
    <link rel="stylesheet" href="<?php echo $assets_url_var; ?>css/select2.min.css?v=<?php echo date('Ymdhis'); ?>">

<style>
    .form--control.style--two {
    padding-left: 65px;
    background: transparent;
}
select.form--control {
    color: rgba(255, 255, 255, 0.8);
}
.form-select {
    display: block;
    width: 100%;
    padding: 0.375rem 2.25rem 0.375rem 0.75rem;
    -moz-padding-start: calc(0.75rem - 3px);
    font-size: 1rem;
    font-weight: 400;
    line-height: 1.5;
    color: #212529;
    background-color: #fff;
    background-image: url(data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M2 5l6 6 6-6'/%3e%3c/svg%3e);
    background-repeat: no-repeat;
    background-position: right 0.75rem center;
    background-size: 16px 12px;
    border: 1px solid #ced4da;
    border-radius: 0.25rem;
    transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
}
</style>

<html lang="en">


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="<?php echo $csrf_name ?>" content="<?php echo $csrf_token; ?>">
    <title><?php echo $english_site_name; ?></title>
    <link rel="shortcut icon" href="<?php echo $favicon; ?>" type="image/x-icon">
    <!-- bootstrap 5  -->
    <link rel="stylesheet" href="<?php echo base_url();?>css/assets/css/lib/bootstrap.min.css">
    <!-- Icon Link  -->
    <link rel="stylesheet" href="<?php echo base_url();?>css/assets/css/all.min.css"> 
    <link rel="stylesheet" href="<?php echo base_url();?>css/assets/css/line-awesome.min.css"> 
    <link rel="stylesheet" href="<?php echo base_url();?>css/assets/css/lib/animate.css"> 

    <!-- Plugin Link -->
    <link rel="stylesheet" href="<?php echo base_url();?>css/assets/css/lib/slick.css">

    <!-- Main css -->
    <link rel="stylesheet" href="<?php echo base_url();?>css/assets/css/main.css">


<style>
    .sel_bx_set{}
    .sel_bx_set .select2-container .select2-selection--single .select2-selection__rendered{padding-left: 0px;}
    .sel_bx_set .select2-container--default .select2-selection--single .select2-selection__arrow {
        height: 26px;
        position: absolute;
        top: 12px;
        right: 15px;
        width: 20px;

    }
    .sel_bx_set .selection{width:100%;}
    .sel_bx_set .select2.select2-container.select2-container--default {
        width: 100% !important;
    }
    .sel_bx_set .select2-selection.select2-selection--single {
        background-color: #f5faff !important;
        border: 1px solid #EEF1FF !important;
        width: 100% !important;
        padding: 10px 20px !important;
        color: #1E266D !important;
        font-family: var(--body-font) !important;
        height: 50px !important;
    }
.pas_set{
    position: relative;
}
.pas_ico{
    position: absolute;
    top:43px;
    right:15px;
}    

.ui-datepicker select.ui-datepicker-month, .ui-datepicker select.ui-datepicker-year {
    width: 50%;
}

.terms_and_condition{
 width: 10%;
 padding: 2px 3px;   
}
.error{
    color : red;
}
</style>
</head>
    <body data-bs-spy="scroll" data-bs-offset="170" data-bs-target=".privacy-policy-sidebar-menu">

        <div class="overlay"></div>
 <div class="preloader">
            <div class="scene" id="scene">
                <input type="checkbox" id="andicator" />
                   <span class="loader"></span>
                   <style>
                       .loader {
            width: 48px;
            height: 48px;
            position: relative;
            animation : rotate 4s linear infinite;
          }
          .loader:before,
          .loader:after {
            content:"";
            display: block;
            border: 24px solid;
            border-color: transparent transparent #fff  #fff;
            position: absolute;
            left: 0;
            top: 0;
            animation: mvx 1s infinite ease-in;
          }
          .loader:before {
            left: -1px;
            top: 1px;
            border-color:#FF3D00  #FF3D00 transparent transparent;
            animation-name:mvrx;
          }

          @keyframes rotate {
            100% {transform: rotate(360deg)}
          }
          @keyframes mvx {
            0% , 15% {transform: translate(0 , 0) rotate(0deg)}
            50% {transform: translate(-50% , 50%) rotate(180deg)}
            100% {transform: translate(0% , 0%) rotate(180deg)}
          }
          @keyframes mvrx {
            0% , 15%  {transform: translate(0 , 0) rotate(0deg)}
            50% {transform: translate(50% , -50%) rotate(180deg)}
            100% {transform: translate(0% , 0%) rotate(180deg)}
          }
    
                   </style>
             
            </div>
        </div>

    <div class="header">
    <div class="container">
        <div class="header-bottom">
            <div class="header-bottom-area align-items-center">
                <div class="logo"><a href="index.html"><img src="<?php echo base_url();?>css/assets/images/logos.png" alt="logo"></a></div>
                <ul class="menu">
                    <li>
                        <a href="<?php echo base_url();?>">Home</a>
                    </li>
            <!--         <li>
                        <a href="about.html">About</a>
                    </li>
                    <li>
                        <a href="games.html">Games <span class="badge badge--sm badge--base text-dark">NEW</span></a>
                    </li>
                    <li>
                        <a href="faq.html">Faq</a>
                    </li> -->
                   <!--  <li>
                        <a href="#0">Pages</a>
                        <ul class="sub-menu">
                            <li>
                                <a href="dashboard.html">User Dashboard</a>
                            </li>
                            <li>
                                <a href="game-details.html">Game Details</a>
                            </li>
                            <li>
                                <a href="policy.html">Privacy Policy</a>
                            </li>
                            <li>
                                <a href="terms-conditions.html">Terms & Conditions</a>
                            </li>
                            <li>
                                <a href="sign-in.html">Sign In</a>
                            </li>
                            <li>
                                <a href="sign-up.html">Sign Up</a>
                            </li>
                        </ul>
                    </li> -->
                <!--     <li>
                        <a href="#0">Blog</a>
                        <ul class="sub-menu">
                            <li><a href="blog.html">Blog</a></li>
                            <li><a href="blog-details.html">Blog Details</a></li>
                        </ul>
                    </li> -->
                  <li>
                        <a href="<?php echo base_url();?>signup">Sign Up</a>
                    </li>
                     <li>
                        <a href="<?php echo base_url();?>signin">Sign In</a>
                    </li>


                    <button class="btn-close btn-close-white d-lg-none"></button>
                </ul>
                <div class="header-trigger-wrapper d-flex d-lg-none align-items-center">
                    <div class="header-trigger me-4">
                        <span></span>
                    </div>
                    <a href="sign-in.html" class="cmn--btn active btn--md d-none d-sm-block">Sign In</a>
                </div>
            </div>
        </div>
    </div>
</div>
    <!-- inner hero section start -->
<section class="inner-banner bg_img">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-7 col-xl-6 text-center">
        <h2 class="title text-white">Sign Up</h2>
        <ul class="breadcrumbs d-flex flex-wrap align-items-center justify-content-center">
          <li><a href="index.html">Home</a></li>
          <li>Sign Up</li>
        </ul>
      </div>
    </div>
  </div>
</section>
<!-- inner hero section end -->
  <?php $this->load->view('front/common/flashmessage'); ?>
    

    <!-- Account Section Starts Here -->
    <section class="account-section overflow-hidden bg_img">
        <div class="container">
            <div class="account__main__wrapper">
                <div class="account__form__wrapper sign-up">
                  

                     <?php
                        if(validation_errors()){
                          $error =  validation_errors();
                          echo '<div class="note note-danger">
                          <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$error.'</div>';
                      }
                      $attributes=array('class'=>'form-horizontal','id'=>'subForm', 'autocomplete' => "off" );
                      echo form_open($action,$attributes);                                         
                      ?>
                   <div class="account__form form row g-4">
                        <div class="col-xl-6 col-md-6">
                            <div class="form-group">
                                <div for="fname" class="input-pre-icon"><i class="las la-user"></i></div>
                                <input id="referral" name="parent" type="text"  value="<?php 
                                if($this->input->get('ref')){
                                    echo $this->input->get('ref');
                                }
                                ?>" class="form--control form-control style--two" placeholder="Enter the referral code" >
                                 <?php 
                                if($this->input->get('ref')){
                                    $ref = $this->input->get('ref');
                                        // echo '<a href=""><span style="color: #1a4dbe;">'.$ref.'</span></a>';
                                }else{
                                        // echo  '<p>Don\'t Have Sponser ID? ';
                                        // echo '<a href="javascript:;" class="click_here_cls"><span style="color: #1a4dbe;">Click Here</span></a>';
                                        // echo '</p>';
                                }?>
                            </div>
                        </div>
                        <div class="col-xl-6 col-md-6">
                            <div class="form-group">
                                <div for="lname" class="input-pre-icon"><i class="las la-user"></i></div>
                                <input id="first_name"  name="first_name" type="text" class="form--control form-control style--two" placeholder="first name" required>
                            </div>
                        </div>

                          <div class="col-xl-6 col-md-6">
                            <div class="form-group">
                                <div for="lname" class="input-pre-icon"><i class="las la-user"></i></div>
                                <input name="last_name" type="text" class="form--control form-control style--two" placeholder="last name" required>
                            </div>
                        </div>




                        <div class="col-xl-6 col-md-6">
    <div class="form-group">
                                <!--<div for="lname" class="input-pre-icon"><i class="las la-user"></i></div>-->
                                <!--<input name="country" type="text" class="form--control form-control style--two" placeholder="country name" required>-->
                                
                                
                                
                                <div class="form-group">
                                <div for="country" class="input-pre-icon"><i class="las la-globe"></i></div>
                                <select  name="country" class="form-select form--control style--two">
                                    <option value="Bangladesh" >Bangladesh</option>
                                    <option value="India">India</option>
                                    <option value="Pakistan" >Pakistan</option>
                                </select>
                            </div>
                                
                                
                                
                                
                                
                                
                            </div>
                        </div>
                        <div class="col-xl-6 col-md-6">
                            <div class="input-group">
                                <span class="input-group-text text--base style--two"></span>
                                <input type="text"  name="phone" id="phone" class="form--control form-control style--two" placeholder="Phone Number">
                            </div>
                        </div>
                        <div class="col-xl-6 col-md-6">
                            <div class="form-group">
                                <div for="email" class="input-pre-icon"><i class="las la-envelope"></i></div>
                                <input id="tenrealm_email" type="email" name="tenrealm_email" class="form--control form-control style--two" placeholder="Email" required>
                            </div>
                        </div>
                        <div class="col-xl-6 col-md-6">
                            <div class="form-group">
                                <div for="username" class="input-pre-icon"><i class="las la-user"></i></div>
                                <input id="datepicker" name="dob" type="text" class="form--control form-control style--two" placeholder="Date Of Birth" required>
                            </div>
                        </div>
                        <div class="col-xl-6 col-md-6">
                            <div class="form-group">
                                <div for="pass" class="input-pre-icon"><i class="las la-lock"></i></div>
                                <input type="password" id="tenrealm_password"  name="tenrealm_password" class="form--control form-control style--two" placeholder="Password" required>
                            </div>
                        </div>
                        <div class="col-xl-6 col-md-6">
                            <div class="form-group">
                                <div for="pass" class="input-pre-icon"><i class="las la-lock"></i></div>
                                <input type="password" name="cnfm_password" id="cnfm_password" class="form--control form-control style--two" placeholder="Confirm Password" required>
                            </div>
                        </div>

                    <!--      <div class="col-xl-6 col-md-6">
                            <div class="form-group">
                                <label id="ebcaptchatext"></label>
                                   <input type="hidden" name="number1" id="number1" value="">
                                <input type="hidden" name="number2" id="number2" value="">
                                <input id="pass" type="text" name="ebcaptchainput" id="ebcaptchainput" class="form--control form-control style--two">
                            </div>
                        </div> -->
<!--  <div class="col-xl-6 col-md-6"> -->
                           <!--  <div class="form-group">
                                <div for="pass" class="input-pre-icon"><i class="las la-lock"></i></div>
                                <input type="checkbox" name="terms_and_condition" id="terms_and_condition" class="form--control form-control style--two" pvalue="1" checked="checked">
                            </div> -->
                      <!--   </div>
 -->
                        <div class="col-lg-12">
                            <div class="form-group">
                                <!-- <button class="cmn--btn active w-100 btn--round" type="submit">Sign Up</button> -->

                                <input type="submit" name="btnsubmit" class="cmn--btn active w-100 btn--round" value="Sign Up"/>
                            </div>
                        </div>
                    </form>
                </div>
               
             
            </div>
        </div>
    </section>
    <!-- Account Section Ends Here -->


    <!-- Footer Section Starts Here -->
<!-- <footer class="footer-section bg_img" style="background: url(<?php echo base_url();?>css/assets/images/footer/bg.jpg) center;">
    <div class="footer-top">
        <div class="container">
            <div class="footer-wrapper d-flex flex-wrap align-items-center justify-content-md-between justify-content-center">
                <div class="logo mb-3 mb-md-0"><a href="index.html"><img src="<?php echo base_url();?>css/assets/images/logo.png" alt="logo"></a></div>
                <ul class="footer-links d-flex flex-wrap justify-content-center">
                    <li><a href="games.html">Games</a></li>
                    <li><a href="terms-conditions.html">Terms & Conditions</a></li>
                    <li><a href="policy.html">Privacy Policy</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <div class="footer-wrapper d-flex flex-wrap justify-content-center align-items-center text-center">
                <p class="copyright text-white">Copyrights &copy; 2021 All Rights Reserved by <a href="#0" class=" text--base ms-2">Viserlab</a></p>
            </div>
        </div>
    </div>
    <div class="shapes">
        <img src="<?php echo base_url();?>css/assets/images/footer/shape.png" alt="footer" class="shape1">
    </div>
</footer> -->
<!-- Footer Section Ends Here -->
    <?php  include realpath(dirname(__DIR__) . '/common/footer.php'); ?>
<script src="<?php echo $assets_url_var; ?>js/select2.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<!-- jQuery library -->
 <script src="<?php echo base_url();?>css/assets/js/lib/jquery-3.6.0.min.js"></script> 
<!-- bootstrap 5 js -->
 <script src="<?php echo base_url();?>css/assets/js/lib/bootstrap.min.js"></script> 

<!-- Pluglin Link -->
<script src="<?php echo base_url();?>css/assets/js/lib/slick.min.js"></script>

<!-- main js -->
<script src="<?php echo base_url();?>css/assets/js/main.js"></script>  

<script>
    var baseURL = "<?php echo base_url(); ?>";
var csrf_name = "<?php  echo $this->security->get_csrf_token_name(); ?>"; // for the name
var csrf_token = "<?php  echo $this->security->get_csrf_hash(); ?>";  // for the value    

$(function(){
  // $('#subForm').ebcaptcha();
});

(function($){

    $(".sel_bx").select2();

     $( function() {
        // $( "#datepicker" ).datepicker();
        $('#datepicker').datepicker({changeYear: true, buttonImageOnly: true, yearRange: "-50:+0", changeMonth: true, dateFormat: 'mm-dd-yy'});
    });

    jQuery.fn.ebcaptcha = function(options){

        var element = this;
        var input = this.find('#ebcaptchainput');
        var label = this.find('#ebcaptchatext');

        var randomNr1 = 0;
        var randomNr2 = 0;
        var totalNr = 0;

        randomNr1 = Math.floor(Math.random()*10);
        randomNr2 = Math.floor(Math.random()*10);
        
        $('#number1').val(randomNr1);
        $('#number2').val(randomNr2);

        totalNr = randomNr1 + randomNr2;
        var texti = "What is "+randomNr1+" + "+randomNr2;
        $(label).text(texti);
    };

})(jQuery);


$(document).ready(function () {


    var _inpname1 = $('.inp1_uppercase');
    _inpname1.keypress(function () {
        var _val = _inpname1.val();
        var _txt = _val.charAt(0).toUpperCase() + _val.slice(1);
        _inpname1.val(_txt);
    })


    var _inpname2 = $('.inp2_uppercase');
    _inpname2.keypress(function () {
        var _val = _inpname2.val();
        var _txt = _val.charAt(0).toUpperCase() + _val.slice(1);
        _inpname2.val(_txt);
    })

    $.validator.addMethod('totalCheck', function(value, element, params) {
        var field_1 = $('#number1').val(),
        field_2 = $('#number2').val();
        return parseInt(value) === (parseInt(field_1) + parseInt(field_2));
    }, "Enter the valid number");


    $.validator.addMethod("strong_password", function (value, element) {
        let password = value;
        if (!(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[@#$%&])(.{8,20}$)/.test(password))) {
            return false;
        }
        return true;
    }, function (value, element) {
        let password = $(element).val();
        if (!(/^(.{8,20}$)/.test(password))) {
            return 'Password must be between 8 to 20 characters long.';
        }
        else if (!(/^(?=.*[A-Z])/.test(password))) {
            return 'Password must contain at least one uppercase.';
        }
        else if (!(/^(?=.*[a-z])/.test(password))) {
            return 'Password must contain at least one lowercase.';
        }
        else if (!(/^(?=.*[0-9])/.test(password))) {
            return 'Password must contain at least one digit.';
        }
        else if (!(/^(?=.*[@#$%&])/.test(password))) {
            return "Password must contain special characters from @#$%&.";
        }
        return false;
    });

        $('#subForm').validate({ // initialize the plugin
            rules: {

                parent: {
                    required: {
                        depends:function(){
                            $(this).val($.trim($(this).val()));
                            return true;
                        }
                    },
                    // remote: baseURL + "is-ref-exist"           
                },
                first_name: {
                    required: {
                        depends:function(){
                            $(this).val($.trim($(this).val()));
                            return true;
                        }
                    },           
                },
                last_name: {
                    required: {
                        depends:function(){
                            $(this).val($.trim($(this).val()));
                            return true;
                        }
                    },
                },
                tenrealm_email: {
                    required: {
                        depends:function(){
                            $(this).val($.trim($(this).val()));
                            return true;
                        }
                    },
                    email: true,                     
                    remote: baseURL + "is-email-exist"
                },
                tenrealm_password: {
                    required: true,
                    minlength: 5,
                    strong_password:true
                },
                cnfm_password: {
                    required: true,
                    minlength: 5,
                    equalTo: "#tenrealm_password"
                },
                ebcaptchainput: {
                    required: {
                        depends:function(){
                            $(this).val($.trim($(this).val()));
                            return true;
                        }
                    },
                    totalCheck: true
                },
                beb_address: {
                    required: {
                            depends:function(){
                            $(this).val($.trim($(this).val()));
                            return true;
                        }    
                    },
                    remote: baseURL + "is-beb-exist"
                },                
            },
            messages:{
             tenrealm_email: {                
                remote: jQuery.validator.format("This {0} is already exists!.")
            },
            parent: {                
                remote: jQuery.validator.format("This {0} is not valid referral!.")
            },
            beb_address: {                
                remote: jQuery.validator.format("This {0} is already exists!.")
            },

        }
    });


        // $(document).on('click', '.click_here_cls', function(event) {
        //     event.preventDefault();
            /* Act on the event */
            // $('#referral').val("<?php //echo (REGISTER_VAR) ? REGISTER_VAR :''; ?>");
        // });

    });

</script>

</body>
</html>