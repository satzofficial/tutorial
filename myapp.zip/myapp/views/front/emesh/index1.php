<!DOCTYPE html>
<html lang="ru">


<!-- Mirrored from demo.artureanec.com/html/cryptoland/demo_4/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 11 Jun 2023 07:08:31 GMT -->
<head>

   <meta charset="utf-8">
   <!-- <base href="/"> -->

   <title>Emush</title>
   <meta name="description" content="">

   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
   
   <!-- Template Basic Images Start -->
   <meta property="og:image" content="path/to/image.html">
   <link rel="icon" href="<?php echo base_url();?>new_css/img/favicon/favicon.ico">
   <link rel="apple-touch-icon" sizes="180x180" href="<?php echo base_url();?>new_css/img/favicon/apple-touch-icon-180x180.png">
   <!-- Template Basic Images End -->
   
   <!-- Custom Browsers Color Start -->
   <meta name="theme-color" content="#000">
   <!-- Custom Browsers Color End -->

   <link rel="stylesheet" href="<?php echo base_url();?>new_css/css/main.min.css">
<script src="jquery-3.6.4.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

<style>
form label {
  display: inline-block;
  width: 100px;
}

form div {
  margin-bottom: 10px;
}

.error {
  color: red;
  margin-left: 5px;
}

label.error {
  display: inline;
}
</style>



   <!-- Load google font
   ================================================== -->
   <script type="text/javascript">
      WebFontConfig = {
         google: { families: [ 'Catamaran:300,400,600,700', 'Raleway:100,700', 'Roboto:700,900'] }
      };
      (function() {
         var wf = document.createElement('script');
         wf.src = ('https:' == document.location.protocol ? 'https' : 'http') + 
         '://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js';
         wf.type = 'text/javascript';
         wf.async = 'true';
         var s = document.getElementsByTagName('script')[0];
         s.parentNode.insertBefore(wf, s);
      })();
   </script>

   <!-- Load other scripts
   ================================================== -->
   <script type="text/javascript">
      var _html = document.documentElement;
      _html.className = _html.className.replace("no-js","js");
   </script>

   <style>.preloader{width: 100%;height: 100%;position: fixed;background-color: #fff;z-index: 9999;}</style>

</head>

<body>

   <div class="preloader"></div>

   <div class="wrapper">

      <header class="header">
         <a href="#" class="logo">
            <div class="logo__img"></div>
              
      
         </a>

         <ul class="menu">
            <li class="menu__item">
               <a href="#about" class="menu__link">About</a>
            </li>
            <li class="menu__item">
               <a href="#services" class="menu__link">Services</a>
            </li>
            <li class="menu__item">
               <a href="#map" class="menu__link">Road Map</a>
            </li>
            <li class="menu__item">
               <a href="#stat" class="menu__link">Statistic</a>
            </li>
            <li class="menu__item">
               <a href="#token" class="menu__link">Token</a>
            </li>
            <li class="menu__item">
               <a href="#docs" class="menu__link">WhitePappers</a>
            </li>
            <li class="menu__item">
               <a href="#team" class="menu__link">Team</a>
            </li>
            <li class="menu__item">
               <a href="#faq" class="menu__link">FAQ</a>
            </li>
              <li class="menu__item">
               <a href="https://emush.net/signup" class="menu__link">Register
            </li>
              <li class="menu__item">
               <a href="https://emush.net/signin" class="menu__link">Login
            </li>
         </ul>

         <div class="header__right">
            <select class="select">
               <option value="ru">ru</option>
               <option value="ua">ua</option>
               <option value="en">en</option>
            </select>
            <div class="sign-in-wrap">
               <a href="#" class="btn-sign-in">Join Emush ICO</a>  
            </div>
         </div>

         <div class="btn-menu">
            <div class="one"></div>
            <div class="two"></div>
            <div class="three"></div>
         </div>
      </header>

      <div class="fixed-menu">
         <div class="fixed-menu__header">
            <a href="#" class="logo">
               <div class="logo__img"></div>
               <div class="logo__title">Emush</div>
            </a>
   
            <div class="btn-close">
                  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 47.971 47.971" style="enable-background:new 0 0 47.971 47.971;" xml:space="preserve" width="512px" height="512px">
                     <path d="M28.228,23.986L47.092,5.122c1.172-1.171,1.172-3.071,0-4.242c-1.172-1.172-3.07-1.172-4.242,0L23.986,19.744L5.121,0.88   c-1.172-1.172-3.07-1.172-4.242,0c-1.172,1.171-1.172,3.071,0,4.242l18.865,18.864L0.879,42.85c-1.172,1.171-1.172,3.071,0,4.242   C1.465,47.677,2.233,47.97,3,47.97s1.535-0.293,2.121-0.879l18.865-18.864L42.85,47.091c0.586,0.586,1.354,0.879,2.121,0.879   s1.535-0.293,2.121-0.879c1.172-1.171,1.172-3.071,0-4.242L28.228,23.986z" fill="#006DF0"/></svg>
            </div>
         </div>
   
         <div class="fixed-menu__content">
   
            <ul class="mob-menu">
               <li class="mob-menu__item">
                  <a href="#about" class="mob-menu__link">About</a>
               </li>
               <li class="mob-menu__item">
                  <a href="#services" class="mob-menu__link">Services</a>
               </li>
               <li class="mob-menu__item">
                  <a href="#map" class="mob-menu__link">Road Map</a>
               </li>
               <li class="mob-menu__item">
                  <a href="#stat" class="mob-menu__link">Statistic</a>
               </li>
               <li class="mob-menu__item">
                  <a href="#token" class="mob-menu__link">Token</a>
               </li>
               <li class="mob-menu__item">
                  <a href="#docs" class="mob-menu__link">WhitePappers</a>
               </li>
               <li class="mob-menu__item">
                  <a href="#team" class="mob-menu__link">Team</a>
               </li>
               <li class="mob-menu__item">
                  <a href="#faq" class="mob-menu__link">FAQ</a>
               </li>
               </li>
              <li class="menu__item">
               <a href="https://emush.net/signup" class="menu__link">Register
            </li>
              <li class="menu__item">
               <a href="https://emush.net/signin" class="menu__link">Login
            </li>
            </ul>
   
            <select class="select">
               <option value="ru">ru</option>
               <option value="ua">ua</option>
               <option value="en">en</option>
            </select>
   
            <div class="btn-wrap">
               <a href="#" class="btn-sign-in">Join Emush ICO</a>
            </div>
            
   
         </div>
      </div>
 
      <section class="promo">
         <div class="container">
       
            <div class="row">
               <div class="col-12 promo__content" data-aos="fade-right">
                <marquee><p style="color:red" >IMPORTANT UPDATE MOST EXPECTED AUTO FILL PENDING REGISTRATIONS COUNT WILL BE SHOWN SOON...</p></marquee>
                  
                  <h3 style="color:red">For News</h3>
                  <p style="color:#5fff00">Emush site is made for you and if you use it properly you will reap the benefits soon.

I don't want to tell you that your daily income is going to be coming very soon and it will be huge and you will know it yourself.

Auto fill Income If you refer new people every day to get your Auto fill Income will come to you faster

(NEVER GIVE UP ON A DREAM)  </p>
                  
                  <h1>Emush Just Entered <span>the Real Crypto World</span></h1>
                  <p>
                  To create a trusted resource for people to learn and earn about cryptocurrencies and blockchain technology.

To provide accurate, up-to-date information and educational resources about cryptocurrencies and blockchain technology to help people make informed decisions and  make incomeon crypto.
creating informative and engaging articles, tutorials, videos, and other resources that will help educate your target audience about cryptocurrencies.
                  </p>

                  <div class="timer-wrap">
                     <!--<div id="timer" class="timer"></div>
                     <div class="timer__titles">
                        <div>Days</div>
                        <div>Hours</div>
                        <div>Minutes</div>
                        <div>Seconds</div>
                     </div> !-->




                  </div>

                  <div class="promo__btns-wrap">
                     <a href="#" class="btn btn--medium btn--orange"><span>Buy Emush Coin</span></a>
                     <a href="#" class="btn btn--big btn--blue">WhitePappers</a>
                  </div>

                  <div style="disblay:none" class="payments">
                     <img src="img/visa.png" alt="">
                     <img src="img/mc.png" alt="">
                     <img src="img/bitcoin.png" alt="">
                     <img src="img/paypal.png" alt="">
                  </div>
               </div>
            </div>
            <img src="<?php echo base_url();?>new_css/img/promo-bg.png" data-aos="fade-up"  alt="" class="promo__img">
            
         </div>
         <div class="scroll-down">
            <img src="<?php echo base_url();?>new_css/img/scroll-down.png" alt="">
         </div>
      </section>

      <section class="economy">
         <div class="container">
            <div class="row">
               <div class="col-lg-8 offset-lg-4">

                  <a data-jarallax-element="-40" href="https://www.youtube.com/watch?v=3cZjVFKzugY&amp;list=PLcpkKchW7Xe5K578xRCwQbPbeVQGN5K9h&amp;index=10" class="economy__video-btn video-btn popup-youtube">
                     <img src="img/video-btn.png" alt="">
                  </a>

                  <div class="economy__block">
                     <div class="economy__block-content">
                        <div class="section-header section-header--white section-header--tire section-header--small-margin">
                           <h4  style="display:none" >decentralised economy</h4>
                           <h2>
                              A Crypto Education platform<span  style="display:none" >enables developer solutions</span>
                           </h2>
                        </div>
                        <p style="display:none">
                           Spend real fights effective anything extra by leading. Mouthwatering leading how real formula also locked-in have can mountain thought. Jumbo plus shine sale.
                        </p>
                        <ul>
                           <li>
                              <span>Vision:</span> To create a trusted resource for people to learn and earn about cryptocurrencies and blockchain technology.
                           </li>
                                  
                               
                           <li>
                              <span>Mission :</span>To provide accurate, up-to-date information and educational resources about cryptocurrencies and blockchain technology to help people make informed decisions and  make incomeon crypto
                           </li>
                           
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <img src="img/video-bg.png"  alt="" class="economy__bg">
      </section>

      <section class="section about" id="about">
         <div class="container">
            <div class="row">
               <div data-aos="fade-right" class="col-lg-5">
                  <div class="section-header section-header--animated section-header--tire section-header--small-margin">
                     <h4>About ICO</h4>
                     <h2>Emush.net Theme <span>is the best for your crypto Eduction</span>
                          </h2>
                  </div>
                  <div class="about__animated-content">
                     
                     <ul>
                        <li>
                           creating informative and engaging articles, tutorials, videos, and other resources that will help educate your target audience about cryptocurrencies.
                        </li>
                  
                     </ul>
                  </div>
               </div>
               <div class="col-lg-6 offset-lg-1 align-items-center">
                  <img src="<?php echo base_url();?>new_css/img/about-img.png" class="about__img img-responsive" alt="">
               </div>
            </div>
         </div>
         <img src="<?php echo base_url();?>new_css/img/about-bg.png" data-jarallax-element="40" alt="" class="about__bg">
      </section>

      <section class="section section--no-pad-bot services" id="services">
         <div class="container">
            <div class="row">
               <div class="col">
                  <div class="section-header section-header--animated section-header--center section-header--medium-margin">
                     <h4>Awesome services</h4>
                     <h2>Why it needs?</h2>
                  </div>

                  <div class="services__items">
                     <div class="services__left">
                        <div data-aos="fade-up" class="service">
                           <div class="service__bg" style="background-color: #e85f70; box-shadow: 0 0 51px rgba(232, 95, 112, 0.74); box-shadow: 0 0 51px rgba(232, 95, 112, 0.74);"></div>
                           <img src="<?php echo base_url();?>new_css/img/service-icon-1.svg" alt="">
                           <div class="service__title">
                              Mining Service
                           </div>
                        </div>
                        <div data-aos="fade-up" data-aos-delay="200" class="service">
                           <div class="service__bg" style="background-color: #fa8936; background-image: linear-gradient(-234deg, #ea9d64 0%, #fa8936 100%); box-shadow: 0 0 51px rgba(250, 137, 54, 0.74);"></div>
                           <img src="<?php echo base_url();?>new_css/img/service-icon-2.svg" alt="">
                           <div class="service__title">
                              CryptoEmush App
                           </div>
                        </div>
                     </div>
                     <div class="services__right">
                        <div data-aos="fade-up" data-aos-delay="400" class="service" >
                           <div class="service__bg" style="background-image: linear-gradient(-234deg, #6ae472 0%, #4bc253 100%); box-shadow: 0 0 51px rgba(75, 194, 83, 0.74);"></div>
                           <img src="<?php echo base_url();?>new_css/img/service-icon-3.svg" alt="">
                           <div class="service__title">
                              Blockchain
                           </div>
                        </div>
                        <div data-aos="fade-up" data-aos-delay="600" class="service">
                           <div class="service__bg" style="background-color: #0090d5; background-image: linear-gradient(-234deg, #29aceb 0%, #0090d5 100%); box-shadow: 0 0 51px rgba(0, 144, 213, 0.74);"></div>
                           <img src="<?php echo base_url();?>new_css/img/service-icon-4.svg" alt="">
                           <div class="service__title">
                              Exchange
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <img src="img/services-bg1.png" alt="" class="services__bg">
         <img src="img/services-bg-1.png" class="services__cosmos" alt="">
      </section>

      <section class="section map" id="map">
         <div class="container">
            <div class="row">
               <div class="col">
                  <div class="section-header section-header--animated section-header--center section-header--medium-margin">
                     <h4>Our way</h4>
                     <h2>Road Map</h2>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-lg-6 offset-lg-4 col-sm-8 offset-sm-4">

                  <div class="road">
                     <div class="road__item">
                        <div class="road__item-metka"></div>
                        <div class="road__item-content">
                           <div class="road__item-title">
                              November 2023
                           </div>
                           <p>
                              Airdrop in Emush coin
                           </p>
                        </div>
                        
                     </div>

                     <div class="road__item">
                        <div class="road__item-metka"></div>
                        <div class="road__item-content">
                           <div class="road__item-title">
                              January 2024 
                           </div>
                           <p>
                              Launch in Emush coin our Platform
                           </p>
                        </div>
                        
                     </div>

                     <div class="road__item">
                        <div class="road__item-metka"></div>
                        <div class="road__item-content">
                           <div class="road__item-title">
                              March 2024 
                           </div>
                           <p>
                           Mining Service
                           </p>
                        </div>
                     </div>

                     <div class="road__item">
                        <div class="road__item-metka"></div>
                        <div class="road__item-content">
                           <div class="road__item-title">
                              June 2024 
                           </div>
                           <p>
                              Listing Exchange 
                           </p>
                        </div>
                     </div>

                     <div class="road__item road__item-active">
                        <div class="road__item-metka"></div>
                        <div class="road__item-content">
                           <div class="road__item-title">
                              September 2024 
                           </div>
                           <p>
                              Own Block chain
                           </p>
                        </div>
                     </div>

                     <div class="road__item road__item-next">
                        <div class="road__item-metka"></div>
                        <div class="road__item-content">
                           <div class="road__item-title">
                              November 2024
                           </div>
                           <p>
                              Profit Sharing
                           </p>
                        </div>
                     </div>

                     <div class="road__item road__item-next">
                        <div class="road__item-metka"></div>
                        <div class="road__item-content">
                           <div class="road__item-title">
                              January 2025 
                           </div>
                           <p>
                              Own Exchange.
                           </p>
                        </div>
                     </div>

                  </div>

               </div>
            </div>
            <img src="<?php echo base_url();?>new_css/img/road_map.png" data-jarallax-element="-40" alt="" class="map__title-bg">
         </div>
      </section>

      <section style="display:none"  class="partners-logo" id="partners-logo">
         <div class="container">
            <div class="row">
               <div data-aos="fade-up" class="col">
                  <div class="partners-logo__block">
                     <div class="partners-logo__item">
                        <img src="<?php echo base_url();?>new_css/img/partners-logo-1.png" alt="">
                        <p>Escrow</p>
                     </div>
                     <div class="partners-logo__item">
                        <img src="<?php echo base_url();?>new_css/img/partners-logo-2.png" alt="">
                        <p>risk: low</p>
                     </div>
                     <div class="partners-logo__item">
                        <img src="<?php echo base_url();?>new_css/img/partners-logo-3.png" alt="">
                        <ul class="rating">
                           <li style="background-image: url(img/star-gold.svg)"></li>
                           <li style="background-image: url(img/star-gold.svg)"></li>
                           <li style="background-image: url(img/star-gold.svg)"></li>
                           <li style="background-image: url(img/star-gold.svg)"></li>
                           <li style="background-image: url(img/star.svg)"></li>
                        </ul>
                     </div>
                     <div class="partners-logo__item">
                        <img src="<?php echo base_url();?>new_css/img/partners-logo-4.png" alt="">
                        <p>risk: low</p>
                     </div>                     
                     
                  </div>
               </div>
            </div>
         </div>
         <img src="<?php echo base_url();?>new_css/img/partenrs-bg.png" data-jarallax-element="20" alt="" class="partners-logo__bg">
      </section>

      <section class="section cases">
         <div class="container">
            <div class="row">
               <div class="col">
                  <div class="section-header section-header--animated section-header--center section-header--medium-margin">
                     <h4>Some facts</h4>
                     <h2>Life Good Usages</h2>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col cases__list">
                  <div data-aos="fade-right" class="cases__item">
                     <img src="<?php echo base_url();?>new_css/img/cases-icon-1.png" alt="" class="cases__item-icon">
                     <div class="cases__item-content">
                        <div class="cases__item-title">
                           Emush App
                        </div>
                        <p class="cases__item-text">
                           Emush apps make it possible for investors to buy and sell cryptocurrencies on the go. They are also called crypto exchange apps. Crypto apps can trade cryptocurrencies over centralized or decentralized exchanges.
                        </p>
                     </div>
                  </div>
                  <div data-aos="fade-left" data-aos-delay="200" class="cases__item">
                     <img src="<?php echo base_url();?>new_css/img/cases-icon-2.png" alt="" class="cases__item-icon">
                     <div class="cases__item-content">
                        <div class="cases__item-title">
                           Mining Service
                        </div>
                        <p class="cases__item-text">
                           Crypto mining enables anyone to become a part of the financial system, without relying on intermediaries or centralized authorities. This promotes financial inclusion, innovation, and democratization
                        </p>
                     </div>
                  </div>
                  <div data-aos="fade-right" class="cases__item">
                     <img src="<?php echo base_url();?>new_css/img/cases-icon-3.png" alt="" class="cases__item-icon">
                     <div class="cases__item-content">
                        <div class="cases__item-title">
                           Blockchain
                        </div>
                        <p class="cases__item-text">
                       Blockchain technology has the potential to fundamentally change the way business is conducted, and to transform the foundations of our economic and social systems.
                        </p>
                     </div>
                  </div>
                  <div data-aos="fade-left" data-aos-delay="200" class="cases__item">
                     <img src="<?php echo base_url();?>new_css/img/cases-icon-4.png" alt="" class="cases__item-icon">
                     <div class="cases__item-content">
                        <div class="cases__item-title">
                           Exchange
                        </div>
                        <p class="cases__item-text">
                           Cryptocurrency transactions are verified by network nodes through cryptography and recorded in a public distributed ledger called a blockchain. The cryptocurrency was invented in 2008 by an unknown person or group of people using the name Satoshi Nakamoto.
                        </p>
                     </div>
                  </div>
                  <div data-aos="fade-right" class="cases__item">
                     <img src="<?php echo base_url();?>new_css/img/cases-icon-5.png" alt="" class="cases__item-icon">
                     <div class="cases__item-content">
                        <div class="cases__item-title">
                           Emush.net
                        </div>
                        <p class="cases__item-text">
                          Cryptocurrencies offer benefits in terms of security, privacy, fast settlement times, low costs, cross-border payments, diversification, potential high returns, and 24/7 liquidity. However, they also come with drawbacks such as volatility, regulation risks, scams, and storage concerns
                        </p>
                     </div>
                  </div>
                  <div data-aos="fade-left" data-aos-delay="200" class="cases__item">
                     <img src="<?php echo base_url();?>new_css/img/cases-icon-6.png" alt="" class="cases__item-icon">
                     <div class="cases__item-content">
                        <div class="cases__item-title">
                           Emush schedule
                        </div>
                        <p class="cases__item-text">
                          You report your income from mining on Form Schedule 1 (1040), or Form Schedule C (1040) if you're self-employed or running a mining business. You'll report any capital gains from selling, swapping or spending mined coins on Form Schedule D (1040) and Form 8949.
                        </p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="row">
               <a href="#" class="btn btn--orange btn--uppercase"><span>Join Emush</span></a>
            </div>
         </div>
         <img src="<?php echo base_url();?>new_css/img/cases-bg.png"  class="cases__bg" alt="">
         <img src="<?php echo base_url();?>new_css/img/cases-imgs.png"  class="cases__elements" alt="">
      </section>

      <section class="data" id="stat">
         <div class="container data__container">
            <div class="row">
               <div class="col">
                  <img src="<?php echo base_url();?>new_css/img/data-bg.png" class="data__img" alt="">
                  <div class="counter__item counter__item-1">
                     <div class="counter__item-title">Current elixit price (BTC)</div>
                     <div class="counter counter__item-value counter__item-value--blue numscroller">Comming Soon</div>
                  </div>
                  <div class="counter__item counter__item-2">
                     <div class="counter__item-title">Avarage batches used</div>
                     <div class="counter counter__item-value counter__item-value--pink">Comming Soon</div>
                  </div>
                  <div class="counter__item counter__item-3">
                     <div class="counter__item-title">Total batches remaining</div>
                     <div class="counter counter__item-value counter__item-value--green">Comming Soon</div>
                  </div>
                  <div class="counter__item counter__item-4">
                     <div class="counter__item-title">Percentage batches</div>
                     <div class="counter counter__item-value counter__item-value--percent counter__item-value--purpure">Comming Soon</div>
                  </div>
               </div>
            </div>
         </div>
         <img src="<?php echo base_url();?>new_css/img/data-bg-space.png" class="data__bg" alt="">
      </section>

      <section class="section section--no-pad-bot facts">
         <div class="container">
            <div class="row">
               <div class="col">
                  <div class="section-header section-header--animated section-header--center section-header--small-margin">
                     <h4>Some facts</h4>
                     <h2>Smart Contract API</h2>
                  </div>
               </div>
            </div>
         </div>
         <div class="facts__line">
            <div class="container">
               <div class="row">
                  <div class="col">
                     <div class="facts__line-list">
                        <div class="facts__item">
                              <img src="<?php echo base_url();?>new_css/img/bitcon-round.png" class="facts__icon" alt="">
                              <div class="facts__title">
                                 Bitcoin + RSK
                              </div>
                           </div>
                           <div class="facts__item">
                              <img src="<?php echo base_url();?>new_css/img/stellar-round.png" class="facts__icon" alt="">
                              <div class="facts__title">
                                 Stellar Lumens
                              </div>
                           </div>
                           <div class="facts__item">
                              <img src="<?php echo base_url();?>new_css/img/counterparty-round.png" class="facts__icon" alt="">
                              <div class="facts__title">
                                 Counterparty
                              </div>
                           </div>
                           <div class="facts__item">
                              <img src="<?php echo base_url();?>new_css/img/lisk.png" class="facts__icon" alt="">
                              <div class="facts__title">
                                 Lisk
                              </div>
                           </div>
                           <div class="facts__item">
                              <img src="<?php echo base_url();?>new_css/img/eos-round.png" class="facts__icon" alt="">
                              <div class="facts__title">
                                 EOS
                              </div>
                           </div>
                     </div>
                  </div>
               </div>
            </div>
            <img src="<?php echo base_url();?>new_css/img/facts-bg.png" class="facts__bg" alt="">
         </div>
         
      </section>

      <section class="section token" id="token">
         <div class="container">
            <div class="row">
               <img src="<?php echo base_url();?>new_css/img/token-img.png" class="token__img" alt="">
               <div data-aos="fade-left" class="col-lg-6 offset-lg-6 token__animated-content">
                  <div class="section-header section-header--tire section-header--small-margin">
                     <h4>About token</h4>
                     <h2>Token Sale</h2>
                  </div>

                  <ul class="token__info-list">
                     <li>
                        <span>Token name:</span> Emush Coin
                     </li>
                     <li>
                        <span>Ticker Symbol:</span>Emush
                     </li>
                     <li>
                        <span>Currency Symbol Image   :</span> Future
                     </li>
                     <li>
                        <span>Starting Price Pre-ICO:</span> Emush for USDT ***
                     </li>
                     <li>
                        <span>Maximum Eroiy produced:</span> Emush coin for USDT ***
                     </li>
                     <li>
                        <span>Maximum Eroiy for Sale:</span> 2 billion (technical limit)
                     </li>
                     <li>
                        <span>Fundraising Goal:</span> USD ***
                     </li>
                     <li>
                        <span>Minimum Purchase:</span> 1 Emush Coin
                     </li>
                  </ul>

                  <div class="token__desc">
                     <div class="token__desc-title">General description</div>
                     <div class="token__desc-text">
                        <p>
                           CRYPTOCURRENCY will be released on the basis of Emush platform and fully comply with BEP-20* standard. 
                        </p>
                        <p>
                           Support of this standard guarantees the compatibility of the token with third-party services (wallets, exchanges, listings, etc.), and provides easy integration.
                        </p>
                     </div>
                  </div>

                  <a href="#" class="btn btn--small btn--uppercase btn--orange"><span>Buy Token</span></a>

               </div>
            </div>
         </div>
      </section>

      <section class="docs" id="docs">
         <div class="container">
            <div class="row">
               <div class="col">
                  <div class="section-header section-header--animated seaction-header--center section-header--tire section-header--medium-margin">
                     <h4>Our files</h4>
                     <h2>Documents</h2>
                  </div>
               </div>
            </div>
            <div class="row">
               <div data-aos="fade-up" class="col-lg-3 col-md-6 col-sm-6 col-12">
                  <a target="_blank" href="<?php echo base_url();?>terms" class="doc">
                     <div class="doc__content">
                        <img src="<?php echo base_url();?>new_css/img/pdf.svg" alt="">
                        <div class="doc__title">
                           Terms & Conditions
                        </div>
                     </div>
                  </a>
               </div>
               <div data-aos="fade-up" data-aos-delay="200" class="col-lg-3 col-md-6 col-sm-6 col-12">
                  <a href="#" class="doc">
                     <div class="doc__content">
                        <img src="<?php echo base_url();?>new_css/img/pdf.svg" alt="">
                        <div class="doc__title">
                           White Pappers
                        </div>
                     </div>
                  </a>
               </div>
               <div data-aos="fade-up" data-aos-delay="400" class="col-lg-3 col-md-6 col-sm-6 col-12">
                  <a href="#" class="doc">
                     <div class="doc__content">
                        <img src="<?php echo base_url();?>new_css/img/pdf.svg" alt="">
                        <div class="doc__title">
                           Privacy Policy
                        </div>
                     </div>
                  </a>
               </div>
               <div data-aos="fade-up" data-aos-delay="600" class="col-lg-3 col-md-6 col-sm-6 col-12">
                  <a href="#" class="doc">
                     <div class="doc__content">
                        <img src="<?php echo base_url();?>new_css/img/pdf.svg" alt="">
                        <div class="doc__title">
                           Business Profile
                        </div>
                     </div>
                  </a>
               </div>
            </div>
         </div>
         <img src="<?php echo base_url();?>new_css/img/docs-bg.png" data-jarallax-element="40" alt="" class="docs__bg">
      </section>

      <section class="data token-data section section--no-pad-bot">
         <div class="container">
            <div class="row">
               <div class="col">
                  <div class="section-header section-header--animated section-header--medium-margin section-header--center">
                     <h4>Our data</h4>
                     <h2>Token Distribution</h2>
                     <div class="bg-title">
                        Token Distribution
                     </div>
                  </div>
               </div>
            </div>
            <div class="row chart__row align-items-center">
               <div class="col-lg-6">
                  <div class="chart">
                     <img class="chart__bg" src="<?php echo base_url();?>new_css/img/chart-bg.png" alt="">
                     <div class="chart__wrap">
                        <canvas id="myChart" width="400" height="400"></canvas>
                     </div>
                  </div>
               </div>
               <div data-aos="fade-left" class="col-lg-6 token-data__animated-content">
                  <div class="chart__title">
                     Allocation of funds
                  </div>
                  <p class="chart__text">
                     Total token supply  - 152,358
                  </p>
                  <ul class="chart__legend">
                     <li>
                        <span style="width: 101px;"></span>
                        18% Founders and Team
                     </li>
                     <li>
                        <span style="width: 153px;"></span>
                        26% Reserved Funding
                     </li>
                     <li>
                        <span style="width: 34px;"></span>
                        4% Advisors
                     </li>
                     <li>
                        <span style="width: 289px;"></span>
                        50% Distribute to Community
                     </li>
                     <li>
                        <span style="width: 22px;"></span>
                        2% Bounty campaign
                     </li>
                  </ul>
               </div>
            </div>
         </div>
      </section>

      <section class="section faq" id="faq">
         <div class="container">
            <div class="row">
               <div class="col">
                  <div class="section-header section-header--center section-header--medium-margin">
                     <h4>FAQ</h4>
                     <h2>Frequency Asked Questions</h2>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-lg-8 offset-lg-2">

                     <ul class="accordion">
                        <li>
                           <a>Can UK citizens take part in the Crypto exchange?</a>
                           <p>
                               The safest way to buy Bitcoin and other cryptocurrencies is to use a regulated exchange or one of the best Bitcoin brokers in the UK. Not only is eToro regulated by the FCA, but the SEC, ASIC, and CySEC too. eToro was founded in 2007 and now boasts a client base of over 30 million users.                          </p>
                        </li>
                        <li>
                           <a>Is cryptocurrency regulated by law </a>
                           <p>
                           The Securities and Exchange Commission, the Chicago Mercantile Exchange, Commodity Futures Trading Commission, and the Financial Industry Regulatory Authority are all involved in some regard. Cryptocurrency transactions between private users—private wallet to private wallet—are not regulated.
                           </p>
                        </li>
                        <li>
                           <a>Can I trade Emush Coin at an exchange?</a>
                           <p>
                              First, you can buy and sell actual crypto coins on an exchange. In this instance, you'd need to pay the full value of the coins upfront, in addition to opening an account on an exchange and creating a wallet for the coins.
                           </p>
                        </li>
                        <li>
                           <a>What is the difference between Coin tokens and Power tokens?</a>
                           <p>
                              Coins are often used as a store of value, while tokens are used to power decentralized applications. The price of a coin is often driven by demand for the coin as a store of value, while the price of a token is often driven by demand for the underlying blockchain.
                           </p>
                        </li>
                        <li>
                           <a>Why is Cryptonet economic model sustainable?</a>
                           <p>
                              Reason is simple. You see, in developing countries, cryptocurrencies help buy the resources and provide financial services due to their quick access facility. Thereby accelerating the economic and social development of these economies and hence, are being seen as a boon for their startup ecosystem.
                           </p>
                        </li>
                        <li>
                           <a>Can I mine Emush Coin?</a>
                           <p>
                         One of the unique features of cryptocurrencies is that you can mine them by solving complex mathematical problems and puzzles. Just like Bitcoin, you can also mine on the Ethereum network, create fresh Ether tokens, and get rewarded with Ether in return for the PoW       
                                  </p>
                        </li>
                     </ul>

               </div>
            </div>
         </div>
      </section>

      <section class="advisors">
         <div class="container">
            <div class="row">
               <div class="col">
                  <div class="section-header section-header--animated section-header--center section-header--big-margin">
                     <h4>Family</h4>
                     <h2>Advisors</h2>
                  </div>
               </div>
            </div>
            <div class="row">
               <div data-aos="fade-right" class="col-md-6">
                  <div class="advisor">
                    
                     <div class="advisor__content">
                        <div class="advisor__title">
                          Christopher Nixon
                        </div>
                        <div class="advisor__post">
                           CEO Capital Limited
                        </div>
                       
                     </div>
                  </div>
               </div>

               <div data-aos="fade-left" data-aos-delay="200" class="col-md-6">
                  <div class="advisor">
                   
                     <div class="advisor__content">
                        <div class="advisor__title">
                           Ann Balock
                        </div>
                        <div class="advisor__post">
                           Cryptonet Speaker
                        </div>
                      
                     </div>
                  </div>
               </div>

               <div data-aos="fade-right" class="col-md-6">
                  <div class="advisor">
                     
                     <div class="advisor__content">
                        <div class="advisor__title">
                           Vladimir Nikitin
                        </div>
                        <div class="advisor__post">
                           Cryptonet Team Lead
                        </div>
                       
                     </div>
                  </div>
               </div>

               <div data-aos="fade-left" data-aos-delay="200" class="col-md-6">
                  <div class="advisor">
                    
                     <div class="advisor__content">
                        <div class="advisor__title">
                           Sam Peters
                        </div>
                        <div class="advisor__post">
                           Team Lead Advisor
                        </div>
                     
                     </div>
                  </div>
               </div>

            </div>
         </div>
      </section>

      <section class="section section--no-pad-top team" id="team">
         <div class="container">
            <div class="row">
               <div class="col">
                  <div class="section-header section-header--tire section-header--medium-margin">
                     <h4>Our brain</h4>
                     <h2>Awesome Team</h2>
                  </div>
               </div>
            </div>
            <div class="row">
         
               
               
               
              
             
               <div data-aos="fade-right" class="col-lg-4 col-xl-3 col-6">
                  <div class="team-member">
                    
                     <div class="team-member__content">
                        <div class="team-member__name">Sam Oldrich</div>
                        <div class="team-member__post">Manager</div>
                        <ul class="team-member__social">
                           <li><a href="#"><img src="<?php echo base_url();?>new_css/img/facebook.svg" alt=""></a></li>
                           <li><a href="#"><img src="<?php echo base_url();?>new_css/img/linkedin.svg" alt=""></a></li>
                           <li><a href="#"><img src="<?php echo base_url();?>new_css/img/google-plus.svg" alt=""></a></li>
                        </ul>
                     </div>
                  </div>
               </div>
               <div data-aos="fade-right" data-aos-delay="100" class="col-lg-4 col-xl-3 col-6">
                  <div class="team-member">
                   
                     <div class="team-member__content">
                        <div class="team-member__name">Denis Portlen</div>
                        <div class="team-member__post">Programmer</div>
                        <ul class="team-member__social">
                           <li><a href="#"><img src="<?php echo base_url();?>new_css/img/facebook.svg" alt=""></a></li>
                           <li><a href="#"><img src="<?php echo base_url();?>new_css/img/linkedin.svg" alt=""></a></li>
                           <li><a href="#"><img src="<?php echo base_url();?>new_css/img/google-plus.svg" alt=""></a></li>
                        </ul>
                     </div>
                  </div>
               </div>
               <div data-aos="fade-right" data-aos-delay="200" class="col-lg-4 col-xl-3 col-6">
                  <div class="team-member">
                    
                     <div class="team-member__content">
                        <div class="team-member__name">Den Miller</div>
                        <div class="team-member__post">Economist</div>
                        <ul class="team-member__social">
                           <li><a href="#"><img src="<?php echo base_url();?>new_css/img/facebook.svg" alt=""></a></li>
                           <li><a href="#"><img src="<?php echo base_url();?>new_css/img/linkedin.svg" alt=""></a></li>
                           <li><a href="#"><img src="<?php echo base_url();?>new_css/img/google-plus.svg" alt=""></a></li>
                        </ul>
                     </div>
                  </div>
               </div>
               <div data-aos="fade-right" data-aos-delay="300" class="col-lg-4 col-xl-3 col-6">
                  <div class="team-member">
                     
                     <div class="team-member__content">
                        <div class="team-member__name">Brawn Lee</div>
                        <div class="team-member__post">Journalist</div>
                        <ul class="team-member__social">
                           <li><a href="#"><img src="<?php echo base_url();?>new_css/img/facebook.svg" alt=""></a></li>
                           <li><a href="#"><img src="<?php echo base_url();?>new_css/img/linkedin.svg" alt=""></a></li>
                           <li><a href="#"><img src="<?php echo base_url();?>new_css/img/google-plus.svg" alt=""></a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <img src="<?php echo base_url();?>new_css/img/team-bg.png" data-jarallax-element="40" alt="" class="team__bg">
      </section>

      <section class="news">
         <div class="container">
            <div class="row">
               <div class="col">
                  <div class="section-header section-header--center section-header--small-margin">
                     <h4>In the world</h4>
                     <h2>Latest News</h2>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col">

                  <div class="news-carousel owl-carousel">
                     <a data-aos="fade-up" href="#" class="news-carousel__item">
                        <div class="news-carousel__item-body">
                           <div class="news-carousel__item-subtitle">Cryptocurrency</div>
                           <h3 class="news-carousel__item-title">
                              MEDIUM OF EXCHANGE VERSUS UNIT OF ACCOUNT
                           </h3>
                           <p>
                              Medium of exchange versus unit ofaccount                                              
Bitcoin’s lack of a central bank and fixed-trajectory money supply have earned it
some criticism from economists concerned about macroeconomic stabilisation.
Countercyclical inflationary stimulus is impossible. 
                           </p>
                           <div style="display:none" class="news-carousel__item-data">
                              September, 15 2017
                           </div>
                        </div>
                     </a>

                     <a data-aos="fade-up" data-aos-delay="200" href="#" class="news-carousel__item">
                        <div class="news-carousel__item-body">
                           <div class="news-carousel__item-subtitle">Cryptocurrency</div>
                           <h3 class="news-carousel__item-title">
                              Pricing and volatility
                           </h3>
                           <p>
                              Bitcoin traded over $1 for the first time in February 2011, for $30 in June 2011,
below $7 in July 2011, below $2.50 in October 2011, climbed back up to $10 by
August 2012, to over $230 in April 2013, fell to below $70 within a week and rose
to over $1100 in November 2013
                           </p>
                           
                        </div>
                     </a>

                     <a data-aos="fade-up" data-aos-delay="200" href="#" class="news-carousel__item">
                        <div class="news-carousel__item-body">
                           <div class="news-carousel__item-subtitle">Cryptocurrency</div>
                           <h3 class="news-carousel__item-title">
                              Keywords
                           </h3>
                           <p>
                              anonymity; Bitcoin; Byzantine Generals Problem; censorship resistance;
cryptocurrency; cryptography; double spending problem; exchange rate indeterminacy;
mining pools; money; new monetary economics; open source;
peer-to-peer networking; proof of work; pseudonymity; trust; volatility
                           </p>
                           
                        </div>
                     </a>

                     <a href="#" class="news-carousel__item">
                        <div class="news-carousel__item-body">
                           <div class="news-carousel__item-subtitle">Cryptocurrency</div>
                           <h3 class="news-carousel__item-title">
                              Conclusion
                           </h3>
                           <p>
                              Cryptocurrency is an impressive technical achievement, but it remains a monetary
experiment. Even if cryptocurrencies survive, they may not fully displace fiat
currencies
                           </p>
                           
                        </div>
                     </a>
                     
                  </div>
                  
               </div>
            </div>
         </div>
      </section>

      <section style="display:none"   class="press section">
         <div class="container">
            <div class="row">
               <div class="col">
                  <div class="section-header section-header--center section-header--medium-margin">
                     <h4>Press About us</h4>
                     <h2>Press About Emushcrypto</h2>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-lg-3 col-12 col-sm-6">
                  <a href="#" class="press__item">
                     <img src="<?php echo base_url();?>new_css/img/press-logo-1.png" alt="">
                  </a>
               </div>
               <div class="col-lg-3 col-12 col-sm-6">
                  <a href="#" class="press__item">
                     <img src="<?php echo base_url();?>new_css/img/press-logo-2.png" alt="">
                  </a>
               </div>
               <div class="col-lg-3 col-12 col-sm-6">
                  <a href="#" class="press__item">
                     <img src="<?php echo base_url();?>new_css/img/press-logo-3.png" alt="">
                  </a>
               </div>
               <div class="col-lg-3 col-12 col-sm-6">
                  <a href="#" class="press__item">
                     <img src="<?php echo base_url();?>new_css/img/press-logo-4.png" alt="">
                  </a>
               </div>
            </div>
         </div>
      </section>

      <section style="display:none"   class="partners">
         <div class="container">
            <div class="row">
               <div class="col">
                  <div class="section-header section-header--tire section-header--medium-margin">
                     <h4>Our friends</h4>
                     <h2>Partners</h2>
                  </div>

                  <div class="logoes">
                     <div>
                        <img src="<?php echo base_url();?>new_css/img/partners-logo-1.png" alt="">
                     </div>
                     <div>
                        <img src="<?php echo base_url();?>new_css/img/partners-logo-2.png" alt="">
                     </div>
                     <div>
                        <img src="<?php echo base_url();?>new_css/img/partners-logo-3.png" alt="">
                     </div>
                     <div>
                        <img src="<?php echo base_url();?>new_css/img/partners-logo-4.png" alt="">
                     </div>
                     <div>
                        <img src="<?php echo base_url();?>new_css/img/partners-logo-5.png" alt="">
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>

      <section class="section contact">
         <div  class="container">
            <div class="row">
               <div class="col">
                  <div class="section-header section-header--center section-header--medium-margin">
                     <h4>Contact us</h4>
                     <h2>Get in Touch</h2>
                  </div>
                 <form  id="first_form"  action="https://emush.net/contact-us" class="form-horizontal"  autocomplete="off" method="post" accept-charset="utf-8">
                     <input type="text" name="name" id="name" class="form__input" placeholder="Name">
                     <input type="email" name="email" id="email" class="form__input" placeholder="Email">
                      <input type="text" name="subject" id="subject"  class="form__input" placeholder="subject">
                      <input type="text" name="phone" id="phone"  class="form__input" placeholder="Phone">
                     <textarea name="comment" id="comment"  class="form__textarea" placeholder="Message"></textarea>
                    <!--  <button class="form__btn btn btn--uppercase btn--orange"><span>Send message</span></button> -->

                     <input type="submit" name="submit" class="form__btn btn btn--uppercase btn--orange" value="Send message"/>
                  </form>
               </div>
            </div>
         </div>
         <img src="img/subscribe-bg.png" class="contact-bg" alt="">
      </section>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
      <script>
$(document).ready(function() {

  $('form[id="first_form"]').validate({
    rules: {
      name: 'required',
      subject: 'required',
      email: {
        required: true,
        email: true,
      },
     comment: 'required',
     
    },
    messages: {
      name: 'This field is required',
      subject: 'This field is required',
      email: 'Enter a valid email',
      comment: 'Enter a valid email',
     
    },
    submitHandler: function(form) {
      form.submit();
    }
  });

});

      </script>

      <footer class="footer">
         <div class="container">
            <div class="row">
               <div class="col-lg-4">
                  
                     <a href="#" class="logo">
            <div class="logo__img"></div>
              
      
         </a>
                  
                  <div class="copyright">© 2023, emush.net </div>
               </div>
               <div class="col-lg-4">
                  <div class="social-block">
                     <div class="social-block__title">
                        Stay connected:
                     </div>

                     <ul class="social-list">
                        <li class="social-list__item">
                           
                           <a href="#" class="social-list__link">
                              <i class="fontello-icon icon-twitter">&#xf309;</i>
                           </a>
                        </li>
                        <li class="social-list__item">
                           <a href="https://www.facebook.com/emushcoin" class="social-list__link">
                              <i class="fontello-icon icon-facebook">&#xf30c;</i>
                           </a>
                        </li>
                        <li class="social-list__item">
                           <a href="#" class="social-list__link">
                              <i class="fontello-icon icon-telegram">&#xf2c6;</i>
                           </a>
                        </li>
                        <li class="social-list__item">
                           <a href="#" class="social-list__link">
                              <i class="fontello-icon icon-bitcoin">&#xf15a;</i>
                           </a>
                        </li>
                        <li class="social-list__item">
                           <a href="#" class="social-list__link">
                              <i class="fontello-icon icon-youtube-play">&#xf16a;</i>
                           </a>
                        </li>
                     </ul>
                  </div>
               </div>
               <div style="display:none" lass="col-lg-4">
                  <form action="#" class="form subscribe" id="subscribe-form">
                     <div class="form__title">Subscribe</div>
                     <div class="form__row">
                        <input type="email" name="subscribe_email" class="form__input" placeholder="Email">
                        <button class="form__btn btn btn--uppercase btn--orange btn--small"><span>Send</span></button>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </footer>

   </div>

   <script src="<?php echo base_url();?>new_css/ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
   <script>window.jQuery || document.write('<script src="js/jquery-2.2.4.min.js"><\/script>')</script>

   <script src="<?php echo base_url();?>new_css/js/scripts.min.js"></script>

</body>

<!-- Mirrored from demo.artureanec.com/html/cryptoland/demo_4/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 11 Jun 2023 07:08:58 GMT -->
</html>
