    <!-- meta tags and other links -->
    <!DOCTYPE html>
<html lang="en">

<!-- Mirrored from template.viserlab.com/casinous/demo/sign-in.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 14 Dec 2022 15:28:10 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Emush</title>
    <link rel="icon" type="image/png" href="<?php echo base_url();?>css/assets/images/logos.png" sizes="16x16">
    <!-- bootstrap 5  -->
    <link rel="stylesheet" href="<?php echo base_url();?>css/assets/css/lib/bootstrap.min.css">
    <!-- Icon Link  -->
    <link rel="stylesheet" href="<?php echo base_url();?>css/assets/css/all.min.css"> 
    <link rel="stylesheet" href="<?php echo base_url();?>css/assets/css/line-awesome.min.css"> 
    <link rel="stylesheet" href="<?php echo base_url();?>css/assets/css/lib/animate.css"> 

    <!-- Plugin Link -->
    <link rel="stylesheet" href="<?php echo base_url();?>css/assets/css/lib/slick.css">

    <!-- Main css -->
    <link rel="stylesheet" href="<?php echo base_url();?>css/assets/css/main.css">
</head>
    <body data-bs-spy="scroll" data-bs-offset="170" data-bs-target=".privacy-policy-sidebar-menu">

        <div class="overlay"></div>
       <div class="preloader">
            <div class="scene" id="scene">
                <input type="checkbox" id="andicator" />
                   <span class="loader"></span>
                   <style>
                       .loader {
            width: 48px;
            height: 48px;
            position: relative;
            animation : rotate 4s linear infinite;
          }
          .loader:before,
          .loader:after {
            content:"";
            display: block;
            border: 24px solid;
            border-color: transparent transparent #fff  #fff;
            position: absolute;
            left: 0;
            top: 0;
            animation: mvx 1s infinite ease-in;
          }
          .loader:before {
            left: -1px;
            top: 1px;
            border-color:#FF3D00  #FF3D00 transparent transparent;
            animation-name:mvrx;
          }

          @keyframes rotate {
            100% {transform: rotate(360deg)}
          }
          @keyframes mvx {
            0% , 15% {transform: translate(0 , 0) rotate(0deg)}
            50% {transform: translate(-50% , 50%) rotate(180deg)}
            100% {transform: translate(0% , 0%) rotate(180deg)}
          }
          @keyframes mvrx {
            0% , 15%  {transform: translate(0 , 0) rotate(0deg)}
            50% {transform: translate(50% , -50%) rotate(180deg)}
            100% {transform: translate(0% , 0%) rotate(180deg)}
          }
    
                   </style>
             
            </div>
        </div>

    <div class="header">
    <div class="container">
        <div class="header-bottom">
            <div class="header-bottom-area align-items-center">
                <div class="logo"><a href="#"><img src="<?php echo base_url();?>css/assets/images/logos.png" alt="logo"></a></div>
                <ul class="menu">
                    <li>
                        <a href="<?php echo base_url();?>">Home</a>
                    </li>
            <!--         <li>
                        <a href="about.html">About</a>
                    </li>
                    <li>
                        <a href="games.html">Games <span class="badge badge--sm badge--base text-dark">NEW</span></a>
                    </li>
                    <li>
                        <a href="faq.html">Faq</a>
                    </li> -->
                   <!--  <li>
                        <a href="#0">Pages</a>
                        <ul class="sub-menu">
                            <li>
                                <a href="dashboard.html">User Dashboard</a>
                            </li>
                            <li>
                                <a href="game-details.html">Game Details</a>
                            </li>
                            <li>
                                <a href="policy.html">Privacy Policy</a>
                            </li>
                            <li>
                                <a href="terms-conditions.html">Terms & Conditions</a>
                            </li>
                            <li>
                                <a href="sign-in.html">Sign In</a>
                            </li>
                            <li>
                                <a href="sign-up.html">Sign Up</a>
                            </li>
                        </ul>
                    </li> -->
                <!--     <li>
                        <a href="#0">Blog</a>
                        <ul class="sub-menu">
                            <li><a href="blog.html">Blog</a></li>
                            <li><a href="blog-details.html">Blog Details</a></li>
                        </ul>
                    </li> -->
                    <li>
                        <a href="<?php echo base_url();?>signup">Sign Up</a>
                    </li>
                     <li>
                        <a href="<?php echo base_url();?>signin">Sign In</a>
                    </li>


                    <button class="btn-close btn-close-white d-lg-none"></button>
                </ul>
                <div class="header-trigger-wrapper d-flex d-lg-none align-items-center">
                    <div class="header-trigger me-4">
                        <span></span>
                    </div>
                  
                </div>
            </div>
        </div>
    </div>
</div>
    <!-- inner hero section start -->
<section class="inner-banner bg_img"  top;">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-7 col-xl-6 text-center">
        <h2 class="title text-white">Sign In</h2>
        <ul class="breadcrumbs d-flex flex-wrap align-items-center justify-content-center">
          <li><a href="index.html">Home</a></li>
          <li>Sign In</li>
        </ul>
      </div>
    </div>
  </div>
</section>
<!-- inner hero section end -->

  <?php $this->load->view('front/common/flashmessage'); ?>
    <!-- Account Section Starts Here -->
    <section class="account-section overflow-hidden bg_img">
        <div class="container">
            <div class="account__main__wrapper">
                <div class="account__form__wrapper">
                  
<?php
                      if(validation_errors()){
                          $error =  validation_errors();
                          echo '<div class="note note-danger">
                          <button aria-hidden="true" data-dismiss="note" class="close" type="button">&#10005;</button>'.$error.'</div>';
                      }
                      $action = 'login_check';
                      $attributes=array('class'=>'form-horizontal','id'=>'subForm','autocomplete' => 'off');
                      echo form_open($action,$attributes);                                         
                      ?>
<input type="hidden" name="hidden_email" value="<?php echo rand(); ?>" id="hidden_email">
                    <div class="account__form form row g-4">
                        <div class="col-12">
                            <div class="form-group">
                                <div for="username" class="input-pre-icon"><i class="las la-user"></i></div>
                                <input id="tenrealm_email" name="tenrealm_email" type="text" class="form--control form-control style--two" placeholder="Username" required>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <div for="pass" class="input-pre-icon"><i class="las la-lock"></i></div>
                                <input id="tenrealm_password" name="tenrealm_password" type="password" class="form--control form-control style--two" placeholder="Password" required>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <button class="cmn--btn active w-100 btn--round"  name="btnsubmit" type="submit">Sign In</button>
                            </div>
                        </div>
                        <div class="d-flex flex-wrap flex-sm-nowrap justify-content-between mt-5">
                            <!--<div class="form--check d-flex align-items-center">-->
                            <!--    <input id="check1" type="checkbox" checked>-->
                            <!--    <label for="check1">Remember me</label>-->
                            <!--</div>-->
                        <a href="<?php echo base_url();?>forgot-password" class="forgot-pass d-block text--base">Forgot Password ?</a>
                        </div>
                    <?php echo form_close(); ?>
                </div>
                <!--<div class="account__content__wrapper" >-->
                <!--    <div class="content text-center text-white">-->
                <!--        <h3 class="title text--base mb-4">Welcome to Casinio</h3>-->
                <!--        <p class="">Sign in your Account. Atque, fuga sapiente, doloribus qui enim tempora?</p>-->
                <!--        <p class="account-switch mt-4">Don't have an Account yet ? <a class="text--base ms-2" href="sign-up.html">Sign Up</a></p>-->
                <!--    </div>-->
                <!--</div>-->
            </div>
        </div>
    </section>
    <!-- Account Section Ends Here -->


    <!-- Footer Section Starts Here -->
<footer class="footer-section bg_img">
    <div class="footer-top">
        <div class="container">
         
        </div>
    </div>

    <!--<div class="shapes">-->
    <!--    <img src="<?php echo base_url();?>css/assets/images/footer/shape.png" alt="footer" class="shape1">-->
    <!--</div>-->
</footer>
<!-- Footer Section Ends Here -->
<script type="text/javascript">

var baseURL = "<?php echo base_url(); ?>";
var csrf_name = "<?php  echo $this->security->get_csrf_token_name(); ?>"; // for the name
var csrf_token = "<?php  echo $this->security->get_csrf_hash(); ?>";  // for the value   


    $(document).ready(function () {        
        $.validator.addMethod('totalCheck', function(value, element, params) {
            var field_1 = $('#number1').val(),
            field_2 = $('#number2').val();
            return parseInt(value) === (parseInt(field_1) + parseInt(field_2));
        }, "Enter the valid number");


     $.validator.addMethod("email_or_mobile", function(value, element) {

        if(/^\d|\w{10,10}$/.test(value)){
            value.replace(/\s+/, "");
        }
        return /^\d|\w{10,10}$/.test(value) || /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(value) //email or No
    }, "Please enter valid email or 16 digit number");



        $('#subForm').validate({ // initialize the plugin
            rules: {
                first_name: {
                    required: {
                        depends:function(){
                            $(this).val($.trim($(this).val()));
                            return true;
                        }
                    },           
                },
                last_name: {
                    required: {
                        depends:function(){
                            $(this).val($.trim($(this).val()));
                            return true;
                        }
                    },
                },
                tenrealm_email: {
                    required: {
                        depends:function(){
                            $(this).val($.trim($(this).val().replace(/\s+/, "")));
                            return true;
                        }
                    },                    
                    email_or_mobile: true,
                    remote: function() {
                                    var email = $('#tenrealm_email').val();                                    
                                    // if(/^\d{11,11}$/.test(email)){ return;}
                                    // if(/^\d$/.test(email)){ return;}   
                                    if(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(email)){
                                        return { url: baseURL + "is-not-email-exist",type: 'post',data: {'tenrealm_email':email} }    
                                    }                                    
                            },
                },
                tenrealm_password: {
                    required: {
                        depends:function(){
                            $(this).val($.trim($(this).val()));
                            return true;
                        }
                    },
                    minlength: 5
                },

            },
             messages: {
                first_name: "Enter your firstname",
                last_name: "Enter your lastname",
                tenrealm_email: {
                    required: "Enter a User ID or Email",
                    remote: jQuery.validator.format("This {0} does not exist")
                },                
            },
            errorPlacement: function(error, element) {                
              if(element.attr("name") == "tenrealm_password") {                
                error.appendTo( element.parent("div").parent('.single-input').find("div#tenrealm_password_error") );
            } else {
                error.insertAfter(element);
            }
        }
    });


    });

</script>    

<!-- jQuery library -->
<script src="<?php echo base_url();?>css/assets/js/lib/jquery-3.6.0.min.js"></script>
<!-- bootstrap 5 js -->
<script src="<?php echo base_url();?>css/assets/js/lib/bootstrap.min.js"></script>

<!-- Pluglin Link -->
<script src="<?php echo base_url();?>css/assets/js/lib/slick.min.js"></script>

<!-- main js -->
<script src="<?php echo base_url();?>css/assets/js/main.js"></script>  
</body>

<!-- Mirrored from template.viserlab.com/casinous/demo/sign-in.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 14 Dec 2022 15:28:11 GMT -->
</html>