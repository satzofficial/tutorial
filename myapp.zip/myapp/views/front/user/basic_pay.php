<?php 
  $this->load->view('front/common/header');
  $user_id = $this->session->userdata('user_id');
  $this->load->view('front/user/basic_navigation');

  $userbalance = getBalance($user_id,$dig_currency[0]->id);
  // $EURO_Balance = bcmul($userbalance ,$dig_currency[0]->online_europrice);
  $EURO_Balance = $userbalance * $dig_currency[0]->online_europrice;
  $coin_address = getAddress($user_id, $dig_currency[0]->id);

?>
<style>
.copy-address {
  font-size:25px;
  width: 50px;
}
#amount_receive_error{
color: red;
}  
.form-paywith {
  background-color: #fff !important;
  border: 0px;
  font-weight: bold;
}
.convert-coin { font-weight: bold; }
</style>
<div class="page-wrapper">
    <div class="page-body">
      <div class="container-xl">
        <div class="row">
          <div class="col-3 col-sm-3">
            </div>
          <div class="col-12 col-sm-6">
            <div class="col-md-12">
              <div class="card">
                <ul class="nav nav-tabs nav-fill transaction-nav" data-bs-toggle="tabs">
                  <li class="nav-item">
                    <a href="javascript:;" id="send-tab" class="nav-link active" data-bs-toggle="tab"><?php echo $this->lang->line('Send');?></a>
                  </li>
                  <li class="nav-item">
                    <a href="javascript:;" id="receive-tab" class="nav-link" data-bs-toggle="tab"><?php echo $this->lang->line('Receive');?></a>
                  </li>
                 </ul>
                <div class="card-body">
                  <div class="tab-content">
                    <div class="tab-pane trans-wrapper show active" id="send-tab-content">

              <?php $action = base_url().'basic-pay';
          $attributes = array('id'=>'withdrawcoin','autocomplete'=>"off",'class'=>'deposit_form1');
          echo form_open($action,$attributes); ?>                           
                      <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label">Euro <?php echo $this->lang->line('Value');?></label>
                        <div class="col">
                          <input type="number" min="10" value="10" class="form-control" id="EuroCurrencyInput" name="EuroCurrencyInput" onkeyup="changeFiatCurrency(this)" placeholder="€ 0">
                          <span></span>
                        </div>
                      </div>
                      <div class="form-group mb-3 row">
                       <!--  <label class="form-label col-3 col-form-label">Convert coin</label> -->
                        <label class="form-label"><?php echo $this->lang->line('Value');?> in <span class="convertcoin-lable"><?=$dig_currency[0]->currency_symbol?></span> : <span class="convert-coin"> </span></label>

                        <!-- <div class="col"> -->
                          <!-- <input readonly type="text" class="form-control convert-coin"> -->
                          <input type="hidden" name="amount" class="convert-coin1">
                        <!-- </div>   -->
                      </div>
                      <div class="form-floating mb-3">
                        <input class="form-control to_address" name="address" id="first" type="text" placeholder="Mobile, email, or address" onkeyup="validaddressFunction(this)" />
                        <input type="hidden" name="valid_address" class="valid_address">
                        <span></span>
                        <label for="first">&#8693; <?=$this->lang->line('Withdraw address');?></label>
                      </div>
                      <label class="form-selectgroup-item">
                        <input type="radio" name="report-type" value="<?=$dig_currency[0]->currency_symbol?>" class="form-selectgroup-input select-currency-send" data-toggle="modal" href="#myCurrencyModal">

                        <span class="form-selectgroup-label d-flex align-items-center p-3"> <span class="me-3"></span> <span class="d-block text-muted1" style="margin-left: -30px;"><?php echo $this->lang->line('Pay with');?></span><span class="form-selectgroup-label-content"> <span class="form-selectgroup-title strong mb-1">
                        <img alt="Bitcoin logo" src="<?=$dig_currency[0]->image?>" aria-label="<?=$dig_currency[0]->currency_name?> logo " style="height: 32px" ;="" class="Image-sc-1i3cgkp-0 ImageWithFallback__AbsoluteImage-ufzvsr-0 dmqghf send-crypto-icon">
                        
                        <span class="send-crypto-sym "><?=$dig_currency[0]->currency_name?></span>

                        </span> </span> </span> </label>
                      <p>Sharecoin Fee : <span class="send_fees_s"></span></p>  
                      <p><?php echo $this->lang->line('Fee(Other Fee)');?> : <span class="send_fees_o"></span></p>  
                      <p><?php echo $this->lang->line('Amount You will receive');?> : <span class="send_amount_receive_sym"></span></p> 
                      <!--<span id="amount_receive_error"></span> -->

                      <input type="hidden" id="hiden_fees_type" value="<?=$dig_currency[0]->withdraw_fees_type?>">
                      <input type="hidden" id="hiden_fees" value="<?=$dig_currency[0]->withdraw_fees?>"> 
                      <input type="hidden" id="hiden_fees_stype" value="<?=$dig_currency[0]->sharecoin_fees_type?>">
                      <input type="hidden" id="hiden_fees_s" value="<?=$dig_currency[0]->sharecoin_fees?>"> 

                    <input type="hidden" class="hiden-coin-sym" value="<?=$dig_currency[0]->currency_symbol?>">    
                    <div class="col-lg-12 mt-2"> 
                      <button class="btn btn-primary ms-auto" type="submit" name="withdrawcoin"><?=$this->lang->line('Withdraw');?></button>
                      <input type="hidden" name="ids" class="send-crypto-id" value="<?=$dig_currency[0]->id?>"> 
                      <input type="hidden" name="sharecoin_fee" id="sharecoin_fee">
                      <input type="hidden" name="other_fee" id="other_fee">
                      <input type="hidden" name="receive_amt" id="receive_amt">
                    </div>
              <?php echo form_close(); ?>       

                    </div>


                    <div class="tab-pane trans-wrapper" id="receive-tab-content">
                      <div class="col-12">
                        <div class="card">
                          <div class="card-header">
                            <img alt="Bitcoin logo" src="<?=$First_coin_image?>" aria-label="Qr code " style="padding: 25px 76px;" class="Image-sc-1i3cgkp-0 ImageWithFallback__AbsoluteImage-ufzvsr-0 dmqghf receive-coin-address">

                          </div>
                          <div class="card-footer">
                            <div class="d-flex">
                              <a href="javascript:;" class="btn btn-link"><?=$this->lang->line('Address');?></a>
                              <a href="javascript:;" onclick="copy_function('<?=$coin_address?>')" class="btn btn-link cryptoaddress-txt" id="copy_icofont"><?=substr($coin_address,0,30).'...'?><i class="icofont-copy copy-address"></i></a>
                            </div>

                      </div>
                      <label class="form-selectgroup-item">
                        <input type="radio" name="report-type" value="<?=$dig_currency[0]->currency_symbol?>" class="form-selectgroup-input select-currency-receive" data-toggle="modal" href="#myCurrencyModal-receive">

                        <span class="form-selectgroup-label d-flex align-items-center p-3"> <span class="me-3"></span> <span class="d-block text-muted1" style="margin-left: -12px;"><?=$this->lang->line('Pay with');?></span><span class="form-selectgroup-label-content"> <span class="form-selectgroup-title strong mb-1">
                        <img alt="<?=$dig_currency[0]->currency_name?> logo" src="<?=$dig_currency[0]->image?>" aria-label="<?=$dig_currency[0]->currency_name?> logo " style="height: 32px" ;="" class="Image-sc-1i3cgkp-0 ImageWithFallback__AbsoluteImage-ufzvsr-0 dmqghf receive-crypto-icon">

                        <span class="receive-crypto-sym"><?=$dig_currency[0]->currency_name?></span>
                        </span> </span> </span> </label>
                    </div>

                  </div>
                </div>
              </div>
            </div>

            <div class="card-footer">
              <div class="row align-items-center">
                <div class="col-auto">
                  <label class="currencybal-label"><?=$dig_currency[0]->currency_symbol?> <?=$this->lang->line('balance');?></label>
                </div>
                <div class="col-auto ms-auto">
                  <label class="form-check form-switch m-0 convertCoin-label">
                   <?=$userbalance.' '.$dig_currency[0]->currency_symbol?> ≈ €<?=$EURO_Balance?>
                  </label>
                </div>
              </div>
            </div>
          </div>

          </div>
          </div>
          <div class="col-md-3 col-lg-3">
          </div>
        </div>
      </div>
    </div>
  </div>

<div class="modal" id="myCurrencyModal" data-backdrop="static">
  <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Select Asset</h4>
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        </div>
        <div class="container" style="padding-top: 10px;">
          <!-- <div class="input-icon mb-3">
            <input type="text" class="form-control" placeholder="Search…">
            <span class="input-icon-addon">
              <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><circle cx="10" cy="10" r="7" /><line x1="21" y1="21" x2="15" y2="15" /></svg>
            </span>
          </div> -->
          <div class="mb-3">
            <label class="form-label"></label>
            <div class="form-selectgroup form-selectgroup-boxes d-flex flex-column">
              <?php
            if(count($dig_currency) >0)
            {
               foreach ($dig_currency as $digital) 
             {
              if (in_array($digital->currency_symbol, array('BTC','ETH','BCH','USDT'))) { 
            if($digital->type=="fiat")
            {
                $format = 2;
            }
            elseif($digital->currency_symbol=="USDT")
            {
                $format = 6;
            }
            else
            {
                $format = 6;
            }
            $coin_price_val = to_decimal($wallet['Exchange AND Trading'][$digital->id], $format);
            $coin_price = $coin_price_val * $digital->online_usdprice;

            $userbalance = getBalance($user_id,$digital->id);
            $USDT_Balance = $userbalance * $digital->online_usdprice;
            // $EURO_Balance = bcmul($userbalance ,$digital->online_europrice);
            $EURO_Balance = $userbalance * $digital->online_europrice;

            ?>

              <label class="form-selectgroup-item flex-fill">
                <input type="radio" name="form-payment" data-feestype="<?=$digital->withdraw_fees_type?>" data-fees="<?=$digital->withdraw_fees?>" data-sfeestype="<?=$digital->sharecoin_fees_type?>" data-sfees="<?=$digital->sharecoin_fees?>" value="<?=$digital->currency_symbol?>" class="form-selectgroup-input select-currency1" id="check-<?=$digital->currency_symbol?>">
                <div class="form-selectgroup-label d-flex align-items-center p-3">
                  <div class="me-3">
                    <span class="form-selectgroup-check"></span>
                  </div>
                  <div>
                    <img style="margin-right:10px;" width="30px" height="30px" src="<?php echo $digital->image;?>" class="table-cryp"><span><?=$digital->currency_name;?>
                  </div>
                  <div class="me-3" style="margin-left:200px;"> <?=$userbalance?></div>
                </div>

                <input type="hidden" class="hiden-coinId" value="<?=$digital->id;?>">
                <input type="hidden" class="hiden-symbol" value="<?=$digital->currency_symbol;?>">
                <input type="hidden" class="hiden-sym" value="<?=$digital->currency_name;?>">
                <input type="hidden" class="hiden-img" value="<?=$digital->image;?>">
                <input type="hidden" class="hiden-walletamount" value="<?=$userbalance;?>">
                <input type="hidden" class="hiden-eurobalance" value="<?=$EURO_Balance;?>">

                <input type="hidden" class="From-currency currency-sym" data-currency="<?=$digital->currency_symbol?>">
              </label>

              <?php }}}?>

              
            </div>
          </div>


        </div>

      </div>
    </div>
</div>

<div class="modal" id="myCurrencyModal-receive" data-backdrop="static">
  <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Select Asset</h4>
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        </div>
        <div class="container" style="padding-top: 10px;">
          <!-- <div class="input-icon mb-3">
            <input type="text" class="form-control" placeholder="Search…">
            <span class="input-icon-addon">
              <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><circle cx="10" cy="10" r="7" /><line x1="21" y1="21" x2="15" y2="15" /></svg>
            </span>
          </div> -->
          <div class="mb-3">
            <label class="form-label"></label>
            <div class="form-selectgroup form-selectgroup-boxes d-flex flex-column">
              <?php
            if(count($dig_currency) >0)
            {
               foreach ($dig_currency as $digital) 
             {
              if (in_array($digital->currency_symbol, array('BTC','ETH','BCH','USDT'))) { 
            if($digital->type=="fiat")
            {
                $format = 2;
            }
            elseif($digital->currency_symbol=="USDT")
            {
                $format = 6;
            }
            else
            {
                $format = 6;
            }
            $coin_price_val = to_decimal($wallet['Exchange AND Trading'][$digital->id], $format);
            $coin_price = $coin_price_val * $digital->online_usdprice;

            $userbalance = getBalance($user_id,$digital->id);
            $USDT_Balance = $userbalance * $digital->online_usdprice;
            $EURO_Balance = bcmul($userbalance ,$digital->online_europrice);

            ?>

              <label class="form-selectgroup-item flex-fill">
                <input type="radio" name="form-payment" value="<?=$digital->currency_symbol?>" class="form-selectgroup-input select-currency1-receive" id="check-receive-<?=$digital->currency_symbol?>">
                <div class="form-selectgroup-label d-flex align-items-center p-3">
                  <div class="me-3">
                    <span class="form-selectgroup-check"></span>
                  </div>
                  <div>
                    <img style="margin-right:10px;" width="30px" height="30px" src="<?php echo $digital->image;?>" class="table-cryp"><span><?=$digital->currency_name;?>
                  </div>
                  <div class="me-3" style="margin-left:200px;"> <?=$userbalance?></div>
                </div>

                <input type="hidden" class="hiden-coinId-receive" value="<?=$digital->id;?>">
                <input type="hidden" class="hiden-symbol-receive" value="<?=$digital->currency_symbol;?>">
                <input type="hidden" class="hiden-sym-receive" value="<?=$digital->currency_name;?>">
                <input type="hidden" class="hiden-img-receive" value="<?=$digital->image;?>">
                <input type="hidden" class="hiden-walletamount-receive" value="<?=$userbalance;?>">
                <input type="hidden" class="hiden-eurobalance-receive" value="<?=$EURO_Balance;?>">

                <input type="hidden" class="currency-sym-receive" data-currency="<?=$digital->currency_symbol?>">
              </label>

              <?php }}}?>

              
            </div>
          </div>


        </div>

      </div>
    </div>
</div>

<?php $this->load->view('front/common/footer'); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
$.validator.addMethod("noSpace", function(value, element) { 
  return value.indexOf(" ") < 0 && value != ""; 
}, "No space please and don't leave it empty");  

$('#withdrawcoin').validate(
{
    errorElement: 'span',
    rules: {
      address:{
        required: true,
        noSpace: true
      },
      EuroCurrencyInput:{
        required: true,
        number:true
      }
    },
    messages: {
      address:{
        required: "<?=$this->lang->line('Please enter address');?>"
      },
      EuroCurrencyInput:{
        required: "<?=$this->lang->line('Please enter amount');?>",
        number: "<?=$this->lang->line('Invalid Amount');?>"
      }
    },
    errorPlacement: function(error, element) {
      $(element).next('span').html(error);
    },
    
    submitHandler: function(form) 
    { 
        form.submit();
    }
});

$(document).on('click', '.transaction-nav li', function() {
  li = $(this).find('a').attr('id');

  $(".transaction-nav li a").not($(this)).removeClass('active show');
  $(".trans-wrapper").removeClass("active show");  
  if(li=='send-tab') {
    $("#send-tab").addClass("active show");      
    $("#send-tab-content").addClass("active show");    
  } else if(li=='receive-tab') {
    $("#receive-tab").addClass("active show");
    $("#receive-tab-content").addClass("active show");
  } 
}); 

function copy_function(lang) 
{
  // console.log(lang)
  $('.copy-address').removeClass('icofont-copy');
  var tempInput = document.createElement("input");
  tempInput.value = lang;
  document.body.appendChild(tempInput);
  tempInput.select();
  document.execCommand("copy");
  document.body.removeChild(tempInput);
  $('.copy-address').addClass('icofont-check');

  $('.copy-address').fadeOut('slow', function(){
    $('.copy-address').removeClass('icofont-check');
    $(".copy-address").css("display", "block");
  });
  $('.copy-address').addClass('icofont-copy');
}

// const formatter = new Intl.NumberFormat('en-US', {
//    minimumFractionDigits: 6,      
//    maximumFractionDigits: 6,
// });

Number.prototype.noExponents= function(){
    var data= String(this).split(/[eE]/);    
    if(data.length== 1) return data[0]; 

    var  z= '', sign= this<0? '-':'',
    str= data[0].replace('.', ''),
    mag= Number(data[1])+ 1;

    if(mag<0){
        z= sign + '0.';
        while(mag++) z += '0';
        return z + str.replace(/^\-/,'');
    }
    mag -= str.length;  
    while(mag--) z += '0';
    return str + z;
}

function changeFiatCurrency(e) {
  apikey = '<?=getCryptoCompareKey()?>';
  rate1 = 0;
  euroAmt = parseFloat($(e).val());
  coin = document.querySelector(".hiden-coin-sym").value;
  
  $.getJSON('https://min-api.cryptocompare.com/data/pricemulti?fsyms=EUR&tsyms='+coin+'&api_key='+apikey, function(data) {

  $.each(data.EUR, function (cur, rate) { 
    fromAmt = euroAmt * rate;
    fromRate = formatter.format(fromAmt);
    if(isNaN(fromAmt)) {
      $('.convertcoin-lable').html(coin);
      $('.convert-coin').html('');
      $('.convert-coin1').val('');
      rate1 +=0;
    } else {
      rate1 +=fromRate;
      $('.convertcoin-lable').html(coin);
      $('.convert-coin').html(fromRate+' '+coin);
      $('.convert-coin1').val(fromRate);
    } 
  });
});

  fees_type = document.getElementById("hiden_fees_type").value;
  fees = document.getElementById("hiden_fees").value;
  sfees_type = document.getElementById("hiden_fees_stype").value;
  sfees = document.getElementById("hiden_fees_s").value;

  // if (String.fromCharCode(e.keyCode).match(/[^0-9]/g)) return false;
  // console.log( rate1+'---'+fees_type+'--'+fees+'--'+sfees_type+'--'+sfees )
  setTimeout(function(){  
    if(fees_type=='Percent'){
        var fees_p = ((parseFloat(rate1) * parseFloat(fees))/100);
        var amount_receive = parseFloat(rate1) - parseFloat(fees_p);
    }
    else{
        var fees_p = fees;
        var amount_receive = parseFloat(rate1) - parseFloat(fees_p);
    }

    if(sfees_type=='Percent'){
        var fees_s = ((parseFloat(rate1) * parseFloat(sfees))/100);
        var fee = (parseFloat(fees_p) + parseFloat(fees_s));
        var amount_receive = parseFloat(rate1) - parseFloat(fee);
        //console.log(fees_s+'--'+fees_p+'--'+amount_receive1);
    }
    else{
        var fees_sum = (parseFloat(fees_p)+ parseFloat(sfees));
        var fees_s = sfees;
        var amount_receive = parseFloat(rate1) - parseFloat(fees_sum);
       // console.log(fees_p+'--'+sfees+'--'+amount_receive);
    }

      fees_s = (/e/.test(fees_s)) ? fees_s.noExponents() : fees_s;
      fees_p = (/e/.test(fees_p)) ? fees_p.noExponents() : fees_p;
      amount_receive = (/e/.test(amount_receive)) ? amount_receive.noExponents() : amount_receive;

      // console.log( fees_s+'--'+fees_p+'--'+amount_receive )
      $('.send_fees_s').html(fees_s);
      $('.send_fees_o').html(fees_p);

      if(amount_receive<=0){
        $('.send_amount_receive_sym').html('0');
        $('#amount_receive_error').html('Please enter valid amount');
      }
      else{
        $('#amount_receive_error').html('');
        $('.send_amount_receive_sym').html(amount_receive);
      }
      
      $('#sharecoin_fee').val(fees_s);
      $('#other_fee').val(fees_p);
      $('#receive_amt').val(amount_receive);

  }, 1000);

}	

$(document).on('click','.select-currency-send',function() {
  selectVal = $(this).val();
  document.getElementById("check-"+selectVal).checked = true;
});

$(document).on('click','.select-currency-receive',function() {
  selectVal = $(this).val();
  document.getElementById("check-receive-"+selectVal).checked = true;
});

$(document).on('click','.select-currency1',function() {

  icon = $(this).val();
  feestype = $(this).attr('data-feestype');
  fees = $(this).attr('data-fees');
  sfeestype = $(this).attr('data-sfeestype');
  sfees = $(this).attr('data-sfees');

  coin_id = $(this).closest('label').find('.hiden-coinId').val();
  symbol = $(this).closest('label').find('.hiden-symbol').val();
  name = $(this).closest('label').find('.hiden-sym').val();
  img = $(this).closest('label').find('.hiden-img').val();
  walletAmt = $(this).closest('label').find('.hiden-walletamount').val();
  eurobalance = $(this).closest('label').find('.hiden-eurobalance').val();  
  convertCoin = walletAmt +' '+symbol+' ≈ €'+ eurobalance; 
  
  $('#hiden_fees_type').val(feestype);
  $('#hiden_fees').val(fees);
  $('#hiden_fees_stype').val(sfeestype);
  $('#hiden_fees_s').val(sfees);

  // console.log(symbol) 
  // base_url = '<?=base_url()?>basic-pay/'+symbol;
  base_url = '<?=base_url()?>basic-pay';
  $('.send-crypto-icon').attr('src', img);
  $('.send-crypto-id').val(coin_id);
  $('.send-crypto-sym').html(name);
  $('.hiden-coin-sym').val(symbol);
  $('.select-currency-send').val(symbol)

  $('.currencybal-label').html(symbol+' Balance');
  $('.convertCoin-label').html(convertCoin); 

  EuroCurrencyInput = document.getElementById("EuroCurrencyInput");
  changeFiatCurrency(EuroCurrencyInput);
  document.getElementById("withdrawcoin").action = base_url;
  });

$(document).on('click','.select-currency1-receive',function() {
  // icon = $(this).val();
  coin_id = $(this).closest('label').find('.hiden-coinId-receive').val();
  symbol = $(this).closest('label').find('.hiden-symbol-receive').val();
  name = $(this).closest('label').find('.hiden-sym-receive').val();
  img = $(this).closest('label').find('.hiden-img-receive').val();
  walletAmt = $(this).closest('label').find('.hiden-walletamount-receive').val();
  eurobalance = $(this).closest('label').find('.hiden-eurobalance-receive').val();  
  convertCoin = walletAmt +' '+symbol+' ≈ €'+ eurobalance; 

  $('.receive-crypto-icon').attr('src', img);
  // $('.send-crypto-id').val(coin_id);
  $('.receive-crypto-sym').html(name);
  $('.select-currency-receive').val(symbol)
  $('.currencybal-label').html(symbol+' Balance');
  $('.convertCoin-label').html(convertCoin);

  base_url='<?php echo base_url();?>';
  $.ajax({
        url: base_url+"change_address",
        type: "POST",
        data: "currency_id="+coin_id,
        success: function(data) {
            var res = jQuery.parseJSON(data);
            adr = res.address;
            str = adr.substr(0,30)+'...<i class="icofont-copy copy-address"></i>';
        
            $(".receive-coin-address").attr("src",res.img);
            $('.cryptoaddress-txt').html(str);
            $('#copy_icofont').attr('onclick',"copy_function('"+adr+"')");
        }
    });

  });

var front_url='<?php echo front_url(); ?>';    
function validaddressFunction(e) {
  address = $(e).val();
  $.ajax({
    url: front_url+"validaddress", 
    type: "POST",
    data:{address:address},     
    success: function(data) {
      // console.log(data) 
      if(data==0) {
        $('.valid_address').val(0);
      } else {
        $('.valid_address').val(data);
      }  
           
    }
  });
}

$(document).ready(function() {
	EuroCurrencyInput = document.getElementById("EuroCurrencyInput");
  	changeFiatCurrency(EuroCurrencyInput);
});

</script>

  <script>
    $(document).ready(function(){

 
        // Close modal on button click
        $(".select-currency1").click(function(){
            $("#myCurrencyModal").modal('hide');
        });

        $(".select-currency1-receive").click(function(){
            $("#myCurrencyModal-receive").modal('hide');
        });
    });
</script>
