<!DOCTYPE html>
<html lang="en">
<?php
$user_id = $this->session->userdata('user_id');
$favicon = $site_common['site_settings']->site_favicon;
$sitelogo = $site_common['site_settings']->site_logo;

?>
<head>
    <meta charset="utf-8">
    <title>IXToken Exchange</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <link rel="icon" type="image/png" href="<?php echo $favicon;?>" />
    <meta content="Ixtokens" name="keywords">
    <meta content="Ixtokens" name="description">

    <!-- Bootstrap CSS File -->
    <link href="<?php echo front_lib();?>bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link href="<?php echo front_lib();?>font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo front_lib();?>animate/animate.min.css" rel="stylesheet">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:700|Roboto:400,500,700&display=swap" rel="stylesheet">

    <!-- OwlCarousel -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">

    <!-- Main Stylesheet File -->
    <link href="<?php echo front_css();?>style.css?v=<?php echo strtotime(date('d-m-Y H:i:s'));?>" rel="stylesheet">
    <link href="<?php echo front_css();?>header.css" rel="stylesheet">
    <link href="<?php echo front_css();?>custom-inner.css" rel="stylesheet">
    <link href="<?php echo front_lib();?>dropdown/animate.min.css" rel="stylesheet">
    <link href="<?php echo front_lib();?>dropdown/bootstrap-dropdownhover.min.css" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo front_css();?>jquery.growl.css?v=<?php echo strtotime(date());?>">
    <style type="text/css">
        .error{
            color: red !important;
        }
    </style>
</head>

<body class="inner-pages">


    <!--========================== Header ============================-->
    <header id="header" data-locale="en-us" data-hostnmae="" class="fedui-root fedui-header header_home inner-header">
        <div class="fedui-header-pc container-fluid">
            <div class="fedui-header-left">
                <h1 class="fedui-header-logo">
                     <a href="<?php echo base_url();?>"><img src="<?php echo $sitelogo;?>"></a>
                </h1>
            </div>
            <div class="fedui-header-right" id="nav-menu-container">
                <nav class="fedui-header-nav">
                    <ul class="nav-menu mr-auto sf-js-enabled sf-arrows" style="touch-action: pan-y;">
                        <li class="menu-active"><a class="fedui-theme-text" href="<?php echo base_url();?>">Home</a></li>

                        <li><a href="<?php echo base_url();?>trade" class="fedui-theme-text">Exchange</a></li>
                        <?php
                        if(isset($user_id) && !empty($user_id)){
                        ?>
                        <li><a href="<?php echo base_url();?>wallet"  class="fedui-theme-text">Wallet</a></li>
                        <?php
                    }
                    else{
                    ?>
                    <li><a href="<?php echo base_url();?>cms/about-us" class="fedui-theme-text">About</a></li>
                        <li><a href="<?php echo base_url();?>contact_us" class="fedui-theme-text">Contact</a></li>
                    <?php
                }
                        ?>
                    </ul>
                   <div class="dropdown cus-header-dropdown">
                        <a href="#" class="btn dropdown-toggle" data-hover="dropdown" data-animations="flipInX flipInY flipInX flipInY" aria-expanded="false"><?php echo UserName($user_id);?> <span class="header-profile-arrow"><i class="fa fa-angle-down" aria-hidden="true"></i></span></a>
                        <ul class="dropdown-menu dropdownhover-bottom" role="menu">
                            <li><a href="<?php echo base_url();?>profile">Profile</a></li>
                            <li><a href="<?php echo base_url();?>settings">Settings</a></li>
                            <li><a href="<?php echo base_url();?>support">Support</a></li>
                            <li><a href="<?php echo base_url();?>logout">Logout</a></li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
    </header>