<?php 
    $this->load->view('front/common/header');
    $user_id = $this->session->userdata('user_id');

     $settings = $site_common['site_settings']; 
    $sitelan = $this->session->userdata('site_lang');
    $heading = $sitelan."_heading";
    $meta_description = $sitelan."_meta_description";
    $meta_keywords = $sitelan."_meta_keywords";
    $title = $sitelan."_title";
    $copy_right_text = $sitelan."_copy_right_text";
    $cms_title = $sitelan."_title";
    $content_description = $sitelan."_content_description";
    $lang_id = $this->session->userdata('site_lang');
   // echo $lang_id;
   if($lang_id!=''){
      $title = $lang_id.'_name';
      $content = $lang_id.'_content';
      $currencyTitle = $lang_id.'_title';

   }else{
      $title = $site_lang.'_name';
      $content = $site_lang.'_content';
      $currencyTitle = $site_lang.'_title';
   }


?>
<link rel="stylesheet" href="<?php echo front_css();?>jquery.dataTables.min.css">
<style>
.grn {
    color: rgb(5, 177, 105);
}
.rdn {
    color: rgb(223, 95, 103);
} 
.custom-select{
  margin-bottom:15px;
  height: 50px !important;
}  
.dltbtn-adrbook {
  background: #dc3545;
  padding: 4px 10px;
  margin-left: 10px;
  margin-right: 0;
  border-radius: 6px;
  border: 1px solid #dc3545;
  color: #fff;
  font-size: 12px;
}  
</style>
<!-- breadcrumb -->
<div class="me-breadcrumb">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="me-breadcrumb-box">
            <h1><?=$this->lang->line('Address Book');?></h1>
          </div>
        </div>
      </div>
    </div>
</div>

<!-- price -->
<div class="me-investment-single me-padder-top">
    <div class="container">
      <?php if($this->session->userdata('user_id')!='') {
            $this->load->view('front/user/sidebar_sticky');  
          }?>
      <div class="row">
  <div class="col-lg-12">
     <div class="table-responsive mb-5">
         <table id="marketCms" class="display w-100 table wallet-table">
            <thead>
               <tr>
                    <th class="text-center"><?=$this->lang->line('name')?></th>
                    <th></th>
                    <th class="text-center"><?=$this->lang->line('coin')?></th>
                    <th></th>
                    <th class="text-center"><?=$this->lang->line('address')?></th>
                    <th></th>
               </tr>
            </thead>
            <tbody>
               <?php if(isset($crypto_address) && !empty($crypto_address)){
                        foreach($crypto_address as $adr){
                    ?>
                    <tr>
                        <td class="text-center"><?=$adr->filename?></td>
                        <td></td>
                        <td class="text-center"><?=$adr->coin?></td>
                        <td></td>
                        <td class="text-center"><?=$adr->address?></td>
                        <td class="text-center"><a href="javascript:;" class="btn editbtn-adrbook"><i class="icofont-edit"></i></a>
                        <a href="<?php echo base_url().'delete_address/'.$adr->id;?>" class="dltbtn-adrbook"><i class="icofont-ui-delete"></i></a></td>

                        <input type="hidden" class="hiden_id" value="<?=$adr->id?>">
                        <input type="hidden" class="hiden_filename" value="<?=$adr->filename?>">
                        <input type="hidden" class="hiden_wallet_type" value="<?=$adr->wallet_type?>">
                        <input type="hidden" class="hiden_emailaddress" value="<?=$adr->email_address?>">
                        <input type="hidden" class="hiden_coin" value="<?=$adr->coin?>">
                        <input type="hidden" class="hiden_des_tag" value="<?=$adr->destination_tag?>">
                        <input type="hidden" class="hiden_address" value="<?=$adr->address?>">
                    </tr>
                    <?php } }?>
               
               
            </tbody>
         </table>
          </div>
          </div>
      </div>
    </div>
  </div>

<div class="modal fade me-login-model address-modal" id="meAddressBook">
      <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
              <button type="button" class="close me-team-close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span>
              </button>
              <div class="modal-body">
                  <h1 class="me-login-title"><?=$this->lang->line('Address Management')?></h1>
                  <?php 
                      $faction = front_url()."add_address_book";
                      $fattributes = array('id'=>'address_book'); 
                      echo form_open($faction,$fattributes);
                  ?>
                      <div class="me-login-form">
                        <input type="text" class="inputCls" id="filename" name="filename" placeholder="<?=$this->lang->line('Name')?>">
                        <select id="wallet_type" name="wallet_type" class="form-control custom-select inputCls disableCls">
                          <option value=""><?=$this->lang->line('Select Wallet Type')?></option>
                          
                          <option value="Internal">Internal</option>
                          <option value="External">External</option>
                        
                        </select>
                        <select id="email_address" name="email_address" class="form-control custom-select inputCls disableCls">
                          <option value=""><?=$this->lang->line('Select Email Address')?></option>
                         
                        </select>
                        <select id="coin" name="coin" class="form-control custom-select inputCls disableCls">
                          <option value=""><?=$this->lang->line('Select coin')?></option>
                          <?php if(count($currency) > 0) {
                              foreach ($currency as $info) { ?>
                          <option ><?=$info->currency_symbol?></option>
                        <?php }}?>
                        </select>
                        <input type="text" class="inputCls disableCls" id="address" name="address" placeholder="<?=$this->lang->line('Address')?>">
                        <input type="text" class="inputCls" id="destination_tag" name="destination_tag" placeholder="<?=$this->lang->line('Destination Tag')?>" style="display:none">
                        <div class="me-login-btn" style="margin-bottom: 10px;">
                          <button class="me-btn"><?=$this->lang->line('Save');?></button>
                        </div>
                        <input class="inputCls" type="hidden" name="coin_id" id="coin_id">
                      </div>
                  <?php echo form_close();
                      ?>
                  
              </div>
          </div>
      </div>
  </div>

  <?php $this->load->view('front/common/footer'); ?>

<script type="text/javascript" src="<?php echo front_js();?>dataTables.min.js"></script>
<script type="text/javascript" src="<?php echo front_js();?>datatables.bootstrap4.min.js"></script>
<script>

add_adr_btn = '<?=$this->lang->line('Insert address');?>'; 
search_coin_name = '<?=$this->lang->line('Search Coin name');?>'; 
next = '<?=$this->lang->line('Next');?>';   
previous = '<?=$this->lang->line('Previous');?>'; 
no_data = '<?=$this->lang->line('No data available in table');?>';   
no_entry = '<?=$this->lang->line('Showing 0 to 0 of 0 entries');?>';   
show_entry = '<?=$this->lang->line('Showing _START_ to _END_ of _TOTAL_ entries');?>';   
filtered = '<?=$this->lang->line('(filtered from _MAX_ total entries)');?>';  

 var marketCmsTable = $('#marketCms').DataTable( {
     "order": [[ 5, "desc" ]],
     "pageLength": 10,
     "lengthChange": false,
     language: { 
         search: '<i class="fa fa-search"></i>',
         searchPlaceholder: search_coin_name,
         'paginate': {
          'previous': previous,
          'next': next,
        },
     },
     oLanguage: {
        "sEmptyTable": no_data,
        "infoEmpty": no_entry,
        "info": show_entry,
        "infoFiltered": filtered
     },
     'aoColumnDefs': [{
         'bSortable': false,
         'aTargets': [-1] 
     }],
 });
        
$('#marketCms_wrapper > .row:first-child > div:first-child').append('<ul class="marketslinqs d-flex" id="marketCms"><li><a class="btn me-AddressBook" href="javascript:;" data-toggle="modal" data-target="#meAddressBook" data-dismiss="modal" aria-label="Close">'+add_adr_btn+'</a></li></ul>');
     
 $('.marketslinqs li a').on( 'click', function () {
     var val = $(this).attr('data-filter');
     var exact = $(this).attr('data-exact');
     if(val != '' && val != undefined && val !== 'ALL'){
         if(exact == 1){
             var regex = '\\b' + val + '\\b';
             marketCmsTable.rows().search(regex, true, false).draw();
         }
         else{
             marketCmsTable.search( val).draw();
         }
         $('input[type=search]').val('');
     }
     else{
         $('input[type=search]').val('');
         marketCmsTable.search('').draw();
     }
 });


$('#address_book').validate({
    rules: {
        filename: {
            required: true,
        },
        coin: {
            required: true,
        },
        address: {
            required: true,
        },
        destination_tag: {
            required: true,
        }
    },
    messages: {
        filename: {
            required: "<?php echo $this->lang->line('Please enter name')?>",
        },
        coin: {
            required: "<?php echo $this->lang->line('Please select coin')?>",
        },
        address: {
            required: "<?php echo $this->lang->line('Please enter address')?>",
        },
        destination_tag: {
            required: "<?php echo $this->lang->line('Please enter destination tag')?>",
        }
    },
    submitHandler: function(form) {
      form.submit();
    }
});


$(document).on('click', '.me-AddressBook', function() {
  $('.inputCls').val('');
});
$(document).on('click', '.editbtn-adrbook', function() {
  id=$(this).closest('tr').find('.hiden_id').val();
  fname=$(this).closest('tr').find('.hiden_filename').val();
  wallet=$(this).closest('tr').find('.hiden_wallet_type').val();
  email=$(this).closest('tr').find('.hiden_emailaddress').val();
  coin=$(this).closest('tr').find('.hiden_coin').val();
  adr=$(this).closest('tr').find('.hiden_address').val();
  des_tag=$(this).closest('tr').find('.hiden_des_tag').val();

  if(des_tag!='') $("#destination_tag").css('display','block').attr("style", "pointer-events: none;").val(des_tag); 
   else $("#destination_tag").css('display','none').val('');

  $('#filename').val(fname);
  $('#wallet_type').val(wallet);
  $('#email_address').val(email);
  $('#address').val(adr);
  $('#coin').val(coin);
  $('#coin_id').val(id);
  $('.disableCls').attr("style", "pointer-events: none;");
  $('#meAddressBook').modal('show');
 
});

$(document).on('change', '.custom-select', function() {
  sym = $(this).val();
  if(sym=='XRP') $("#destination_tag").css('display','block'); 
    else $("#destination_tag").css('display','none'); 
});


</script>

<script>
          var front='<?php echo front(); ?>';
          $(document).ready(function(e) {
          $.ajax({
                    url: front+'user/ajax_email',
                    type: 'POST',
                    success: function ($array_mail) {
                      $('#email_address').html($array_mail);
}

                });
        });

        </script> 