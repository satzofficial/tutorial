<?php  include realpath(dirname(__DIR__) . '/common/inner_header.php'); ?>
<?php
$unique_id = ($users->unique_id) ? $users->unique_id :'';
$wlink = base_url()."signup?ref=".$unique_id;
$main_balance_centum = 24471955;
$level_income_centum = 24072544;
$global_income_centum = 381136;
$sponsor_income_centum = 18275;
?>

<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css">
  .ui-dialog-titlebar-close {
    visibility: hidden;
}


.modal-confirm {    
  color: #636363;
  width: 400px;
}
.modal-confirm .modal-content {
  padding: 20px;
  border-radius: 5px;
  border: none;
  text-align: center;
  font-size: 14px;
}
.modal-confirm .modal-header {
  border-bottom: none;   
  position: relative;
}
.modal-confirm h4 {
  text-align: center;
  font-size: 26px;
  margin: 30px 0 -10px;
}
.modal-confirm .close {
  position: absolute;
  top: -5px;
  right: -2px;
}
.modal-confirm .modal-body {
  color: #999;
}
.modal-confirm .modal-footer {
  border: none;
  text-align: center;   
  border-radius: 5px;
  font-size: 13px;
  padding: 10px 15px 25px;
}
.modal-confirm .modal-footer a {
  color: #999;
}   
.modal-confirm .icon-box {
  width: 80px;
  height: 80px;
  margin: 0 auto;
  border-radius: 50%;
  z-index: 9;
  text-align: center;
  border: 3px solid #3fc3ee;
}
.modal-confirm .icon-box i {
  color: #3fc3ee;
  font-size: 46px;
  display: inline-block;
  margin-top: 13px;
}
.modal-confirm .btn, .modal-confirm .btn:active {
  color: #fff;
  border-radius: 4px;
  background: #60c7c1;
  text-decoration: none;
  transition: all 0.4s;
  line-height: normal;
  min-width: 120px;
  border: none;
  min-height: 40px;
  border-radius: 3px;
  margin: 0 5px;
}
.modal-confirm .btn-secondary {
  background: #c1c1c1;
}
.modal-confirm .btn-secondary:hover, .modal-confirm .btn-secondary:focus {
  background: #a8a8a8;
}
.modal-confirm .btn-danger {
  background: #f15e5e;
}
.modal-confirm .btn-danger:hover, .modal-confirm .btn-danger:focus {
  background: #ee3535;
}
.trigger-btn {
  display: inline-block;
  margin: 100px auto;
}
</style> 


</div>


<div id="modal-claim" class="modal fade">
  <div class="modal-dialog modal-confirm">
    <div class="modal-content">
      <div class="modal-header flex-column">
        <div class="icon-box">
          <i class="material-icons">check</i>
        </div>            
        <h4 class="modal-title w-100">Are you sure?</h4>  
          <!-- <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button> -->
      </div>
      <div class="modal-body">
        <p>Do you want to claimed the level income?</p>
      </div>
      <div class="modal-footer justify-content-center">
        <input type="hidden" name="type" value="" id="type">
        <button type="button" class="btn btn-secondary close-modal" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-danger" data-type="level" onclick="confirm_levelincome(this)">Confirm</button>
      </div>
    </div>
  </div>
</div> 

<?php  
// echo "<pre>";
// echo print_r($result);


?>

<!DOCTYPE html>
<html>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>
<div class= "container">
<h2>Deposit History</h2>

<table>
  <tr>
    <th>Name</th>
    <th>Amount</th>
    <th>status</th>
  </tr>
<?php  foreach($result as $res) {  ?>

  <tr>
    <td><?php  echo $res->hash;?></td>
    <td><?php echo $res->amount;?></td>
    <td><?php if($res->status =='1'){
        echo "completed";
    }else{
        echo "in Process";
    }
         ?></td>
  </tr>
  <?php  } ?>
  
</table>
</div>
</body>
</html>





<?php  include realpath(dirname(__DIR__) . '/common/inner_footer.php'); ?>

<div id="income-confirmation-dialog" title="Confirmation Required">
  Are you sure about this?
</div>
<script>   

$(document).ready(function() {

    $('#modal-claim').modal({backdrop:'static', keyboard: false}); 
    $( '.copy32343534, .whatsapp_cls' ).tooltip();
   
})


  if (document.querySelector('.copy32343534') !== null) {
    document.getElementById("copy32343534").addEventListener("click", copy_password);
  }
  
  function copy_password(e) {
    e.preventDefault();
    var text = document.getElementById('hlink').value;
    var elem = document.createElement("textarea");
    document.body.appendChild(elem);
    elem.value = text;
    elem.select();
    document.execCommand("copy");
    document.body.removeChild(elem);

    $('.referral_link').removeClass('fa-link').addClass('fa-check');
    $('.referral_link').delay(1000).fadeOut('slow');
    
    $("#copy32343534").load(location.href + " #copy32343534>*", "");

  }

</script>


<?php if(isset($remaining_period_timestamp)){ ?>
  <script type="text/javascript">
   var countDownDate = <?php echo $remaining_period_timestamp; ?> * 1000;
   var now = <?php echo time() ?> * 1000;

// Update the count down every 1 second
var x = setInterval(function() {
  now = now + 1000;
// Find the distance between now an the count down date
var distance = countDownDate - now;
// Time calculations for days, hours, minutes and seconds
var days = Math.floor(distance / (1000 * 60 * 60 * 24));
var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
var seconds = Math.floor((distance % (1000 * 60)) / 1000);
// Output the result in an element with id="demo"
document.getElementById("package-remainder").innerHTML = days + "d " + hours + "h " + minutes + "m " + seconds + "s ";
// If the count down is over, write some text 
if (distance < 0) {
  clearInterval(x);
  document.getElementById("package-remainder").innerHTML = "EXPIRED";
}

}, 1000);

</script>
<?php } ?>


<script type="text/javascript">
  $(document).ready(function() {
    var confirmDialogId = $('#income-confirmation-dialog');

    $(confirmDialogId).dialog({
      autoOpen: false,
      modal: true,
      // dialogClass:'transparent'
    });

    $.fn.confirmation = function(_this){
      var remainingBal = '0.00';
      var myDialog = $(confirmDialogId).dialog({
        closeOnEscape: false,
        open: function(event, ui) {
            $(".ui-dialog-titlebar-close", ui.dialog || ui).hide();
        },
        buttons : {
          "Confirm" : function() {
            var _claim_parent = _this.closest('.with-radial-gradient');
            var Type = _this.data('type');
            $.ajax({
              url: baseURL + 'claim',
              type: 'POST',
              dataType: 'json',
              data: {type : Type},
              success: function(res) {
                if(res.status == true){
                  $('.main-balance-amount-status').html(res.main_balance.toString(2));
                  _claim_parent.find('span.claim-amount-status').html(remainingBal);
                  _claim_parent.find('.claim-status').html(res.msg).show().delay(4000).fadeOut();
                }
                myDialog.dialog('close');
              }
            });            
          },
          "Cancel" : function() {
            $(this).dialog("close");
          }
        }
      });

      $(confirmDialogId).dialog("open");
       // $('#modal-claim').modal('show'); 

        
    }


    $(document).on('click', '.level-income-claim, .global-income-claim, .sponsor-income-claim', function(event) {
      event.preventDefault();
      /* Act on the event */
      var _this = $(this);
      $.fn.confirmation(_this);
        // $('#type').val($(this).data('type'));
        // $('#modal-claim').modal('show');   
    });


  });


// $(document).on('click', '.close-modal', function() {

//   $("#modal-claim").modal("hide"); 
// });




// function confirm_levelincome(_this) {
    
//     console.log(_this);
//     return;
    
//     var remainingBal = '0.00';
//     var Type = $('#type').val();
//     var _claim_parent = _this.closest('.with-radial-gradient');
//     var Type = _this.data('type');



//     $.ajax({
//       url: baseURL + 'claim',
//       type: 'POST',
//       dataType: 'json',
//       data: {type : Type},
//       success: function(res) {
//         if(res.status == true){
//           $('.main-balance-amount-status').html(res.main_balance.toString(2));
//           _claim_parent.find('span.claim-amount-status').html(remainingBal);
//           _claim_parent.find('.claim-status').html(res.msg).show().delay(4000).fadeOut();
//         }
//         // myDialog.dialog('close');
//       }
//     }); 
// }


</script>





</body>
</html>