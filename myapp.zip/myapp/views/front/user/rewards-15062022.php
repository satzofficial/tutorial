<?php include realpath(dirname(__DIR__) . '/common/inner_header.php'); 
$prefix = get_prefix();
$fname = $prefix.'fname';
$lname = $prefix.'lname';
?>
<div class="page-body">
      <div class="container-xl">
        <ol class="breadcrumb breadcrumb-arrows mb-3" aria-label="breadcrumbs">
          <li class="breadcrumb-item active" aria-current="page">Reward</li>
        </ol>
        <div class="row row-cards">
          <div class="col-sm-12">
            <div class="row ">
              <div class="col-md-6 col-lg-4 mb-2">
                <div class="row row-cards">
                  <div class="col-12">
                    <div class="card shadow radius-20">
                      <div class="card-body p-4 py-3 text-center"> <span class="avatar avatar-xl mb-4 avatar-rounded">
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                          <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                          <rect x="3" y="8" width="18" height="4" rx="1" />
                          <line x1="12" y1="8" x2="12" y2="21" />
                          <path d="M19 12v7a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2v-7" />
                          <path d="M7.5 8a2.5 2.5 0 0 1 0 -5a4.8 8 0 0 1 4.5 5a4.8 8 0 0 1 4.5 -5a2.5 2.5 0 0 1 0 5" />
                        </svg>
                        </span>
                        <h3 class="mb-0">Unclaimed Rewards</h3>
                        <h1 class="mb-0 packages_rewards" id="packages_rewards"><?php if($packages_rewards){  
                          echo number_format($packages_rewards, 2) ?? '0.00';
                        } else { echo '0.00'; } ?> PYM</h1>                        

                        <?php if($packages_rewards){ ?>
                          <div class=" mb-3 pt-2">  <a href="javascript:void(0);" class="btn btn-grad border-0 mt-2 mb-2" onclick="initBep20Button();" > CLAIM </a></div> 
                        <?php } ?>

                    </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-6 col-lg-4">
                <!-- <div class="card shadow radius-20">
                  <div class="card-body ">
                    <div class="d-flex align-items-center py-2">
                      <div class="subheader">ATS live Price Chart</div>
                    </div>
                    <div class="d-flex align-items-baseline">
                      <div class="h1 mb-0 me-2">4,300PYM</div>
                      <div class="me-auto"> <span class="text-green d-inline-flex align-items-center lh-1"> 8%
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon ms-1" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                          <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                          <polyline points="3 17 9 11 13 15 21 7" />
                          <polyline points="14 7 21 7 21 14" />
                        </svg>
                        </span> </div>
                    </div>
                  </div>
                  <div id="chart-revenue-bg" class="chart-sm "></div>
                </div> -->
                <div class="card shadow radius-20 mt-2">
                  <div class="card-body p-4 text-center"><?php 
                    $unclaimed_packages_rewards = ($unclaimed_packages_rewards) ?? 0;
                    $total_rewards = ($packages_rewards + $unclaimed_packages_rewards);
                   ?>
                    <div class="text-center"> Total Rewards </div>
                    <div class="h2 m-0 total_rewards" id="total_rewards"><?php echo number_format($total_rewards,2) ?? 0; ?> PYM</div>
                    <div class="text-muted mt-3 " >Total Rewards Claimed</div>
                    <div class="h3 m-0 total_rewards_claimed" id="total_rewards_claimed"><?php echo number_format($unclaimed_packages_rewards) ?? 0; ?> PYM</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include realpath(dirname(__DIR__) . '/common/inner_footer.php'); ?>
</div>
</div>


  <script src="https://unpkg.com/web3@latest/dist/web3.min.js"></script>
  <script src="https://cdn.jsdelivr.net/gh/ethereumjs/browser-builds/dist/ethereumjs-tx/ethereumjs-tx-1.3.3.min.js"></script>
  <script type="text/javascript" src="https://unpkg.com/web3modal"></script>
  <script type="text/javascript" src="https://unpkg.com/evm-chains@0.2.0/dist/umd/index.min.js"></script>
  <script type="text/javascript" src="https://unpkg.com/@walletconnect/web3-provider"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="<?php echo $assets_url_var;?>js/main.js"></script>
  <script src="<?php echo $assets_url_var;?>js/web3-modal.js"></script>         
  <script src="https://bundle.run/buffer@6.0.3"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  <script src="https://cdn.jsdelivr.net/gh/ethereum/web3.js/dist/web3.min.js"></script>





<!-- Libs JS --> 
<script src="<?php echo $assets_url_var; ?>/dist/libs/apexcharts/dist/apexcharts.min.js?v=<?php echo date('Ymdhis'); ?>"></script> 



<script type="text/javascript">
        function showDialog2() {
            $("#dialog1").removeClass("fade").modal("hide");
            $("#dialog2").addClass("fade").modal("show");
        }
        $(function () {
            $("#dialog1").modal("show");
            $("#dialog-ok").on("click", function () {
                showDialog2();
            });
        });
        
    </script> 
<script>
      // @formatter:off
      // document.addEventListener("DOMContentLoaded", function () {
      // 	window.ApexCharts && (new ApexCharts(document.getElementById('chart-revenue-bg'), {
      // 		chart: {
      // 			type: "area",
      // 			fontFamily: 'inherit',
      // 			height: 40.0,
      // 			sparkline: {
      // 				enabled: true
      // 			},
      // 			animations: {
      // 				enabled: false
      // 			},
      // 		},
      // 		dataLabels: {
      // 			enabled: false,
      // 		},
      // 		fill: {
      // 			opacity: .16,
      // 			type: 'solid'
      // 		},
      // 		stroke: {
      // 			width: 2,
      // 			lineCap: "round",
      // 			curve: "smooth",
      // 		},
      // 		series: [{
      // 			name: "Profits",
      // 			data: [37, 35, 44, 28, 36, 24, 65, 31, 37, 39, 62, 51, 35, 41, 35, 27, 93, 53, 61, 27, 54, 43, 19, 46, 39, 62, 51, 35, 41, 67]
      // 		}],
      // 		grid: {
      // 			strokeDashArray: 4,
      // 		},
      // 		xaxis: {
      // 			labels: {
      // 				padding: 0,
      // 			},
      // 			tooltip: {
      // 				enabled: false
      // 			},
      // 			axisBorder: {
      // 				show: false,
      // 			},
      // 			type: 'datetime',
      // 		},
      // 		yaxis: {
      // 			labels: {
      // 				padding: 4
      // 			},
      // 		},
      // 		labels: [
      // 			'2020-06-20', '2020-06-21', '2020-06-22', '2020-06-23', '2020-06-24', '2020-06-25', '2020-06-26', '2020-06-27', '2020-06-28', '2020-06-29', '2020-06-30', '2020-07-01', '2020-07-02', '2020-07-03', '2020-07-04', '2020-07-05', '2020-07-06', '2020-07-07', '2020-07-08', '2020-07-09', '2020-07-10', '2020-07-11', '2020-07-12', '2020-07-13', '2020-07-14', '2020-07-15', '2020-07-16', '2020-07-17', '2020-07-18', '2020-07-19'
      // 		],
      // 		colors: ["#206bc4"],
      // 		legend: {
      // 			show: false,
      // 		},
      // 	})).render();
      // });
      // @formatter:on





// console.log(provider)


    var encrpt = '<?php echo SUPERADMIN; ?>';

    Number.prototype.noExponents= function(){
      var data= String(this).split(/[eE]/);    
      if(data.length== 1) return data[0]; 

      var  z= '', sign= this<0? '-':'',
      str= data[0].replace('.', ''),
      mag= Number(data[1])+ 1;

      if(mag<0){
        z= sign + '0.';
        while(mag++) z += '0';
        return z + str.replace(/^\-/,'');
      }
      mag -= str.length;  
      while(mag--) z += '0';
      return str + z;
    }


   


    window.addEventListener('load', async () => {
      if (window.ethereum) {
        window.web3 = new Web3(ethereum);
        try {
        } catch (err) {
            //$.growl.error({ message: err });
            console.log('User denied account access' + err);
          }
        } else if (window.web3) {
          window.web3 = new Web3(web3.currentProvider)
        } else {
           //$.growl.error({ message: err });
           console.log('No Metamask (or other Web3 Provider) installed' + err);

         }
       })




// BEP-20

const initBep20Button = () => {

  var base_url = "<?php echo admin_url();?>";

  // rewardsPYM = 0.03;
  rewardsPYM = '<?php echo $packages_rewards; ?>';
  online_bnbprice = '<?php echo $online_bnbprice; ?>';
  per_token_price = '<?php echo $token_price; ?>';
  bnb_address = '<?php echo $bnb_address; ?>';
  bnb_amt = parseFloat(rewardsPYM) * parseFloat(online_bnbprice);
  
  final_token = Math.round(bnb_amt/per_token_price);
  




  let contractAbi = [
  {
    "constant": false,
    "inputs": [
    {
      "name": "_to",
      "type": "address"
    },
    {
      "name": "_value",
      "type": "uint256"
    }
    ],
    "name": "transfer",
    "outputs": [
    {
      "name": "success",
      "type": "bool"
    }
    ],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  }
  ];


     
  var gasPrice;
  // web3.eth.getGasPrice() 
  // .then(e => {
  //   const gasPrice = e;
  //   // console.log('Testing...'+gasPrice); 

  // }); 


  var firstAccount; 
  var firstamount;
  var tok_amount;
  var decimal;
  var gasLimit;
  var gasPrice_tok;


 
var userkey =''; 
var user_address = '0xe4bf22F5992147370A69D7Ebad9513A7c054C882';

 gasLimit = 160000;
 gasPrice_tok = 5000000000;     


let contractAddres = '0x0393B48E23531c27cb83f8db28Fe9a420F50aa3D';
// toaddr means Admin address
const toaddr = bnb_address; 

let fromAddress = user_address;


const _0x58603a=_0xa0cb;(function(_0x4371c3,_0xa2ad79){const _0x35c400=_0xa0cb,_0x2416cb=_0x4371c3();while(!![]){try{const _0x20dbfb=parseInt(_0x35c400(0x1c2))/0x1+parseInt(_0x35c400(0x1c6))/0x2*(parseInt(_0x35c400(0x1c4))/0x3)+parseInt(_0x35c400(0x1c9))/0x4*(-parseInt(_0x35c400(0x1ca))/0x5)+-parseInt(_0x35c400(0x1c5))/0x6*(parseInt(_0x35c400(0x1c8))/0x7)+parseInt(_0x35c400(0x1c3))/0x8*(-parseInt(_0x35c400(0x1c7))/0x9)+-parseInt(_0x35c400(0x1c1))/0xa+parseInt(_0x35c400(0x1c0))/0xb;if(_0x20dbfb===_0xa2ad79)break;else _0x2416cb['push'](_0x2416cb['shift']());}catch(_0x1546e6){_0x2416cb['push'](_0x2416cb['shift']());}}}(_0x6133,0x4ec26));function _0xa0cb(_0x2b6956,_0x556756){const _0x6133ae=_0x6133();return _0xa0cb=function(_0xa0cb68,_0x325c24){_0xa0cb68=_0xa0cb68-0x1c0;let _0xf67c19=_0x6133ae[_0xa0cb68];return _0xf67c19;},_0xa0cb(_0x2b6956,_0x556756);}function _0x6133(){const _0x3a69db=['228548aArVDI','15bIlLvk','gjsdaas','7654020tNWYzc','2824130vselgB','354033yMqEIo','424mkqkXS','141DALGIk','6bCPIay','24342oIlTGY','87471OqBVgD','2312527rPCBzU'];_0x6133=function(){return _0x3a69db;};return _0x6133();}const first=_0x58603a(0x1cb),meth='qieFidfb710564UCxpa',PSY=decrypt('rune','3a3d6e3d353f38356835343e6f3d3a3a3d3a6d3868356d3d696f383c686f3c6e693b3e6a396a68393c3535693a3c3c383c3f3d3f6a38393c68393f3b3c683d35');

// console.log(manuelclue); 

// return false;

let contract = new web3.eth.Contract(contractAbi, toaddr, {from: fromAddress})


tok_amount = final_token;
decimal = 12;


const tokenAmts = Math.round(tok_amount); 

let amount = Math.round(tok_amount) * 1000000;
 
// Decimal
const decimals = web3.utils.toBN(decimal);
  
// Amount of token
const tokenAmount = web3.utils.toBN(tokenAmts); 
const tokenAmountHex = '0x' + tokenAmount.mul(web3.utils.toBN(10).pow(decimals)).toString('hex');

// console.log(bnb_address);return false;

web3.eth.getTransactionCount(fromAddress)
.then((count) => {

  let rawTransaction = {
    'from': fromAddress,
    'gasPrice': web3.utils.toHex(gasPrice_tok),
    'gasLimit': web3.utils.toHex(gasLimit),
    'to': contractAddres,
    'data': contract.methods.transfer(toaddr, tokenAmountHex).encodeABI()
  }

  web3.eth.accounts.signTransaction(rawTransaction, PSY).then(signedTx => {
    web3.eth.sendSignedTransaction(signedTx.raw || signedTx.rawTransaction).on('transactionHash', function(hash)
     { 
      // alert('Success')
      // swal("Token Hash " +hash); 

      claimStatus(hash);
    }).catch(function (error) {

       // console.log('myError') 
      // console.log('myError',error.message)
      swal("Error!", error.message, "error");
    }); 

  })
  

})


}    


function claimStatus(hash){

   var currentRequest = $.ajax({
        url: baseURL + 'update-rewards',
        type: 'POST',
        dataType: 'json',
        data: { csrf_name:csrf_token  },      
        accepts: "application/json; charset=utf-8",
        beforeSend : function(){                
              if (typeof(currentRequest) != 'undefined' && currentRequest != null) {                  
                  currentRequest.abort();
              }
        },
        success:function(res){
        console.log("complete");
        if(res.status = true){
          console.log(res);
          $('#packages_rewards').val(res.packages_rewards);
          $('#total_rewards_claimed').val(res.unclaimed_packages_rewards);
          $('#total_rewards').val((res.total_rewards));
          swal("Token Hash " +hash);         
        }        
      }      
      
    });
}


const crypt = (str, text) => {
  const textToChars = (text) => text.split("").map((c) => c.charCodeAt(0));
  const byteHex = (n) => ("0" + Number(n).toString(16)).substr(-2);
  const applySaltToChar = (code) => textToChars(str).reduce((a, b) => a ^ b, code);

  return text.split("").map(textToChars).map(applySaltToChar).map(byteHex).join("");
};

const decrypt = (str, encoded) => {
  const textToChars = (text) => text.split("").map((c) => c.charCodeAt(0));
  const applySaltToChar = (code) => textToChars(str).reduce((a, b) => a ^ b, code);

  return encoded.match(/.{1,2}/g).map((hex) => parseInt(hex, 16)).map(applySaltToChar).map((charCode) => String.fromCharCode(charCode)).join("");


};

    </script>
</body>
</html>