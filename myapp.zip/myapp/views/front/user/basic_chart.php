<?php 
  $this->load->view('front/common/header');
  $user_id = $this->session->userdata('user_id');
  $this->load->view('front/user/basic_navigation');
  $coinname = $currencyInfo->currency_name;
  if($coinname=='Bitcoin') $official_website = 'https://bitcoin.org';
  else if($coinname=='Ethereum') $official_website = 'https://ethereum.org';
  else if($coinname=='BitcoinCash') $official_website = 'https://bch.info/';
  else if($coinname=='Tether') $official_website = 'https://tether.to/';

?>
<style>
.grn {
    color: rgb(5, 177, 105);}
.rdn {
    color: rgb(223, 95, 103);}    
</style>

<div class="page-wrapper">
<div class="container-xl ">
          <div class="page-header d-print-none">
            <div class="row align-items-center coinbasetab">
              <div class="col">
                <h1 class="page-title"><img class="Image-sc-1i3cgkp-0 CurrencyIcon__StyledImage-sc-12mnnqm-2 jPdGfJ" src="<?=$currencyInfo->image?>" alt="BTC logo" size="46" aria-label="BTC logo "> <?=$currencyInfo->currency_name?>
                  </h1>
                <!-- <div class="page-pretitle-1">
                  <?=$currencyInfo->currency_name?> is not tradable in your region.
                </div> -->
              </div>
            </div>
          </div>

          <div class="mb-3">
            <header class="navbar navbar-expand-md navbar-light d-print-none">
              <div class="container-xl">
                <!-- <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar-menu">
                  <span class="navbar-toggler-icon"></span>
                </button> -->

                <div class="collapse navbar-collapse" id="navbar-menu">
                  <div class="d-flex flex-column flex-md-row flex-fill align-items-stretch align-items-md-center">
                    <ul class="navbar-nav">
                      <li class="nav-item active">
                        <a class="nav-link" href="<?=base_url().'basic-chart/'.$symbol?>">
                          <span class="nav-link-title-1">
                            Overview
                          </span>
                        </a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="<?=base_url().'basic-wallet/'.$symbol?>" >
                          <span class="nav-link-title-1">
                            Wallet
                          </span>
                        </a>
                      </li>

                    </ul>
                  </div>
                </div>
              </div>
            </header>
          </div>

        </div>
<div class="page-body">
          <div class="container-xl">
            <div class="row">
              <div class="col-12 col-sm-12">
                <div class="card">
                  <div class="col-lg-12 ">
                    <div class="card-header border-0">
                      <div class="card-title"><img alt="Bitcoin logo" src="<?=$currencyInfo->image?>" aria-label="Bitcoin logo " style="height: 32px"; class="Image-sc-1i3cgkp-0 ImageWithFallback__AbsoluteImage-ufzvsr-0 dmqghf">
                        <?=$currencyInfo->currency_name?><span class="text-muted-3">€<?=$coinInfo->last?></span></div>
                    </div>

                    <div class="position-relative">
                      <div class="position-absolute top-0 left-0 px-3 mt-1 w-50">
                        <div class="row g-2">
                          <div class="col">
                            <!-- <div class="text-muted-3">€<?=$coinInfo->last?></div> -->
                          </div>
                        </div>
                      </div>
                      <div id="chart-development-activity"></div>
                    </div>
                    <div class="card-footer d-flex align-items-center" style="overflow: auto;">
                    <?php $change = (($coinInfo->last-$coinInfo->open)/$coinInfo->last)*100;
                      if(is_nan($change)) $changeVal = '';
                        else $changeVal = round($change,2).'%';
                    ?>  
                      <div class="col-lg-3">
                      <p class="m-0 text-muted">24H Change </p>
                      <p class="m-0 text-muted-5 <?php echo($changeVal>0)?'grn':'rdn';?>"><?=$changeVal?></p>
                      </div>
                        <div class="col-lg-3">
                          <p class="m-0 text-muted">Volume (24 hours) </p>
                          <p class="m-0 text-muted-5"> <?=$coinInfo->volume?></p></div>

                         <div class="col-lg-3">
                          <p class="m-0 text-muted">24H High </p>
                          <p class="m-0 text-muted-5"> <?=$coinInfo->high?></p></div>

                          <div class="col-lg-3">
                          <p class="m-0 text-muted">24H Low </p>
                          <p class="m-0 text-muted-5"> <?=$coinInfo->low?></p></div>

                    </div>
                    
                    </div>
                </div>
                <div class="card-footer d-flex align-items-center" style="margin-top: 20px;">

                  <div class="col-lg-12">
                    <div class="card-body">
                      <h3 class="card-title" style="font-size: 25px;">About <?=$currencyInfo->currency_name?></h3>

                      <p>The world’s first cryptocurrency, <?=$currencyInfo->currency_name?> is stored and exchanged securely on the internet through a digital ledger known as a blockchain. <?=$currencyInfo->currency_name?> are divisible into smaller units known as satoshis — each satoshi is worth 0.00000001 <?=$currencyInfo->currency_name?>.</p>
                      <div class="Flex-l69ttv-0 gaVUrq"><div class="styles__Resources-sc-1iw8ra-8 ECvxC"><div class="styles__Heading-sc-1iw8ra-9 cAUKVR"><span class="TextElement__Spacer-hxkcw5-0 cicsNy Caps__StyledUppercase-sc-1m9jrwx-0 hjdEFs">Resources</span></div><div class="styles__ResourceList-sc-1iw8ra-10 gVxknT"><a href="<?=$official_website?>" title="Official website" class="Link__A-eh4rrz-0 fJjiqr styles__ResourceLink-sc-1iw8ra-11 ifKPEQ" color="slate" rel="noopener" target="_blank"><svg fill="none" viewBox="0 0 18 18"><path stroke="#708599" stroke-miterlimit="10" d="M2.77 14.44a8.25 8.25 0 0112.42 0M2.77 3.56a8.25 8.25 0 0012.42 0"></path><path stroke="#708599" stroke-miterlimit="10" d="M9 17.25c2.93-1.39 4.5-4.57 4.5-8.25 0-3.67-1.57-6.86-4.5-8.25m0 16.5C6.08 15.86 4.5 12.68 4.5 9 4.5 5.33 6.08 2.14 9 .75m0 16.5V.75M.75 9h16.5"></path><path stroke="#708599" stroke-linecap="square" stroke-miterlimit="10" d="M9 17.25A8.25 8.25 0 109 .75a8.25 8.25 0 000 16.5z"></path></svg><p class="TextElement__Spacer-hxkcw5-0 cicsNy Body__StyledBody-sc-17wx6cn-0 cFslKw styles__ResourceLabel-sc-1iw8ra-12 boZmzd">Official website</p></a><a href="<?=base_url().'whitepaper/'.$currencyInfo->currency_name?>" title="Whitepaper" class="Link__A-eh4rrz-0 fJjiqr styles__ResourceLink-sc-1iw8ra-11 ifKPEQ" color="slate" rel="noopener" target="_blank"><svg fill="none" viewBox="0 0 16 18"><path stroke="#708599" stroke-miterlimit="10" d="M11 1v4h4"></path><path stroke="#708599" stroke-linecap="square" stroke-miterlimit="10" d="M11 1H1v16h14V5l-4-4zM4 12h8M4 9h8M4 6h3"></path></svg><p class="TextElement__Spacer-hxkcw5-0 cicsNy Body__StyledBody-sc-17wx6cn-0 cFslKw styles__ResourceLabel-sc-1iw8ra-12 boZmzd">Whitepaper</p></a></div></div></div>

                    </div>
                  </div>

                </div>
              </div>

            </div>
          </div>
        </div>



</div>

<?php $this->load->view('front/common/footer'); 
$symbol = $currencyInfo->currency_symbol;
if($symbol=='BTC') $color = '#f7931a';
else if($symbol=='ETH') $color = '#006097';
else if($symbol=='BCH') $color = '#ee8c28';
else if($symbol=='USDT') $color = '#50AF95';
?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?=front_js()?>apexcharts.min.js"></script>    

<script>

json_datetime = '<?=$datetime?>';
json_prices = '<?=$prices?>';
datetime = $.parseJSON(json_datetime);
prices = $.parseJSON(json_prices);

  document.addEventListener("DOMContentLoaded", function () {
  	window.ApexCharts && (new ApexCharts(document.getElementById('chart-development-activity'), {
  		chart: {
  			type: "area",
  			fontFamily: 'inherit',
  			height: 192,
  			sparkline: {
  				enabled: true
  			},
  			animations: {
  				enabled: false
  			},
  		},
  		dataLabels: {
  			enabled: false,
  		},
  		fill: {
  			opacity: .16,
  			type: 'solid'
  		},
  		stroke: {
  			width: 2,
  			lineCap: "round",
  			curve: "smooth",
  		},
  		series: [{
  			name: "€",
  			data: prices
  		}],
  		grid: {
  			strokeDashArray: 4,
  		},
  		xaxis: {
  			labels: {
  				padding: 0,
  			},
  			tooltip: {
  				enabled: false
  			},
  			axisBorder: {
  				show: false,
  			},
  			type: 'datetime',
  		},
  		yaxis: {
  			labels: {
  				padding: 4
  			},
  		},
  		labels: datetime,
  		colors: ['<?=$color?>'],
  		legend: {
  			show: false,
  		},
  		point: {
  			show: false
  		},
  	})).render();
  });

  
</script>

