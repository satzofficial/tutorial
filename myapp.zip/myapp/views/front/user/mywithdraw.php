<?php 
// $this->load->view('front/common/header');
$user_id = $this->session->userdata('user_id');
// $url1=$_SERVER['REQUEST_URI'];
// $min = min_to_sec(1);
// header("Refresh: $min; URL=$url1");
// date_default_timezone_set('Asia/Kolkata');
// echo date_default_timezone_get();
// $date = date('Y-m-d H:i:s');
// $UTC = gmdate('M d, Y H:i:s', strtotime($date));
?>
<?php 
// session_start();
// $counter = strtotime(date("Y-m-d H:i:s")." +2 minutes");
// $current_time = strtotime(date("Y-m-d H:i:s"));
// if($_SESSION["withdraw_timer"]){
//   if($current_time > $_SESSION["withdraw_timer"]){
//     $date = $counter;
//     // echo 'Fresher';
//   }else{
//     $date = $_SESSION["withdraw_timer"];  
//     // echo 'session';
//   }   
// }else{
//   $date = $counter;
// }
// $_SESSION["withdraw_timer"] = $date;
?>
<!Doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
  <meta http-equiv="X-UA-Compatible" content="ie=edge"/>
  <title>Ten Realm</title>
  <!-- CSS files -->
  <link href="https://design.getcrypex.com/ten-realm/dashboard/dist/css/tenrealm.css" rel="stylesheet"/>
  <link href="http://code.jquery.com/ui/1.9.1/themes/ui-lightness/jquery-ui.css" rel="stylesheet"/>
<!--    <link href="./dist/css/tenrealm-flags.min.css" rel="stylesheet"/>
    <link href="./dist/css/tenrealm-payments.min.css" rel="stylesheet"/>
    <link href="./dist/css/tenrealm-vendors.min.css" rel="stylesheet"/>
    <link href="./dist/css/demo.min.css" rel="stylesheet"/>-->

  </head>
  <body class="antialiased">
    <span id="msg"></span>
    <div id="dialog" style="display: none"></div>
    <div class="wrapper">
      <div class="sticky-top">
        <header class="navbar navbar-expand-md navbar-light sticky-top d-print-none">
          <div class="container-xl">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar-menu"> <span class="navbar-toggler-icon"></span> </button>
            <h1 class="navbar-brand navbar-brand-autodark d-none-navbar-horizontal pe-0 pe-md-3"> <a href="."> <img src="https://design.getcrypex.com/ten-realm/dashboard/static/logo.png" width="110" height="32" alt="tenrealm" class="navbar-brand-image"> </a> </h1>
            <div class="navbar-nav flex-row order-md-last">
              <div class="nav-item dropdown"> <a href="#" class="nav-link d-flex lh-1 text-reset p-0" data-bs-toggle="dropdown" aria-label="Open user menu"> <span class="avatar avatar-sm" style="background-image: url(./static/avatars/000m.jpg)"></span>
                <div class="d-none d-xl-block ps-2">
                  <div>Jeyabalan</div>
                  <div class="mt-1 small text-muted">ID: 123456</div>
                </div>
              </a>
              <div class="dropdown-menu dropdown-menu-end dropdown-menu-arrow"> <a href="#" class="dropdown-item"> <span class="avatar avatar-xs rounded me-2" style="background-image: url(./static/avatars/000m.jpg)"></span>
                <h5 class="m-0"><span class="h6">Sponsor</span> <br/>
                Paweł Kuna </h5>
              </a>
              <div class="dropdown-divider"></div>
              <a href="profile.html" class="dropdown-item">Profile</a>
              <div class="dropdown-divider"></div>
              <a href="#" class="dropdown-item">Logout</a> </div>
            </div>
          </div>
        </div>
      </header>

      <div class="navbar-expand-md">
        <div class="collapse navbar-collapse" id="navbar-menu">
          <div class="navbar navbar-light">
            <div class="container-xl">
              <ul class="navbar-nav">
                <li class="nav-item"> <a class="nav-link" href="index.html" > <span class="nav-link-title"> Home </span> </a> </li>
                <li class="nav-item dropdown"> <a class="nav-link dropdown-toggle" href="#navbar-extra" data-bs-toggle="dropdown" role="button" aria-expanded="false" > <span class="nav-link-title"> Affiliate </span> </a>
                  <div class="dropdown-menu"> <a class="dropdown-item" href="level-income.html" > Level Income </a> <a class="dropdown-item" href="global-income.html" > Global Income </a> <a class="dropdown-item" href="sponsor-income.html" > Sponsor Income </a> </div>
                </li>
                <li class="nav-item dropdown"> <a class="nav-link dropdown-toggle" href="#navbar-extra" data-bs-toggle="dropdown" role="button" aria-expanded="false" > <span class="nav-link-title"> Wallet </span> </a>
                  <div class="dropdown-menu"> <a class="dropdown-item" href="paymentgateway.html" > Payment Gateway </a> <a class="dropdown-item" href="activation.html" > Activation </a> <a class="dropdown-item" href="transfer.html" > Transfer </a><a class="dropdown-item" href="transactions.html" > Transaction </a> </div>
                </li>
                <li class="nav-item"> <a class="nav-link" href="reward.html" > <span class="nav-link-title"> Rewards </span> </a> </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="page-wrapper">
      <div class="page-body">
        <div class="container-xl">
          <ol class="breadcrumb breadcrumb-arrows mb-3" aria-label="breadcrumbs">
            <li class="breadcrumb-item"><a href="#">Wallet</a></li>
            <li class="breadcrumb-item active" aria-current="page">Payment Gateway</li>
          </ol>
          <div class="row row-cards">
            <div class="col-sm-12">
              <div class="row ">
                <div class="col-md-6 col-lg-3">
                  <div class="card shadow radius-20">
                    <div class="card-body p-4 pb-0 text-center">
                      <div class="text-end text-green position-absolute pull-right"> <span class="text-green d-inline-flex align-items-center lh-1"> 6% <!-- Download SVG icon from http://tabler-icons.io/i/trending-up -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon ms-1" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                          <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                          <polyline points="3 17 9 11 13 15 21 7"></polyline>
                          <polyline points="14 7 21 7 21 14"></polyline>
                        </svg>
                      </span> </div>
                      <span class="avatar avatar-xl mb-3 avatar-rounded" style="background-image: url(./static/Litecoin-LTC-icon.png)"></span>
                      <h3 class="m-0 mb-1"><a href="#">LITECOIN</a></h3>
                    </div>
                    <dl class="row p-3">
                      <dt class="col-5">Current Price:</dt>
                      <dd class="col-7">129.01PYM</dd>
                      <dt class="col-5">Market Cap:</dt>
                      <dd class="col-7">8954743108.62</dd>
                      <dt class="col-5">24Hr Vol:</dt>
                      <dd class="col-7">575967145.46PYM</dd>
                    </dl>
                    <div class="d-flex"> <a href="#" class="card-btn"  data-bs-toggle="modal" data-bs-target="#modal-deposit"> Deposit</a> <a href="#" class="card-btn" data-bs-toggle="modal" data-bs-target="#modal-withdraw"> Withdraw</a> </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <footer class="footer footer-transparent d-print-none ">
    <div class="container">
      <div class="row">
        <div class="col-12 col-lg-auto mt-3 mt-lg-0 ">
          <ul class="list-inline list-inline-dots mb-0">
            <li class="list-inline-item"> Copyright &copy; 2022 <a href="." class="link-secondary">tenrealm</a>.
            All rights reserved. </li>
          </ul>
        </div>
      </div>
    </div>
  </footer>
</div>
</div>

<div class="modal modal-blur fade" id="modal-deposit" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
    <?php
      $action = '';
      $attributes = array('id'=>'pre_deposit_form','autocomplete'=>"off",'class'=>'pre_deposit_form');
      echo form_open($action,$attributes);
      ?>
    <div class="modal-content shadow radius-20">
      <div class="modal-body">
        <div class="modal-title"><span class="avatar avatar-xs mt-3 mr-2 avatar-rounded" style="background-image: url(./static/Litecoin-LTC-icon.png)"></span>LITECOIN</div>
        <div>
          <div class="input-group mb-2"> <span class="input-group-text"> PYM </span>
            <input type="text" class="form-control" autofocus name="user_deposit_amount" id="user_deposit_amount" min="0" placeholder="Enter deposit value" autocomplete="off">
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary float-right pre-modal-deposit" >Deposit</button>
        <button type="button" class="btn btn-link link-secondary me-auto pre_deposit_cancel_btn" data-bs-dismiss="modal">Cancel</button></div>
      </div>
       <?php echo form_close(); ?>
    </div>
  </div>


  <div class="modal modal-blur fade" id="modal-qacode" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
      <?php
      $action = '';
      $attributes = array('id'=>'deposit_form','autocomplete'=>"off",'class'=>'deposit_form');
      echo form_open($action,$attributes);
      ?>
      <input type="hidden" name="user_deposit_amount_submit" value="" id="user_deposit_amount_submit" >
      <div class="modal-content shadow radius-20">
        <div class="modal-body pb-0">
          <div class="modal-title h1">
            <h2>Initializing</h2>
          </div>
          <div>
            <div class="row">
              
              <div class="col-md-6 col-xl-6"> <a id="copy3234" class="card card-link" href="javascript:;">
                <div class="card-body p-2">
                  <div class="row">
                    <div class="col-auto"> <span class="avatar rounded" style="background-image: url(./static/Litecoin-LTC-icon.png)"></span> </div>
                    <div class="col" >
                      <div class="font-weight-medium" id="get_ltc_values">123456789</div> <span>LTC</span>
                      <div class="text-muted">Civil Engineer</div>
                    </div>
                  </div>
                </div>
              </a>
              <span class="badge bg-green-lt mt-1 show_copied_to_clipboard"
               style="display: none;" id="show_copied_to_clipboard">Copied to clipboard!</span>
             </div>

              <div class="col-md-6 col-xl-6"> <a class="card card-link" href="#">
                <div class="card-body p-2">
                  <div class="row">
                    <div class="col">
                      <div class="font-weight-medium text-right">
                        <h1> <strong id="display-user-deposit-amount"></strong> </h1>
                      </div>
                    </div>
                  </div>
                </div>
              </a> </div>
            </div>
            <div id="display_qr_code_as_true" >
            <p class="mt-3 mb-1">To complete your payment, please send <strong>0.00808983 LTC</strong> or scan the QR code</p>
            <div class="card">
              <div class="card-body text-center">
                <div class="mb-3"> <img id="qr_code_for_scanner" src="" alt="" style="height:160px;"></div>
              </div>
              <!-- <form> -->
                <div class="input-group">
                  <input type="text" class="form-control" value="<?php echo md5(rand()); ?>" readonly placeholder="Some path" id="crypto_address" >
                  <span class="input-group-btn">
                    <button class="btn btn-default" type="button" id="copy-button" data-toggle="tooltip" data-placement="button" title="Copy to Clipboard" > Copy </button>
                    <span style="color:#66A81A;font-weight:bold;" class="copy_but"></span>
                  </span>
                </div>

                  <div id="countdown">
                    <div id="tiles">
                      <span id="hours">00</span>
                      <span id="minutes">00</span>
                      <span  id="seconds">00</span></div>
                    <div class="labels">                   
                      <li>Hrs</li>
                      <li>Mins</li>
                      <li>Secs</li>
                    </div>
                  </div>
                  <div id="expire-countdown"></div>

                <p class="text-center pb-0 mb-0">Gateway expires at <span class="badge bg-azure-lt" id="endDate"></span></p>
              </div>
            </div>
            <div id="display_qr_code_as_false"  style="display:none;">This deposit has expired. Please create a new transaction.</div>

            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-link link-secondary me-auto deposit_form_cancel" >Cancel</button>
            <button type="submit" class="btn btn-primary deposit_form_submit" id="deposit_form_submit">Yes, Done</button>
          </div>
        </div>
        <?php echo form_close(); ?>
      </div>
    </div>


    <div class="modal modal-blur fade" id="modal-withdraw" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog modal-sm modal-dialog-centered" role="document">      
       <?php
       $action = '';
       $attributes = array('id'=>'withdrawcoinForm','autocomplete'=>"off",'class'=>'withdraw_form');
       echo form_open($action,$attributes);
       ?>
       <input type="hidden" name="withdrawcoin" value="1242342">
       <div class="modal-content shadow radius-20">
        <div class="modal-body">
          <div class="modal-title"> <span class="avatar avatar-xs mt-3 mr-2 avatar-rounded" style="background-image: url(./static/Litecoin-LTC-icon.png)"></span>LITECOIN</div>
          <div>
            <label for="inp" class="inp">
              <input type="text" id="amount" name="amount" class="form-control" placeholder=" ">
              <span class="label">Withdraw Amount</span> <span class="focus-bg"></span> </label>
              <label for="inp" class="inp">
                <input type="text" id="address" name="address" class="form-control" placeholder=" ">
                <span class="label">Payment Address</span> <span class="focus-bg"></span> </label>
              </div>
            </div>
            <div class="alert alert-danger print-error-msg" style="display:none"></div>
            <div class="modal-footer">            
              <button type="button" class="btn btn-link link-secondary me-auto cancel_btn" >Cancel</button>
              <button type="submit" name="withdrawcoin" class="btn btn-primary float-right" value="9823853" >Yes, Withdraw</button>
              <!-- <input type="submit" name="withdrawcoin" class="btn btn-primary float-right" value="Yes, Withdraw" > -->
            </div>
          </div>
          <?php echo form_close(); ?>  
        </div>
      </div>


      <div class="modal modal-blur fade prfile-dir" id="modal-report" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Jeyabalan Profile</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <div class="row g-2 align-items-center">
                <div class="col-auto"> <span class="avatar avatar-lg" style="background-image: url(./static/avatars/000m.jpg)"></span> </div>
                <div class="col">
                  <h4 class="card-title m-0"> Jeyabalna </h4>
                  <div class="text-muted"> Id: 1234567890 </div>
                  <div class="text-muted"> Mailid: jeyabalan@sp.com </div>
                  <div class="text-muted"> Joining Date/Time: July / 20222 : 22.30AM </div>
                </div>
              </div>
            </div>
            <div class="modal-body">
              <div class="form-selectgroup-boxes row mb-3 ">
                <div class="col-lg-6"> <span class="form-selectgroup-label d-flex align-items-center p-3 bg-green-lt mb-2"> <span class="form-selectgroup-label-content"> <span class="form-selectgroup-title strong mb-1">Modern Earth</span> <span class="d-block text-muted text-black ">Joining Date/Time: July / 20222 : 22.30AM</span> </span> </span>
                </label>
              </div>
              <div class="col-lg-6"> <span class="form-selectgroup-label d-flex align-items-center p-3 bg-blue-lt mb-2"> <span class="form-selectgroup-label-content"> <span class="form-selectgroup-title strong mb-1">Glorious Moon</span> <span class="d-block text-muted text-black "><a href="#"  data-bs-toggle="modal" data-bs-target="#modal-small">Activated</a></span> </span> </span>
              </label>
            </div>
            <div class="col-lg-6"> <span class="form-selectgroup-label d-flex align-items-center p-3 mb-2"> <span class="form-selectgroup-label-content"> <span class="form-selectgroup-title strong mb-1">Mysterious Mars</span> <span class="d-block text-muted text-black ">In Activated</span> </span> </span>
            </label>
          </div>
          <div class="col-lg-6"> <span class="form-selectgroup-label d-flex align-items-center p-3 mb-2"> <span class="form-selectgroup-label-content"> <span class="form-selectgroup-title strong mb-1">Modern Earth</span> <span class="d-block text-muted text-black ">In Activated</span> </span> </span>
          </label>
        </div>
        <div class="col-lg-6"> <span class="form-selectgroup-label d-flex align-items-center p-3 mb-2"> <span class="form-selectgroup-label-content"> <span class="form-selectgroup-title strong mb-1">Modern Earth</span> <span class="d-block text-muted text-black ">In Activated</span> </span> </span>
        </label>
      </div>
      <div class="col-lg-6"> <span class="form-selectgroup-label d-flex align-items-center p-3 mb-2"> <span class="form-selectgroup-label-content"> <span class="form-selectgroup-title strong mb-1">Modern Earth</span> <span class="d-block text-muted text-black ">In Activated</span> </span> </span>
      </label>
    </div>
  </div>
</div>
<div class="modal-footer"> <a href="#" class="btn btn-link link-secondary" data-bs-dismiss="modal"> Cancel </a> </div>
</div>
</div>
</div>
<div class="modal modal-blur fade" id="modal-small" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-body">
        <div class="row">
          <div class="col-sm-12">
            <div class="card1">
              <div class="empty">
                <div class="empty-img"><img src="./static/illustrations/undraw_quitting_time_dm8t.svg" height="128" alt=""> </div>
                <h4 class="empty-title">Modern Earth</h4>
                <h2 class="empty-subtitle text-muted"> 100PYM </h2>
                <div class="empty-action">
                  <input type="text" class="form-control" name="example-text-input" placeholder="Enter User Id">
                  Activation for <span class="badge bg-blue p-2 mt-2"> <span class="avatar" style="background-image: url(./static/avatars/005f.jpg)"></span> Dunn Slane </span> </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-link link-secondary me-auto" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-green" data-bs-dismiss="modal"  data-bs-toggle="modal" data-bs-target="#modal-success">Yes, Activated</button>
        </div>
      </div>
    </div>
  </div>
  <div class="modal modal-blur fade" id="modal-success" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
      <div class="modal-content">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        <div class="modal-status bg-success"></div>
        <div class="modal-body text-center py-4"> 
          <!-- Download SVG icon from http://tabler-icons.io/i/circle-check -->
          <svg xmlns="http://www.w3.org/2000/svg" class="icon mb-2 text-green icon-lg" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
            <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
            <circle cx="12" cy="12" r="9" />
            <path d="M9 12l2 2l4 -4" />
          </svg>
          <h3>Activated succedeed</h3>
          <div class="text-muted">Your payment of $290 has been successfully submitted. Your invoice has been sent to support@tabler.io.</div>
        </div>
        <div class="modal-footer">
          <div class="w-100">
            <div class="row">
              <div class="col"><a href="#" class="btn btn-white w-200" data-bs-dismiss="modal"> Go to dashboard </a></div>
              <div class="col"><a href="#" class="btn btn-success w-20 mr-5 text-center" data-bs-dismiss="modal"> 
                <!-- Download SVG icon from http://tabler-icons.io/i/download -->
                <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                  <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                  <path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2 -2v-2" />
                  <polyline points="7 11 12 16 17 11" />
                  <line x1="12" y1="4" x2="12" y2="16" />
                </svg>
              </a><a href="#" class="btn btn-success w-20 mr-5 text-center" data-bs-dismiss="modal"> 
                <!-- Download SVG icon from http://tabler-icons.io/i/brand-whatsapp -->
                <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                  <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                  <path d="M3 21l1.65 -3.8a9 9 0 1 1 3.4 2.9l-5.05 .9" />
                  <path d="M9 10a0.5 .5 0 0 0 1 0v-1a0.5 .5 0 0 0 -1 0v1a5 5 0 0 0 5 5h1a0.5 .5 0 0 0 0 -1h-1a0.5 .5 0 0 0 0 1" />
                </svg>
              </a></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="modal modal-blur fade" id="modal-large" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-full-width modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Modern Earth Global Farming Income Chart </h5>
          <span class="float-end"><!-- Download SVG icon from http://tabler-icons.io/i/cloud-download -->
            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
              <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
              <path d="M19 18a3.5 3.5 0 0 0 0 -7h-1a5 4.5 0 0 0 -11 -2a4.6 4.4 0 0 0 -2.1 8.4" />
              <line x1="12" y1="13" x2="12" y2="22" />
              <polyline points="9 19 12 22 15 19" />
            </svg>
          </span>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="table-responsive">
            <table
            class="table table-vcenter card-table border-n">
            <thead>
              <tr>
                <th>Level</th>
                <th>Price</th>
                <th>Users</th>
                <th>Income</th>
                <th>Upgrade</th>
                <th>Regeneration</th>
                <th>To Sponsor</th>
                <th>Profit</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td >1</td>
                <td class="text-muted" > 1 </td>
                <td class="text-muted" >2</td>
                <td class="text-muted" > 2 </td>
                <td> NIL </td>
                <td> NIL </td>
                <td> 0.2 </td>
                <td> 1.80 </td>
              </tr>
              <tr>
                <td >2</td>
                <td class="text-muted" > 1 </td>
                <td class="text-muted" >4</td>
                <td class="text-muted" >4</td>
                <td> NIL </td>
                <td> NIL </td>
                <td> 0.2 </td>
                <td> 3.80 </td>
              </tr>
              <tr>
                <td >3</td>
                <td class="text-muted" > 1 </td>
                <td class="text-muted" >8</td>
                <td class="text-muted" >8</td>
                <td> NIL </td>
                <td> NIL </td>
                <td> 0.4 </td>
                <td> 7.60 </td>
              </tr>
              <tr>
                <td >4</td>
                <td class="text-muted" > 1 </td>
                <td class="text-muted" >16</td>
                <td class="text-muted" >16</td>
                <td> NIL </td>
                <td> NIL </td>
                <td> 0.8 </td>
                <td> 15.20 </td>
              </tr>
              <tr>
                <td >5</td>
                <td class="text-muted" > 1 </td>
                <td class="text-muted" >32</td>
                <td class="text-muted" >32</td>
                <td> NIL </td>
                <td> NIL </td>
                <td> 1.60 </td>
                <td> 30.40 </td>
              </tr>
              <tr>
                <td >6</td>
                <td class="text-muted" > 1 </td>
                <td class="text-muted" >64</td>
                <td class="text-muted" >64</td>
                <td> NIL </td>
                <td> NIL </td>
                <td> 3.20 </td>
                <td> 40.80 </td>
              </tr>
              <tr>
                <td >7</td>
                <td class="text-muted" > 1 </td>
                <td class="text-muted" >128</td>
                <td class="text-muted" >128</td>
                <td> NIL </td>
                <td> NIL </td>
                <td> 6.40 </td>
                <td> 1.60 </td>
              </tr>
              <tr>
                <td >8</td>
                <td class="text-muted" > 1 </td>
                <td class="text-muted" >256</td>
                <td class="text-muted" >256</td>
                <td> NIL </td>
                <td> NIL </td>
                <td> 12.80 </td>
                <td> 223.20 </td>
              </tr>
              <tr>
                <td >9</td>
                <td class="text-muted" > 1 </td>
                <td class="text-muted" >512</td>
                <td class="text-muted" >512</td>
                <td> NIL </td>
                <td> NIL </td>
                <td> 25.60 </td>
                <td> 466.40 </td>
              </tr>
              <tr>
                <td >10</td>
                <td class="text-muted" > 1 </td>
                <td class="text-muted" >1024</td>
                <td class="text-muted" >1024</td>
                <td> NIL </td>
                <td> NIL </td>
                <td> 51.20 </td>
                <td> 952.80 </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn me-auto" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/ui/1.13.1/jquery-ui.min.js" integrity="sha256-eTyxS0rkjpLEo16uXTS0uVCS4815lc40K2iVpWDvdSY=" crossorigin="anonymous"></script>
<!-- Libs JS --> 
<script src="https://design.getcrypex.com/ten-realm/dashboard/dist/libs/apexcharts/dist/apexcharts.min.js"></script> 
<!-- tenrealm Core --> 
<script src="https://design.getcrypex.com/ten-realm/dashboard/dist/js/tenrealm.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/additional-methods.min.js?v=20220222022403"></script>

<script type="text/javascript">

  
  var baseURL = "<?php echo base_url(); ?>";
  var $csrf_name = "<?php  echo $this->security->get_csrf_token_name(); ?>"; // for the name
  var $csrf_token = "<?php  echo $this->security->get_csrf_hash(); ?>";  // for the value    

  var _print_withdraw_error_class = $(".print-error-msg");
  var _error_div_amount_class = $(".print-error-msg>div.amount_err");
  var _error_div_address_class = $(".print-error-msg>div.address_err");
  var withdrawForm = $('#withdrawcoinForm');
  var depositForm = $('#deposit_form');
  var preDepositForm = $('#pre_deposit_form');

  function showDialog2() {
    $("#dialog1").removeClass("fade").modal("hide");
    $("#dialog2").addClass("fade").modal("show");
  }
  $(function () {
    $("#dialog1").modal("show");
    $("#dialog-ok").on("click", function () {
      showDialog2();
    });
  });
</script> 

<script>





  $(document).ready(function() {
  // Initialize the tooltip.
  $('#copy-button').tooltip();
});
</script> 
<script>
// SATZ JS settings
$(document).ready(function () {

$('#modal-withdraw').modal({backdrop:'static', keyboard: false}); 
$('#modal-deposit').modal({backdrop:'static', keyboard: false});
$('#modal-qacode').modal({backdrop:'static', keyboard: false});
  

      $('#withdrawcoinForm').validate({ // initialize the plugin
        rules: {
          amount: {
           required: {
            depends:function(){
             $(this).val($.trim($(this).val()));
             return true;
           }
         },      
         number:true,
       },
       address: {
        required: {
          depends:function(){
           $(this).val($.trim($(this).val()));
           return true;
         }
       },
       minlength: 5,

     }
   },
   submitHandler: function (form, event) {
    event.preventDefault();
    withdrawForm.find('.print-error-msg').empty().hide();          
    var amount = $('#amount').val();
    var address = $('#address').val();
        $.ajax({
          url: baseURL + "withdraw_validation",
          type: 'POST',
          dataType: 'json',
            data: {  // MUST send the CSRF Token Value
              <?php  echo $this->security->get_csrf_token_name(); ?> : function() {
                return "<?php  echo $this->security->get_csrf_hash(); ?>";
              },
              address:address , amount : amount
            },
            accepts: "application/json; charset=utf-8",
            success: function(data) {                
              if($.isEmptyObject(data.error)){
                $.fn.errorFn(data); 
                $.fn.successFormSubmitFn(form); 
                return;
              }else{
                $.fn.successFn(data,1);                   
              }                
            },
            error: jqueryErrorHandling,
          });



            // form.submit();
          }
      });


      $.fn.successFormSubmitFn = (function(form){
        // console.log(form);
        var url = "<?php echo base_url('withdraw/LTC'); ?>";
        $.ajax({
          url: url,
          type: 'POST',
          dataType: 'json',
          data : withdrawForm.serialize(),
          success:function(data){
            console.log(data);
          }
        });


      })


      $.fn.errorFn = (function(data){          
        if($.isEmptyObject(data.error)){          
          _print_withdraw_error_class.html('');
          _print_withdraw_error_class.css('display','none');  
        }
        return true;
      })

      $.fn.successFn = (function(data){            
        _print_withdraw_error_class.css('display','block');                    
        if(_error_div_amount_class.length == 0){              
          _print_withdraw_error_class.html(data.error);
          return true;
        }else{
          return true;              
        }     
      })


      

      // Reset of the modal 
      $(document).on('click', '.cancel_btn', function(){          
        // alert('sample2');
        withdrawForm[0].reset();          
        $('#user_deposit_amount').val('');
        withdrawForm.validate().resetForm();
        withdrawForm.find('.error').removeClass('error');
        withdrawForm.find('.print-error-msg').empty().hide();
        $('#modal-withdraw').modal('hide');        
      })

      
      $(document).on('click', '.pre_deposit_cancel_btn', function(){    
        // alert('sample1');
        $('#user_deposit_amount').val('');
        preDepositForm.validate().resetForm();
        preDepositForm.find('.error').removeClass('error');
        preDepositForm.find('.print-error-msg').empty().hide();
        $('#modal-deposit').modal('hide');        
      })      



      $(document).on('click','.pre-modal-deposit', function(){

        $('#pre_deposit_form').validate({ // initialize the plugin
           rules: {
              user_deposit_amount: {
                 required: {
                  depends:function(){
                  $(this).val($.trim($(this).val()));
                  return true;
                 },
               },
             number:true,
          },
          },
          submitHandler: function (form, event) {
            event.preventDefault();                    
            $.fn.get_deposit_details();
          }
          });
      })

    });

  
$.fn.get_deposit_details = function(){
        var data = { "<?php  echo $this->security->get_csrf_token_name(); ?>" : "<?php  echo $this->security->get_csrf_hash(); ?>" };
        var getDepositURL = baseURL + 'get_deposit_details';
        $.ajax({
          url: getDepositURL,
          data,
          type: 'POST',
          dataType: 'json',                      
          success:function(result){
            if(result.status == true){
              var getUserDepositAmount = $('#user_deposit_amount').val();
              $('#user_deposit_amount_submit').val(getUserDepositAmount);
              $('#display-user-deposit-amount').html(getUserDepositAmount+' PYM');
              var QRcode = result.First_coin_image;
              // var CryptoAddress = result.crypto_address;
              var CryptoAddress = '4224';
              $('#qr_code_for_scanner').attr('src', QRcode);
              $('#crypto_address').val(CryptoAddress);              
              userDefinedTimer(result.user_defined_timestamp);
             
              // var idVar = setInterval(() => { return is_completed_transaction(true); }, 4000);              
              $('#modal-qacode').modal('show');
            }
          },
        });
}
  

  


    // Numeric only control handler
    $.fn.ForceNumericOnly = (function()
    {
      return this.each(function()
      {
        $(this).keydown(function(e)
        {
          var key = e.charCode || e.keyCode || 0;
              // allow backspace, tab, delete, enter, arrows, numbers and keypad numbers ONLY
              // home, end, period, and numpad decimal
              return (                          
                key == 8 || 
                key == 9 ||
                key == 13 ||
                key == 46 ||
                key == 110 ||
                key == 190 ||
                (key >= 35 && key <= 40) ||
                (key >= 48 && key <= 57) ||
                (key >= 96 && key <= 105)
                );
            });
      });
    });

    $("#amount").ForceNumericOnly();
    $("#user_deposit_amount").ForceNumericOnly();


document.getElementById("copy3234").addEventListener("click", copy_password);

function copy_password() {
    var copyText = document.getElementById("get_ltc_values");
    var textArea = document.createElement("textarea");

    document.body.appendChild(textArea);
    textArea.value = copyText.textContent;
    my_textarea = textArea;
    my_textarea.onfocus = function () {
       my_textarea.select();
       my_textarea.onfocus = undefined;
    } 
    my_textarea.focus();
    my_textarea.focus();
    my_textarea.select();
    document.execCommand("Copy");    
    textArea.remove();    
    document.getElementById("show_copied_to_clipboard").style.display = "block";
    setTimeout(function() {
    var loader = document.getElementById("show_copied_to_clipboard");
    loader.style.transition = '.5s';
    loader.style.opacity = '0';
    loader.style.visibility = 'none';
    }, 1250);

}

document.getElementById("copy-button").addEventListener("click", function() {
    copyToClipboardMsg(document.getElementById("crypto_address"), "msg");
});

function copyToClipboardMsg(elem, msgElem) {  
    var succeed = copyToClipboard(elem);
    var msg;
    if (!succeed) {
        msg = "Copy not supported or blocked.  Press Ctrl+c to copy."
    } else {
        msg = "Text copied to the clipboard."
    }
    if (typeof msgElem === "string") {
        msgElem = document.getElementById(msgElem);
    }
    msgElem.innerHTML = msg;
    setTimeout(function() {
        msgElem.innerHTML = "";
    }, 2000);
}

function copyToClipboard(elem) {
    // create hidden text element, if it doesn't already exist
    console.log(elem.innerHTML);
    var targetId = "_hiddenCopyText_";
    var isInput = elem.tagName === "INPUT" || elem.tagName === "TEXTAREA" || elem.innerHTML != "";
    var origSelectionStart, origSelectionEnd;
    if (isInput) {
        // can just use the original source element for the selection and copy
        target = elem;
        origSelectionStart = elem.selectionStart;
        origSelectionEnd = elem.selectionEnd;
    } else {
        // must use a temporary form element for the selection and copy
        target = document.getElementById(targetId);
        if (!target) {
            var target = document.createElement("textarea");
            target.style.position = "absolute";
            target.style.left = "-9999px";
            target.style.top = "0";
            target.id = targetId;
            document.body.appendChild(target);
        }
        target.textContent = elem.textContent;
    }
    // select the content
    var currentFocus = document.activeElement;
    target.focus();
    target.setSelectionRange(0, target.value.length);
    
    // copy the selection
    var succeed;
    try {
        succeed = document.execCommand("copy");
    } catch(e) {
        succeed = false;
    }
    // restore original focus
    if (currentFocus && typeof currentFocus.focus === "function") {
        currentFocus.focus();
    }
    
    if (isInput) {
        // restore prior selection
        elem.setSelectionRange(origSelectionStart, origSelectionEnd);
    } else {
        // clear temporary content
        target.textContent = "";
    }
    return succeed;
}

</script> 
<script>
// Display network error
function jqueryErrorHandling(xhr, status, exception) {
  alert('sample EREORE');
  var responseText;
  $("#dialog").html("");
  try {
    responseText = jQuery.parseJSON(xhr.statusText);
    $("#dialog").append("<div><b>" + status + " " + exception + "</b></div>");
    $("#dialog").append("<div><u>Exception</u>:<br /><br />" + responseText.ExceptionType + "</div>");
    $("#dialog").append("<div><u>StackTrace</u>:<br /><br />" + responseText.StackTrace + "</div>");
    $("#dialog").append("<div><u>Message</u>:<br /><br />" + responseText.Message + "</div>");
  } catch (e) {
    var errorMessage = xhr.statusText;
    $("#dialog").html(errorMessage);
    $("#dialog").dialog({
      title: "Exception Details",
      autoOpen: true,
      modal: true,
      width: 700,
      buttons: {
        Close: function() {
          $(this).dialog('close');
        }
      }
    });
  }
}

</script>

<script>
    function userDefinedTimer(timestamp=0){  
      
      var customTime;
      if(timestamp==0){         
        customTime = 1000;  
        timestamp=1;
        alert('sampleerer')
        // debugger;
        is_completed_transaction(false);      
       }else{
        customTime = 1000;
       }


      var countDownDate = new Date(parseInt(timestamp) * 1000).getTime();
      var utcSeconds = parseInt(timestamp);
      var d = new Date(0);
      d.setUTCSeconds(utcSeconds);
      document.getElementById('endDate').innerText = d.toUTCString().slice(0,-3) + 'UTC';
        var myInterval = setInterval(function () {
          const now = Math.round((new Date()).getTime())
          var distance = countDownDate - now - 10000;                
          if (distance > 0) {            
              is_completed_transaction(true);             
              var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
              var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
              var seconds = Math.floor((distance % (1000 * 60)) / 1000);              
              document.getElementById("minutes").innerHTML = (minutes.toString().length == 1) ? '0' + minutes : minutes;
              document.getElementById("seconds").innerHTML = (seconds.toString().length == 1) ? '0' + seconds : seconds;
              document.getElementById("hours").innerHTML = (hours.toString().length == 1) ? '0' + hours : hours;
              if (distance < 0) {
                  document.getElementById( 'display_qr_code_as_true' ).style.display = 'none';
                  document.getElementById( 'display_qr_code_as_false' ).style.display = 'block';                  
                  clearInterval(myInterval);
                  document.getElementById("expire-countdown").innerHTML = "EXPIRED";
                  document.getElementById("qr_code_for_scanner").innerHTML = '<div class="expire-box">EXPIRED</div>'
              }              
          }else{   
            alert('instant')
            is_completed_transaction(false);  
            // stopFn();
            clearInterval(myInterval);
            document.getElementById( 'display_qr_code_as_true' ).style.display = 'none';
            document.getElementById( 'display_qr_code_as_false' ).style.display = 'block';
            document.getElementById( 'deposit_form_submit' ).style.display = 'none';
            // return 'sample23';
          }
      }, customTime);   

      if(timestamp == 0){ return clearInterval(myInterval); }
    }
    

    function stopFn() {
      alert('HERERERE')
     return is_completed_transaction(false);      
    }

    function is_completed_transaction(flag){
      if(flag == false) return;
      var CryptoAddress = $('#crypto_address').val();      
       $.ajax({
          url: baseURL + 'is_completed_transaction',
          type: 'POST',
          dataType: 'json',
          data: {
                <?php  echo $this->security->get_csrf_token_name(); ?> : function() {
                return "<?php  echo $this->security->get_csrf_hash(); ?>";
              },
              crypto_address : CryptoAddress
            },
          accepts: "application/json; charset=utf-8",
          success:function(data){
            if(data.status == true){              
              alert('transition completed');
              $('#modal-qacode').modal('hide');
              $('#modal-deposit').modal('hide');
              $('.cancel_btn').trigger('click');
              $('.pre_deposit_cancel_btn').trigger('click');
              return true;
            }            
          }
        });
    }

    $.fn.are_u_sureFn = (function(){
        window.onbeforeunload = function() {
          return "Data will be lost if you leave the page, are you sure?";
        };  
    });

    $(document).on('click', '.deposit_form_cancel', function(){
         var ask = window.confirm("Are you sure?");
        if (ask) {          
          userDefinedTimer(0);
          $('#modal-qacode').modal('hide');
          $('#modal-deposit').modal('hide');
          $('.cancel_btn').trigger('click');
          $('.pre_deposit_cancel_btn').trigger('click');

        }
    });

</script>

</body>
</html>


