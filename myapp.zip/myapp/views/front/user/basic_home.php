<?php 
  $this->load->view('front/common/header');
  $user_id = $this->session->userdata('user_id');
  $this->load->view('front/user/basic_navigation');

  if(count($currencyDet))
      {
        $tot_balance = 0;
        $tot_Euro_balance = 0;
        foreach($currencyDet as $cur)
        {
            $balance = getBalance($user_id,$cur->id);
            $usd_balance = $balance * $cur->online_usdprice;
            $eur_balance = $balance * $cur->online_europrice;

            $tot_balance += $usd_balance;
            $tot_Euro_balance += $eur_balance;
        }
      }
?>
<style>
.changes-txt {
  margin-left: 50px;
  /*margin-top: -28px;*/
}  
.changes-price {
  margin-left: 30px;
 /* margin-bottom: -15px;*/
}
.grn {
    color: rgb(5, 177, 105);}
.rdn {
    color: rgb(223, 95, 103);} 

#stuff {

    -webkit-transition: all 500ms ease-in-out;
    -moz-transition: all 500ms ease-in-out;
    -ms-transition: all 500ms ease-in-out;
    -o-transition: all 500ms ease-in-out;
    transition: all 500ms ease-in-out; position:absolute; z-index:999999;  width:100px; left:45%; top:-0%; 
}
.hover-stf { position:relative; height:auto;}
.transaction-img {
  max-width: 50px;
  /*height: 50px; */
}


</style>
<div class="page-wrapper">
	<div class="page-body">
      <div class="container-xl">
        <div class="row row-deck row-cards">
          <div class="col-lg-12" style="overflow: auto;">
            <div class="row row-cards">

                <div class="card">
                  <div class="card-header">
                    <h3 class="card-title"><?php echo $this->lang->line('Watchlist');?></h3>
                  </div>

                  <div class="col-lg-12 chartt">
                  <?php if($currencyDet) {
                    foreach ($currencyDet as $key1 => $currency) {
                      if(in_array($key1, array('0','1'))) { 
                        if(is_nan($currency->change_price)) $changeVal = '';
                          else $changeVal = round($currency->change_price,2).'%';
                      ?>
                    <div class="col-lg-6" style="<?=($key1==0)?'border-right:inset;':''?>">
                    <div class="card-header border-0">
                      <div class="card-title" style="display: contents;"><img alt="Bitcoin logo" src="<?=$currency->image?>" aria-label="Bitcoin logo " style="height: 32px"; class="Image-sc-1i3cgkp-0 ImageWithFallback__AbsoluteImage-ufzvsr-0 dmqghf Bitcoin-image">
                        <?=$currency->currency_name?><span class="text-muted-3">€<?=$currency->euro_price?></span><span class="changes-txt">24H</span><span class="changes-price <?=($changeVal>0)?'grn':'rdn'?>"><?=$changeVal?></span>
                        <!-- <p class="changes-txt">24 H</p>  
                        <p class="changes-price <?=($changeVal>0)?'grn':'rdn'?>"><?=$changeVal?></p>  --> 
                      </div>
                    </div>
                    <div class="position-relative hover-stf" id="<?=$key1?>">
                      <div class="stuff asset-btn-<?=$key1?>" id="stuff"><a href="<?=base_url().'basic-chart/'.$currency->currency_symbol.'-EUR'?>" class="btn btn-success"><?php echo $this->lang->line('View asset');?></a></div>
                      <div class="position-absolute top-0 left-0 px-3 mt-1 w-50">
                        <div class="row g-2">
                          <div class="col">
                            <!-- <div class="text-muted-3">€<?=$currency->euro_price?></div> -->
                          </div>
                        </div>
                      </div>
                        <div id="<?=$currency->currency_name?>-chart"></div> 
                    </div>
                  </div>
                <?php }}}?>  
                </div>

                <div class="col-lg-12 chartt">
                  <?php if($currencyDet) {
                    foreach ($currencyDet as $key1 => $currency) {
                      if(in_array($key1, array('2','3'))) { 
                        if(is_nan($currency->change_price)) $changeVal = '';
                          else $changeVal = round($currency->change_price,2).'%';
                      ?>
                    <div class="col-lg-6" style="<?=($key1==2)?'border-right:inset;':''?>">
                    <div class="card-header border-0">
                      <div class="card-title" style="display: contents;"><img alt="Bitcoin logo" src="<?=$currency->image?>" aria-label="Bitcoin logo " style="height: 32px"; class="Image-sc-1i3cgkp-0 ImageWithFallback__AbsoluteImage-ufzvsr-0 dmqghf Bitcoin-image">
                        <?=$currency->currency_name?><span class="text-muted-3">€<?=$currency->euro_price?></span><span class="changes-txt">24H</span><span class="changes-price <?=($changeVal>0)?'grn':'rdn'?>"><?=$changeVal?></span>
                        <!-- <p class="changes-txt">24 H</p>  
                        <p class="changes-price <?=($changeVal>0)?'grn':'rdn'?>"><?=$changeVal?></p> -->  
                      </div>
                    </div>
                    <div class="position-relative hover-stf" id="<?=$key1?>">
                      <div class="stuff asset-btn-<?=$key1?>" id="stuff"><a href="<?=base_url().'basic-chart/'.$currency->currency_symbol.'-EUR'?>" class="btn btn-success"><?php echo $this->lang->line('View asset');?></a></div>
                      <div class="position-absolute top-0 left-0 px-3 mt-1 w-50">
                        <div class="row g-2">
                          <div class="col">
                            <!-- <div class="text-muted-3">€<?=$currency->euro_price?></div> -->
                          </div>
                        </div>
                      </div>
                        <div id="<?=$currency->currency_name?>-chart"></div>
                    </div>
                  </div>
                <?php }}}?>  
                </div>


                </div>
                </div>
              </div>


          <div class="col-md-6">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title"><?php echo $this->lang->line('Your Portfolio');?></h3>
              </div>
              <div class="table-responsive">
                <table class="table card-table table-vcenter text-nowrap datatable">
                  <tr>
                     <th><?=$this->lang->line('Coin');?></th>
                    <th><?=$this->lang->line('Available Balance');?></th>
                    <th>Euro <?=$this->lang->line('Value');?></th> 
                  </tr>
                  <tbody>
                  <?php
                    if(count($currencyDet) >0)
                    {
                       foreach ($currencyDet as $digital) 
                     {
                    if($digital->type=="fiat")
                    {
                        $format = 2;
                    }
                    elseif($digital->currency_symbol=="USDT")
                    {
                        $format = 6;
                    }
                    else
                    {
                        $format = 6;
                    }
                    $coin_price_val = to_decimal($wallet['Exchange AND Trading'][$digital->id], $format);
                    $coin_price = $coin_price_val * $digital->online_usdprice;

                    $userbalance = getBalance($user_id,$digital->id);
                    $USDT_Balance = $userbalance * $digital->online_usdprice;
                    // $EURO_Balance = bcmul($userbalance ,$digital->online_europrice);
                    $EURO_Balance = abs($userbalance*$digital->online_europrice);
                            
                        ?>
                        <tr>
                        <td> <img alt="<?php echo $digital->currency_name;?> logo" src="<?php echo $digital->image;?>" aria-label="Bitcoin logo " style="height: 32px"; class="Image-sc-1i3cgkp-0 ImageWithFallback__AbsoluteImage-ufzvsr-0 dmqghf"><span><?=$digital->currency_name;?></span></td>
                        <td><?php echo $userbalance; ?></td>
                        <td><?php echo $EURO_Balance; ?></td> 
                    </tr>
                    <?php }}?>  
                    
                  </tbody>
                </table>
              </div>
              <div class="card-footer d-flex align-items-center">
                <p class="m-0 text-muted-2"><?php echo $this->lang->line('Total Balance');?> = <span><strong> €<?=number_format($tot_Euro_balance, 2);?></strong></span></p>
                
              </div>
            </div>
          </div>


          <div class="col-md-6">
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title"><?php echo $this->lang->line('Your Transactions');?></h3>
                </div>
                <div class="card-table table-responsive">
                  <table class="table table-vcenter">
                  <tr>
                    <th colspan="2"><?=$this->lang->line('Send / Receive');?></th>
                    <th><?=$this->lang->line('Status');?></th>
                    <th><?=$this->lang->line('Amount');?></th> 
                  </tr>
                    <tbody>
                    <?php if(isset($history) && !empty($history)){
                      foreach($history as $trans){
                        if($trans->status=='Completed') $statusClr = 'green';
                        else $statusClr = 'red';

                        if($trans->type=='Deposit') {
                          $image_type = 'receiver.png';
                          $transfer_type = $this->lang->line('Received');
                        }  elseif($trans->type=='Withdraw') {
                          $image_type = 'sender.png';
                          $transfer_type = $this->lang->line('Sent');
                        }
                        if($trans->status=='Completed'){
                          $status = $this->lang->line('Completed');
                        }elseif ($trans->status=='Pending') {
                          $status = $this->lang->line('Pending Transaction');
                        }else{
                          $status = $this->lang->line('Cancelled Transaction');
                        }

                      ?>  
                      <tr>

                        <td class="w-1">
                          <img class="transaction-img" src="<?=front_img().$image_type?>">
                        </td>
                        <td class="td-truncate">
                          <div class="text-truncate">
                            <?=$transfer_type.' '.getcryptocurrency($trans->currency_id)?>
                          </div>
                        </td>
                        <td style="color: <?=$statusClr?>;"><?=$status?></td>
                        <td class="text-nowrap text-muted"><?=number_format($trans->amount,8)?></td>
                      </tr>
                      
                    <?php }} else { ?>
                      <tr><td colspan="4" style="text-align:center;">No Transactions found</td></tr>
                    <?php }?>  
                    </tbody>
                  </table>
                </div>
                <!-- <div class="card-footer d-flex align-items-center">
                  <p class="m-0 text-muted-2">View Portfolio &#10095;</p> 
                </div> -->
              </div>
            </div>
          </div>







      </div>
    </div>


  </div>        

<?php $this->load->view('front/common/footer'); 
?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?=front_js()?>apexcharts.min.js"></script>
<script>
base_url = '<?=base_url()?>get_chartData';  
$.getJSON(base_url, function (response) {
  $.each(response, function (index, val) {
    data = JSON.parse(val);

    array_date=[]; array_price=[]; 
    $.each(data, function (i, v) {
        array_date.push(v[0]);
        array_price.push(v[1]);
    })
    dateData = array_date.reverse();
    priceData = array_price.reverse();
    
    if(index=='Bitcoin') color = '#f7931a';
    else if(index=='Ethereum') color = '#006097';
    else if(index=='BitcoinCash') color = '#ee8c28';
    else if(index=='Tether') color = '#50AF95';

    // console.log( index );
    
    window.ApexCharts && (new ApexCharts(document.getElementById(index+'-chart'), {
      chart: {
        type: "area",
        fontFamily: 'inherit',
        height: 192,
        sparkline: {
          enabled: true
        },
        animations: {
          enabled: false
        },
      },
      dataLabels: {
        enabled: false,
      },
      fill: {
        opacity: .16,
        type: 'solid'
      },
      stroke: {
        width: 2,
        lineCap: "round",
        curve: "smooth",
      },
      series: [{
        name: "€",
        data: priceData
      }],
      grid: {
        strokeDashArray: 4,
      },
      xaxis: {
        labels: {
          padding: 0,
        },
        tooltip: {
          enabled: false
        },
        axisBorder: {
          show: false,
        },
        type: 'datetime',
      },
      yaxis: {
        labels: {
          padding: 4
        },
      },
      labels: dateData,
      colors: [color],
      legend: {
        show: false,
      },
      point: {
        show: false
      },
    })).render();

  
  });

  

  

});

$('.stuff').hide(); 

$('.hover-stf').mouseover(function () {
  id = $(this).attr('id');
  $('.asset-btn-'+id).show();      
});
$('.hover-stf').mouseout(function () {
      $('.stuff').hide();      
});     
</script>




