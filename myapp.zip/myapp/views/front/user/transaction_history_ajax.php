<?php
if(empty($transaction_arr)){
  echo '<tr><td>';
  echo '<label style="text-align:center;">There are no transactions<label>';
  echo '</td></tr>';
}else{  

  $icon = '';
  $details_url = '#';
  $local_transaction_id_var='';
  $username='';
  $type='';
  $msg='';
  $since='';  
  $fiat_amount='';
  $sum_fiat_amount=0;
  $amt_color = 'bg-lime-lt';
  $sign = '+';
  $red_icon =  '<svg xmlns="http://www.w3.org/2000/svg" class="icon send-icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
        <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
        <line x1="12" y1="5" x2="12" y2="19"></line>
        <line x1="18" y1="11" x2="12" y2="5"></line>
        <line x1="6" y1="11" x2="12" y2="5"></line>
        </svg>';
  $green_icon =  '<svg xmlns="http://www.w3.org/2000/svg" class="icon recived-icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
        <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
        <line x1="12" y1="5" x2="12" y2="19"></line>
        <line x1="16" y1="15" x2="12" y2="19"></line>
        <line x1="8" y1="15" x2="12" y2="19"></line>
        </svg>';

  // echo '<pre>';print_r($transaction_arr);exit;  
  foreach ($transaction_arr as $trkey => $trvalue) {     

    if($trvalue['access']==='transaction'){
      $trvalue['status'] = 'Completed';
      if($trvalue['status']=='Completed'){
        $color =  'bg-green-lt';
        $msg = 'TOP LEVEL SEGMENT';
      }else if($trvalue['status']=='Cancelled'){
        $color =  'bg-red-lt';
        $msg = 'TOP LEVEL SEGMENT';
      }else{
        $color =  'bg-orange-lt';
        $msg = 'TOP LEVEL SEGMENT';
      }


      if($trvalue['type']=='Withdraw'){
        $icon = $red_icon ;
        $sign = '-';
        $amt_color='';
      }else if($trvalue['type']=='Deposit'){                
        $sign = '+';
        $icon = $green_icon ;
      }

      
      $unique_id = $trvalue['unique_id'];
      $username = (unique_id_to_username($unique_id))??'';
      $type = ($trvalue['type']) ? $trvalue['type'] :'-';
      $date_time = ($trvalue['timestamp']) ? timestamp_UTC_conversion($trvalue['timestamp']) :'-';
      $since = ($trvalue['timestamp']) ? time_calculator($trvalue['timestamp']) :'-';
      $fiat_amount = ($trvalue['pym'])??'0.00';   
      $local_transaction_id_var = $trvalue['local_transaction_id'];  
      $encrypt_local_transaction_id = encryptIt($local_transaction_id_var); 
      $details_url = base_url(). 'transaction-details/'. $encrypt_local_transaction_id;
      // print_r($trvalue);exit; 
    }


    if($trvalue['access']==='income'){
      $date_time = ($trvalue['timestamp']) ? timestamp_UTC_conversion($trvalue['timestamp']) :'-';
      $since = ($trvalue['timestamp']) ? time_calculator($trvalue['timestamp']) :'-';
      $local_transaction_id_var = $trvalue['local_transaction_id'];
      $fiat_amount = ($trvalue['pym'])??'0.00';
      $from_user_id = $trvalue['from_id'];
      $username = (user_id_to_fname($from_user_id))??'';
      $username = 'FROM '.$username;
      $msg = 'DIRECT INCOME';  
      $color =  'bg-green-lt';
      $icon = $green_icon ;
      $sign = '+';
    }


    if($trvalue['access']==='x2_p'){
      $date_time = ($trvalue['timestamp']) ? timestamp_UTC_conversion($trvalue['timestamp']) :'-';
      $since = ($trvalue['timestamp']) ? time_calculator($trvalue['timestamp']) :'-';
      $local_transaction_id_var = $trvalue['local_transaction_id'];
      $fiat_amount = $trvalue['profit'];
      $msg = '2x AUTOFILLED LEVEL SEGMENT';  
      $color =  'bg-green-lt';
      $icon = $green_icon ;
      $sign = '+';
    }


    if($trvalue['access']==='x2_s'){
      $date_time = ($trvalue['timestamp']) ? timestamp_UTC_conversion($trvalue['timestamp']) :'-';
      $since = ($trvalue['timestamp']) ? time_calculator($trvalue['timestamp']) :'-';
      $local_transaction_id_var = $trvalue['local_transaction_id'];
      $fiat_amount = $trvalue['sponsor'];
      $msg = '2x SPONSOR INCOME'; 
      $color =  'bg-green-lt';
      $icon = $green_icon ;
      $sign = '+';
    }


    if($trvalue['access']==='x4_p'){
      $date_time = ($trvalue['timestamp']) ? timestamp_UTC_conversion($trvalue['timestamp']) :'-';
      $since = ($trvalue['timestamp']) ? time_calculator($trvalue['timestamp']) :'-';
      $local_transaction_id_var = $trvalue['local_transaction_id'];
      $fiat_amount = $trvalue['profit'];
      $msg = '4x AUTOFILLED LEVEL SEGMENT'; 
      $color =  'bg-green-lt'; 
      $icon = $green_icon ;
      $sign = '+';
    }


    if($trvalue['access']==='x4_s'){
      $date_time = ($trvalue['timestamp']) ? timestamp_UTC_conversion($trvalue['timestamp']) :'-';
      $since = ($trvalue['timestamp']) ? time_calculator($trvalue['timestamp']) :'-';
      $local_transaction_id_var = $trvalue['local_transaction_id'];
      $fiat_amount = $trvalue['sponsor'];
      $msg = '4x SPONSOR INCOME';
      $color =  'bg-green-lt';
      $icon = $green_icon ;
      $sign = '+';
    }


    if($trvalue['access']==='sys_auto_upgrade'){
      $date_time = ($trvalue['timestamp']) ? timestamp_UTC_conversion($trvalue['timestamp']) :'-';
      $since = ($trvalue['timestamp']) ? time_calculator($trvalue['timestamp']) :'-';
      $local_transaction_id_var = $trvalue['local_transaction_id'];
      $fiat_amount = $trvalue['already_activated_income'];
      $msg = 'AUTO UPGRADE INCOME';
      $color =  'bg-green-lt';
      $icon = $green_icon ;
      $sign = '+';
    }


    ?>                                    
    <tr class="<?php echo $color; ?>">
      <td>
        <div class="widget-26-job-starred">
            <a href="#" data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#modal-qacode"><?php echo $icon; //echo $trvalue['access']; ?></a>
        </div>
      </td>
      <td class="firstName">
        <div class="widget-26-job-title">
            <a href="<?php echo ($details_url)??'#'; ?>" data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#modal-qacode 2">
                <span class="transactions_arr">#<?php echo $local_transaction_id_var; ?></span>
                  <?php echo $username;  if($trvalue['access']==='transaction'){ ?><?php } echo '  '. $msg; ?>
            </a>
            <p class="m-0"><?php echo $date_time; ?> UTC <span class="time"><?php echo $since; ?></span></p>
        </div>
      </td>
      <td>
        <div class="widget-26-job-category <?php echo $amt_color; ?>">
            <span> <?php echo $sign .'  '. $fiat_amount ?> EMD</span>
        </div>
      </td>
      </tr>
      <?php       
      // if($transaction_arr && end(array_keys($transaction_arr))==$trkey && 1==0){
      if(end(array_keys($transaction_arr))==$trkey){
      ?>
        <tr>
          <td></td>
          <td> <b>TOTAL</b></td>
          <td >
           <?php            
           echo $value = array_sum(array_column($transaction_arr,'pym')). ' EMD';
            ?> 
          </td>
        <tr>
      <?php } ?>      
<?php }  } ?>