<?php 
    $this->load->view('front/common/header');
    $user_id = $this->session->userdata('user_id');
$this->load->view('front/user/basic_navigation');

// echo "<pre>";print_r($currency_info);
?>
<style>
.grn {
    color: rgb(5, 177, 105);}
.rdn {
    color: rgb(223, 95, 103);}    

.pos-rel { position:relative;}
.swap-wrp {    position: absolute;
    left: 10px;
    top: 47px;
    width: 40px;
    height: 40px;
    border: 1px solid #e0e2e4;
    color: #206bc4;
    z-index: 9;
    font-size: 21px;
    padding: 5px 10px;
    border-radius: 4px;
    background: #FFF;}
.swap-wrp a{ color: #206bc4; }
.swap-wrp a:hover{ color: #000; }   
.pob-absolute { position:absolute; right:10px; top:25px; }
.pob-absolute:hover { color:#000; }   

.form-item-title { 
	float: left; 
	margin-right: 100px;
}
</style>


  <div class="page-wrapper">
    <div class="page-body">
      <div class="container-xl">
        <div class="row">
          <div class="col-12 col-sm-12">
            <div class="card">
              <!-- <div class="card-body border-bottom py-3">
                <div class="d-flex">
                  <div class="text-muted float-right float-end " style="margin-right:10px;">
                    <div class="bs-example">
                      <div class="btn-group">
                        <div class="btn-group">
                          <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">24h</button>
                          <div class="dropdown-menu"> <a href="#" class="dropdown-item">24h</a> <a href="#" class="dropdown-item">1h</a> <a href="#" class="dropdown-item">2h</a> <a href="#" class="dropdown-item">3h</a> <a href="#" class="dropdown-item">4h</a> </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="text-muted float-right float-end ">
                    <div class="bs-example">
                      <div class="btn-group">
                        <div class="btn-group">
                          <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">Tradable assets</button>
                          <div class="dropdown-menu"> <a href="#" class="dropdown-item">Tradable assets</a> <a href="#" class="dropdown-item">Watchlist</a> <a href="#" class="dropdown-item">All assests</a> <a href="#" class="dropdown-item">Top gainers</a> <a href="#" class="dropdown-item">Top losers</a> </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div> -->

              <div class="table-responsive">
                <table class="table card-table table-vcenter text-nowrap datatable">
                  <thead>
                    <tr>
                      <th><?=$this->lang->line('Name');?></th>
                      <th><?=$this->lang->line('Price');?></th>
                      <th><?=$this->lang->line('24H Change');?></th>
                      <th><?=$this->lang->line('24H High');?></th>
                      <th><?=$this->lang->line('24H Low');?></th>
                      <th><?=$this->lang->line('Volume');?></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php if(isset($currency_info) && !empty($currency_info)){
                      foreach($currency_info as $key => $currency){
                        if (in_array($key, array('Bitcoin','Ethereum','BitcoinCash','Tether','eLira'))) {

                          $get_pair = get_elira_pair();
                          $img = getCoinImage($key);
                          $change = (($currency->last-$currency->open)/$currency->last)*100;

                          if($key=='Bitcoin') $symbol='BTC';
                          else if($key=='Ethereum') $symbol='ETH';
                          else if($key=='BitcoinCash') $symbol='BCH';
                          else if($key=='Tether') $symbol='USDT';
                          else if($key=='eLira') $symbol='LIR';

                          if(is_nan($change)) $changeVal = $get_pair->priceChangePercent;
                          else $changeVal = number_format($change,2).'%';

                          if($currency->last!='') $lastprice = $currency->last;
                            else $lastprice = $get_pair->lastPrice;
                          if($currency->high!='') $high = $currency->high;
                            else $high = $get_pair->change_high; 
                          if($currency->low!='') $low = $currency->low;
                            else $low = $get_pair->change_low;     
                          if($currency->volume!='') $volume = $currency->volume;
                            else $volume = $get_pair->volume;  

                        ?>
                    <tr>
                      <td><a href="<?=base_url().'basic-chart/'.$symbol.'-EUR'?>">
                        <img alt="Bitcoin logo" src="<?=$img?>" aria-label="Bitcoin logo " style="height: 32px"; class="Image-sc-1i3cgkp-0 ImageWithFallback__AbsoluteImage-ufzvsr-0 dmqghf">
                        <?=$key?>
                        </td></a>
                      <td> <?='€'.$lastprice?> </td>
                      <td class="<?php echo($changeVal>0)?'grn':'rdn';?>"><?=$changeVal?> </td> 
                      <td><?=$high?></td>
                      <td><?=$low?></td>
                      <td><?=$volume?></td>
                      <td><a class="wallet-table-btn" href="<?=base_url().'basic-exchange/'.$symbol.'_EUR'?>"><?php echo $this->lang->line('Trade');?></a></td>
                    </tr>

                  <?php }}}?>
                    
                    
                  </tbody>
                </table>
              </div>
             
            </div>
          </div>
          
         

        </div>
      </div>
    </div>
   
  </div>

<div class="modal" id="myCurrencyModal" data-backdrop="static">
  <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Select Asset</h4>
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        </div>
        <input type="hidden" class="select-currency-key">
        <div class="container" style="padding-top: 10px;">
           <!--<div class="input-icon mb-3">
            <input type="text" class="form-control" placeholder="Search…">
            <span class="input-icon-addon">
              <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><circle cx="10" cy="10" r="7" /><line x1="21" y1="21" x2="15" y2="15" /></svg>
            </span>
          </div> -->
          <div class="mb-3">
            <label class="form-label"></label>
            <div class="form-selectgroup form-selectgroup-boxes d-flex flex-column">

            <?php
            if(count($dig_currency) >0)
            {
               foreach ($dig_currency as $digital) 
             {
              if (in_array($digital->currency_symbol, array('BTC','ETH','BCH','USDT','EUR'))) { 
            if($digital->type=="fiat")
            {
                $format = 2;
            }
            elseif($digital->currency_symbol=="USDT")
            {
                $format = 6;
            }
            else
            {
                $format = 6;
            }
            $coin_price_val = to_decimal($wallet['Exchange AND Trading'][$digital->id], $format);
            $coin_price = $coin_price_val * $digital->online_usdprice;

            $userbalance = getBalance($user_id,$digital->id);
            $USDT_Balance = $userbalance * $digital->online_usdprice;
            // $EURO_Balance = bcmul($userbalance ,$digital->online_europrice);
            $EURO_Balance = $userbalance * $digital->online_europrice;

            ?>

              <label class="form-selectgroup-item flex-fill coin-wrapper">
                <input type="radio" name="form-payment" value="<?=$digital->currency_symbol?>" class="form-selectgroup-input select-currency1 <?=$digital->currency_symbol?>" id="check-<?=$digital->currency_symbol?>">
                <div class="form-selectgroup-label d-flex align-items-center p-3">
                  <div class="me-3">
                    <span class="form-selectgroup-check"></span>
                  </div>
                  <div>
                    <img style="margin-right:10px;" width="30px" height="30px" src="<?php echo $digital->image;?>" class="table-cryp"><span><?=$digital->currency_name;?>
                  </div>
                  <div class="me-3" style="margin-left:200px;"> <?=$userbalance?></div>
                </div>

                <input type="hidden" class="hiden-symbol" value="<?=$digital->currency_symbol;?>">
                <input type="hidden" class="hiden-sym" value="<?=$digital->currency_name;?>">
                <input type="hidden" class="hiden-img" value="<?=$digital->image;?>">
                <input type="hidden" class="hiden-walletamount" value="<?=$userbalance;?>">
                <input type="hidden" class="hiden-eurobalance" value="<?=$EURO_Balance;?>">

              </label>

              <?php }}}?>


            </div>
          </div>

        </div>

      </div>
    </div>
</div>

<?php 
$this->load->view('front/common/footer'); ?>
<script src="<?=front_js()?>apexcharts.min.js"></script>    
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
$(document).ready(function () {
  $("#EuroCurrencyInput").keypress(function (e) {
     if (e.which != 8 && e.which != 0 && (e.which < 46 || e.which > 57)) {
        return false;
    }
   });
});
// const formatter = new Intl.NumberFormat('en-US', {
//    minimumFractionDigits: 6,      
//    maximumFractionDigits: 6,
// });

function getCrypto(coin) {
  
  if(coin=='BTC') sym = '₿';
  else if(coin=='ETH') sym = 'Ξ';
  else if(coin=='BCH') sym = 'Ƀ';
  else if(coin=='EUR') sym = '€';
  else if(coin=='USDT') sym = '₮';
  $('.input-crypto-symbol').html(sym);
  EuroCurrencyInput = document.getElementById("EuroCurrencyInput");
  changeFiatCurrency(EuroCurrencyInput);
}

function changeFiatCurrency(e) {

  apikey = '<?=getCryptoCompareKey()?>';
  sel_crypto = $(".select-crypto").val();
  amount = parseFloat($(e).val());

  $.getJSON('https://min-api.cryptocompare.com/data/pricemulti?fsyms='+sel_crypto+'&tsyms=BTC,ETH,BNB,BCH,USDT,XRP,EUR&api_key='+apikey, function(data) {

    fcurrency = document.querySelector(".From-currency");
    fromCurrency = fcurrency.getAttribute('data-currency');
    tcurrency = document.querySelector(".To-currency");
    toCurrency = tcurrency.getAttribute('data-currency');

    if(fromCurrency == 'EUR') $('.From-currencyprice').html(amount);
      else $('.To-currencyprice').html(amount);

    $.each(data, function (index, coins) {
      $.each(coins, function (cur, rate) {
        // console.log(cur+'--'+rate)
        if(fromCurrency==cur) {
          fromAmt = amount * rate;
          fromRate = formatter.format(fromAmt);
          if(isNaN(fromAmt)) $('.From-currencyprice').html(fromCurrency);
           else $('.From-currencyprice').html(fromRate);
        }
        if(toCurrency==cur) {
          toAmt = amount * rate;
          toRate = formatter.format(toAmt);
          if(isNaN(toRate)) $('.To-currencyprice').html(toCurrency);
           else $('.To-currencyprice').html(toRate);
        }

     });
    });  
      
  });
}

function changeFiatCurrency1(e) {

  apikey = '<?=getCryptoCompareKey()?>';
  euroAmt = parseFloat($(e).val());
  $.getJSON('https://min-api.cryptocompare.com/data/pricemulti?fsyms=EUR&tsyms=BTC,ETH,BNB,BCH,USDT,XRP&api_key='+apikey, function(data) {
  
  fcurrency = document.querySelector(".From-currency");
  fromCurrency = fcurrency.getAttribute('data-currency');
  tcurrency = document.querySelector(".To-currency");
  toCurrency = tcurrency.getAttribute('data-currency');
  if(fromCurrency == 'EUR'){
     $('.From-currencyprice').html(euroAmt);
  }
  if(toCurrency == 'EUR'){

    $('.To-currencyprice').html(euroAmt);
  
  }
  $.each(data.EUR, function (cur, rate) {
    if(fromCurrency==cur) {
      fromAmt = euroAmt * rate;
      fromRate = formatter.format(fromAmt);
      if(isNaN(fromAmt)) $('.From-currencyprice').html(fromCurrency);
       else $('.From-currencyprice').html(fromRate);
    }
    if(toCurrency==cur) {
      toAmt = euroAmt * rate;
      toRate = formatter.format(toAmt);
      if(isNaN(toRate)) $('.To-currencyprice').html(toCurrency);
       else $('.To-currencyprice').html(toRate);
    }
   
  });
});
}

$(document).on('click','.select-currency',function() {
  $('.coin-wrapper').removeAttr('style');
  selectVal = $(this).val();
  sym = $(this).closest('label').find('.currency-sym').attr('data-currency');
  $('.select-currency-key').val(selectVal);

  fcurrency = document.querySelector(".From-currency");
  fromCurrency = fcurrency.getAttribute('data-currency');
  tcurrency = document.querySelector(".To-currency");
  toCurrency = tcurrency.getAttribute('data-currency');

  if(selectVal==0) coin = toCurrency;
   else coin = fromCurrency;

   $("#check-"+coin).parent().css("display","none");
  // document.getElementById("check-"+coin).style.display = "none";
 

  // console.log(coin);
  document.getElementById("check-"+sym).checked = true;
});


$(document).on('click','.select-currency1',function() {
  icon = $(this).val();
  key = $('.select-currency-key').val();
  symbol = $(this).closest('label').find('.hiden-symbol').val();
  name = $(this).closest('label').find('.hiden-sym').val();
  img = $(this).closest('label').find('.hiden-img').val();
  walletAmt = $(this).closest('label').find('.hiden-walletamount').val();
  eurobalance = $(this).closest('label').find('.hiden-eurobalance').val();  
  convertCoin = walletAmt +' '+symbol+' ≈ €'+ eurobalance;  

  if(walletAmt>0) {
    walletLabel = '';
  } else {
    walletLabel = "You don't have any "+name+" to trade. Fund your account to get started.";
  }

  if(key==0) {
    $('.currencybal-label').html(symbol+' Balance');
    $('.convertCoin-label').html(convertCoin);  
  }
  $('.coinwallet-label').html(walletLabel);
  $('.crypto-icon-'+key).attr('src', img);
  // $('.crypto-name-'+key).html( name );
  $('.crypto-sym-'+key).attr('data-currency', icon);

  EuroCurrencyInput = document.getElementById("EuroCurrencyInput");
  changeFiatCurrency(EuroCurrencyInput);
  // console.log( EuroCurrencyInput )
});

function swapCrypto() {
	N1 = $('.crypto-wrapper0').html();
	N2 = $('.crypto-wrapper1').html();
	$('#crypto-container0').html(N2);
    $('#crypto-container1').html(N1);
}

  </script>
  <script>
    $(document).ready(function(){

 
        // Close modal on button click
        $(".select-currency1").click(function(){
            $("#myCurrencyModal").modal('hide');
        });
    });
</script>