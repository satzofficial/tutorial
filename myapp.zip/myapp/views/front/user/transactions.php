<?php include realpath(dirname(__DIR__) . '/common/inner_header.php'); 
$prefix = get_prefix();
$fname = $prefix.'fname';
$lname = $prefix.'lname';
// $data['compact_arr'] = compact('transactions_arr','packageIncome','xx2_profit','xx2_sponsor','xx4_profit','xx4_sponsor'); 
?>
<style type="text/css">
  #transaction_table_body{
    padding: 0;
    overflow-y: auto;
    max-height: 200px;
    border: 0px solid #dbdbdb;
    border-radius: 3px;
    margin-bottom: 10px;
  }
</style>
<style>
  .widget-26 {
    color: #3c4142;
    font-weight: 400;
  }
  .widget-26 tr:first-child td {
  }
  .widget-26 .widget-26-job-emp-img img {
    width: 35px;
    height: 35px;
    border-radius: 50%;
  }
  .widget-26 .widget-26-job-title {
    min-width: 200px;
  }
  .widget-26 .widget-26-job-title a {
    font-weight: 400;
    font-size: 0.875rem;
    color: #3c4142;
    line-height: 1.5;
    font-weight: 700;
  }
  .widget-26 .widget-26-job-title a:hover {
    color: #000;
    text-decoration: none;
  }
  .widget-26 .widget-26-job-title .employer-name {
    margin: 0;
    line-height: 1.5;
    font-weight: 400;
    color: #3c4142;
    font-size: 0.8125rem;
    color: #3c4142;
  }
  .widget-26 .widget-26-job-title .employer-name:hover {
    color: #68CBD7;
    text-decoration: none;
  }
  .widget-26 .widget-26-job-title .time {
    font-size: 12px;
    font-weight: 400;
  }
  .widget-26 .widget-26-job-info {
    min-width: 100px;
    font-weight: 400;
  }
  .widget-26 .widget-26-job-info p {
    line-height: 1.5;
    color: #3c4142;
    font-size: 0.8125rem;
  }
  .widget-26 .widget-26-job-info .location {
    color: #3c4142;
  }
  .widget-26 .widget-26-job-salary {
    min-width: 70px;
    font-weight: 400;
    color: #3c4142;
    font-size: 0.8125rem;
  }
  .widget-26 .widget-26-job-category {
   padding: .5rem;
   display: inline-flex;
   white-space: nowrap;
   border-radius: 15px;
 }
 .widget-26 .widget-26-job-category .indicator {
  width: 10px;
  height: 10px;
  margin-right: .5rem;
  float: left;
  border-radius: 50%;
}
.widget-26 .widget-26-job-category span {
  font-size: 0.8125rem;
  color: #3c4142;
  font-weight: 600;
}
.widget-26 .widget-26-job-starred svg.send-icon {
  color: #dc3545;
}
.widget-26 .widget-26-job-starred svg.recived-icon {
  color: #2fb344;
}
.widget-26 .widget-26-job-starred svg.starred {
  fill: #fd8b2c;
}
.bg-soft-base {
  background-color: #e1f5f7;
}
.bg-soft-warning {
  background-color: #fff4e1;
}
.bg-soft-success {
  background-color: #d1f6f2;
}
.bg-soft-danger {
  background-color: #fedce0;
}
.bg-soft-info {
  background-color: #d7efff;
}
.search-form {
/*  width: 80%;
  margin: 0 auto;
  margin-top: 1rem;*/
}
.search-form input {
  height: 100%;
  background: transparent;
  border: 0;
  display: block;
  width: 100%;
  padding: 1rem;
  height: 100%;
  font-size: 1rem;
}
.search-form select {
  background: transparent;
  border: 0;
  padding: 1rem;
  height: 100%;
  font-size: 1rem;
}
.search-form select:focus {
  border: 0;
}
.search-form button {
  height: 100%;
  width: 100%;
  font-size: 1rem;
  border:0 none;
}
.search-form button svg {
  width: 24px;
  height: 24px;
}
.search-body {
  margin-bottom: 1.5rem;
}
.search-body .search-filters .filter-list {
  margin-bottom: 1.3rem;
}
.search-body .search-filters .filter-list .title {
  color: #3c4142;
  margin-bottom: 1rem;
}
.search-body .search-filters .filter-list .filter-text {
  color: #727686;
}
.search-body .search-result .result-header {
  margin-bottom: 2rem;
}
.search-body .search-result .result-header .records {
  color: #3c4142;
}
.search-body .search-result .result-header .result-actions {
  text-align: right;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.search-body .search-result .result-header .result-actions .result-sorting {
  display: flex;
  align-items: center;
}
.search-body .search-result .result-header .result-actions .result-sorting span {
  flex-shrink: 0;
  font-size: 0.8125rem;
}
.search-body .search-result .result-header .result-actions .result-sorting select {
  color: #68CBD7;
}
.search-body .search-result .result-header .result-actions .result-sorting select option {
  color: #3c4142;
}
@media (min-width: 768px) and (max-width: 991.98px) {
 .search-body .search-filters {
   display: flex;
 }
 .search-body .search-filters .filter-list {
   margin-right: 1rem;
 }
}
.card-margin {
  margin-bottom: 1.875rem;
}
@media (min-width: 992px) {
  .col-lg-2 {
   flex: 0 0 16.66667%;
   max-width: 16.66667%;
 }
}
.card-margin {
  margin-bottom: 1.875rem;
}
</style>
<div class="page-body">
  <div class="container-xl">
    <ol class="breadcrumb breadcrumb-arrows mb-3" aria-label="breadcrumbs">
      <li class="breadcrumb-item"><a href="<?php echo base_url('payment'); ?>">Wallet</a></li>
      <li class="breadcrumb-item active" aria-current="page">Transactions</li>
    </ol>
    <div class="row">
      <div class="col-lg-12">
        <div class="col-lg-12 card-margin mt-3">
          <div class="card search-form">
            <div class="card-body p-0">
              <form id="search-form" onsubmit="return false;">
                <div class="row">
                  <div class="col-12">
                    <div class="row no-gutters">
                      <div class="col-lg-11 col-8 p-0">                        
                        <input type="search" id="myInput" onkeyup="myFunction()"  placeholder="Search Username..." class="form-control tranfer_search"  name="tranfer_search">
                      </div>
                      <div class="col-lg-1 col-4 p-0">
                        <button type="submit" class="btn btn-base">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search">
                            <circle cx="11" cy="11" r="8"></circle>
                            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                          </svg>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
        <div class="col-lg-12">
          <div class="card card-margin shadow radius-20">
            <div class="card-body p-2">
              <div class="row search-body">
                <div class="col-lg-12">
                  <div class="search-result">
                    <div class="card" >
                      <div class="card-body card-body-scrollable card-body-scrollable-shadow">
                        <div class="result-body">                              
                          <div class="table-responsive pb-0 mb-0" style="overflow: auto;height:600px;"> 
                            <div id="transactions-load" style="display:none;text-align:center;margin-top:150px;max-height:0;">
                              <!-- <img src="<?php //echo front_img().'loader.gif'?>"> -->
                              <?php include realpath(dirname(__DIR__) . '/common/loader.php'); ?>
                            </div>
                            <table class="table widget-26 table_transaction_history_content" id="table_transaction_history_content">                      
                              <tbody id="table_transaction_history_content_body" class="table_transaction_history_content_body">
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<?php include realpath(dirname(__DIR__) . '/common/inner_footer.php'); ?>

</div>
</div>
<script type="text/javascript">
  function myFunction() {
    var input, filter, table, tr, td, i, txtValue, td2, txtValue2;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("table_transaction_history_content");
    tr = table.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[1];
      td2 = tr[i].getElementsByTagName("td")[2];      
      if (td || td2) {
        txtValue = td.textContent || td.innerText;
        txtValue2 = td2.textContent || td2.innerText;      
        if ((txtValue.toUpperCase().indexOf(filter) || txtValue2.toUpperCase().indexOf(filter) ) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }
    }
  }

  $(document).ready(function() {
    $.ajax({
      url: baseURL + "transactions-ajax",
      type: "GET",
      dataType:'json',
      beforeSend: function(){
        $("#transactions-load").show();
      },
      success: function(r) {
        if(r.status==true){          
          let decrypt = $.fn.displayDecryptData(r.data);        
          $('#table_transaction_history_content_body').html(decrypt);
          $("#transactions-load").hide();  
        }        
      }
    });
  });

</script>
</body>
</html>