<?php  include realpath(dirname(__DIR__) . '/common/header.php'); ?>
<style type="text/css">
  .sign-in-up form .cmn-btn {
    margin-top: 12px;
    width: auto;
}
</style>
<!-- Login In start -->
<section class="login">
    <div class="overlay pt-120 pb-120">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="form-content">
                        <div class="section-header">
                           
                            <p  style="color:white" >Your Security is our top priority. You’ll need this to log into your Emush Account</p>
                        </div>                        
                      <?php $this->load->view('front/common/flashmessage'); ?>
                      <?php 
                              $action = front_url()."forgot-check";
                              $attributes = array('id'=>'subForm'); 
                              echo form_open($action,$attributes);                                        
                              ?>
                              <div class="row">
                                <div class="col-12">
                                    <div class="single-input">
                                        <label for="email">User Email</label>
                                        <input type="text" name="forgot_detail" id="forgot_detail" placeholder="Your User Email here" autofocus autocomplete="off" >
                                    </div>
                                </div>  
                                
                                <div class="col-12">
                                    <div class="single-input">
                                        <label for="email">User ID</label>
                                        <input type="text" name="uid" id="uid" placeholder="Your User ID" autofocus autocomplete="off" >
                                    </div>
                                </div>  
                                
                                
                            </div>
                            <div class="btn-area">
                                <input type="submit" name="btnsubmit" value="Submit" class="cmn-btn" />
                            </div>
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Login In end -->
    <?php include realpath(dirname(__DIR__) . '/common/footer.php'); ?>

    <script type="text/javascript">
var baseURL = "<?php echo base_url(); ?>";
var csrf_name = "<?php  echo $this->security->get_csrf_token_name(); ?>"; // for the name
var csrf_token = "<?php  echo $this->security->get_csrf_hash(); ?>";  // for the value    
$(document).ready(function () {

$('#subForm').validate({ // initialize the plugin
    rules: {
        forgot_detail: {
            required: {
                depends:function(){
                    $(this).val($.trim($(this).val()));
                    return true;
                }
            },
            remote: baseURL + "is-not-email-exist",
            email: true
        },  

       uid: 'required',       
   },
    messages: {
        forgot_detail: {
            required: "Enter a user email",
            remote: jQuery.validator.format("This {0} does not exist")
        },
        uid: 'Enter a User ID',
    
}
});
});
</script>
</body>
</html>