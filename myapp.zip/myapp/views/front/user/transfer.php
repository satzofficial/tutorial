<?php include realpath(dirname(__DIR__) . '/common/inner_header.php'); 
$prefix = get_prefix();
$fname = $prefix.'fname';
$lname = $prefix.'lname';
?>
<style>
.widget-26 {
  color: #3c4142;
  font-weight: 400;
}
.widget-26 tr:first-child td {
}
.widget-26 .widget-26-job-emp-img img {
  width: 35px;
  height: 35px;
  border-radius: 50%;
}
.widget-26 .widget-26-job-title {
  min-width: 200px;
}
.widget-26 .widget-26-job-title a {
  font-weight: 400;
  font-size: 0.875rem;
  color: #3c4142;
  line-height: 1.5;
  font-weight: 700;
}
.widget-26 .widget-26-job-title a:hover {
  color: #000;
  text-decoration: none;
}
.widget-26 .widget-26-job-title .employer-name {
  margin: 0;
  line-height: 1.5;
  font-weight: 400;
  color: #3c4142;
  font-size: 0.8125rem;
  color: #3c4142;
}
.widget-26 .widget-26-job-title .employer-name:hover {
  color: #68CBD7;
  text-decoration: none;
}
.widget-26 .widget-26-job-title .time {
  font-size: 12px;
  font-weight: 400;
}
.widget-26 .widget-26-job-info {
  min-width: 100px;
  font-weight: 400;
}
.widget-26 .widget-26-job-info p {
  line-height: 1.5;
  color: #3c4142;
  font-size: 0.8125rem;
}
.widget-26 .widget-26-job-info .location {
  color: #3c4142;
}
.widget-26 .widget-26-job-salary {
  min-width: 70px;
  font-weight: 400;
  color: #3c4142;
  font-size: 0.8125rem;
}
.widget-26 .widget-26-job-category {
 padding: .5rem;
  display: inline-flex;
  white-space: nowrap;
  border-radius: 15px;
}
.widget-26 .widget-26-job-category .indicator {
  width: 10px;
  height: 10px;
 margin-right: .5rem;
  float: left;
  border-radius: 50%;
}
.widget-26 .widget-26-job-category span {
  font-size: 0.8125rem;
  color: #3c4142;
  font-weight: 600;
}
.widget-26 .widget-26-job-starred svg.send-icon {
  color: #dc3545;
}
.widget-26 .widget-26-job-starred svg.recived-icon {
  color: #2fb344;
}
.widget-26 .widget-26-job-starred svg.starred {
  fill: #fd8b2c;
}
.bg-soft-base {
  background-color: #e1f5f7;
}
.bg-soft-warning {
  background-color: #fff4e1;
}
.bg-soft-success {
  background-color: #d1f6f2;
}
.bg-soft-danger {
  background-color: #fedce0;
}
.bg-soft-info {
  background-color: #d7efff;
}
.search-form {
/*  width: 80%;
  margin: 0 auto;
  margin-top: 1rem;*/
}
.search-form input {
  height: 100%;
  background: transparent;
  border: 0;
  display: block;
  width: 100%;
  padding: 1rem;
  height: 100%;
  font-size: 1rem;
}
.search-form select {
  background: transparent;
  border: 0;
  padding: 1rem;
  height: 100%;
  font-size: 1rem;
}
.search-form select:focus {
  border: 0;
}
.search-form button {
  height: 100%;
  width: 100%;
  font-size: 1rem;
  border:0 none;
}
.search-form button svg {
  width: 24px;
  height: 24px;
}
.search-body {
  margin-bottom: 1.5rem;
}
.search-body .search-filters .filter-list {
  margin-bottom: 1.3rem;
}
.search-body .search-filters .filter-list .title {
  color: #3c4142;
  margin-bottom: 1rem;
}
.search-body .search-filters .filter-list .filter-text {
  color: #727686;
}
.search-body .search-result .result-header {
  margin-bottom: 2rem;
}
.search-body .search-result .result-header .records {
  color: #3c4142;
}
.search-body .search-result .result-header .result-actions {
  text-align: right;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.search-body .search-result .result-header .result-actions .result-sorting {
  display: flex;
  align-items: center;
}
.search-body .search-result .result-header .result-actions .result-sorting span {
  flex-shrink: 0;
  font-size: 0.8125rem;
}
.search-body .search-result .result-header .result-actions .result-sorting select {
  color: #68CBD7;
}
.search-body .search-result .result-header .result-actions .result-sorting select option {
  color: #3c4142;
}
 @media (min-width: 768px) and (max-width: 991.98px) {
 .search-body .search-filters {
 display: flex;
}
 .search-body .search-filters .filter-list {
 margin-right: 1rem;
}
}
.card-margin {
  margin-bottom: 1.875rem;
}
 @media (min-width: 992px) {
.col-lg-2 {
 flex: 0 0 16.66667%;
 max-width: 16.66667%;
}
}
.card-margin {
  margin-bottom: 1.875rem;
}

</style>
<div class="page-body">
  <div class="container-xl">
    <ol class="breadcrumb breadcrumb-arrows mb-3" aria-label="breadcrumbs">
      <li class="breadcrumb-item"><a href="<?php echo base_url('payment'); ?>">Wallet</a></li>
      <li class="breadcrumb-item active" aria-current="page">Transfer</li>
    </ol>
    <div class="row">
      <div class="col-lg-4">
        <div class="row row-cards">
         <?php $attributes=array('id'=>'wallet_transfer','autocomplete'=>"off");
         $reg_action =current_url();
         echo form_open($reg_action,$attributes);
         ?> 
         <input type="hidden" name="type" value="0" id="type">
         <div class="col-12">
          <div class="card shadow radius-20">
            <div class="card-body p-3 py-3 text-left">
              <h2 class="mb-2 text-left">Transfer</h2>
              <div>
                <label for="inp" class="inp">
                  <input type="text" id="user_id" name="user_id" class="form-control required" placeholder=" User Id">
                  <span class="label"></span> </label>
                  <p class="text-muted text-left mb-1 pb-1">Transaction with <span class="badge bg-azure-lt mt-1">
        
                    <span id="get-user-details-cls" class=" get-user-details-cls" ></span></span></p>
                  <label for="inp" class="inp">
                    <input type="text" id="amount" name="amount" class="form-control required" placeholder="Enter EMUSH Volume">
                    <span class="label"></span> <span class="focus-bg"></span> </label>
                    <p class="mb-3"> Available Credits : <span id="current_balance" class="badge bg-green-lt"> <?php echo ($user_balance) ? my_number_format($user_balance) : 0.00;?> EMUSH</span> </p>
                  </div>
                </div>
                <div class="alert alert-danger print-purchase-status-msg" id="print-purchase-status-msg" style="display: none;"></div>
                <div class="d-flex"> 
                  <input type="submit" name="btnsubmit" class="sendbtnsubmit" id="send_activation_form_submit_btn" value="submit" style="display:none;" > 
                  <a href="javascript:;" class="card-btn send-btn-alternative-anchor-cls" data-type="1" id="send-btn-alternative-anchor-cls">
                  <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                    <line x1="10" y1="14" x2="21" y2="3" />
                    <path d="M21 3l-6.5 18a0.55 .55 0 0 1 -1 0l-3.5 -7l-7 -3.5a0.55 .55 0 0 1 0 -1l18 -6.5" />
                  </svg>
                    Send</a> 
                  <input type="submit" name="reqsubmit" class="requestbtnsubmit" id="request_activation_form_submit_btn" value="submit" style="display:none;" > 
                 <!--  <a href="javascript:;" class="card-btn request-btn-alternative-anchor-cls" data-type="2" id="send-btn-alternative-anchor-cls">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                      <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                      <line x1="12" y1="5" x2="12" y2="19"></line>
                      <line x1="18" y1="13" x2="12" y2="19"></line>
                      <line x1="6" y1="13" x2="12" y2="19"></line>
                    </svg>
                  Request</a> --> </div>
                  
                </div>
              </div>

              <?php echo form_close(); ?>
            </div>
          </div>
          <div class="col-lg-8">
            <div class="col-lg-12 card-margin mt-3">
              <div class="card search-form ">
                <div class="card-body p-0">
                  <form id="search-form" onsubmit="return false;">
                    <div class="row">
                      <div class="col-12">
                        <div class="row no-gutters">
                          <div class="col-lg-11 col-8 p-0">
                            <!-- <input type="text" placeholder="Search Username..." class="form-control tranfer_search" id="tranfer_search" name="tranfer_search"> -->
                            <input type="search" id="myInput" onkeyup="myFunction()" autocomplete="off" placeholder="Search Username..." class="form-control tranfer_search"  name="tranfer_search" >
                          </div>
                          <div class="col-lg-1 col-4 p-0">
                            <button type="submit" class="btn btn-base">
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search">
                                <circle cx="11" cy="11" r="8"></circle>
                                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                              </svg>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
            <div class="col-lg-12">
              <div class="card card-margin  shadow radius-20">
                <div class="card-body p-2">
                  <div class="row search-body">
                    <div class="col-lg-12">
                      <div class="search-result">
                        <div class="card" style="height: calc(20rem + 10px)">
                          <div class="card-body card-body-scrollable card-body-scrollable-shadow">
                            <div class="result-body">
                              <div class="table-responsive pb-0 mb-0">
                                <div id="transactions-load" style="display:none;text-align:center;margin-top:150px;">
                                  <?php  include realpath(dirname(__DIR__) . '/common/loader.php'); ?>
                                </div>
                                
                                
                                <table class="table widget-26 table_transaction_history_content" id="table_transaction_history_content">
                                <tbody id="table_transaction_history_content_body" class="table_transaction_history_content_body">
                                </tbody>
                                </table>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include realpath(dirname(__DIR__) . '/common/inner_footer.php'); ?>
</div>
</div>


<script type="text/javascript">

  $(document).ready(function() {
  
  var UserCurrentBal = "<?php echo ($user_balance) ? my_number_format($user_balance) : 0.00;?>";
  var walletTransferForm = $('#wallet_transfer');
  var currentInput = $('#get-user-details-cls');
  var sendActivationFormSubmitBtn = $('input#send_activation_form_submit_btn');
  var sendActivationFormSubmitAnchorBtn = $('#send-btn-alternative-anchor-cls');
  var requestActivationFormSubmitBtn = $('input#request_activation_form_submit_btn');
  var requestActivationFormSubmitAnchorBtn = $('#request-btn-alternative-anchor-cls');
  var _print_ajax_status_cls = $("#print-purchase-status-msg");
  var currentBal = $("#current_balance");
  var user_idID = $("#user_id");
  var amountID = $("#amount");
  var _TableHistoryContentTable = $("#table_transaction_history_content");
  var _TableHistoryContentBody = $("#table_transaction_history_content_body");
  var _user_transfer_image = $('.user-transfer-image');
  
  $.fn.historyWrapper = function(data){
   var receivedRow = '<tr class="bg-green-lt">\
                      <td><div class="widget-26-job-title"> <a href="#">Transfer to <span class="avatar" style="background-image: url(./static/avatars/003m.jpg)"></span> VEERA472 </a>\
                          <p class="m-0">16th Feb, 2022 03:02 <span class="time">UTC 1 days ago</span></p>\
                        </div></td>\
                      <td><div class="widget-26-job-category bg-lime-lt"> <i class="indicator bg-success"></i> <span>20EMUSH</span>\
                      </div></td>\
                      <td><div class="widget-26-job-starred"> <a href="#">\
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon recived-icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="#2fb344" stroke-linecap="round" stroke-linejoin="round">\
                            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>\
                            <line x1="3" y1="7" x2="21" y2="7"></line>\
                            <path d="M6 20l-3 -3l3 -3"></path>\
                            <path d="M6 4l-3 3l3 3"></path>\
                            <line x1="3" y1="17" x2="21" y2="17"></line>\
                          </svg>\
                          </a></div></td>\
                      </tr>';
      return receivedRow;
  }
  


  $(document).on('click', '.send-btn-alternative-anchor-cls', function(e){
      e.preventDefault();
      $('#type').val(0);
      $("#amount").attr("min", "0");
      $("#amount").attr("max", UserCurrentBal);
      sendActivationFormSubmitBtn.trigger('click');
  });

    $(document).on('click', '.request-btn-alternative-anchor-cls', function(e){
      e.preventDefault();
      $('#type').val(1);
      var _this = $(this);       
      $('#amount').removeAttr("min");
      $('#amount').removeAttr("max");
      requestActivationFormSubmitBtn.trigger('click');
  });



  walletTransferForm.validate(
  {
    ignore: [],
    rules: {
     user_id: {
               required: {
                depends:function(){
                 $(this).val($.trim($(this).val().replace(/\s+/g, '')));
                 return true;
               }
             },      
             // number:true,
             remote: {
                  url: baseURL + 'is-transaction-user-details-available',
                  type: 'POST',  
                  cache: false,                                  
                  data: { csrf_name : csrf_token , 'type' : $('#type').val() },
                  dataType: 'json',
                  beforeSend : function(){
                      currentInput.html('');
                      sendActivationFormSubmitBtn.prop("disabled", false);
                      _print_ajax_status_cls.hide().empty();
                      if (typeof(currentRequest) != 'undefined' && currentRequest != null) {                        
                          currentRequest.abort();
                      }
                  },
                  dataFilter: function (result) {
                      var result = $.parseJSON(result);                  
                      if(result.status==true){
                        if(result.data.pp.length > 0){
                          var pp_imsge = '<img class="avatar user-transfer-image" src="'+ result.data.pp +'" alt="img">';
                          currentInput.html( pp_imsge + ' ' + result.data.username);     
                        }else{
                          currentInput.html(result.data.username);   
                        }                        
                         return true;                   
                      }else{
                        $.fn.errorFn(result);                        
                      }                      
                  }
              },
           },
      amount: {
        required: {
                depends:function(){
                  if($('#type').val() == 0){
                       $("#amount").attr("min", "0");
                       $("#amount").attr("max", UserCurrentBal); 
                  }                  
                 $(this).val($.trim($(this).val().replace(/\s+/g, '')));
                 return true;
               }
             },  
        number:true
      }
    },
    messages: {
      user_id: {
        required: "Please enter User Id",
        // number: "Only enter number",

      },
      amount: {
        required: "Please enter Amount",
        number: "Only enter number",
      }

    },

    submitHandler: function(form) { 
      sendActivationFormSubmitBtn.attr("disabled", true);
      $.ajax({
        url: baseURL + "wallet-transfer",
        type:"post",
        data: walletTransferForm.serializeArray(),
        dataType:'json',
        success: function(result) {
          sendActivationFormSubmitBtn.prop("disabled", false);
          if(result.status == true){  
            // let decrypt = $.fn.displayDecryptData(r.data);          
            currentBal.html('');
            currentBal.html(result.format_balance + ' EMUSH'); 
            user_idID.val('');           
            amountID.val('');
            currentInput.html('');          
            $('#amount').attr('max', result.balance);
            $.fn.successFn(result);
            // $.fn.historyWrapper();
            _TableHistoryContentBody.prepend(result.current_history);
          }else{            
            $.fn.errorFn(result);
          }          
        },
        error: jqueryErrorHandling        
      });
      return false;
    }
  });

  $.fn.successFn = function(data){  
    if (typeof(data.msg) == 'undefined' && data.msg == null) { return;}    
    _print_ajax_status_cls.removeClass('alert-danger').addClass('alert-success').empty().show().html('').html(data.msg).delay(3000).fadeOut();
   }


  $.fn.errorFn = function(data){        
  if (typeof(data.msg) == 'undefined' && data.msg == null) { return;}        
    _print_ajax_status_cls.removeClass('alert-success').addClass('alert-danger').empty().show().html('').html(data.msg).delay(3000).fadeOut(); 
 }

});


// Display network error
function jqueryErrorHandling(xhr, status, exception) {  
  var responseText;
  $("#dialog").html("");
  try {
    responseText = jQuery.parseJSON(xhr.statusText);
    if(responseText == 'OK'){ return;}
    $("#dialog").append("<div><b>" + status + " " + exception + "</b></div>");
    $("#dialog").append("<div><u>Exception</u>:<br /><br />" + responseText.ExceptionType + "</div>");
    $("#dialog").append("<div><u>StackTrace</u>:<br /><br />" + responseText.StackTrace + "</div>");
    $("#dialog").append("<div><u>Message</u>:<br /><br />" + responseText.Message + "</div>");
  } catch (e) {
    var errorMessage = xhr.statusText;
    if(errorMessage == 'OK'){ return;}
    $("#dialog").html(errorMessage);
    $("#dialog").dialog({
      title: "Exception Details",
      autoOpen: true,
      modal: true,
      width: 700,
      buttons: {
        Close: function() {
          $(this).dialog('close');
        }
      }
    });
  }
}

 function myFunction() {
    var input, filter, table, tr, td, i, txtValue, td2, txtValue2;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("table_transaction_history_content");
    tr = table.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[0];
      td2 = tr[i].getElementsByTagName("td")[1];
     
      if (td || td2) {
        txtValue = td.textContent || td.innerText;
        txtValue2 = td2.textContent || td2.innerText;        
        if ((txtValue.toUpperCase().indexOf(filter) || txtValue2.toUpperCase().indexOf(filter) ) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }
    }
  }

$(document).ready(function() {
    $.ajax({
      url: baseURL + "transfer-ajax",
      type: "GET",
      dataType:'json',
      beforeSend: function(){
        $("#transactions-load").show();
      },
      success: function(r) {
        if(r.status==true){          
          let decrypt = $.fn.displayDecryptData(r.data);
          $('#table_transaction_history_content_body').html(decrypt);
          $("#transactions-load").hide();  
        }
      }
    });
    

    $(document).on('click', '.user-request-callover', function(e){
      e.preventDefault();
      var _this = $(this);    

      $('#user_id').val(_this.data('id'));
      $('#user_id').trigger('click');
      $('#amount').val(_this.data('amt'));
      $('input[value!=""]').trigger('keyup');
      $('input[value!=""]').focus();
    })

  });

</script>
</body>
</html>