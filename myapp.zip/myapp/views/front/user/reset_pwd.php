<?php include realpath(dirname(__DIR__) . '/common/header.php'); ?>
<!-- Login In start -->
<section class="login">
    <div class="overlay pt-120 pb-120">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="form-content">
                        <div class="section-header">
                          
                            <p style="color:white">Your Security is our top priority. You’ll need this to log into your Emush Account</p>
                        </div>
                    <?php $this->load->view('front/common/flashmessage'); ?>
                    <?php 
                      $action1 ='';$attributes=array('id'=>'reset_pw_user'); 
                      echo form_open($action1,$attributes);
                      ?>
                      <div class="row">
                        <div class="col-12">
                            <div class="single-input">
                                <label for="email"> ENTER YOUR NEW PASSWORD</label>
                                <input type="text" name="reset_password" id="reset_password" placeholder="Enter Your Password">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="single-input ">
                                <label for="confirmPass">CONFIRM YOUR NEW PASSWORD</label>
                                <div class="password-show d-flex align-items-center">
                                    <input type="password" class="passInput" name="reset_cpassword" id="reset_cpassword" autocomplete="off" placeholder="Enter Your Cofirm Password">                                    
                                    <img class="showPass password_on" src="<?php echo $assets_url_var; ?>images/icon/show-hide.png" alt="icon">
                                    <img class="showPass password_off" style="display:none;" src="<?php echo $assets_url_var; ?>images/vision.png" alt="icon">                                                                                              
                                </div>
                                <div id="tenrealm_password_error"></div>
                            </div>
                            
                        </div>
                    </div>
                    <div class="btn-area">
                        <input type="submit" name="btnsubmit" class="cmn-btn btnsubmit" value="Submit" >
                    </div>
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
</section>
<!-- Login In end -->
<?php include realpath(dirname(__DIR__) . '/common/footer.php'); ?>
<?php //$this->load->view('front/common/footer'); ?>
<script type="text/javascript">
    $(document).ready(function () {

    $.validator.addMethod("strong_password", function (value, element) {
        let password = value;
        if (!(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[@#$%&])(.{8,20}$)/.test(password))) {
            return false;
        }
        return true;
    }, function (value, element) {
        let password = $(element).val();
        if (!(/^(.{8,20}$)/.test(password))) {
            return 'Password must be between 8 to 20 characters long.';
        }
        else if (!(/^(?=.*[A-Z])/.test(password))) {
            return 'Password must contain at least one uppercase.';
        }
        else if (!(/^(?=.*[a-z])/.test(password))) {
            return 'Password must contain at least one lowercase.';
        }
        else if (!(/^(?=.*[0-9])/.test(password))) {
            return 'Password must contain at least one digit.';
        }
        else if (!(/^(?=.*[@#$%&])/.test(password))) {
            return "Password must contain special characters from @#$%&.";
        }
        return false;
    });

      $(document).on('click', '.btnsubmit', function(){
          $('#reset_pw_user').validate({ // initialize the plugin
            rules: {
                reset_password: {
                    required: true,
                    minlength: 5,
                    strong_password:true
                },
                reset_cpassword: {
                    required: true,
                    minlength: 5,
                        equalTo: "#reset_password"
                }        
            },
           errorPlacement: function(error, element) {
              if(element.attr("name") == "reset_cpassword") {
                console.log(error);
                $("div#tenrealm_password_error").html(error);
                console.log(element.parent("div.single-input").find("div#tenrealm_password_error"));
                error.appendTo( element.parent("div.single-input").find("div#tenrealm_password_error"));
            } else {
                error.insertAfter(element);
            }
        }
        });
      })

        
    });

</script>