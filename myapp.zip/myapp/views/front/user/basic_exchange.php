<?php 
    $this->load->view('front/common/header');
    $user_id = $this->session->userdata('user_id');
$this->load->view('front/user/basic_navigation');
$pairId = $pair_id;

    $token_chart = $this->common_model->customQuery("SELECT * FROM tenrealm_trade_pairs WHERE id='".$pairId."'")->row();

    if($token_chart->priceChangePercent>=0){
        $class1="clr-green";
        $b21 =  rtrim($token_chart->priceChangePercent,'0');
        if($b21!=0){
        $b21 = '+'.number_format(rtrim($b21,'.'),2).'%';
    }
    else{
        $b21 = '+0 '.'%';
    }
    $arrow = 'up';
    }
    else{
        $class1="clr-red";
        $b21 =  rtrim($token_chart->priceChangePercent,'0');
        $b21 = '-'.number_format(rtrim($b21,'.'),2).'%';
        $arrow = 'down';
    }

    $prefix = get_prefix();                                        
$url = $this->uri->segment(2);
$Exp = explode('_', $url);
$First_Currency = $Exp[0];
$Second_Currency = $Exp[1];

 $from_currency_id = $this->common_model->customQuery("select * from ".$prefix."currency where currency_symbol='".$Exp[0]."'")->row('id');
    $to_currency_id = $this->common_model->customQuery("select * from ".$prefix."currency where currency_symbol='".$Exp[1]."'")->row('id');

    $pair_details = $this->common_model->customQuery("select * from ".$prefix."trade_pairs where from_symbol_id='".$from_currency_id."' and to_symbol_id='".$to_currency_id."'")->row();
    $pair_ids = $pair_details->id;
    $from_currency_dets = getcryptocurrencydetail($from_currency_id);
    $to_currency_dets = getcryptocurrencydetail($to_currency_id);

    // print_r($pair_id)
?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/w/bs4/dt-1.10.18/datatables.min.css" >
<style>
.fees-col {
  color: #000 !important;
  font-weight: bold;
}
#instant_buy_price {
  border: 0px;
  background-color: #fff;
}
#instant_sell_price {
  border: 0px;
  background-color: #fff;
}
.buy-convert {
  border: 0px;
  background-color: #fff;
}
.sell-convert {
  border: 0px;
  background-color: #fff;
}
.align-items-center {
  cursor: default !important;
}
/* Loader */
.se-pre-con {
  position: fixed;
  left: 0px;
  top: 0px;
  width: 100%;
  height: 100%;
  z-index: 9999;
  background: url('<?=front_img()?>exchange-loader.gif') center no-repeat #0c0707;
  background-size: 10%;
  opacity: 0.6;
}
.trade-loader {
  position: fixed;
  left: 0px;
  top: 0px;
  width: 100%;
  height: 100%;
  z-index: 9999;
  background: url('<?=front_img()?>trade-loader.gif') center no-repeat #0c0707;
  background-size: 5%;
  opacity: 0.6;
}
/* Loader */
.amount_percentage {
  /*width: 50px;*/
  background-color: rgb(164 202 243);
  text-align: center;
  margin-left: 10px;
  margin-top: -8px;
  height: 33px;
  cursor: pointer;
}
.amount_percentage a {
  color: #000;
}
/*.amount-container {
  padding: 12px;
}*/
.amount_percentage:hover {
  background-color: #4699F2 !important;
}
</style>

<div class="se-pre-con"></div>
<div class="trade-loader" style="display:none;"></div>
<div class="page-wrapper">
    <div class="page-body">
      <div class="container-xl">
        <div class="row">
          <div class="col-3 col-sm-3">
          </div>
          <input type="hidden" id="exchange_type" value="1">  
          <input type="hidden" id="sorting_type"> 
          <input type="hidden" id="from_currency_value" name="from_currency_value" value="<?php echo str_replace(",","",$from_cur);?>">
		  <input type="hidden" id="to_currency_value" name="to_currency_value" value="<?php echo str_replace(",","",$to_cur);?>">
          <div class="col-12 col-sm-6">
            <div class="col-md-12">
              <div class="card">
                <ul class="nav nav-tabs nav-fill trade-navbar" data-bs-toggle="tabs">
                  <li class="nav-item">
                    <a href="javascript:;" id="buy-tab" class="nav-link active" data-bs-toggle="tab"><?=$this->lang->line('Buy');?></a>
                  </li>
                  <li class="nav-item">
                    <a href="javascript:;" id="sell-tab" class="nav-link" data-bs-toggle="tab"><?=$this->lang->line('Sell');?></a>
                  </li>
                 </ul>
                <div class="card-body">
                  <div class="tab-content">
                    <div class="tab-pane trade-navbar-wrapper show active" id="buy-tab-content">

                    <?php $to_cur_str = str_replace(',', '', $to_cur);
                         // $first_cur_str = str_replace(',', '', $First_Currency);
                    ?>  
                    <h4 class="d-flex"><?=$this->lang->line('Buy');?> <?php echo $First_Currency;?> <span class="ml-auto"> <span class="buy_bal"><?=$to_cur_str?> <?php echo $Second_Currency;?></span></span></h4>

                  <div class="form-group mb-3 row">
                    <label class="form-label col-3 col-form-label"><?=$this->lang->line('Amount in Euro');?></label>
                    <div class="col-3">
                      <input type="number" class="form-control" name="instant_buy_amount" id="instant_buy_amount" onkeyup="calculation_basic('buy','instant')" >
                      
                    </div>
                    <div class="col-6">
                      <ul class="flex-fill amount-container">
                        <li class="amount_percentage form-control" onclick="change_instant_trade('buy','10','instant')"><a href="javascript:void(0);">10</a></li>
                        <li class="amount_percentage form-control" onclick="change_instant_trade('buy','25','instant')"><a href="javascript:void(0);">25</a></li>
                        <li class="amount_percentage form-control" onclick="change_instant_trade('buy','50','instant')"><a href="javascript:void(0);">50</a></li>
                        <li class="amount_percentage form-control" onclick="change_instant_trade('buy','100','instant')"><a href="javascript:void(0);">100</a></li>
                      </ul>
                    </div>  
                    <span style="color:#e80303;" class="error-minimum-buy"></span>
                  </div>
                  <div class="form-group mb-3 row buyRate-wrapper"></div>

                  <div class="form-group mb-3 row">
                    <label class="form-label col-3 col-form-label"><?=$this->lang->line('Price for coin');?></label>
                    <div class="col">
                      <input type="number" class="form-control" name="instant_buy_price" readonly="rr" id="instant_buy_price" value="<?php echo $token_chart->lastPrice;?>">
                    </div>
                  </div>
                  <div class="form-group mb-3 row">
                    <label class="form-label col-3 col-form-label"><?=$this->lang->line('Total in');?>  <?=$First_Currency;?></label>
                    <div class="col">
                      <input type="number" class="form-control" name="instant_buy_tot" id="instant_buy_tot" onkeyup="calculation_with_total('buy','instant')">
                    </div>  
                  </div>
                <label class="form-selectgroup-item">
                  <span class="form-selectgroup-label d-flex align-items-center p-3 "> <span class="me-3"></span> <span class="d-block text-muted1" style="margin-left: -30px;"><?=$this->lang->line('Buy');?></span><span class="form-selectgroup-label-content"> <span class="form-selectgroup-title strong mb-1">
                  <img alt="Bitcoin logo" src="<?=$from_currency_dets->image?>" aria-label="<?=$from_currency_dets->currency_name?> logo " style="height: 32px" ;="" class="Image-sc-1i3cgkp-0 ImageWithFallback__AbsoluteImage-ufzvsr-0 dmqghf send-crypto-icon">
                        
                  <span><?=$from_currency_dets->currency_name?></span>  
                  </span> </span> </span> </label>

                <label class="form-selectgroup-item">
                  <input type="radio" name="report-type" value="1" class="form-selectgroup-input" data-toggle="modal" href="#myModal2">

                  <span class="form-selectgroup-label d-flex align-items-center p-3"> <span class="me-3"></span> <span class="d-block text-muted1" style="margin-left: -30px;"><?=$this->lang->line('Pay with');?></span><span class="form-selectgroup-label-content"> <span class="form-selectgroup-title strong mb-1">
                    <span>Euro Account</span>
                  </span> </span> </span> </label>  
 
                  <p class="fees-col"><?=$this->lang->line('Fee');?> : <span><?=TrimTrailingZeroes(getfeedetails_buy($pair_id))?>%
                    <small style="float:right;" class="fees-col" id="buy_instant_fees">0</small> </span></p>
                <div class="col-lg-12 mt-2"> 

                  <button type="button" class="btn btn-primary ms-auto" id="buy_btn" onclick="order_placed('buy','instant')"><?=$this->lang->line('Buy Now');?></button>
                </div>

                    </div>


                <div class="tab-pane trade-navbar-wrapper" id="sell-tab-content">
                  <h4 class="d-flex"><?=$this->lang->line('Sell');?> <?php echo $First_Currency;?> <span class="ml-auto"> <span class="sell_bal"><?php echo $from_cur;?> <?=$First_Currency;?></span></h4>
                 
                <div class="form-group mb-3 row">
                  <label class="form-label col-3 col-form-label"><?=$this->lang->line('Amount in');?>  <?=$First_Currency;?></label>
                  <div class="col">
                    <input type="number" class="form-control" name="instant_sell_amount" id="instant_sell_amount" onkeyup="calculation_basic('sell','instant')">
                  </div>
                </div>
                <div class="form-group mb-3 row sellRate-wrapper"> </div>
                <div class="form-group mb-3 row">
                  <label class="form-label col-3 col-form-label"><?=$this->lang->line('Price for coin');?></label>
                  <div class="col">
                    <input readonly type="text" name="instant_sell_price" id="instant_sell_price" class="form-control sell-marketprice" value="<?php echo $token_chart->lastPrice;?>">
                  </div>  
                </div>
                <div class="form-group mb-3 row">
                  <label class="form-label col-3 col-form-label"><?=$this->lang->line('Total in Euro');?> </label>
                  <div class="col-3">
                    <input class="form-control to_address" name="instant_sell_tot" id="instant_sell_tot" type="text" onkeyup="calculation_with_total('sell','instant')" />
                    
                  </div>
                  <div class="col-6">
                    <ul class="flex-fill amount-container">
                      <li class="amount_percentage form-control" onclick="change_instant_trade('sell','10','instant')"><a href="javascript:void(0);">10</a></li>
                      <li class="amount_percentage form-control" onclick="change_instant_trade('sell','25','instant')"><a href="javascript:void(0);">25</a></li>
                      <li class="amount_percentage form-control" onclick="change_instant_trade('sell','50','instant')"><a href="javascript:void(0);">50</a></li>
                      <li class="amount_percentage form-control" onclick="change_instant_trade('sell','100','instant')"><a href="javascript:void(0);">100</a></li>
                    </ul>
                  </div>
                  <span style="color:#e80303;" class="error-minimum-sell"></span>
                </div>
                
              <label class="form-selectgroup-item">
                <span class="form-selectgroup-label d-flex align-items-center p-3"> <span class="me-3"></span> <span class="d-block text-muted1" style="margin-left: -30px;"><?=$this->lang->line('Sell');?></span><span class="form-selectgroup-label-content"> <span class="form-selectgroup-title strong mb-1">
                <img alt="Bitcoin logo" src="<?=$from_currency_dets->image?>" aria-label="<?=$from_currency_dets->currency_name?> logo " style="height: 32px" ;="" class="Image-sc-1i3cgkp-0 ImageWithFallback__AbsoluteImage-ufzvsr-0 dmqghf send-crypto-icon">
                  <span><?=$from_currency_dets->currency_name?></span> 
                </span> </span> </span> </label>

              <label class="form-selectgroup-item">
                <input type="radio" name="report-type" value="1" class="form-selectgroup-input" data-toggle="modal" href="#myModal2">

                <span class="form-selectgroup-label d-flex align-items-center p-3"> <span class="me-3"></span> <span class="d-block text-muted1" style="margin-left: -30px;"><?=$this->lang->line('Pay with');?></span><span class="form-selectgroup-label-content"> <span class="form-selectgroup-title strong mb-1">
                  <span>Euro Account</span>
                </span> </span> </span> </label>  
                
                <p class="fees-col"><?=$this->lang->line('Fee');?> : <span><?=TrimTrailingZeroes(getfeedetails_sell($pair_id))?>%
                  <small style="float:right;" class="fees-col" id="sell_instant_fees">0</small> </span></p>

              <div class="col-lg-12 mt-2"> 
                <button type="button" class="btn btn-primary ms-auto" id="sell_btn" onclick="order_placed('sell','instant')"><?=$this->lang->line('Sell Now');?></button>
              </div>  
                    </div>

              </div>
            </div>

          </div>

          </div>
          </div>
          <div class="col-md-3 col-lg-3"> </div>
        </div>

      </div>

    </div>

     <div class="page-body">
          <div class="container-xl">
            <div class="row row-cards">
              <div class="col-md-12">
                <div class="card" style="border-radius: 10px;">
                  <ul class="nav nav-tabs current-userorder basictable" data-bs-toggle="tabs">
                    <li class="nav-item">
                      <a href="#tab_open_order" class="nav-link active" data-toggle="tab"><?=$this->lang->line('Open Order');?></a>
                    </li>
                    <li class="nav-item">
                      <a href="#tab_trade_history" class="nav-link" data-toggle="tab"><?=$this->lang->line('Trade History');?></a>
                    </li>
                  </ul>
                  <div class="card-body">
                    <div class="tab-content">
                      <div class="tab-pane active show" id="tab_open_order">
                        <div class="col-12">
                          <div class="card">
                            <div class="table-responsive">
                              <table id="open_order" class="table table-vcenter card-table" style="width:100%;">
                                <thead>
                                  <tr>
                                    <th style="background-color: #a4caf3;"><?=$this->lang->line('Date');?></th>
                                    <th style="background-color: #a4caf3;"><?=$this->lang->line('Type');?></th>
                                    <th style="background-color: #a4caf3;"><?=$this->lang->line('Pair');?></th>
                                    <th style="background-color: #a4caf3;"><?=$this->lang->line('Order Type');?></th>
                                    <th style="background-color: #a4caf3;"><?=$this->lang->line('Amount');?></th>
                                    <th style="background-color: #a4caf3;"><?=$this->lang->line('Price');?></th>
                                    <th style="background-color: #a4caf3;"><?=$this->lang->line('Total');?></th>
                                    <th style="background-color: #a4caf3;"><?=$this->lang->line('Cancel');?></th>
                                  </tr>
                                </thead>
                                <tbody class="open_orders"></tbody>
                              </table>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="tab-pane" id="tab_trade_history">
                        <div class="col-12">
                          <div class="card">
                            <div class="table-responsive">
                              <table id="trade_history_tab" class="table table-vcenter card-table" style="width:100%;">
                                <thead>
                                  <tr>
                                    <th style="background-color: #a4caf3;"><?=$this->lang->line('Date');?></th>
                                    <th style="background-color: #a4caf3;"><?=$this->lang->line('Type');?></th>
                                    <th style="background-color: #a4caf3;"><?=$this->lang->line('Pair');?></th>
                                    <th style="background-color: #a4caf3;"><?=$this->lang->line('Amount');?></th>
                                    <th style="background-color: #a4caf3;"><?=$this->lang->line('Price');?></th>
                                    <th style="background-color: #a4caf3;"><?=$this->lang->line('Total');?></th>
                                    <th style="background-color: #a4caf3;"><?=$this->lang->line('Status');?></th>
                                  </tr>
                                </thead>
                                <tbody class="transactionhistory"></tbody>
                              </table>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>

  </div>


<?php 
$this->load->view('front/common/basic_footer'); 
$this->load->view('front/trade/trade_footer');
?>
<script> 
var user_id='<?php echo $user_id;?>';    
$(document).on('click', '.trade-navbar li', function() { 
  li = $(this).find('a').attr('id');
  $(".trade-navbar li a").not($(this)).removeClass('active show');
  $(".trade-navbar-wrapper").removeClass("active show");  
  if(li=='buy-tab') {
    $("#buy-tab").addClass("active show");      
    $("#buy-tab-content").addClass("active show");    
  } else if(li=='sell-tab') {
    $("#sell-tab").addClass("active show");
    $("#sell-tab-content").addClass("active show");
  } 
});

function check_user_login()
{
    if(user_id==''||user_id==undefined||user_id==0) {
        Swal.fire('Please Login the site.')
        return false;
    }
    return true;
}

</script>