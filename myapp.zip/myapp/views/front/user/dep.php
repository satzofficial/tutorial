<?php include realpath(dirname(__DIR__) . '/common/inner_header.php'); 
$prefix = get_prefix();
?>
<div class="page-wrapper">
  <div class="page-body">
    <div class="container-xl">
      <ol class="breadcrumb breadcrumb-arrows mb-3" aria-label="breadcrumbs">
        <li class="breadcrumb-item"><a href="#">Affiliate</a></li>
        <li class="breadcrumb-item active" aria-current="page">Level Income</li>
      </ol>
      <div class="row row-cards">
        <div class="col-sm-12">
          <div class="card shadow radius-20">
            <div class="card-body">
              <h4 class="card-title">Deposite History</h4>
              <div class="row">
                <div class="">
                  <ul class="nav nav-tabs" data-bs-toggle="tabs">
                    <?php 
                    if($packages_arr){
                     foreach ($packages_arr as $pack_key => $pack_value) {
                      $pack_key  =  $pack_key + 1;
                      $pack_name = ($pack_value['package_name']) ? $pack_value['package_name'] :'';
                      ?>
                      <li class="nav-item">
                       <a href="#tabs-<?php echo $pack_key; ?>" class="nav-link <?php if($pack_key==1){ echo 'active'; } ?>" data-bs-toggle="tab">
                        <span class="lg-block"><?php echo strtoupper($pack_name); ?></span> 
                        <span class="xs-block">
                         <?php if($pack_key==1){ ?>
                           <!-- Download SVG icon from http://tabler-icons.io/i/moon-2 -->
                           <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                            <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                            <path d="M16.418 4.157a8 8 0 0 0 0 15.686" />
                            <circle cx="12" cy="12" r="9" />
                          </svg>
                        <?php }else if($pack_key==2){ ?>
                         <!-- Download SVG icon from http://tabler-icons.io/i/target -->
                         <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                          <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                          <circle cx="12" cy="12" r="1" />
                          <circle cx="12" cy="12" r="5" />
                          <circle cx="12" cy="12" r="9" />
                        </svg>
                      <?php }else if($pack_key==3){ ?>
                       <!-- Download SVG icon from http://tabler-icons.io/i/moon-stars -->
                       <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                        <path d="M12 3c.132 0 .263 0 .393 0a7.5 7.5 0 0 0 7.92 12.446a9 9 0 1 1 -8.313 -12.454z" />
                        <path d="M17 4a2 2 0 0 0 2 2a2 2 0 0 0 -2 2a2 2 0 0 0 -2 -2a2 2 0 0 0 2 -2" />
                        <path d="M19 11h2m-1 -1v2" />
                      </svg>
                    <?php }else if($pack_key==4){ ?>
                     <!-- Download SVG icon from http://tabler-icons.io/i/omega -->
                     <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M4 19h5v-1a7.35 7.35 0 1 1 6 0v1h5" /></svg>
                   <?php }else if($pack_key==5){ ?>
                     <!-- Download SVG icon from http://tabler-icons.io/i/moon -->
                     <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                      <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                      <path d="M12 3c.132 0 .263 0 .393 0a7.5 7.5 0 0 0 7.92 12.446a9 9 0 1 1 -8.313 -12.454z" />
                    </svg>

                  <?php }else{ ?>
                   <!-- Download SVG icon from http://tabler-icons.io/i/sun -->
                   <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                    <circle cx="12" cy="12" r="4" />
                    <path d="M3 12h1m8 -9v1m8 8h1m-9 8v1m-6.4 -15.4l.7 .7m12.1 -.7l-.7 .7m0 11.4l.7 .7m-12.1 -.7l-.7 .7" />
                  </svg>
                <?php } ?>

              </span>

            </a>
          </li>

        <?php } }  ?>
      </ul>
                  
       <?php 
                  
                  print_r($dep);
                  echo "test";
                  
        if(isset($dep) && $dep!='') { ?>          
                  
                  
                  
      <div class="card-body border-n">
       <table>
  <tr>
    <th>Hash</th>
    <th>Amount</th>
    <th>Status</th>
  </tr>
         
         <?php   foreach($dep as $d){    ?>
  <tr>
    <td><?php echo $d->hash;?></td>
    <td><?php echo $d->amount;?></td>
    <td><?php echo $d->status;?></td>
  </tr>
         <?php }
                                           
         ?>
  
  
  
</table>
       <?php }else{
         
         echo "No Records Found";
} ?>   
              </div>
            </div>
          </div>
          <?php   ?>

        </div>
      </div>
    </div>
  </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<div class="modal modal-blur fade prfile-dir" id="modal-report" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog modal-lg modal-dialog-centered" role="document">
   <div class="modal-content shadow radius-20">
      <div class="modal-header">
         <h5 class="modal-title"><span id="popup-pro-name-first"> </span>  Level Income</h5>
         <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
         <div class="custom-modal-body">
            <div class="card none-card" style="height: calc(13.6rem + 10px)">
               <div class="card-body card-body-scrollable card-body-scrollable-shadow">
                  <input type="hidden" value="" name="selected_package_id" id="selected_package_id" class="selected_package_id" />
                  <input type="hidden" value="" name="selected_level_id" id="selected_level_id" class="selected_level_id" />
                  <div class="row" id="popup-package-user-profile-list">
                  </div>
               </div>
            </div>
              <!-- Paginate -->
              <div id='pagination-popup'></div>
         </div>
         <div class="modal-footer"> <a href="#" class="btn btn-link link-secondary" data-bs-dismiss="modal"> Cancel </a> </div>
      </div>
   </div>
</div>
</div>




<div class="modal modal-blur fade prfile-dir" id="modal-profile-report" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog modal-lg modal-dialog-centered" role="document">
   <div class="modal-content shadow radius-20">
      <div class="modal-header">
         <h5 class="modal-title"><span id="popup-pro-profile-name"> </span>  Personal Details</h5>
         <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          <div class="row g-2 ">
            <div class="col-auto align-top" id="popup-profile-img"> </div>
            <div class="col">
                <input type="hidden" name="popup_id" id="popup-hidden-user-id" value="">
               <h4 class="card-title m-0" id="popup-username">  </h4>
               <div class="text-muted" id="popup-unique-id"> Id:  </div>
               <div class="text-muted" id="popup-email"> Mailid: </div>
               <div class="text-muted" id="popup-date-of-joining"> </div>
               <div class="text-muted" id="popup-date-total-earning"> </div>
            </div>
            <div class="col-12">
               <div class="card border-0 shadow-n">
                  <div class="card-body">
                     <div class="divide-y">
                        <div class="row popup-all-package" id="popup-all-package">
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="modal-footer"> <a href="#" class="btn btn-link link-secondary" data-bs-dismiss="modal"> Cancel </a> </div>
      </div>
   </div>
</div>
</div>

<?php include realpath(dirname(__DIR__) . '/common/inner_footer.php'); ?>
<script>
 
$(document).ready(function(){
      $('.levelincome-tooltip').tooltip();
      var  printUserDetailPopup = $('.print_user_detail_popup');

      $.fn.allpurchasedPackageList = function(package, userPackage){
            var list = '';
            $.each(package, function(index, val) {
               /* iterate through array or object */
             if ((userPackage.includes(val.id)) ){                  
                  var avatar = 'avatar bg-green-lt';
                  var badge = 'badge bg-green';                    
              }else{
                  var avatar = 'avatar bg-red-lt';
                  var badge = 'badge bg-red';                 
              }
             list +='<div class="atv-mlm col-6">\
                            <div class="row" >\
                               <div class="col-auto">\
                                  <span class="'+ avatar +'">\
                                     <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">\
                                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>\
                                        <circle cx="12" cy="7" r="4" />\
                                        <path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2" />\
                                     </svg>\
                                  </span>\
                               </div>\
                               <div class="col">\
                                  <div class="text-truncate"> <strong>'+val.package_name+'</strong> </div>\
                               </div>\
                               <div class="col-auto align-self-center">\
                                  <div class="'+badge+'"></div>\
                               </div>\
                            </div>\
                         </div>';
            });
            return list;
      }

     $('#pagination-popup').on('click','a',function(e){
       e.preventDefault();       
       var pagepopupno = $(this).data('ci-pagination-page');        
       loadPopUpPagination(pagepopupno);
     });
 
       
      function loadPopUpPagination(pagepopupno){ 
         return true;       
        var package_id = $('#selected_package_id').val();
        var level = $('#selected_level_id').val();        
        $.ajax({
          url: baseURL + 'auto-level-income-list/'+ pagepopupno,
          type: 'get',
          dataType: 'json',
          data: {'csrf_name' : csrf_token, 'id' : package_id, 'level' : level },          
          success: function(response){
              if(response.status == true){
                  let decrypt = $.fn.displayDecryptData(response.data);
                  $.fn.createPopupList(decrypt.result, decrypt.row);
                  $('#pagination-popup').html(decrypt.pagination);
                  $('#modal-report').modal('show');     
              }              
           }
        });
      }



      $.fn.createPopupList = function(result,sno){         
           var sno = Number(sno);
           var popUpbodyContent = $('#popup-package-user-profile-list');
           popUpbodyContent.empty();
           if(result.length < 1){
                popUpbodyContent.append('<level style="text-align:center;">There are no direct downlines</label>');return;   
            }
           $.each(result, function(index, val) {
             var name = val.name;
             var short_name = val.short_name;
             var image = val.pp;
             var id = val.id;
             // var unique_id = val.unique_id;
             if(val.pp_status == true){
              var icon = '<span class="avatar avatar-sm avatar-rounded" style="background-image: url('+image+')"></span>'; 
             }else{
              var icon = '<span class="avatar avatar-sm avatar-rounded" style="background-image: url('+avatarImage+')"></span>'; 
              // var icon = '<span class="avatar avatar-sm avatar-rounded"> '+ short_name +' </span>';
             }
            var   colmd6_list_box='<div class="col-md-6 col-xl-4 mb-2">\
                                <a class="card card-link popup-list-user" href="javascript:;" data-popup_ids="'+ id +'" >\
                                   <div class="card-body">\
                                      <div class="row">\
                                         <div class="col-auto">'+ icon +'\
                                         </div>\
                                         <div class="col">\
                                            <div class="font-weight-medium">'+ name +'</div>\
                                         </div>\
                                      </div>\
                                   </div>\
                                </a>\
                             </div>';
               popUpbodyContent.append(colmd6_list_box);
            });
      }

      $(document).on('click', '.print_user_detail_popup', function(){
        var _this = $(this);
        var package_id = _this.data('package_id');
        var level_id = _this.data('levels');
        $('#selected_package_id').val(package_id);
        $('#selected_level_id').val(level_id);
        loadPopUpPagination(0);        
      });



      $.fn.fetchedUserData = function(id){
          $.ajax({
              url: baseURL + 'display-level-list-personal',
              type: 'POST',
              dataType: 'json',
              data: {'csrf_name' : csrf_token, 'id' : id},
              success: function(result){                
                if(result.status == true){ 
                  let decrypt = $.fn.displayDecryptData(result.data);
                  if(decrypt.personal.pp_status == 1){
                    var pp = decrypt.personal.pp;
                    var popupProfileImg = '<span class="avatar avatar-lg" style="background-image: url('+ pp +')"></span>';
                  }else{                  
                    var popupProfileImg = '<span class="avatar avatar-lg" style="background-image: url('+ avatarImage +')"></span>';
                    // var popupProfileImg = '<span class="avatar avatar-lg" > ' + decrypt.personal.short_name+ '</span>';
                  }                  
                  // $('#popup-hidden-user-id').val(id);
                  $('#popup-pro-profile-name').html();
                  $('#popup-profile-img').html(popupProfileImg);
                  $('#popup-username').html(decrypt.personal.name);
                  if(decrypt.personal.fname.length > 0){
                    $('#popup-pro-profile-name').html(decrypt.personal.fname);  
                  }
                  $('#popup-unique-id').html('Id : ' + decrypt.personal.unique_id);
                  $('#popup-email').html('Email Address : ' + decrypt.personal.email);
                  $('#popup-date-of-joining').html('Joining Date/Time : ' + decrypt.personal.date_of_joinings + ' UTC');
                  $('#popup-date-total-earning').html('Total Earning : ' + decrypt.personal.total_earning);
                  $('#popup-all-package').html($.fn.allpurchasedPackageList(decrypt.packages_arr, decrypt.user_packages_arr));
                  // loadPopUpPagination(0);                  
                  $('#modal-profile-report').modal('show');
                }

              }
          });

        }

      $(document).on('click', '.popup-list-user', function(e){
        e.preventDefault();
        var _this = $(this);        
        var id = _this.data('popup_ids'); 
        $.fn.fetchedUserData(id);
     })


}); 
 
</script>