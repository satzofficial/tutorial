<?php

  $user_btcbalance = getBalance($users->id,1);
  $currencyDet = getcurrencydetail(1);
  $EURO_Balance = $user_btcbalance * $currencyDet->online_europrice;

?>
<div class="col-md-4 col-lg-4">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <h3 class="card-title"><?php echo $this->lang->line('Crypto Converter');?></h3>
        </div>
        <div class="modal-body">
			<select class="form-control select-crypto" onchange="getCrypto(this.value);" style="margin-bottom:10px;">
			  <option value="">Select Coin</option>
			  <?php
            if(count($dig_currency) >0) {
              foreach ($dig_currency as $digital) {
              	if (in_array($digital->currency_symbol, array('BTC','ETH','BCH','USDT','EUR'))) { ?>	
              	<option <?=($digital->currency_symbol=='EUR')?'selected':''?> value="<?=$digital->currency_symbol;?>"><?=$digital->currency_name;?></option>

            <?php }}}?>
			</select>
          <div class="input-icon mb-3">
<span class="input-icon-addon input-crypto-symbol">
<!-- <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M17.2 7a6 7 0 1 0 0 10"></path><path d="M13 10h-8m0 4h8"></path></svg> -->
€
</span>

<input type="text" class="form-control" id="EuroCurrencyInput" onkeyup="changeFiatCurrency(this)" name="example-text-input" placeholder="0">
            
            <?php if($user_btcbalance==0) {
                  $walletTxt = "You don't have any Bitcoin to trade. Fund your account to get started.";
                }
                if($user_btcbalance>0) {
                  $walletTxt = '';
                }
            ?>
          </div>  
          <label class="form-label coinwallet-label"><?=$walletTxt?></label>
          
          <div class="form-selectgroup-boxes row mb-3">
          <?php
    if(count($dig_currency) >0)
    {
      foreach ($dig_currency as $ckey => $digital) {
      if (in_array($digital->currency_symbol, array('BTC','ETH'))) {

    if($digital->type=="fiat")
    {
        $format = 2;
    }
    elseif($digital->currency_symbol=="USDT")
    {
        $format = 6;
    }
    else
    {
        $format = 6;
    }
    $coin_price_val = to_decimal($wallet['Exchange AND Trading'][$digital->id], $format);
    $coin_price = $coin_price_val * $digital->online_usdprice;

    $userbalance = getBalance($user_id,$digital->id);
    $USDT_Balance = $userbalance * $digital->online_usdprice;
    // $EURO_Balance = bcmul($userbalance ,$digital->online_europrice);
    // $EURO_Balance = $userbalance * $digital->online_europrice;

    if($ckey==0) {
      $labelTxt = 'From';

    } else {
      $labelTxt = 'To';
    }
    ?>
       
    <div class="col-lg-12">
      <div class="pos-rel">
        <?php if($ckey==0) {?>
          <div class="swap-wrp"><a href="javascript:void(0);" class="swap-crypto" onclick="swapCrypto()"><i class="fa fa-exchange" aria-hidden="true"></i></a></div>
        <?php }?>
        
        <label class="form-selectgroup-item">
        <input type="radio" name="report-type" value="<?=$ckey?>" class="form-selectgroup-input select-currency" data-toggle="modal" href="#myCurrencyModal">

        <span class="form-selectgroup-label d-flex align-items-center p-3"> <span class="me-3"> <span class="form-selectgroup-check"></span> </span> <span class="d-block text-muted1">
        <?=$labelTxt?></span><span class="form-selectgroup-label-content crypto-wrapper<?=$ckey?>" id="crypto-container<?=$ckey?>"> <span class="form-selectgroup-title strong mb-1">
        <img style="margin-right:10px;" width="30px" height="30px" src="<?php echo $digital->image;?>" class="table-cryp crypto-icon-<?=$ckey?>"> 

        <span class="<?=$labelTxt?>-currencyprice"><?=$digital->currency_name;?></span>
        </span>
          <a href="javascript:void(0);" class="pob-absolute"><i class="fa fa-chevron-right"></i></a>
        </span></span> 
        <input type="hidden" class="<?=$labelTxt?>-currency currency-sym crypto-sym-<?=$ckey?>" data-currency="<?=$digital->currency_symbol?>">
      </label> 
        </div>
        </span>

        
      </label>
        
    </div>
          <?php }}}?>  
          </div>

          <div class="row">
            <div class="mt-3 mb-2">
              <h4 class="m-0 float-start currencybal-label">BTC <?=$this->lang->line('Balance');?></h4>
              <small class="text-muted float-end convertCoin-label"><?=$user_btcbalance.' BTC ≈ €'.$EURO_Balance?></small>
            </div>
          </div>
        </div>
      </div>
    </div>
    
  </div>