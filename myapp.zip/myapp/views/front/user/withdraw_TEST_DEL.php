<?php 
$this->load->view('front/common/header');
$user_id = $this->session->userdata('user_id');

if($selcur_id==5) { $style="display:none;"; }
else { $style="display:block;"; }

?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.1/css/select2.min.css" rel="stylesheet" />
<style type="text/css">
  #amount_receive_error{
    color: red;
  }
  .bs-tabs .nav-tabs { margin-bottom: 2px;
    background: #f4f4f4; }
    .bs-tabs .nav-tabs > li.active > a, .nav-tabs > li.active > a:focus, .nav-tabs > li.active > a:hover { border-width: 0; }
    .bs-tabs .nav-tabs > li > a { border: none; color: #000;padding: 10px 30px;       display: block;  background: #f4f4f4;}
    .bs-tabs .nav-tabs > li.active > a, .bs-tabs .nav-tabs > li > a:hover { border: none;  color: #000 !important; }
    .bs-tabs .nav-tabs > li > a::after { content: ""; height: 2px; position: absolute; width: 100%; left: 0px; bottom: -1px; transition: all 250ms ease 0s; transform: scale(0); }
    .bs-tabs .nav-tabs > li.active > a::after, .bs-tabs .nav-tabs > li:hover > a::after { transform: scale(1);  }
    .bs-tabs .tab-nav > li > a::after {  color: #fff; }
    .bs-tabs .tab-pane { padding: 15px 0; }
    .bs-tabs .tab-content{padding:20px;     background: #f4f4f4;}
    .bs-tabs .nav-tabs > li  {   
      text-align: center;
      color: #000;

      margin-right: 2px;}
      .bs-tabs .nav-tabs > li a.active  {
        background: #4699F2; color:#FFF !important;
      }
      .select2-container--default .select2-selection--single {
        background-color: #fff;
        border: 1px solid #aaa;
        border-radius: 4px;
        width: 250px !important;
      }
      .select2-container--default .select2-selection--single .select2-selection__arrow {
        height: 26px;
        position: absolute;
        top: 1px;
        right: 155px !important; 
        width: 20px;
      }
      .select2-container--default .select2-results>.select2-results__options {
        max-height: 200px;
        overflow-y: auto;
        width: 250px !important;
      }
      .select2-container--open .select2-dropdown--below {
        border-top: none;
        border-top-left-radius: 0;
        border-top-right-radius: 0;
        width: 250px !important;
      }
      .select2-container--open .select2-dropdown--above {
        border-bottom: none;
        border-bottom-left-radius: 0;
        border-bottom-right-radius: 0;
        width: 250px !important;
      }
      @media all and (max-width:724px){
        .bs-tabs .nav-tabs > li > a > span {display:none;}   
        .bs-tabs .nav-tabs > li > a {padding: 5px 5px;}
      }

      #chart-area, #widget-container, .tv-main-panel {background: #000;}
      .chart-page .chart-container {border: black solid 0;}

      .withdraw-btn { border-color: #fabc2e;  }

      .fiat_withdraw {
        margin-top: 15px;
        text-align: center;
      }
      .modal-content1 {
        position: relative;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        -ms-flex-direction: column;
        flex-direction: column;
        width: 100%;
        pointer-events: auto;
        background-color: #fff;
        background-clip: padding-box;
        border: 1px solid rgba(0, 0, 0, 0.2);
        border-radius: 0.3rem;
        outline: 0;
        height: 770px;
      }
      .error-addressbook {
        color: red;
        margin-left: 120px;
      }

    </style>

    <!-- breadcrumb -->
    <div class="me-breadcrumb">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="me-breadcrumb-box">
              <h1><?php echo $this->lang->line('Withdraw');?></h1>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="me-service-single me-padder-top me-padder-bottom">
      <?php $this->load->view('front/user/sidebar_sticky');?>

      <div class="content-body">
        <div class="container">
          <div class="row">    



            <div class="col-sm-12">
              <?php
              $this->load->helper('form');
              $error = $this->session->flashdata('error');
              if($error) {
                ?>
                <div class="alert alert-danger alert-dismissable">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <?php echo $this->session->flashdata('error'); ?>                    
                </div>
              <?php } ?>
              <?php  
              $success = $this->session->flashdata('success');
              if($success)
              {
                ?>
                <div class="alert alert-success alert-dismissable">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <?php echo $this->session->flashdata('success'); ?>
                </div>
              <?php } ?>              
              <div class="row">
                <div class="col-md-12">
                  <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                </div>
              </div>
            </div>




            <?php $action = '';
            $attributes = array('id'=>'withdrawcoin','autocomplete'=>"off",'class'=>'deposit_form');
            echo form_open($action,$attributes); ?> 
            <div class="row">
              <div class="col-lg-12">
                <div class="deposit-main-box">
                  <div class="row align-items-center">
                    <?php $action = '';
                    $attributes = array('id'=>'withdrawcoin','autocomplete'=>"off",'class'=>'deposit_form');
                    echo form_open($action,$attributes); ?>    
                    <div class="col-lg-6" >
                      <div class="deposit-form bottom-border" style="height:485px">
                        <input type="hidden" name="fees" id="fees" value="<?php echo $fees;?>">
                        <input type="hidden" name="fees_type" id="fees_type" value="<?php echo $fees_type;?>"> 

                        <input type="hidden" name="sharecoin_fees_type" id="sharecoin_fees_type" value="<?php echo $sel_currency->sharecoin_fees_type;?>"> 

                        <input type="hidden" name="sharecoin_fees" id="sharecoin_fees" value="<?php echo $sel_currency->sharecoin_fees;?>">

                        <div class="form-group">
                          <select class="form-control custom-select" onchange="getcurrency(this.value,this);" name="ids" id="exampleFormControlSelect1">
                            <?php if(count($currency)>0){
                              $h =1;
                              foreach($currency as $cur){
                                ?>
                                <option <?php if($selcur_id==$cur->id) { echo 'selected';} ?> value="<?php echo $cur->id?>_<?php echo $cur->currency_name?>_<?php echo $wallet['Exchange AND Trading'][$cur->id]?>"><?php echo $cur->currency_symbol?></option>

                                <?php 
                                $h++;
                              } 
                            }?>
                          </select>
                        </div>
                        <p class="cryptoonly" <?php if($sel_currency->id == 5){?> style="display: none;" <?php } ?>>
                          <div class="row">
                            <div class="col-lg-6"><span>Sharecoin Fee :</span></div>    
                            <div class="col-lg-6"><span id="fees_s"></span> <span class="amount_receive_sym" style="float:right;"><?php echo $selcsym?></span></div>
                          </div>

                          <div class="row">
                            <div class="col-lg-6"><span><?php echo $this->lang->line('Fee');?>(Other Fee) :</span></div>    
                            <div class="col-lg-6"><span id="fees_p" class="sym"></span> <span class="amount_receive_sym" style="float:right;"><?php echo $selcsym?></span></div>
                          </div>    

                        </p>
                        <p class="cryptoonly" <?php if($sel_currency->id == 5){?> style="display: none;" <?php } ?>>
                          <div class="row">
                            <div class="col-lg-6"><span><?php echo $this->lang->line('Amount You will receive');?> :</span></div>    
                            <div class="col-lg-6"><span id="amount_receive" class="sym"></span> <span class="amount_receive_sym" style="float:right;"><?php echo $selcsym?></span></div>
                          </div>    
                        </p>

                        <div class="grey-box">
                         <?php $sitelan = $this->session->userdata('site_lang'); 
                         if($sitelan=='english') {?>
                          <h4>TRANSFER PROCESS</h4> 
                          <ul>
                            <li><span><i class="fas fa-check"></i>Enter only <span class="currency-txt-sym"><?php echo $sel_currency->currency_symbol?></span> addresses</li>
                            <li><span><i class="fas fa-check"></i> The transfer is irrevocable</span></li>
                            <?php if($sel_currency->crypto_type=='eth') {?>
                              <!-- <li class="ethereum_coin"><span><i class="fas fa-check"></i> The Gas cost will be charged to the sender address</span></li> -->
                            <?php } ?> 
                          </ul>
                        <?php } elseif($sitelan=='italian') {?>   
                          <h4>PROCESSO DI TRASFERIMENTO</h4> 
                          <ul>
                            <li><span><i class="fas fa-check"></i> Inserire solo indirizzi <span class="currency-txt-sym"><?php echo $sel_currency->currency_symbol?></span></li>
                            <li><span><i class="fas fa-check"></i> Il trasferimento è irrevocabile</span></li>
                            <?php if($sel_currency->crypto_type=='eth') {?>
                              <!-- <li class="ethereum_coin"><span><i class="fas fa-check"></i> Il costo Gas sarà addebitato al mittente per l'ammontare mostrato</span></li> -->  
                            <?php } ?>
                          </ul>
                        <?php }?>  
                      </div>

                      <div class="form-group text-left det_tag" <?php if($selcur_id!=6){echo 'style="display:none;"';} ?>>
                        <div class="d-flex align-items-center justify-content-between">
                          <label for="formGroupExampleInput"><?php echo $this->lang->line('Destination Tag');?></label>
                        </div>
                        <input type="text" class="form-control" name="destination_tag" id="destination_tag" placeholder="<?php echo $this->lang->line('Destination Tag');?>" value="">
                      </div> 
                      <span></span>

                    </div>




                  </div>
                  <div class="col-lg-6" >
                    <div class="deposit-address sakthi" style="height:473px">
                      <div class="form-group cryptoonly dropdown" style="<?php echo $style?>">
                        <!-- <label style="min-width:110px;" for="select"><?php echo $this->lang->line('Search Address Book Name')?></label>  -->
                        <!-- <span class="error-addressbook"></span> -->
                                 <!-- <select class="form-control search-addressbook" placeholder="<?php echo $this->lang->line('select from you address book');?>" onchange="selectaddressFunction(this)">
                                    <option value=""><?php echo $this->lang->line('Select')?></option>
                                    <?php if(count($address_book)>0){ 
                                      foreach($address_book as $adr){ ?>
                                      <option value="<?php echo $adr->address?>" data-coin="<?php echo $adr->coin?>"><?php echo $adr->filename?></option>
                                    <?php }}?>
                                   </select>
                                 -->

                                 <label for="exampleInputEmail1" style="margin-top:20px;"><?php echo $this->lang->line('Withdraw address');?></label>
                                 <input type="text" onkeyup="validaddressFunction(this)" class="form-control to_address" name="address" id="address" aria-describedby="emailHelp">
                                 <input type="hidden" name="valid_address" class="valid_address">
                                 
                                 <small id="emailHelp" class="form-text text-muted"><?php echo $this->lang->line('This address is only for');?> <span class="currency-adr-txt"><?php echo $sel_currency->currency_symbol?></span> <?php echo $this->lang->line('based');?> <span class="currency-txt"><?php echo $sel_currency->currency_name?>(<?php echo $sel_currency->currency_symbol?>).</span></small> 

                               </div>
                               <span></span><br>

                               <p class="amount-wrap">
                                <span><?php echo $this->lang->line('Available Balance');?></span>
                                <span class="totbal">
                                  <?php if($selcur_id==5) {
                                    $available_balance=number_format($currency_balance,2);
                                  } else {
                                    $available_balance=number_format($currency_balance,8);
                                  } echo $available_balance; ?>
                                </span> 
                              </p>

                              <label for="exampleInputEmail1" class="cryptoonly" <?php if($sel_currency->id == 5){?> style="display: none;" <?php } ?>><?php echo $this->lang->line('Withdraw Amount');?></label> 

                              <div class="input-group mb-3 cryptoonly" <?php if($sel_currency->id == 5){?> style="display: none;" <?php } ?>>
                                <input type="text" name="amount" id="amount" class="form-control" placeholder="<?php echo $this->lang->line('Amount');?>" onkeyup="calculate();" aria-describedby="basic-addon2">

                                <div class="input-group-append">
                                  <button style="color:#4699F2" class="btn btn-outline-secondary" onclick="max_balance('<?php echo $currency_balance?>','<?php echo $available_balance?>');" type="button">MAX</button> 
                                </div>
                                <!-- <label id="amount_receive_error"></label> -->
                                <div class="input-group-append">
                                  <button class="btn btn-outline-secondary sym amount_receive_sym" type="button"><?php echo $selcsym?></button> 
                                </div>

                              </div>
                              <span id="amount_receive_error"></span>     

                                        <!-- <div class="form-group text-left det_tag" <?php if($selcur_id!=6){echo 'style="display:none;"';} ?>>
                                            <div class="d-flex align-items-center justify-content-between">
                                                <label for="formGroupExampleInput"><?php echo $this->lang->line('Destination Tag');?></label>
                                            </div>
                                            <input type="text" class="form-control" name="destination_tag" id="destination_tag" placeholder="<?php echo $this->lang->line('Destination Tag');?>" value="">
                                        </div> 
                                        <span></span>  --> 
                                      </div>
                                    </div>
                                    <?php echo form_close(); ?>  
                                  </div>
                                  <!-- $bankwire->id          -->

                                  <?php if((trim($user->verify_level2_status)=='Completed')&& (count($bankwire)==1)) { ?>                
                                    <div class="col-md-12 fiat_withdraw" <?php if($sel_currency->id != 5){?> style="display: none;" <?php } ?>>

                                      <?php if(getSiteSettings('paypeaks_mobile')==1){ ?>
                                        <button type="button" class="auth_btn" style="padding: 5px 28px !important;" data-toggle="modal" data-target="#mobile_wallet"><?php echo $this->lang->line('Mobile Money');?></button>

                                      <?php } if(getSiteSettings('paypeaks_bank')==1){ ?>
                                        <button type="button" class="auth_btn" style="padding: 5px 28px !important;" data-toggle="modal" data-target="#bank_wire"><?php echo $this->lang->line('Bank Transfer');?></button>
                                      <?php }?>
                                    </div>  
                                  <?php } else {?> 
                                    <div class="form-group fiat_withdraw" <?php if($sel_currency->id != 5){?>style="display: none;" <?php } ?>> 

                                      <?php if((trim($user->verify_level2_status)=='Completed')&& (count($bankwire)==0)) {  ?>

                                        <?php echo $this->lang->line('Please Complete Bankwire');?><a style="color: #4699F2;" href="<?php echo base_url();?>update_bank_details"> <?php echo $this->lang->line('Click here');?></a>
                                      <?php } if((trim($user->verify_level2_status)!='Completed')&& (isset($bankwire) && count($bankwire)==1)) {  ?>

                                        <?php echo $this->lang->line('Please Complete KYC');?><a style="color: #4699F2;" href="<?php echo base_url();?>settings"> <?php echo $this->lang->line('Click here');?></a>
                                      <?php }?>            

                                    </div> 

                                  <?php }?>                

                                  <div class="col-sm-12 mb-5 cryptoonly" <?php if($sel_currency->id == 5){?> style="display: none;" <?php } ?>>
                                    <button class="withdraw-btn" type="submit" name="withdrawcoin" value="submit"><?php echo $this->lang->line('Withdraw');?></button>
                                  </div>              

                                </div>
                              </div>
                            </div>
                            <?php echo form_close(); ?>  

                          </div>     
                        </div>

                      </div>

                    </div>


                    <!--Mobile Wallet modal start-->
                    <div class="modal fade right" id="mobile_wallet" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                    aria-hidden="true"> 

                    <!-- Add class .modal-full-height and then add class .modal-right (or other classes from list above) to set a position to the modal -->
                    <div class="modal-dialog modal-full-height modal-right iks-popup" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h4 class="modal-title w-100" id="myModalLabel">Mobile Money</h4>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
                        </div>
                        <div class="modal-body">
                          <div class="col-sm-12">
                            <div class="row">
                              <div class="col-sm-12 deposit-address bank_wire">
                                <?php
                                $action = front_url()."withdraw/EUR";
                                $attributes = array('id'=>'withdraw_mobile','autocomplete'=>"off"); 
                                echo form_open($action,$attributes); 
                                ?>
                                <input type="hidden" name="currency" class="currency" value="<?php echo $sel_currency->id;?>" >
                                <div class="form-row">
                                  <div class="col-8 col-md-8">
                                    <div class="row">
                                      <div class="col-12 col-md-12">
                                        <label for="basic-url">Mobile number</label>
                                        <div class="mb-3">
                                          <input type="text" class="form-control input_anim" aria-label="Small" aria-describedby="inputGroup-sizing-sm" name="mobile_number">
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="col-8 col-md-8">
                                    <div class="row">
                                      <div class="col-12 col-md-12">
                                        <label for="basic-url">Name</label>
                                        <div class="mb-3">
                                          <input type="text" class="form-control input_anim" aria-label="Small" aria-describedby="inputGroup-sizing-sm" name="pay_name">
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="col-8 col-md-8">
                                    <div class="row">
                                      <div class="col-12 col-md-12">
                                        <label for="basic-url">Product</label>
                                        <div class="mb-3">
                                          <select name="productcode" class="form-control ">
                                            <?php
                              // $Products = Get_Paypeaks_Products('CREDIT','MOBILE MONEY');
                              // foreach($Products as $Lists){
                                            ?>
                                            <!-- <option value='<?php echo $Lists->product_code;?>'><?php echo $Lists->product_name;?></option> -->
                                            <?php
                              // }
                                            ?>
                                          </select>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="col-8 col-md-8">
                                    <div class="row">
                                      <div class="col-12 col-md-12">
                                        <label for="basic-url">Enter amount</label>
                                        <div class="mb-3">
                                          <input type="text" class="form-control input_anim" aria-label="Small" aria-describedby="inputGroup-sizing-sm" name="amount1" id="amount1" onkeyup="calculate1();">
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="col-8 col-md-8">
                                    <div class="row">
                                      <div class="col-12 col-md-12">
                                        <label for="basic-url">Narration</label>
                                        <div class="mb-3">
                                          <textarea class="form-control input_anim" name="narration" rows="3"></textarea>
                                        </div>
                                      </div>
                                    </div>
                                  </div>

                                  <div class="col-8 col-md-8">
                                    <div class="col-12 col-md-12">
                                      <label>Fee</label><label>:<span id="fees_p1">0</span> <span class="sym"><?php echo $selcsym?></span></label>
                                    </div>

                                  </div>
                                  <div class="col-8 col-md-8">
                                    <div class="col-12 col-md-12">
                                      <label>Amount You will receive</label><label>:<span id="amount_receive1">0</span> <span class="sym"><?php echo $selcsym?></span></label>
                                    </div>
                                  </div>

                                  <div class="col-12 col-md-12">
                                    <div class="row">
                                      <div class="col-12 col-md-12">
                                        <input type="hidden" name="payment_types" id="payment_types" value="mobile_wallet">
                                        <div class="profile-flex border-0 pt-4 pull-left">
                                          <div class="text-center">
                                            <button name="withdraw_mobile" class="auth_btn" type="submit"> Withdraw </button>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <?php echo form_close();?> </div>
                              </div>
                            </div>
                          </div>

                        </div>
                      </div>
                    </div>
                    <!--Mobile Wallet modal end-->

                    <!--Bank Transfer modal start-->
                    <div class="modal fade right" id="bank_wire" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                    aria-hidden="true"> 
                    <div class="modal-dialog modal-full-height modal-right iks-popup" role="document">
                      <div class="modal-content1">
                        <div class="modal-header">
                          <h4 class="modal-title w-100" id="myModalLabel">Bank Transfer</h4>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
                        </div>
                        <div class="modal-body">
                          <div class="col-sm-12">
                            <div class="row">
                              <div class="col-sm-12 deposit-address bank_wire">
                                <?php
                                $action = front_url()."withdraw/EUR";
                                $attributes = array('id'=>'withdraw_bank','autocomplete'=>"off"); 
                                echo form_open($action,$attributes); 

                                $country = get_countryname($bankwire->bank_country);
                                ?>
                                <h4 class="modal-title w-100 text-center" style="margin-top:10px"><?php echo $this->lang->line('Account Details');?></h4>
                                <div class="form-row text-center" style="margin-top:20px;">
                                  <div class="col-12">
                                    <div class="mb-3">
                                      <div class="form-row">
                                        <div class="col-lg-6">
                                          <label for="basic-url"><?php echo $this->lang->line('Bank Name');?></label>     
                                        </div>
                                        <div class="col-lg-6">
                                          <label for="basic-url"><?php echo $bankwire->bank_name?></label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="col-12">
                                    <div class="mb-3">
                                      <div class="form-row">
                                        <div class="col-lg-6">
                                          <label for="basic-url"><?php echo $this->lang->line('Account Number');?></label>     
                                        </div>
                                        <div class="col-lg-6">
                                          <label for="basic-url"><?php echo $bankwire->bank_account_number?></label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="col-12">
                                    <div class="mb-3">
                                      <div class="form-row">
                                        <div class="col-lg-6">
                                          <label for="basic-url"><?php echo $this->lang->line('Account Holder Name');?></label>     
                                        </div>
                                        <div class="col-lg-6">
                                          <label for="basic-url"><?php echo $bankwire->bank_account_name?></label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="col-12">
                                    <div class="mb-3">
                                      <div class="form-row">
                                        <div class="col-lg-6">
                                          <label for="basic-url"><?php echo $this->lang->line('Swift/BIC Code');?></label>
                                        </div>
                                        <div class="col-lg-6">
                                          <label for="basic-url"><?php echo $bankwire->bank_swift?></label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="col-12">
                                    <div class="mb-3">
                                      <div class="form-row">
                                        <div class="col-lg-6">
                                          <label for="basic-url"><?php echo $this->lang->line('Bank Country');?></label>
                                        </div>
                                        <div class="col-lg-6">
                                          <label for="basic-url"><?php echo $country?></label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>

                                <div class="form-row">
                                  <div class="col-8 col-md-8">
                                    <div class="row">
                                      <div class="col-12 col-md-12">
                                        <label for="basic-url"><?php echo $this->lang->line('Coin Name');?></label>
                                        <div class="mb-3">
                                          <input type="text" disabled class="form-control input_anim" aria-label="Small" aria-describedby="inputGroup-sizing-sm" name="coin_name" value="<?php echo $sel_currency->currency_symbol?>">
                                          <input type="hidden" name="currency" value="<?php echo $sel_currency->id?>">
                                        </div>
                                      </div>
                                      <div class="col-12 col-md-12">
                                        <label for="basic-url"><?php echo $this->lang->line('Enter Amount');?></label>
                                        <div class="mb-3">
                                          <input type="text" class="form-control input_anim fiat_amount" aria-label="Small" aria-describedby="inputGroup-sizing-sm" name="amount2" id="amount2" onkeyup="calculate2();" >
                                        </div>
                                      </div>

                                      <div class="col-12 col-md-12">
                                        <label>Fee</label><label>:<span id="fees_p2">0</span> <span class="sym"><?php echo $selcsym?></span></label>
                                      </div>
                                      <div class="col-12 col-md-12">
                                        <label>Amount You will receive</label><label>:<span id="amount_receive2">0</span> <span class="sym"><?php echo $selcsym?></span></label>
                                      </div>

                                    </div>
                                  </div>

                                  <div class="col-12 col-md-12">
                                    <div class="row">
                                      <div class="col-12 col-md-12">
                                        <input type="hidden" name="payment_types" id="payment_types" value="bank_wire">
                                        <input type="hidden" name="account_number" value="<?php echo $bankwire->bank_account_number?>">
                                        <input type="hidden" name="account_name" value="<?php echo $bankwire->bank_account_name?>">
                                        <input type="hidden" name="bank_name" value="<?php echo $bankwire->bank_name?>">
                                        <input type="hidden" name="bank_swift" value="<?php echo $bankwire->bank_swift?>">
                                        <input type="hidden" name="bank_country" value="<?php echo $bankwire->bank_country?>">
                                        <input type="hidden" name="bank_city" value="<?php echo $bankwire->bank_city?>">
                                        <input type="hidden" name="bank_address" value="<?php echo $bankwire->bank_address?>">
                                        <input type="hidden" name="bank_postalcode" value="<?php echo $bankwire->bank_postalcode?>">

                                        <div class="profile-flex border-0 pt-4">
                                          <div class="text-center">
                                            <button name="withdraw_bank" class="auth_btn" type="submit"> <?php echo $this->lang->line('Fiat Withdraw');?> </button>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>



                                <?php echo form_close();?> </div>
                              </div>
                            </div>
                          </div>

                        </div>
                      </div>
                    </div>
                    <!--Mobile Wallet modal end-->

                    <!--========================== Footer ============================-->
                    <?php
                    $this->load->view('front/common/footer');
                    ?>


                    <script type="text/javascript">

                     $.validator.addMethod("noSpace", function(value, element) { 
                      return value.indexOf(" ") < 0 && value != ""; 
                    }, "No space please and don't leave it empty");

                     $("#withdrawcoin").validate({
                      errorElement: 'span',
                      rules: {
                        address: {
                          required: true,
                          noSpace: true
                        },
                        amount: {
                          required: true,
                          number:true
                        },
                        destination_tag: {
                          required: true,
                          number: true
                        },
                        ids: {
                          required: true
                        },

                      },
                      messages: {
                        address: {
                          required: "<?php echo $this->lang->line('Please enter address');?>"
                        },
                        amount: {
                          required: "<?php echo $this->lang->line('Please enter amount');?>",
                          number: "<?php echo $this->lang->line('Invalid Amount');?>"
                        },
                        destination_tag: {
                          required: "<?php echo $this->lang->line('Please enter destination tag');?>",
                          number: '<?php echo $this->lang->line('Please enter numbers only');?>'
                        },
                        ids: {
                          required: "<?php echo $this->lang->line('Please select currency');?>"
                        },

                      },
                      errorPlacement: function(error, element) {
                        $(element).parent().next('span').html(error);
                      },

                      submitHandler: function(form) 
                      { 
                        var fees_type = $('#fees_type').val();
                        var fees = $('#fees').val();

                        var amount = $('#amount').val();

                        if(fees_type=='Percent'){
                          var fees_p = ((parseFloat(amount) * parseFloat(fees))/100);
                          var amount_receive = parseFloat(amount) - parseFloat(fees_p);
                        }
                        else{
                          var fees_p = fees;
                          var amount_receive = parseFloat(amount) - parseFloat(fees_p);
                        }
                        if(parseFloat(amount_receive)<=0){
                          $.growl.error({ message: 'Please enter valid amount' });
                          return false;
                        }
                        else if(parseFloat(amount)<=parseFloat(fees_p)){

                          $.growl.error({ message: 'Please enter valid amount' });
                          return false;
                        }
                        else{
                          form.submit();
                        }
                      }     
                    });

                     $('#withdraw_mobile').validate(
                     {
                      rules: {
                        mobile_number:{
                          required: true,
                          number: true
                        },
                        pay_name:{
                          required: true
                        },
                        amount1: {
                          required: true,
                          number: true,
                        },
                        narration: {
                          required: true
                        }
                      },
                      messages: {
                        mobile_number:{
                          required:'Please enter mobile number',
                          number:'Please enter valid number'
                        },
                        pay_name:{
                          required: 'Please enter name',
                        },
                        amount1: {
                          required: "Please enter amount",
                          number: "Only enter numbers as decimal or float"
                        },
                        narration: {
                          required: "Please enter Narration"          
                        }
                      },
                      invalidHandler: function(form, validator) {
                        if (!validator.numberOfInvalids())
                        {
                          return;
                        }
                        else
                        {
                          var error_element=validator.errorList[0].element;
                          error_element.focus();
                        }
                      },
                      highlight: function (element) {
                //$(element).parent().addClass('error')
              },
              unhighlight: function (element) {
                $(element).parent().removeClass('error')
              },
              submitHandler: function(form) 
              { 
                form.submit();
              }
            });

                     $('#withdraw_bank').validate(
                     {
                      rules: {
                        account_number:{
                          required: true,
                          number: true
                        },
                        pay_name:{
                          required: true
                        },
                        amount2: {
                          required: true,
                          number: true,
                        },
                        narration: {
                          required: true
                        }
                      },
                      messages: {
                        account_number:{
                          required:'Please enter Account number',
                          number:'Please enter valid number'
                        },
                        pay_name:{
                          required: 'Please enter name',
                        },
                        amount2: {
                          required: "Please enter amount",
                          number: "Only enter numbers as decimal or float"
                        },
                        narration: {
                          required: "Please enter Narration"          
                        }
                      },
                      invalidHandler: function(form, validator) {
                        if (!validator.numberOfInvalids())
                        {
                          return;
                        }
                        else
                        {
                          var error_element=validator.errorList[0].element;
                          error_element.focus();
                        }
                      },
                      highlight: function (element) {
                //$(element).parent().addClass('error')
              },
              unhighlight: function (element) {
                $(element).parent().removeClass('error')
              },
              submitHandler: function(form) 
              { 
                form.submit();
              }
            });

                     function getcurrency(ids,texts){
                      window.location = texts.options[texts.selectedIndex].text;
                    }

                    function getcurrency1(ids,texts)
                    { 
                      var txt = texts.options[texts.selectedIndex].text;
                      var namer = ids.split("_");
                      var id = namer[0];
                      var cname = namer[1];
                      var bal =  namer[2]; 
                      $(".amount_receive_sym").html(txt);
                      $(".syname").html(cname);

                      currency_txt = cname+'('+txt+')';
                      $('.currency-txt').html(currency_txt);
                      $('.currency-adr-txt').html(txt);
                      if((txt=='ETH')||(txt=='LIR')||(txt=='USDT')) {
                        $('.ethereum_coin').show();
                      } else {
                        $('.ethereum_coin').hide();
                      }
                      $('.currency-txt-sym').html(txt);


                      if(id==5)
                      {
                        var bals =  parseFloat(bal).toFixed(2);
                        $(".totbal").html(bals);
                        $(".cryptoonly").hide();
                        $(".det_tag").hide();
                        $(".fiat_withdraw").show();
                      }
                      else
                      {
                       var bals = parseFloat(bal).toFixed(8);
                       $(".totbal").html(bals);
                       $(".cryptoonly").show();
                       $(".fiat_withdraw").hide();
                       if(id==6){
                        $(".det_tag").show();
                      }
                      else{
                        $(".det_tag").hide();
                      }
                    }
                  }
                  function calculate(){

                    var fees_type = $('#fees_type').val();
                    var fees = $('#fees').val();
                    var sharecoin_fees = $('#sharecoin_fees').val();
                    var sharecoin_fees_type = $('#sharecoin_fees_type').val();
                    var amount = $('#amount').val();

                    if(fees_type=='Percent'){
                      var fees_p = ((parseFloat(amount) * parseFloat(fees))/100);
                      var amount_receive = parseFloat(amount) - parseFloat(fees_p);
                    }
                    else{
                      var fees_p = fees;
                      var amount_receive = parseFloat(amount) - parseFloat(fees_p);
                    }

    // Start sharecoin fees
    if(sharecoin_fees_type=='Percent'){
      var fees_s = ((parseFloat(amount) * parseFloat(sharecoin_fees))/100);
      var fee = (parseFloat(fees_p) + parseFloat(fees_s));
      var amount_receive = parseFloat(amount) - parseFloat(fee);
    }
    else{
      var fees_sum = (parseFloat(fees_p)+ parseFloat(sharecoin_fees));
      var fees_p =fees_p;
      var fees_s = sharecoin_fees;
      var amount_receive = parseFloat(amount) - parseFloat(fees_sum);
    }
    //End sharecoin fees

    fees_s = (/e/.test(fees_s)) ? fees_s.noExponents() : fees_s;
    fees_p = (/e/.test(fees_p)) ? fees_p.noExponents() : fees_p;
    amount_receive = (/e/.test(amount_receive)) ? amount_receive.noExponents() : amount_receive;

    $('#fees_p').html(fees_p);
    $('#fees_s').html(fees_s);
    
    $('#amount_receive').html(amount_receive); 
  }

  function calculate1(){

    var fees_type = $('#fees_type').val();
    var fees = $('#fees').val();

    var amount = $('#amount1').val();

    if(fees_type=='Percent'){
      var fees_p = ((parseFloat(amount) * parseFloat(fees))/100);
      var amount_receive = parseFloat(amount) - parseFloat(fees_p);
    }
    else{
      var fees_p = fees;
      var amount_receive = parseFloat(amount) - parseFloat(fees_p);
    }
    $('#fees_p1').html(fees_p);
    if(amount_receive<=0){
      $('#amount_receive1').html('0');
      $('#amount_receive_error1').html('Please enter valid amount');
    }
    else{
      $('#amount_receive_error1').html('');
      $('#amount_receive1').html(amount_receive);
    }
  }


  function calculate2(){

    var fees_type = $('#fees_type').val();
    var fees = $('#fees').val();

    var amount = $('#amount2').val();

    // console.log(fees)
    if(fees_type=='Percent'){
      var fees_p = ((parseFloat(amount) * parseFloat(fees))/100);
      var amount_receive = parseFloat(amount) - parseFloat(fees_p); 
    }
    else{
      var fees_p = fees;
      var amount_receive = parseFloat(amount) - parseFloat(fees_p);
    }
    $('#fees_p2').html(fees_p);  
    if(amount_receive<=0){
      $('#amount_receive2').html('0');
      $('#amount_receive_error2').html('Please enter valid amount');
    }
    else{
      $('#amount_receive_error2').html('');
      $('#amount_receive2').html(amount_receive);
    }
  }

  function max_balance(avlbal, avlbal1) {

    var fees_type = $('#fees_type').val();
    var fees = $('#fees').val();
    var sharecoin_fees = $('#sharecoin_fees').val();
    var sharecoin_fees_type = $('#sharecoin_fees_type').val();
    var amount = avlbal;
    $('#amount').val(avlbal1);
    if(fees_type=='Percent'){

      var fees_p = ((parseFloat(amount) * parseFloat(fees))/100);
      var amount_receive = parseFloat(amount) - parseFloat(fees_p);
      var fees_p = fees_p.toFixed(8);
      var amount_receive = amount_receive.toFixed(8);
    }
    else{
      var fees_p = fees;
      var amount_receive = parseFloat(amount) - parseFloat(fees_p);
    }

    // Start Sharecoin Fee
    if(sharecoin_fees_type=='Percent'){

      var fees_s = ((parseFloat(amount) * parseFloat(sharecoin_fees))/100);
      var fee = (parseFloat(fees_p) + parseFloat(fees_s));

      var amount_receive = parseFloat(amount) - parseFloat(fee);
      var fees_sharecoin = fees_s.toFixed(8);  
      var amount_receive = amount_receive.toFixed(8);
    }
    else{
      var fees_sum = (parseFloat(fees_p)+ parseFloat(sharecoin_fees));
      var fees_p =fees_p;
      var fees_s = sharecoin_fees;
      var amount_receive = parseFloat(amount) - parseFloat(fees_sum);

    }
//End Sharecoin Fee

$('#fees_p').html(fees_p);
$('#fees_s').html(fees_s);
$('#amount_receive').html(amount_receive);
}

var front_url='<?php echo front_url(); ?>';    
function validaddressFunction(e) {
  address = $(e).val();
  checkAddress(address);
}

function checkAddress(address) {
  $.ajax({
    url: front_url+"validaddress", 
    type: "POST",
    data:{address:address},     
    success: function(data) {
      if(data==0) {
        $('.valid_address').val(0);
      } else {
        $('.valid_address').val(data);
      }  
    }
  });
}

function selectaddressFunction(e) {
  address = $(e).val();
  coin = $(e).find('option:selected').attr('data-coin');
  csym = '<?php echo $sel_currency->currency_symbol?>';

  checkAddress(address);
  $('#address').val(address);
}
Number.prototype.noExponents= function(){
  var data= String(this).split(/[eE]/);    
  if(data.length== 1) return data[0]; 

  var  z= '', sign= this<0? '-':'',
  str= data[0].replace('.', ''),
  mag= Number(data[1])+ 1;

  if(mag<0){
    z= sign + '0.';
    while(mag++) z += '0';
    return z + str.replace(/^\-/,'');
  }
  mag -= str.length;  
  while(mag--) z += '0';
  return str + z;
}

</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.1/js/select2.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {

    $(".search-addressbook").select2({
      width  : 400,
      height : 300,
      //theme  : 'light',
      onchange : function(val){}
    });
  });
</script>