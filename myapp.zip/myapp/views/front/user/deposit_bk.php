<?php $sitelan = $this->session->userdata('site_lang'); 
       $this->load->view('front/common/inner_header'); 
      $user_id=$this->session->userdata('user_id');

      $name = $sitelan."_name";
      $heading = $sitelan."_heading";
      $content = $sitelan."_content";
?>
    <div class="inner-body">
        <div class="container">
            <div class="inner-card-box">
                <div class="d-flex justify-content-between flex-wrap align-items-center">
                    <div class="inner-card-head">
                        <span>Deposit</span>
                    </div>

                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="deposit-form">
                            <div class="row align-items-center">
                                <div class="col-lg-6">
                                    <div class="add-copy-sec">
                                        <form>
                                            <label>Send to your secure  <?php echo $dig_currency->currency_symbol; ?> deposit address</label>
                                            <div class="input-group">
                                                <input type="text" readonly class="form-control" aria-label="Recipient's username" aria-describedby="basic-addon2" name="crypto_address" id="crypto_address" value="<?php echo $crypto_address; ?>">

                                                <div class="input-group-append">
                                                    <span class="input-group-text" id="basic-addon2" onClick="copy_function()">Copy</span>
                                                </div>
                                            </div>
                                        </form>

                                    </div>
                                </div>
                                <div class="col-lg-2 text-center">
                                    <span class="or-divide">or</span>
                                </div>
                                <div class="col-lg-4">
                                    <div class="qr-sec">
                                        <p>Scan this QR Code</p>
                                           <img src="https://chart.googleapis.com/chart?cht=qr&chs=280x280&chl=<?php echo $crypto_address; ?>&choe=UTF-8&chld=L" alt="" id="crypto_img" class="img-fluid">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>


        </div>
    </div>
<?php $this->load->view('front/common/inner_footer'); ?>
<?php $this->load->view('front/common/scripts'); ?>

   <script type="text/javascript">
              function copy_function() 
    {
        var copyText = document.getElementById("crypto_address");
        copyText.select();
        document.execCommand("COPY");
        $('.copy_but').html("COPIED");
    }
        </script>


</body>

</html>