
<style type="text/css">
  .dashboard_img{
    height:40px;
    width:40px;
  }
  .profile-pic{
      height:100px;
    width:100px;
  }
  .profile-box {
margin-top: 111px;
border-top: 1px solid #dedbdb;
padding-top: 10px;
}
</style>
<?php $sitelan = $this->session->userdata('site_lang'); 
       $this->load->view('front/common/inner_header'); 
      $user_id=$this->session->userdata('user_id');

      $name = $sitelan."_name";
      $heading = $sitelan."_heading";
      $content = $sitelan."_content";

       $usermail = getUserEmail($users->id);
       $username = UserName($users->id);
      if($users->verify_level2_status=="" || $users->verify_level2_status=="Pending" || $users->verify_level2_status=="Rejected")
       {
        $kyc_status = $this->lang->line('Not Verified');
        $sym = 'times-circle';
        $sta = 'text-red';
       }
       else
       {
         $kyc_status = $this->lang->line('Verified');
         $sym = 'check-circle';
         $sta = 'text-green';
       }
?>

 
    <div class="inner-body">
        <div class="container-fluid">
            <div class="inner-card-box">
                <div class="inner-card-head">
                    <span class="mb-2">Dashboard</span>
                </div>
                <div class="row">
                  <div class="col-lg-3"></div>
                  <div class="col-lg-9">
                    <div class="row dash-wallet">
                            <?php
                            if(isset($dig_currency) && !empty($dig_currency))
                            {
                                foreach($dig_currency as $digital)
                                {
                                  $userbalance = getBalance($user_id,$digital->id);
                                    ?>
                            <div class="col-xl-3 col-md-6">
                                <div class="card card-stats">
                                    <!-- Card body -->
                                    <div class="card-body">
                                        <div class="row align-items-center">
                                            <div class="col">
                                                <h5 class="card-title text-uppercase text-muted mb-0">Total <?php echo strtoupper($digital->currency_symbol);?></h5>
                                                <span class="h6 mt-2 font-weight-bold mb-0 d-block"><?php echo number_format($userbalance,8); ?></span>
                                            </div>
                                            <div class="col-auto">
                                                <div>
                                                    <img src="<?php echo $digital->image;?>" alt="" class="img-fluid dashboard_img" accept="*">
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <?php 
                                }
                            }
                            ?>
                           
                        </div>
                  </div>
                </div>
                <div class="row">
                    <div class="col-lg-3">
                        <div class="profile-box">
                            <div class="card" style="position: relative; top:-29pxpx;">
                                <div class="card-body text-center">
                                    <p class="pfle-active">
                                        Active
                                    </p>
                                    <div> 
                                       <?php $img =  ($users->profile_picture)?$users->profile_picture:base_url().'assets/front/img/no_img.jpg';?>

                                      <img src="<?=$img?>" class="img-lg rounded-circle profile-pic mb-2" alt="profile image">
                                        <h4><?php echo $username; ?></h4>
                                        <p class="text-muted mb-1 mt-2"><?php echo ($usermail)?$usermail:'';?> <span class="clr-green"><i class="fas fa-check-circle"></i></span> </p>
                                        <p class="text-muted mb-1 mt-2"><?php echo ($users->ixtoken_phone)?$users->ixtoken_phone:'----------';?>  <!-- <span class="clr-red"><i class="fas fa-times-circle"></i></span> --></p>
                                    </div>
                                    <!-- <div class="d-flex justify-content-around">
                                        <a class="btn btn-info btn-sm mt-1 mb-1" href="<?php  echo base_url(); ?>settings">Edit Profile </a>
                                    </div> -->

                                    <div class="d-flex justify-content-around align-items-center">
                                        <span class="clr-grey"> <?php echo $this->lang->line('KYC Status')?> :</span>
                                        <a class="btn btn-success btn-sm mt-3 mb-4" href="<?php  echo base_url(); ?>settings"><?=$kyc_status?></a>
                                        </div>



                                    

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="row">
                    <div class="col-lg-12">
                        <ul class="nav nav-pills justify-content mt-4" id="pills-tab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">Profile</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">KYC</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">Change Password</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="pills-contact1-tab" data-toggle="pill" href="#pills-contact1" role="tab" aria-controls="pills-contact1" aria-selected="false">2FA</a>
                            </li>
                        </ul>
                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                              <div class="inner-box-body">
                                 <div class="row">

                                        <div class="col-lg-12">
                                <?php 
                                    $attributes=array('id'=>'verification_form',"autocomplete"=>"off"); 
                                      $action = front_url() . 'profile-edit';
                                    echo form_open_multipart($action,$attributes); 
                                ?>     

                                  <div class="form-row">
                                  <!-- <div class="col-lg-3">
                                      <div class="image-update mb-3">
                                         
                                              <div class="pfle-image">
                                                <?php $img =  ($users->profile_picture)?$users->profile_picture:base_url().'assets/front/img/no_img.jpg';?>
                                                  <img src="<?=$img?>" alt="" class="img-fluid">
                                                 <input type='file' name="profile_photo" id="imageUpload" accept=".png, .jpg, .jpeg, .svg" />
                                                 <label for="imageUpload"></label>
                                                  <div class="text-center mt-3">
                                                      <a href="javascript:void(0);" class="form-btn" id="profile-upload-btn"> Change Profile</a>
                                                  </div>
                                              </div>
                                        
                                      </div>
                                   </div>  -->              
                                   <div class="col-lg-9">
                                     <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label for="firstname">First Name</label>
                                             <input type="text" class="form-control" placeholder="<?php echo $this->lang->line('First Name')?>" id="firstname" name="firstname" value="<?php echo $users->ixtoken_fname; ?>">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="lastname">Last Name</label>
                                                <input type="text" class="form-control" placeholder="<?php echo $this->lang->line('LastName')?>" id="lastname" name="lastname" value="<?php echo $users->ixtoken_lname; ?>">                                           
                                             </div>
                                        </div>
                                    <?php $usermail = getUserEmail($users->id);?>

                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label for="email">Email Id</label>
                                                 <input type="text" class="form-control" placeholder="sample@mail.com" disabled id="email" name="email" value="<?php echo ($usermail)?$usermail:'';?>">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="phone">Mobile Number</label>
                                              <input type="text" id="phone" name="phone" 
                                        value="<?php echo ($users->ixtoken_phone)?$users->ixtoken_phone:'';?>" class="form-control" placeholder="<?php echo $this->lang->line('Enter Phone Number')?>">
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label for="inputEmail4">Address1</label>
                                                 <input type="text" id="address" name="address" value="<?php echo ($users->street_address)?$users->street_address:'';?>" class="form-control" placeholder="<?php echo $this->lang->line('Enter Address')?>">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="inputPassword4">Address 2</label>
                                                  <input type="text" id="address1" name="address1" value="<?php echo ($users->street_address_2)?$users->street_address_2:'';?>" class="form-control" placeholder="<?php echo $this->lang->line('Enter Address')?>">
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label for="register_country">Country</label>
                                               <select name="register_country" id="register_country" class="custom-select select_inner">
                                        <?php if($countries) {
                                            foreach($countries as $co) {
                                              ?>
                                              <option <?php if($co->id==$users->country) { echo "selected"; } ?>
                                              value ="<?php echo $co->id; ?>"><?php echo $co->country_name; ?></option>
                                              <?php
                                            }
                                          } ?>
                                    </select>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="state">State</label>
                                               <input type="text" id="state" name="state" 
                                        value="<?php echo ($users->state)?$users->state:'';?>" class="form-control" placeholder="<?php echo $this->lang->line('Enter State')?>">
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label for="inputEmail4">City</label>
                                                 <input type="text" id="city" name="city" 
                                        value="<?php echo ($users->city)?$users->city:'';?>" class="form-control" placeholder="<?php echo $this->lang->line('Enter City')?>">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="inputPassword4">Zip Code</label>
                                                  <input type="text" id="postal_code" name="postal_code" 
                                        value="<?php echo ($users->postal_code)?$users->postal_code:'';?>" class="form-control" placeholder="<?php echo $this->lang->line('Enter Postal')?>">
                                            </div>
                                        </div>
                                        <div class="text-center mt-3">
                                          <button type="submit" class="form-btn"><?php echo $this->lang->line('Submit')?></button>
                                        </div>
                                      </div>
                                    </div>
                                  <?php echo form_close();?>                            
                                </div>
                              </div>
                             </div>
                            </div>
                            <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                                <div class="inner-box-body">
                                    <div class="inner-box-head">
                                        <h4>KYC</h4>
                                    </div>
                                    <p class="clr-red mt-2">Upload Id Proof (or) Passport Front and Back Sides</p>
                                      <?php
                      $status1 = $users->photo_1_status;
                      $status2 = $users->photo_2_status;
                      $status3 = $users->photo_3_status;
                      $status4 = $users->photo_4_status;
                      $status5 = $users->photo_5_status;

                      $status_addr = ($status1==3)?'circle':'close';
                      $status_id = ($status2==3)?'circle':'close';
                      $status_photo = ($status3==3)?'circle':'close';
                      $status_id_back = ($status4==3)?'circle':'close';
                       $status_bank = ($status5==3)?'circle':'close';
                      if($status1==0)
                      {
                        $sts1 = $this->lang->line('Not Uploaded');
                        $cls1 = 'verified_notup';
                        $clss1 ='text-info';
                        $sym1 = '';
                      }                       
                      elseif($status1==1)
                      {
                        $sts1= $this->lang->line('Pending');
                        $cls1 = 'verified_pend';
                        $clss1 ='text-primary';
                        $sym1 = 'fas fa-info-circle';
                      }                        
                      elseif($status1==2)
                      {
                        $sts1 = $this->lang->line('Rejected');
                        $cls1 = 'verified_not';
                        $clss1 ='text-red';
                        $sym1 = 'far fa-times-circle';
                      }                        
                      else
                      {                        
                        $sts1 = $this->lang->line('Verified');
                        $cls1 = 'verified';
                        $clss1 ='text-green';
                        $sym1 = 'far fa-check-circle';
                      }

                      if($status2==0)
                      {
                        $sts2 = $this->lang->line('Not Uploaded');
                        $cls2 = 'verified_notup';
                        $clss2 ='text-info';
                        $sym2 = '';
                      }                       
                      elseif($status2==1)
                      {
                        $sts2= $this->lang->line('Pending');
                        $cls2 = 'verified_pend';
                        $clss2 ='text-primary';
                        $sym2 = 'fas fa-info-circle';
                      }                        
                      elseif($status2==2)
                      {
                        $sts2 = $this->lang->line('Rejected');
                        $cls2 = 'verified_not';
                        $clss2 ='text-red';
                        $sym2 = 'far fa-times-circle';
                      }                        
                      else
                      {                        
                        $sts2 = $this->lang->line('Verified');
                        $cls2 = 'verified';
                        $clss2 ='text-green';
                        $sym2 = 'far fa-check-circle';
                      }

                      if($status3==0)
                      {
                        $sts3 = $this->lang->line('Not Uploaded');
                        $cls3 = 'verified_notup';
                        $clss3 ='text-info';
                        $sym3 = '';
                      }                       
                      elseif($status3==1)
                      {
                        $sts3= $this->lang->line('Pending');
                        $cls3 = 'verified_pend';
                        $clss3 ='text-primary';
                        $sym3 = 'fas fa-info-circle';
                      }                        
                      elseif($status3==2)
                      {
                        $sts3 = $this->lang->line('Rejected');
                        $cls3 = 'verified_not';
                        $clss3 ='text-red';
                        $sym3 = 'far fa-times-circle';
                      }                        
                      else
                      {                        
                        $sts3 = $this->lang->line('Verified');
                        $cls3 = 'verified';
                        $clss3 ='text-green';
                        $sym3 = 'far fa-check-circle';
                      }

                         if($status4==0)
                      {
                        $sts4 = $this->lang->line('Not Uploaded');
                        $cls4 = 'verified_notup';
                        $clss4 ='text-info';
                        $sym4 = '';
                      }                       
                      elseif($status4==1)
                      {
                        $sts4= $this->lang->line('Pending');
                        $cls4 = 'verified_pend';
                        $clss4 ='text-primary';
                        $sym4 = 'fas fa-info-circle';
                      }                        
                      elseif($status4==2)
                      {
                        $sts4 = $this->lang->line('Rejected');
                        $cls4 = 'verified_not';
                        $clss4 ='text-red';
                        $sym4 = 'far fa-times-circle';
                      }                        
                      else
                      {                        
                        $sts4 = $this->lang->line('Verified');
                        $cls4 = 'verified';
                        $clss4 ='text-green';
                        $sym4 = 'far fa-check-circle';
                      }

                      if($status5==0)
                      {
                        $sts5 = $this->lang->line('Not Uploaded');
                        $cls5 = 'verified_notup';
                        $clss5 ='text-info';
                        $sym5 = '';
                      }                       
                      elseif($status5==1)
                      {
                        $sts5= $this->lang->line('Pending');
                        $cls5 = 'verified_pend';
                        $clss5 ='text-primary';
                        $sym5 = 'fas fa-info-circle';
                      }                        
                      elseif($status5==2)
                      {
                        $sts5 = $this->lang->line('Rejected');
                        $cls5 = 'verified_not';
                        $clss5 ='text-red';
                        $sym5 = 'far fa-times-circle';
                      }                        
                      else
                      {                        
                        $sts5 = $this->lang->line('Verified');
                        $cls5 = 'verified';
                        $clss5 ='text-green';
                        $sym5 = 'far fa-check-circle';
                      }
            ?>
                                    <div class="upload-kyc">
                                        <div class="row">
                                            <div class="col-lg-4">
                                                <div class="upload-form">
                                                    <p class="file-name">Id Proof(Front Side)<span class="<?=$clss2?>"><?=$sts2?> <i class="<?=$sym2?>"></i></span></p>
                                                    <?php
                                                    $attributes=array('id'=>'verification_forms2'); 
                                                    $action = front_url() . 'id_verification';
                                                    echo form_open_multipart($action,$attributes);
                                                    if($users->photo_2_status==3 && $users->photo_id_2!=""){ 
                                                    $style = "display:none";

                                                    }
                                                    else
                                                    {
                                                    $style = "display:block";
                                                    }
                                                    if(($users->photo_2_status==1 && $users->photo_id_2 !='') || ($users->photo_2_status==3 && $users->photo_id_2 !='')){
                                                    $img = $users->photo_id_2;
                                                    $text = "";
                                                    }
                                                    else
                                                    {
                                                    $img = images_url().'up-img.png';
                                                    $text = "img";
                                                    }
                                                    ?>
                                                    <div class="input-group mb-3">
                                                            <div class="custom-file" style="<?php echo $style;?>">
                                                   <input type="file" class="custom-file-input" name="photo_id_2" id="imageUpload3">
                                                   <input type="hidden" id="id_proof" value="<?php echo $users->photo_id_2;?>">
                                                                <label class="custom-file-label" for="imageUpload3">Choose file</label>
                                                            </div>
                                                        </div>
                                                        <div class="upload-img">
                                                            <img id="blah" src="<?php echo $img;?>" alt="" class="img-fluid">
                                                        </div>
                                                    <?php echo form_close();?>
                                                    <span class="photo_error">
                                                    <small style="padding-left: 85px;" class="error_msg photo_id_2_error error"></small>
                                                    </span>
                                                  <div style="<?php echo $style;?>">
                                                     <button type="submit" id="id_submit" class="form-btn"><?php echo $this->lang->line('Save')?></button>
                                                    
                                                    <button id="id_cancel" type="submit" class="form-btn"><?php echo $this->lang->line('Cancel')?></button>
                                                  </div>
                                                   
                                                    
                                                    
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="upload-form">
                                                    <p class="file-name">Id Proof(Back Side)<span class="<?=$clss4?>"><?=$sts4?> <i class="<?=$sym4?>"></i></span></p>
                                                     <?php
                                                    $attributes=array('id'=>'verification_forms4'); 
                                                    $action = front_url() . 'id_verification_back';
                                                    echo form_open_multipart($action,$attributes);
                                                    if($users->photo_4_status==3 && $users->photo_id_4!=""){ 
                                                    $style = "display:none";

                                                    }
                                                    else
                                                    {
                                                    $style = "display:block";
                                                    }
                                                    if(($users->photo_4_status==1 && $users->photo_id_4 !='') || ($users->photo_4_status==3 && $users->photo_id_4 !='')){
                                                    $img1 = $users->photo_id_4;
                                                    $text = "";
                                                    }
                                                    else
                                                    {
                                                    $img1 = images_url().'up-img.png';
                                                    $text = "img";
                                                    }
                                                    ?>
                                                        <div class="input-group mb-3">
                                                            <div class="custom-file" style="<?php echo $style;?>">
                                                                <input type="file" class="custom-file-input" id="imageUpload4" name="photo_id_4">
                                                                 <input type="hidden" id="id_proof_1" value="<?php echo $users->photo_id_2;?>">
                                                                <label class="custom-file-label" for="imageUpload4">Choose file</label>
                                                            </div>
                                                        </div>
                                                        <div class="upload-img">
                                                           <img id="blah1" src="<?php echo $img1;?>" alt="" class="img-fluid">
                                                        </div>
                                                     <?php echo form_close();?>
                                                      <span class="photo_error1">
                                                    <small style="padding-left: 85px;" class="error_msg photo_id_4_error error"></small>
                                                    </span>
                                                  <div style="<?php echo $style;?>">
                                                      <button type="submit" id="id_1_submit" class="form-btn"><?php echo $this->lang->line('Save')?></button>
                                                    
                                                    <button id="id_1_cancel" type="submit" class="form-btn"><?php echo $this->lang->line('Cancel')?></button>

                                                  </div>
                                                    
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="upload-form">
                                                    <p class="file-name">Selfie Photo <span class="<?=$clss3?>"><?=$sts3?> <i class="<?=$sym3?>"></i></span></p>
                                                     <?php
                                                          $attributes=array('id'=>'verification_forms3'); 
                                                          $action = front_url() . 'photo_verification';
                                                          echo form_open_multipart($action,$attributes);
                                                          if($users->photo_3_status==3 && $users->photo_id_3!="")
                                                          { 
                                                            $style = "display:none";
                                                            
                                                          }
                                                          else
                                                          {
                                                            $style = "display:block";
                                                          }
                                                          if(($users->photo_3_status==1 && $users->photo_id_3 !='') || ($users->photo_3_status==3 && $users->photo_id_3 !='')){
                                                            $img = $users->photo_id_3;
                                                            $text = "";
                                                          }
                                                          else
                                                          {
                                                            $img = images_url().'up-img.png';
                                                            $text = "img";
                                                          }
                                                    ?>
                                                        <div class="input-group mb-3">
                                                            <div class="custom-file" style="<?php echo $style;?>">
                                                                <input type="file" class="custom-file-input" id="inputGroupFile01" name="photo_id_3" accept=".png, .jpg, .jpeg, .svg">
                                                                <input type="hidden" id="photo_proof" value="<?php echo $users->photo_id_3;?>">

                                                                <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                                                            </div>
                                                        </div>
                                                        <div class="upload-img">
                                                            <img id="blah2" src="<?php echo $img;?>" alt="" class="img-fluid">
                                                        </div>
                                                       <?php echo form_close();?>
                                                      <span class="photo_error">
                                                      <small style="padding-left: 85px;" class="error_msg photo_id_3_error error"></small>
                                                    </span>
                                                       <div style="<?php echo $style;?>">
                                                      <button type="submit" id="photo_submit" class="form-btn"><?php echo $this->lang->line('Save')?></button>
                                                    
                                                    <button id="photo_cancel" type="submit" class="form-btn"><?php echo $this->lang->line('Cancel')?></button>

                                                  </div>
                                                </p>
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="upload-form">
                                                    <p class="file-name">Address Proff (Optional)<span class="<?=$clss1?>"><?=$sts1?> <i class="<?=$sym1?>"></i></span></p>
                                                       <?php
                                                          $attributes=array('id'=>'verification_forms1'); 
                                                          $action = front_url() . 'address_verification';
                                                          echo form_open_multipart($action,$attributes);
                                                          if($users->photo_1_status==3 && $users->photo_id_1!=""){ 
                                                            $style = "display:none";
                                                            
                                                          }
                                                          else
                                                          {
                                                            $style = "display:block";
                                                          }
                                                          if(($users->photo_1_status==1 && $users->photo_id_1 !='') || ($users->photo_1_status==3 && $users->photo_id_1 !='')){
                                                            $img = $users->photo_id_1;
                                                            $text = "";
                                                          }
                                                          else
                                                          {
                                                            $img = images_url().'up-img.png';
                                                            $text = "img";
                                                          }
                                                    ?>
                                                        <div class="input-group mb-3">
                                                            <div class="custom-file" style="<?php echo $style;?>">
                                                                <input type='file' id="imageUpload1" name="photo_id_1" accept=".png, .jpg, .jpeg, .svg" />
                                                                <input type="hidden" id="addr_proof" value="<?php echo $users->photo_id_1;?>">

                                                                <label class="custom-file-label" for="imageUpload1">Choose file</label>
                                                            </div>
                                                        </div>
                                                        <div class="upload-img">
                                                            <img id="blah3" src="<?php echo $img;?>" alt="" class="img-fluid">
                                                        </div>
                                                    <?php echo form_close();?>
                                                    <span class="photo_error">
                                                      <small style="padding-left: 85px;" class="error_msg photo_id_1_error error"></small>
                                                  </span>
                                                   <div style="<?php echo $style;?>">
                                                      <button type="submit" id="addr_submit" class="form-btn"><?php echo $this->lang->line('Save')?></button>
                                                    
                                                    <button id="addr_cancel" type="submit" class="form-btn"><?php echo $this->lang->line('Cancel')?></button>

                                                  </div>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="upload-form">
                                                    <p class="file-name">Bank Statement (Optional)<span class="<?=$clss5?>"><?=$sts5?> <i class="<?=$sym5?>"></i></span></p>
                                                      <?php
                                                            $attributes=array('id'=>'verification_forms5'); 
                                                            $action = front_url() . 'bank_verification';
                                                            echo form_open_multipart($action,$attributes);
                                                            if($users->photo_5_status==3 && $users->photo_id_5!=""){ 
                                                              $style = "display:none";
                                                              
                                                            }
                                                            else
                                                            {
                                                              $style = "display:block";
                                                            }
                                                            if(($users->photo_5_status==1 && $users->photo_id_5 !='') || ($users->photo_5_status==3 && $users->photo_id_5 !='')){
                                                              $img = $users->photo_id_5;
                                                              $text = "";
                                                            }
                                                            else
                                                            {
                                                              $img = images_url().'up-img.png';
                                                              $text = "img";
                                                            }
                                                      ?>
                                                        <div class="input-group mb-3">
                                                            <div class="custom-file" style="<?php echo $style;?>">
                                                                <input type="file"  name="photo_id_5"  class="custom-file-input" id="imageUpload5">
                                                                <input type="hidden" id="bank_proof" value="<?php echo $users->photo_id_5;?>">

                                                                <label class="custom-file-label" for="imageUpload5">Choose file</label>
                                                            </div>
                                                        </div>
                                                        <div class="upload-img">
                                                            <img  id="imagePreview5" src="<?php echo $img;?>" alt="" class="img-fluid">
                                                        </div>
                                                      <?php echo form_close();?>

                                                        <span class="bank_error">
                                                            <small style="padding-left: 85px;" class="error_msg photo_id_5_error error"></small>
                                                        </span>

                                                        <div style="<?php echo $style;?>">
                                                      <button type="submit" id="bank_submit" class="form-btn"><?php echo $this->lang->line('Save')?></button>
                                                    
                                                    <button id="bank_cancel" type="submit" class="form-btn"><?php echo $this->lang->line('Cancel')?></button>

                                                  </div>
                                                 </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="inner-box-head mt-5">
                                        <h4>Bank Wire Details (Optional)</h4>
                                    </div>
                                    
                                       <?php 
                                    $attributes=array('id'=>'bankwire',"autocomplete"=>"off","class"=>"mt-4"); 
                                      $action = front_url() . 'bank_details';
                                    echo form_open_multipart($action,$attributes); 
                                ?>   
                                        <div class="form-row">
                                           <div class="form-group col-md-6">
                                                <label for="inputEmail4">Currency</label>
                                                <!-- <?php if($user_bank->currency){ ?>
                                                <input type="text" class="form-control" disabled value="<?php echo $user_bank->currency;?>">
                                              <?php }else{ ?>
                                                  <input type="text" class="form-control" id="currency" name="currency">
                                              <?php } ?> -->
                                              <select class="form-control" id="currency" name ="currency">
                                                <?php if(count($currencies)>0) { foreach($currencies as $cur) { ?>

                                                  <option value="<?php echo $cur->id;?>" <?php if($user_bank->currency==$cur->id) { echo "selected"; } ?>><?php echo $cur->currency_symbol;?>
                                                    
                                                  </option>
                                                <?php } } ?>
                                              </select>
                                            </div>

                                            <div class="form-group col-md-6">
                                                <label for="inputEmail4">Bank Name</label>
                                               <?php if($user_bank->bank_name){ ?>
                                                <input type="text" class="form-control" disabled value="<?php echo $user_bank->bank_name;?>">
                                                 <?php }else{ ?>
                                                   <input type="text" class="form-control" id="bank_name" name="bank_name">
                                                    <?php } ?>
                                            </div>
                                           
                                        </div>
                                        <div class="form-row">
                                           <div class="form-group col-md-6">
                                                <label for="inputEmail4">Account Number</label>
                                                <?php if($user_bank->bank_account_number){ ?>
                                                <input type="text" class="form-control" disabled value="<?php echo $user_bank->bank_account_number;?>">
                                                <?php }else{ ?>
                                                  <input type="text" class="form-control" id="bank_account_number" name="bank_account_number">
                                                <?php } ?>
                                            </div>

                                            <div class="form-group col-md-6">
                                                <label for="inputEmail4">Account Holder Name</label>
                                                <?php if($user_bank->bank_account_name){ ?>
                                                <input type="text" class="form-control" disabled value="<?php echo $user_bank->bank_account_name;?>">
                                                <?php }else{ ?>
                                                <input type="text" class="form-control" id="bank_account_name" name="bank_account_name">
                                                <?php } ?>
                                            </div>
                                           
                                        </div>
                                        <div class="form-row">
                                           <div class="form-group col-md-6">
                                                <label for="inputEmail4">Swift/IFSC Code</label>
                                                 <?php if($user_bank->bank_swift){ ?>
                                                  <input type="text" class="form-control" disabled value="<?php echo $user_bank->bank_swift;?>">
                                                 <?php }else{ ?>
                                                 <input type="text" class="form-control" id="bank_swift" name="bank_swift">
                                                <?php } ?>
                                            </div>

                                            <div class="form-group col-md-6">
                                                <label for="inputEmail4">Bank Address</label>
                                                 <?php if($user_bank->bank_address){ ?>
                                                <input type="text" class="form-control" disabled value="<?php echo $user_bank->bank_address;?>">
                                                 <?php }else{ ?>
                                                  <input type="text" class="form-control" id="bank_address" name="bank_address">
                                                <?php } ?>
                                            </div>
                                            
                                        </div>
                                        <div class="form-row">
                                          <div class="form-group col-md-6">
                                                <label for="inputEmail4">Bank City</label>
                                                  <?php if($user_bank->bank_city){ ?>
                                                <input type="text" class="form-control" disabled value="<?php echo $user_bank->bank_city;?>">
                                                 <?php }else{ ?>
                                                  <input type="text" class="form-control" id="bank_city" name="bank_city">
                                                <?php } ?>
                                            </div>

                                            <div class="form-group col-md-6">
                                                <label for="inputEmail4">Bank Country</label>
                                                  <?php if($user_bank->bank_country){ ?>
                                                <input type="text" class="form-control" disabled value="<?php echo $user_bank->bank_country;?>">
                                                 <?php }else{ ?>
                                                 <input type="text" class="form-control" id="bank_country" name="bank_country">
                                                <?php } ?>
                                            </div>
                                           
                                        </div>
                                        <div class="form-row">
                                         
                                            <div class="form-group col-md-6">
                                                <label for="inputEmail4">Zipcode</label>
                                                  <?php if($user_bank->bank_postalcode){ ?>
                                                <input type="text" class="form-control" disabled value="<?php echo $user_bank->bank_postalcode;?>">
                                                 <?php }else{ ?>
                                                  <input type="text" class="form-control" id="bank_postalcode" name="bank_postalcode">
                                                <?php } ?>
                                            </div>
                                        </div>
                                        <?php if($user_bank==""){ ?>
                                        <div class="text-center mt-3">
                                            <button type="submit" class="form-btn">Submit</button>
                                        </div>
                                      
                                      <?php } ?>
                                     <?php echo form_close();?>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
                                <div class="inner-box-body">
                                  <?php 
                                   $attributes=array('id'=>'change_password','class'=>'max-500');
                                   $action=base_url().'settings';
                                   echo form_open($action,$attributes); ?>
                                        <div class="form-row justify-content-center">
                                            <div class="form-group col-md-6">
                                                <label for="oldpass">Old Password</label>
                                              <input type="password" name="oldpass" id="oldpass" class="form-control" placeholder="<?php echo $this->lang->line('Enter Old Password')?>">
                                               <span class="old_error error_msg error"></span>
                                            </div>
                                        </div>
                                        <div class="form-row justify-content-center">

                                            <div class="form-group col-md-6">
                                                <label for="newpass">New Password</label>
                                                <input type="password" name="newpass" id="newpass" class="form-control" placeholder="<?php echo $this->lang->line('Enter New Password')?>">
                                                        <span class="newpass_error error_msg error"></span>
                                            </div>
                                        </div>
                                        <div class="form-row justify-content-center">

                                            <div class="form-group col-md-6">
                                                <label for="confirmpass">Confirm New Password</label>
                                               <input type="password" name="confirmpass" id="confirmpass" class="form-control" placeholder="<?php echo $this->lang->line('Retype Password')?>">
                                                  <span class="error_msg confirmpass_error error"></span>
                                            </div>
                                        </div>
                                        <div class="text-center mt-3">
                                           <input type="submit" name="chngpass" class="form-btn" value="<?php echo $this->lang->line('Change Password')?>"/>
                                        </div>
                                    <?php echo form_close();?>                            
                                </div>

                            </div>
                            <div class="tab-pane fade" id="pills-contact1" role="tabpanel" aria-labelledby="pills-contact1-tab">
                                <div class="inner-box-body">
                                    <div class="auth-entry">
                                        <div class="row align-items-center">
                                            <div class="col-lg-6">
                                                <div class="auth-details">
                                                    <p>To Get the Google Authenticator Details.</p>
                                                    <a href="https://support.google.com/accounts/answer/1066447?co=GENIE.Platform%3DAndroid&hl=en" target="_blank" class="gt-code">Get code</a>
                                                    <?php 
                                                          $attributes=array('id'=>'security','class'=>'mb-4 mt-4');
                                                          $action=base_url().'settings';
                                                          echo form_open($action,$attributes); 
                                                          if($users->randcode=='' || $users->randcode=='disable')
                                                          {
                                                            $btn_content = $this->lang->line('ENABLE');
                                                          }
                                                           else{
                                                            $btn_content = $this->lang->line('DISABLE');
                                                          }                                     
                                                        ?>
                                                        <div class="form-row">

                                                            <div class=" form-group col-md-10 ">
                                                                <input type="text" class="form-control" id="inputEmail4" name="code" id="code">
                                                            <input type="hidden" name="secret" id="secret" value="<?php echo $secret;?>">
                                                            </div>
                                                        </div>
                                                        <div class="mt-1">
                                                               <input name="tfa_sub" type="submit" class="form-btn" value="<?php echo $this->lang->line('Submit')?>"/>
                                                        </div>
                                                     <?php echo form_close();?>

                                                </div>
                                            </div>
                                            <div class="col-lg-6 ">
                                                <div class="scan-qr">
                                                    <p>Scan this QR Code</p>
                                                    <img src="<?php echo $url;?>" alt="" class="img-fluid">
                                                    <p>or Enter the key manually</p>
                                                    <h4><?php echo $secret;?></h4>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
              <!--           <div class="row">
                            <div class="col-lg-12">

                                <div class="dash-history">
                                    <h2 class="mt-2 mb-2"> <span> Login History</span></h2>
                                    <div class="table-responsive ">
                                        <table id="example" class="table" style="width:100%">
                                            <thead>
                                                <tr>
                                            <th><?php echo $this->lang->line('S.no')?></th>
                                            <th><?php echo $this->lang->line('Date & Time')?></th>
                                            <th><?php echo $this->lang->line('IP Address')?></th>
                                            <th><?php echo $this->lang->line('Browser')?></th>
                                        </tr> 
                                            </thead>
                                              <tbody>
                                        <?php
                                            if(count($login_history) >0) 
                                            {
                                                $i=1;
                                                foreach($login_history as $login)
                                                {
                                        ?>
                                        <tr>
                                            <td><?php echo $i++;?></td>
                                            <td><?php echo date('d-m-y H:i A',$login->date);?></td>
                                            <td><?php echo substr($login->ip_address,0,14);?></td>
                                            <td><?php echo $login->browser_name;?></td>
                                        </tr>
                                        <?php } 
                                    }?>                                        
                                    </tbody>

                                        </table>
                                    </div>
                                </div>
                            </div>
                           
                        </div>
 -->
                    
                    </div>
                </div>
            </div>
        </div>
    </div>
<!--      <?php $this->load->view('front/common/inner_footer'); ?>

 -->  
<?php $this->load->view('front/common/footer'); ?>
 <?php $this->load->view('front/common/scripts'); ?>
 <!--   <script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.22/js/dataTables.bootstrap4.min.js "></script> -->
  <!--   <script>
        $(document).ready(function() {
            $('#example').DataTable({
                "paging": false,
                "searching": false
            });
        });
    </script> -->

<script>
  function readURL(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    
    reader.onload = function(e) {
      $('#blah').attr('src', e.target.result);
    }
    
    reader.readAsDataURL(input.files[0]); // convert to base64 string
  }
}

$("#imageUpload3").change(function() {
  readURL(this);
});

 function readURL_back(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    
    reader.onload = function(e) {
      $('#blah1').attr('src', e.target.result);
    }
    
    reader.readAsDataURL(input.files[0]); // convert to base64 string
  }
}

$("#imageUpload4").change(function() {
  readURL_back(this);
});

/**************/
function readURL_photo(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    
    reader.onload = function(e) {
      $('#blah2').attr('src', e.target.result);
    }
    
    reader.readAsDataURL(input.files[0]); // convert to base64 string
  }
}

$("#inputGroupFile01").change(function() {
  readURL_photo(this);
});


/**************/
function readURL_address(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    
    reader.onload = function(e) {
      $('#blah3').attr('src', e.target.result);
    }
    
    reader.readAsDataURL(input.files[0]); // convert to base64 string
  }
}

$("#imageUpload1").change(function() {
  readURL_address(this);
});

/**************/
function readURL_bank(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    
    reader.onload = function(e) {
      $('#imagePreview5').attr('src', e.target.result);
    }
    
    reader.readAsDataURL(input.files[0]); // convert to base64 string
  }
}

$("#imageUpload5").change(function() {
  readURL_bank(this);
});

/*******************/

$("#addr_submit").click(function(){
  var photo_id_1 = $('#imageUpload1').val();
      var error_msg = '';
      if(photo_id_1 == '' || photo_id_1 == null){
        $('.photo_id_1_error').html('Provide Address Proof').fadeIn(1000).fadeOut(3000);
        $('#imageUpload1').focus();
        return false;
      }else{
        $("#verification_forms1").submit();
        return true;
      }
      

});

$("#addr_cancel").click(function(){
  
        var photo_id_1 = $('#addr_proof').val();
      var error_msg = '';
      if(photo_id_1 == '' || photo_id_1 == null){
        $('.photo_id_1_error').html('No Address proof to cancel').fadeIn(1000).fadeOut(3000);
        $('#imageUpload1').focus();
        return false;
      }else{
        $("#verification_forms1").submit();
        return true;
      }
  
});

$(".addr_upload").click(function(){
$("#imageUpload1").trigger("click");
});

$("#id_submit").click(function(){
  var photo_id_2 = $('#imageUpload3').val();
      var error_msg = '';
      if(photo_id_2 == '' || photo_id_2 == null){
        $('.photo_id_2_error').html('Provide ID Proof').fadeIn(1000).fadeOut(3000);
        $('#imageUpload3').focus();
        return false;
      }else{
        $("#verification_forms2").submit();
        return true;
      }
      

});

$("#id_cancel").click(function(){
  
        var photo_id_2 = $('#id_proof').val();
      var error_msg = '';
      if(photo_id_2 == '' || photo_id_2 == null){
        $('.photo_id_2_error').html('No ID Proof to cancel').fadeIn(1000).fadeOut(3000);
        $('#imageUpload3').focus();
        return false;
      }else{
        $("#verification_forms2").submit();
        return true;
      }
  
});

$(".id_upload").click(function(){
$("#imageUpload3").trigger("click");
});


$("#id_1_submit").click(function(){
  var photo_id_4 = $('#imageUpload4').val();
      var error_msg = '';
      if(photo_id_4 == '' || photo_id_4 == null){
        $('.photo_id_4_error').html('Provide ID Proof').fadeIn(1000).fadeOut(3000);
        $('#imageUpload4').focus();
        return false;
      }else{
        $("#verification_forms4").submit();
        return true;
      }
      

});

$("#id_1_cancel").click(function(){
  
        var photo_id_4 = $('#id_proof_1').val();
      var error_msg = '';
      if(photo_id_4 == '' || photo_id_4 == null){
        $('.photo_id_2_error').html('No ID Proof to cancel').fadeIn(1000).fadeOut(3000);
        $('#imageUpload4').focus();
        return false;
      }else{
        $("#verification_forms4").submit();
        return true;
      }
  
});

$(".id_upload").click(function(){
$("#imageUpload4").trigger("click");
});


$("#photo_submit").click(function(){
  var photo_id_3 = $('#inputGroupFile01').val();
      var error_msg = '';
      if(photo_id_3 == '' || photo_id_3 == null){
        $('.photo_id_3_error').html('Provide Photo Proof').fadeIn(1000).fadeOut(3000);
        $('#inputGroupFile01').focus();
        return false;
      }else{
        $("#verification_forms3").submit();
        return true;
      }
      
});

$("#photo_cancel").click(function(){
 var photo_id_3 = $('#photo_proof').val();
      var error_msg = '';
      if(photo_id_3 == '' || photo_id_3 == null){
        $('.photo_id_3_error').html('No Photo Proof to cancel').fadeIn(1000).fadeOut(3000);
        $('#inputGroupFile01').focus();
        return false;
      }else{
        $("#verification_forms3").submit();
        return true;
      }
});

$(".photo_upload").click(function(){
$("#inputGroupFile01").trigger("click");
});

/**************/

$("#bank_submit").click(function(){
  var photo_id_5 = $('#imageUpload5').val();
      var error_msg = '';
      if(photo_id_5 == '' || photo_id_5 == null){
        $('.photo_id_5_error').html('Provide Photo Proof').fadeIn(1000).fadeOut(3000);
        $('#imageUpload5').focus();
        return false;
      }else{
        $("#verification_forms5").submit();
        return true;
      }
      
});

$("#bank_cancel").click(function(){
 var photo_id_5 = $('#bank_proof').val();
      var error_msg = '';
      if(photo_id_5 == '' || photo_id_5 == null){
        $('.photo_id_5_error').html('No Photo Proof to cancel').fadeIn(1000).fadeOut(3000);
        $('#imageUpload5').focus();
        return false;
      }else{
        $("#verification_forms5").submit();
        return true;
      }
});

$(".photo_upload").click(function(){
$("#inputGroupFile01").trigger("click");
});
</script>
 <script>
        $(document).ready(function() {
            $(".pfle-image #profile-upload-btn").click(function() {
                $(".pfle-image input").trigger("click");
            });
        });

         $.validator.addMethod('ZipChecker', function() {
    }, 'Invalid zip code');
         $.validator.addMethod("lettersonly", function(value) {
    return (/^[a-zA-Z\s]*$/.test(value));
});
        $('#bankwire').validate({
        rules: {
          currency: {
          required: true
          },
          bank_name: {
          required: true
          },
          bank_account_number: {
          required: true
          },
          bank_account_name: {
          required: true,
          lettersonly: true
          },
          bank_swift: {
          required: true
          },
          bank_address: {
          required: true
          },
          bank_city: {
          required: true,
          lettersonly: true
          },
          bank_country: {
          required: true,
          lettersonly: true
          },
          postal_code: {
          required: true,
          number: true,
          maxlength: 7,
          ZipChecker: function(element) {
          values=$("#postal_code").val();

                 if( values =="0" || values =="00" || values =="000" || values =="0000" || values =="00000"  || values =="000000"   || values =="0000000" )
                 {
                    return true;
                 }
                 }
              },
              phone: {
                required: true
              }
          },
  messages: {
    bank_name: {
      required: "<?php echo $this->lang->line('Please enter bank name')?>"
    },
    bank_account_number: {
      required: "<?php echo $this->lang->line('Please enter bank account number')?>"
    },
    bank_account_name: {
      required: "<?php echo $this->lang->line('Please enter bank account name')?>",
      lettersonly: "<?php echo $this->lang->line('Please enter letters only')?>"
    },
    bank_swift: {
      required: "<?php echo $this->lang->line('Please enter bank swift')?>"
    },
    bank_address: {
      required: "<?php echo $this->lang->line('Please enter bank address')?>"
    },
    bank_city: {
      required: "<?php echo $this->lang->line('Please enter bank city')?>",
      lettersonly: "<?php echo $this->lang->line('Please enter letters only')?>"
    },
    bank_country: {
      required: "<?php echo $this->lang->line('Please enter bank bank country')?>",
      lettersonly: "<?php echo $this->lang->line('Please enter letters only')?>"
    },
    postal_code: {
      required: "<?php echo $this->lang->line('Please enter postal code')?>"
    }
  }
});
</script>
</body>

</html>