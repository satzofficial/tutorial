<?php 
    $this->load->view('front/common/header');
    $user_id = $this->session->userdata('user_id');
    $segment = $this->uri->segment(3, 0);
    $lang_id = $this->session->userdata('site_lang');

    if($this->uri->segment(2)=='twostep-verification') { 
      $active_tab = 'twostep-verification';
    } else if($this->uri->segment(2)=='account-change-password') { 
      $active_tab = 'account-change-password';
    } else {
      $active_tab = '';
    }

    // echo $active_tab;
?>
<style>
.kyc-status-Rejected {
  margin-bottom: 25px !important;
  color: red !important;
  font-weight: bold;
} 
.kyc-status-Respinto {
  margin-bottom: 25px !important;
  color: red !important;
  font-weight: bold;
}

.kyc-status-Completed {
  margin-bottom: 25px !important;
  color: #28a745 !important;
  font-weight: bold;
} 
.kyc-status-Completato {
  margin-bottom: 25px !important;
  color: #28a745 !important;
  font-weight: bold;
} 

.kyc-status-Pending {
  margin-bottom: 25px !important;
  color: orange !important;
  font-weight: bold;
}  
.kyc-status-in-attesa-di {
  margin-bottom: 25px !important;
  color: orange !important;
  font-weight: bold;
}  
label.upload_btn1 {
border: 1px solid #282F44;
border-radius: 20px;
padding: 2px 10px;
font-size: 11px;
letter-spacing: 0;
color: #333;
background: #e7d5a2;
width: 100px;
text-align: center;
margin: 10px;
margin-left: 34px;
}

 .modal-content1 {
    position: relative;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -ms-flex-direction: column;
    flex-direction: column;
    width: 100%;
    pointer-events: auto;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid rgba(0, 0, 0, 0.2);
    border-radius: 0.3rem;
    outline: 0;
    height: 770px;
 }


</style>
  
  <!-- breadcrumb -->
  <div class="me-breadcrumb">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="me-breadcrumb-box">
            <h1><?=$this->lang->line('KYC');?></h1>
          </div>
        </div>
      </div>
    </div>
  </div>

 <main id="main">   
  <section class="inner-pages">
    <div class="container">
      <?php if($this->session->userdata('user_id')!='') {
            $this->load->view('front/user/sidebar_sticky');  
          }?>
      <div class="row mt-2">
        <div class="col-lg-12">
          <ul class="nav nav-pills custom_pills" id="settings_tab" role="tablist">
            <li class="nav-item"> <a class="nav-link <?php if($active_tab=='') { echo 'active show';}?>" id="kyc-tab" data-toggle="pill" href="#kyc" role="tab" aria-controls="pills-kyc" aria-selected="true"><?=$this->lang->line('KYC');?></a> </li>
            <li class="nav-item <?php if($active_tab=='twostep-verification') { echo 'active show';}?>"> <a class="nav-link" id="verification-tab" data-toggle="pill" href="#two_verification" role="tab" aria-controls="pills-verification" aria-selected="false"><?=$this->lang->line('Two-Step Verification');?></a> </li>
            <li class="nav-item <?php if($active_tab=='account-change-password') { echo 'active show';}?>"> <a class="nav-link" id="change-password-tab" data-toggle="pill" href="#change_password" role="tab" aria-controls="pills-password" aria-selected="false"><?=$this->lang->line('Change Password');?></a> </li>
          </ul>
          <div class="dash-profile-body background-grey"> 
            <!-- KYC Tab -->
            <div class="tab-content" id="settings_tab_content" >
              <?php  
                  $lang_pending = $this->lang->line('Pending');
                  $lang_rejected = $this->lang->line('Rejected');
                  $lang_completed = $this->lang->line('Completed');

                 if($users->photo_1_status==1) { $address_status = $lang_pending; } 
                 else if($users->photo_1_status==2) { $address_status = $lang_rejected; } 
                 else if($users->photo_1_status==3) { $address_status = $lang_completed; }

                 if($users->photo_2_status==1) { $id_status = $lang_pending; } 
                 else if($users->photo_2_status==2) { $id_status = $lang_rejected; } 
                 else if($users->photo_2_status==3) { $id_status = $lang_completed; }

                 if($users->photo_3_status==1) { $selfie_status = $lang_pending; } 
                 else if($users->photo_3_status==2) { $selfie_status = $lang_rejected; } 
                 else if($users->photo_3_status==3) { $selfie_status = $lang_completed; }
              
            ?>
              
              <div class="tab-pane fade <?php if($active_tab=='') { echo 'active show';}?>" id="kyc" role="tabpanel" aria-labelledby="kyc-tab">
              <?php if($users->verification_level > 1) {?>  

                <div class="row mt-4 px-4"> 
                  <?php $attributes=array('id'=>'verification_forms2'); 
                        $action = front_url() . 'address_verification';
                        echo form_open_multipart($action,$attributes); ?>  

                <div class="col-md-12 mb-3">       
                  <!-- Address Proof -->
                  <div class="col-md-4 mb-3 text-left-setting">
                    <p class="kyc-status-<?=(($address_status=='in attesa di')?str_replace(' ','-',$address_status):$address_status)?>"><?=$address_status?></p>
                    <?php 
                        $img = front_img().'id_proof.png';
                        
 
                        if(!empty(trim($users->photo_id_1)) && ($users->photo_1_status==3 || $users->photo_1_status==1)){
                            $img = $users->photo_id_1;
                        }
                        ?>
                    <h2 class="settings_title"><?=$this->lang->line('Your id document front');?></h2>
                     <!-- <img id="address_proof" src="<?=$img?>" alt="Address Proof" class="img-fluid mb-3 proof_img"> -->

                    <?php
                      $img = $users->photo_id_1;
                      $extension = pathinfo($img, PATHINFO_EXTENSION);
                      if($extension == 'png' || $extension == 'jpg' || $extension == 'jpeg'){
                    ?>
                      <img id="address_proof" src="<?=$img?>" alt="Address Proof" class="img-fluid mb-3 proof_img">
                      <?php }elseif($users->photo_id_1 == ""){
                        $img = front_img().'id_proof.png';
                        ?>
                        <img id="address_proof" src="<?=$img?>" alt="Address Proof" class="img-fluid mb-3 proof_img">
                      <?php }?>
                      <?php 
                        $img = $users->photo_id_1;
                        $extension = pathinfo($img, PATHINFO_EXTENSION);
                        if($extension == 'pdf'){
                      ?>
                      <iframe src="<?php echo $img; ?>" width="100px" height="60px"></iframe>
                    <?php }?>
                      <?php if(($users->photo_1_status==0 || $users->photo_1_status==2)) {
                      	if($users->photo_1_status==0) $fileCls = 'imageInput';
                      	else if($users->photo_1_status==2) $fileCls = 'imageInput1';
                       ?>
                      <p class="kyc_note mt-2"><?=$this->lang->line('Maximum file size should be below 2mb');?></p>
                      <p class="kyc_note mt-2"><?=$this->lang->line('ACCEPTED FILE JPG AND PNG ONLY');?></p>
                      <label for="imgInp1" class="upload_btn"><?=$this->lang->line('Upload Image');?></label>
                      
                      <input type="file" name="photo_id_1" id="imgInp1" class="imgInp <?=$fileCls?> photo_id_1" accept=".png, .jpg, .jpeg, .pdf" >
                      <input type="hidden" id="photo_ids_1" name="photo_ids_1" value="<?php echo $users->photo_id_1;?>">
                      <span id="upload_pdf_name" style="font-weight: bold;"></span>
                        <span id="upload_pdf_error" style="margin-top: 10px;color: #ff0000;"></span>
                       
                      



                      <?php } if(($users->photo_1_status==0 || $users->photo_1_status==2 || $users->photo_2_status==0 || $users->photo_2_status==2)){ ?>
                        <span class="photo_error">
                            <small style="" class="error_msg photo_id_1_error error"></small>
                        </span>
                       <div class="selbtn address_submit_btn" style="display: none;">
                            <div class="text-left-setting mt-3 mb-2 kyc-confirm-btn" style="float:right;">
                              <button type="button" id="address_submit" name="address_submit" class="auth_btn address_submit"><?=$this->lang->line('Submit');?></button>
                            </div>
                        </div> 
                    <?php }?>                      
                  </div>
                  
                  <!-- Address Proof -->
                  <div class="col-md-4 text-left-setting">
                    <p class="kyc-status-<?=(($id_status=='in attesa di')?str_replace(' ','-',$id_status):$id_status)?>"><?=$id_status?></p>
                    <?php
                        
                        $img1 = front_img().'id_proof.png';

                        if(!empty(trim($users->photo_id_2)) && ($users->photo_2_status==3 || $users->photo_2_status==1)){
                            $img1 = $users->photo_id_2;
                        }
                    ?>
                    <h2 class="settings_title"><?=$this->lang->line('Your id document back');?></h2>

                    <?php 
                       $img1 = $users->photo_id_2;
                       $extension = pathinfo($img1, PATHINFO_EXTENSION);
                       if($extension == 'png' || $extension == 'jpg' || $extension == 'jpeg'){
                    ?>
                      <img id="id_proof" src="<?php echo $img1;?>" alt="ID Proof" class="img-fluid mb-3 proof_img">
                    <?php }elseif($users->photo_id_2 == ""){
                      $img1 = front_img().'id_proof.png';
                      ?>
                      <img id="id_proof" src="<?php echo $img1;?>" alt="ID Proof" class="img-fluid mb-3 proof_img">
                    <?php }?>
                    <?php 
                         $img1 = $users->photo_id_2;
                         $extension = pathinfo($img1, PATHINFO_EXTENSION);
                         if($extension == 'pdf'){
                    ?>
                    <iframe src="<?php echo $img1;?>" width="100px" height="60px"></iframe>
                  <?php }?>
                      <?php if(($users->photo_2_status==0 || $users->photo_2_status==2)) { 
                      	if($users->photo_2_status==0) $fileCls = 'imageInput';
                      	else if($users->photo_2_status==2) $fileCls = 'imageInput1';
                      	?>
                      <p class="kyc_note mt-2"><?=$this->lang->line('Maximum file size should be below 2mb');?></p>
                      <p class="kyc_note mt-2"><?=$this->lang->line('ACCEPTED FILE JPG AND PNG ONLY');?></p>
                      <label for="imgInp2" class="upload_btn"><?=$this->lang->line('Upload Image');?></label>
                      <input type="file" name="photo_id_2" id="imgInp2" class="imgInp <?=$fileCls?> photo_id_2" accept=".png, .jpg, .jpeg, .pdf">
                      <input type="hidden" id="photo_ids_2" name="photo_ids_2" value="<?php echo $users->photo_id_2;?>">
                      <span id="upload_pdf_name" style="font-weight: bold;"></span>
                        <span id="upload_pdf_error" style="margin-top: 10px;color: #ff0000;"></span>

                      <?php } ?> 
                                       
                  </div>
                  
                  <?php echo form_close(); ?>   


                  <?php $pto1 = $users->photo_1_status;
                        $pto2 = $users->photo_2_status;
                        $pto3 = $users->photo_3_status;
                  ?>
                  <!-- Selfie Proof -->
                  <div class="col-md-4 text-left-setting">
                    <p class="kyc-status-<?=(($selfie_status=='in attesa di')?str_replace(' ','-',$selfie_status):$selfie_status)?>"><?=$selfie_status?></p>
                    <?php if($lang_id=='italian'){ ?>
                      <p class="mt-4">Per la legge italiana è obbligatorio identificare l'utente tramite bonifico bancario. E' quindi necessario che il nuovo utente, dopo aver caricato i propri documenti, depositi un importo minimo (10 euro) sul proprio conto tramite bonifico bancario dal proprio conto corrente personale.</p>

                      <p class="mt-4">NOTA BENE: il conto deve obbligatoriamente essere intestato al titolare dei documenti caricati. L'IBAN su cui effettuare il bonifico comparirà appena saranno stati inviati fronte e retro del documento.</p>
                      
                      <?php if(($pto1==3)&&($pto2==3)&&($pto3==0)||($pto3==2)){?>
                      <a href="javascript:;" class="auth_btn" style="padding: 5px 28px !important;" data-toggle="modal" data-target="#mobile_wallet"><?=$this->lang->line('Bank Wire');?></a>
                      <?php } ?>
                    <?php } else {?>
                      <p class="mt-4">As per the italian law is mandatory to identify the user via bank wire. So it’s necessary for the new user, after uploading his documents, deposit a minimum amount (10 euros) to his account via bank wire from his own personal bank account.</p>

                      <p class="mt-4">PLEASE NOTE: the account must necessarily be in the name of the holder of the uploaded documents. The IBAN on which to make the transfer will appear as soon as the front and back of the document have been sent.</p>
                      
                      <?php if(($pto1==3)&&($pto2==3)&&($pto3==0)||($pto3==2)){?>
                      <a href="javascript:;" class="auth_btn" style="padding: 5px 28px !important;" data-toggle="modal" data-target="#mobile_wallet"><?=$this->lang->line('Bank Wire');?></a>
                      <?php } ?>
                      
                    <?php }?>
                      
                  </div>
                </div>  
                </div>

              <?php } else {?>
              
              <div id="verify_text" class="d-flex align-items-center justify-content-center row py-4 mt-4"><div class="col-md-6 ">
                <div class="form-group row">
                  <label for="inputEmail3" class="col-sm-12 col-form-label text-center"><?=$this->lang->line('Please Complete My Data Information')?> <a href="<?=base_url()?>settings_profile" style="color: #4699F2;"> <?=$this->lang->line('Click Here')?> </a></label>
                </div></div>
              </div>
              
             <?php }?>  

              </div>

             
              
              <!-- Two Step Verification Tab -->
              <div class="tab-pane fade <?php if($active_tab=='twostep-verification') { echo 'active show';}?>" id="two_verification" role="tabpanel" aria-labelledby="verification-tab">
              <?php $attributes1=array('id'=>'security','class'=>'deposit_form');
                  $action1=base_url().'security';
                  echo form_open($action1,$attributes1); 
                  if($users->randcode=='' || $users->randcode=='disable') {
                    $btn_content = 'ENABLE AUTHENTICATION IN 2 STEPS';
                    $label_txt = $this->lang->line('Insert Code to Enable');
                  } else {
                    $btn_content = 'DISABLE AUTHENTICATION IN 2 STEPS';
                    $label_txt = $this->lang->line('Insert Code to Disable');
                  }?>
                  <div class="form-group text-left-setting">
                    
                    <!-- <p><?=$this->lang->line('Two-step verification (called “two-factor authentication”) adds an extra layer of security to your account should your password be discovered. in fact, with the activation of the 2-factor authentication, to access your account you will have to use two steps:');?></p> -->

                    <?php if($lang_id=='italian'){ ?>
                      <p>La verifica in due passaggi (detta “autenticazione a due fattori”) aggiunge un ulteriore livello di sicurezza al tuo account nel caso venisse scoperta la tua password. infatti, con I’attivazione dell'autenticazione a 2 fattori, per accedere al tuo account dovrai usare due passaggi:</p>

                    <?php } else {?>
                      <p>Two-step verification (called “two-factor authentication”) adds an extra layer of security to your account should your password be discovered. in fact, with the activation of the 2-factor authentication, to access your account you will have to use two steps:</p>
                    <?php }?>  

                    <p><?=$this->lang->line('- the prime is something you know, for example your password;')?></p>
                    <p><?=$this->lang->line('- the second something you own, for example your phone.')?></p>
                  </div>
                  <div class="d-flex align-items-center justify-content-center row">
                    <div class="deposit_form_div col-md-8 ml-auto">
                      
                    	<p><?=$this->lang->line('For more information on Google Authenticator')?> <a href="https://support.google.com/accounts/answer/1066447" target="https://support.google.com/accounts/answer/1066447" class="verification_btn"><?=$this->lang->line('Click here');?></a></p>
                    	<p><?=$this->lang->line('First you need to download the google Authenticator App')?></p>
                    	<p><?=$this->lang->line('To enable two-step verification, frame this QRcode with the Google Authenticator App and enter the code generate from you app in the field below.')?></p>
                    	<!-- <p><?=$this->lang->line('or manually enter the alphanumeric code you find under the QRcode below')?></p> -->

                    	<div class="row">
                    	<div class="col-md-2"></div>
                    	<div class="col-md-8">
                    <input type="text" style="width:250px;" class="form-control" id="code" name="code" placeholder="">
                    <input type="hidden" name="secret" id="secret" value="<?php echo $secret;?>">
                    <button style="width:250px;background:#28a745;color:#fff" class="verification_btn mt-4" type="submit"><?=$this->lang->line($btn_content);?></button>
                    </div>
                      <div class="col-md-2"></div>
					         </div>
                    </div>
                    <div class="deposit_form_div col-md-4 ml-auto">
                    	<img class="qr-code mb-3" src="<?=$url?>" alt="QR Code" style="margin-top: 10px" >
                      <p class="mb-2 verification_key"></p><?=$secret?>		
                    </div>
                  </div>
                
                <?php echo form_close();?>
              </div>
              
              <!-- Change Password Tab -->
              <div class="tab-pane fade <?php if($active_tab=='account-change-password') { echo 'active show';}?>" id="change_password" role="tabpanel" aria-labelledby="change-password-tab">
                <div class="d-flex align-items-center justify-content-center row py-4 mt-4">
                  <div class="col-md-6">
                    <?php 
                       $attributes=array('id'=>'change_password1','class'=>'change_password_form');
                       $action=base_url().'settings';
                       echo form_open($action,$attributes); ?>
                    
                      <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-4 col-form-label text-left-setting"><?=$this->lang->line('Current Password');?></label>
                        <div class="col-sm-8">
                          <input type="password" name="oldpass" id="oldpass" class="form-control" id="inputEmail3" placeholder="<?=$this->lang->line('Enter Your Current Password');?>">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-4 col-form-label text-left-setting"><?=$this->lang->line('New Password');?></label>
                        <div class="col-sm-8">
                          <input type="password" class="form-control" name="newpass" id="newpass" placeholder="<?=$this->lang->line('Enter Your New Password');?>">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-4 col-form-label text-left-setting"><?=$this->lang->line('Confirm New Password');?></label>
                        <div class="col-sm-8">
                          <input type="password" class="form-control"  name="confirmpass" id="confirmpass" placeholder="<?=$this->lang->line('Enter Your Confirm New Password');?>">
                        </div>
                      </div>
                      <div class="form-group row">
                        <div class="col-sm-12">
                          <div class="text-center mt-3 mb-2">
                            <button class="auth_btn" name="chngpass" type="submit"><?=$this->lang->line('Save');?></button>
                          </div>
                        </div>
                      </div>
                    <?php
                    echo form_close();
                    ?>
                  </div>
                </div>
              </div>
            </div>
        <?php if($users->verification_level > 1) {
            if($active_tab=='') {
            if($lang_id=='italian'){ ?>
              <p class="mt-4 kyc_contents">E’ necessario caricare un documento di identità fronte retro, chiaramente leggibile.
Se dovete caricare il passaporto, per fronte si intende la copertina e per retro si intende la
pagina con i dati. I documenti di identità accettati sono: carta d’identità, patente, passaporto,
per i cittadini italiani. Carta d’identità e passaporto per i cittadini UE. Passaporto per i
cittadini di paesi non UE</p>
            <?php } else { ?> 
              <p class="mt-4 kyc_contents">Please upload the front and the back of your id document. If you have a passport please
upload the cover and your data’s page. The acceptable id documents are: for EU citizen
national ID card or passport. For non EU resident only passports.</p>            
            <?php }}
           } else { 

          }?>  



          </div>
        </div>
      </div>
    </div>
  </section>
</main>
<!-- End #main --> 
 

<div class="modal fade right" id="mobile_wallet" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true"> 
  <div class="modal-dialog modal-full-height modal-right iks-popup" role="document">
    <div class="modal-content1" >
      <div class="modal-header">
        <h4 class="modal-title w-100 text-center" id="myModalLabel"><?=$this->lang->line('Bank Wire header');?></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
      </div>
      <div class="modal-body">
        <div class="col-sm-12">
              <div class="row">
                <div class="col-sm-12 deposit-address bank_wire">
                  <?php
                      $action = front_url()."deposit/EUR";
                      $attributes = array('id'=>'deposit_bank','autocomplete'=>"off",'enctype'=>"multipart/form-data"); 
                      echo form_open($action,$attributes); 

                    $bank_det = get_admin_bank_details(1);
                    $currency=$this->common_model->getTableData('currency',array('id'=>$bank_det->currency))->row();
                  ?>

                  <h4 class="modal-title w-100 text-center" style="margin-top:10px"><?=$this->lang->line('Account Details');?></h4>
                  <div class="form-row text-center" style="margin-top:20px;">
                    <div class="col-12">
                      <div class="mb-3">
                        <div class="form-row">
                          <div class="col-lg-6">
                            <label for="basic-url"><?=$this->lang->line('Account Name');?></label>     
                          </div>
                          <div class="col-lg-6">
                              <label for="basic-url"><?=$bank_det->bank_account_name?></label>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-12">
                      <div class="mb-3">
                        <div class="form-row">
                          <div class="col-lg-6">
                            <label for="basic-url"><?=$this->lang->line('Account Number');?></label>     
                          </div>
                          <div class="col-lg-6">
                              <label for="basic-url"><?=$bank_det->bank_account_number?></label>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-12">
                      <div class="mb-3">
                        <div class="form-row">
                          <div class="col-lg-6">
                            <label for="basic-url"><?=$this->lang->line('Swift/BIC Code');?></label>     
                          </div>
                          <div class="col-lg-6">
                              <label for="basic-url"><?=$bank_det->bank_swift?></label>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-12">
                      <div class="mb-3">
                        <div class="form-row">
                          <div class="col-lg-6">
                            <label for="basic-url"><?=$this->lang->line('Branch City');?></label>     
                          </div>
                          <div class="col-lg-6">
                              <label for="basic-url"><?=$bank_det->bank_city?></label>
                          </div>
                        </div>
                      </div>
                    </div>

                  </div>

                  
                  <h6 style="font-style:italic;"><?=$this->lang->line('Simply enter your surname and name as the reason for the transfer, followed by the word "IDENTIFICATION".');?></h6>
                  <p><?=$this->lang->line('After making the transfer, fill in the fields below and upload a payment receipt in .pdf format (the maximum file size must be less than 2 MB)')?></p>
                  
                  <input type="hidden" name="currency" class="currency" value="<?php echo $sel_currency->id;?>" >
                  <div class="form-row">
                    <div class="col-8 col-md-8">
                      <div class="row">
                        <div class="col-12 col-md-12">
                          <label for="basic-url"><?=$this->lang->line('Coin Name');?></label>
                          <div class="mb-3">
                            <input type="text" disabled class="form-control input_anim" aria-label="Small" aria-describedby="inputGroup-sizing-sm" name="coin_name" value="<?=$currency->currency_symbol?>">
                            <input type="hidden" name="currency" value="<?=$currency->id?>">
                          </div>
                        </div>
                        <div class="col-12 col-md-12">
                          <label for="basic-url"><?=$this->lang->line('Enter Amount');?></label>
                          <div class="mb-3">
                            <input type="text" readonly class="form-control input_anim fiat_amount" aria-label="Small" value="10" aria-describedby="inputGroup-sizing-sm" name="amount" onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')">
                          </div>
                        </div>
                        <!-- <div class="col-12 col-md-12">
                          <label for="basic-url"><?=$this->lang->line('Reference Number');?></label>
                          <div class="mb-3">
                            <input type="text" class="form-control input_anim" aria-label="Small" aria-describedby="inputGroup-sizing-sm" name="ref_no">
                          </div>
                        </div> -->
                      </div>
                    </div>

                    <div class="col-4 col-md-4">
                      <div class="row">
                          <img style="max-width:160px;" src="<?=front_img();?>pdf-icon.png">
                          <label for="imgInp3" class="upload_btn1"><?=$this->lang->line('Upload pdf');?></label>
                        <input type="file" name="upload_pdf" id="imgInp3" class="imgInp upload_pdf" accept="application/pdf">
                        <span id="upload_pdf_name" style="font-weight: bold;"></span>
                        <span id="upload_pdf_error" style="margin-top: 10px;color: #ff0000;"></span>
                      </div>
                    </div>
                   
                    
                    <div class="col-12 col-md-12">
                      <div class="row">
                        <div class="col-12 col-md-12">
                          <input type="hidden" name="payment_types" id="payment_types" value="bank">
                          <input type="hidden" name="kyc_verify" value="kyc_verify">
                          <input type="hidden" name="admin_id" value="1">

                          <input type="hidden" name="account_number" value="<?=$bank_det->bank_account_number?>">
                          <input type="hidden" name="account_name" value="<?=$bank_det->bank_account_name?>">
                          <input type="hidden" name="bank_name" value="<?=$bank_det->bank_name?>">
                          <input type="hidden" name="bank_swift" value="<?=$bank_det->bank_swift?>">
                          <input type="hidden" name="bank_country" value="<?=$bank_det->bank_country?>">
                          <input type="hidden" name="bank_city" value="<?=$bank_det->bank_city?>">
                          <input type="hidden" name="bank_address" value="<?=$bank_det->bank_address?>">
                          <input type="hidden" name="bank_postalcode" value="<?=$bank_det->bank_postalcode?>">

                          <div class="profile-flex border-0 pt-4 kyc-confirm-btn">
                            <div class="text-center">
                              <button name="deposit_bank" class="auth_btn deposit_bank" type="submit"><?=$this->lang->line('Confirm');?> </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>


                  

                  <?php echo form_close();?> </div>
              </div>
            </div>
       </div>
    
    </div>
  </div>
</div>

<?php 
    $this->load->view('front/common/footer');
    $user_id    = $this->session->userdata('user_id');
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $get_os     = $_SERVER['HTTP_USER_AGENT'];
    ?>
    <script type="text/javascript">
         var base_url='<?php echo base_url();?>';
    var front_url='<?php echo front_url();?>';
    var user_id='<?php echo $user_id;?>';
    var ip_address = '<?php echo $ip_address;?>';
    var get_os     = '<?php echo $get_os;?>';

    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';


    $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
        if (options.type.toLowerCase() == 'post') {
            options.data += '&'+csrfName+'='+$("input[name="+csrfName+"]").val();
            if (options.data.charAt(0) == '&') {
                options.data = options.data.substr(1);
            }
        }
    });

    $( document ).ajaxComplete(function( event, xhr, settings ) {
        if (settings.type.toLowerCase() == 'post') {
            $.ajax({
                url: front_url+"get_csrf_token", 
                type: "GET",
                cache: false,             
                processData: false,      
                success: function(data) {

                     $("input[name="+csrfName+"]").val(data);
                }
            });
        }
    });

    $('#security').validate({
        rules: {
            code: {
                required: true,
                number: true,
                minlength: 6
            }
        },
        messages: {
            code: {
                required: 'Please enter code',
                number: 'Please enter valid code',
                minlength:'Please 6 digit valid code'
            }
        }
    });

        $('#change_password1').validate({
      rules: {
        oldpass: {
          required: true,
          remote: {
                    url: front_url+'oldpassword_exist',
                    type: "post",
                    csrf_token : csrfName,
                    data: {
                        oldpass: function() {
                        return $( "#oldpass" ).val();
                        }
                    }
                }
        },
       newpass: {
          required: true
        },
        confirmpass: {
          required: true,
          equalTo : "#newpass"
        }
    },
     messages: {
        oldpass: {
          required: "<?=$this->lang->line('Please enter Old Password');?>",
           remote: "<?=$this->lang->line('Invalid Old Password');?>"
        },
        newpass: {
          required: "<?=$this->lang->line('Please enter New Password');?>"
        },
        confirmpass: {
          required: "<?=$this->lang->line('Please enter Confirm Password');?>",
          equalTo : "<?=$this->lang->line('Confirm Password not matches with New Password');?>"
        }
    }
});

  function readURL1(input) {

    
      if (input.files && input.files[0]) {

        fileSize = input.files[0].size;
        if(fileSize > 2000000) { 
          $('#address_proof').attr('src', base_url+'assets/front/images/id_proof.png');

          $.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: '<?=$this->lang->line('Maximum file size should be below 2mb');?>' });
          callValidProof();
        } else {
          var reader = new FileReader();
            reader.onload = function(e) {
                var url = input.value;
                var ext = url.substring(url.lastIndexOf('.') + 1).toLowerCase();
                if(ext == 'jpeg' || ext == 'jpg' || ext == 'png'){
                  
                  $('#address_proof').attr('src', e.target.result);
                }
                if(ext == 'pdf'){

                  $('#address_proof').attr('src', base_url+'assets/front/images/pdf-icon.png');
                }
                
            }
            reader.readAsDataURL(input.files[0]);
            callValidProof();
        }
      }
    }
    $("#imgInp1").change(function() {
        readURL1(this);
    });


    function readURL2(input) {
        if (input.files && input.files[0]) {

        	fileSize = input.files[0].size;
	    	if(fileSize > 2000000) { 
          $('#id_proof').attr('src', base_url+'assets/front/images/id_proof.png');
	    		$.growl.error({location: "cc",size:"large", title: "Share Coin Exchange", message: '<?=$this->lang->line('Maximum file size should be below 2mb');?>' });
	    		callValidProof();
	    	} else {
	    		var reader = new FileReader();
            reader.onload = function(e) {
                
                var url = input.value;
                var ext = url.substring(url.lastIndexOf('.') + 1).toLowerCase();
                 console.log(ext);
             
                if(ext == 'jpeg' || ext == 'jpg' || ext == 'png'){
                  
                  $('#id_proof').attr('src', e.target.result);
                }
                if(ext == 'pdf'){

                  $('#id_proof').attr('src', base_url+'assets/front/images/pdf-icon.png');
                  //$('#id_proof').attr('src', e.target.result);
                }
            }
            reader.readAsDataURL(input.files[0]); 
            callValidProof();
	    	  }
        }
    }
    $(document).on('change','#imgInp2',function() {
        readURL2(this);
    });
    function readURL3(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#selfie_proof').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }

    $("#imgInp3").change(function() {
        readURL3(this);
    });

$("#address_submit").click(function(){

	$("#verification_forms2").submit();
    return true;
});
$("#address_cancel").click(function(){
    var photo_id_1 = $('#imgInp1').val();
    var photo_id_2 = $('#imgInp2').val();

    if($.trim(photo_id_1) == '' || $.trim(photo_id_1) == null){ 
      $('.photo_id_1_error').html("<?=$this->lang->line('No Document Front to cancel')?>").fadeIn(1000).fadeOut(3000);
    } else{
      $('#imgInp1').val('');
      $('#address_proof').attr('src', base_url+'assets/front/images/id_proof.png');
    }

    if(($.trim(photo_ids_1)!='')&&($.trim(photo_id_2) == '' || $.trim(photo_id_2) == null)){ 
      $('.photo_id_2_error').html("<?=$this->lang->line('No Document Back to cancel')?>").fadeIn(1000).fadeOut(3000);
      $('#imgInp2').focus();
    }else{
        $('#imgInp2').val('');
        $('#id_proof').attr('src', base_url+'assets/front/images/id_proof.png');
    }

});

    $("#id_submit").click(function(){
        var photo_id_3 = $('#imgInp2').val();
        var error_msg = '';
        if($.trim(photo_id_3) == '' || $.trim(photo_id_3) == null){
            $('.photo_id_2_error').html("<?=$this->lang->line('Provide Document Back')?>").fadeIn(1000).fadeOut(3000);
            $('#imgInp2').focus();
            return false;
        }else{
            $("#verification_forms3").submit();
            return true;
        }
    });
    $("#id_cancel").click(function(){
        var photo_id_3 = $('#imgInp2').val();
        var error_msg = '';
        if($.trim(photo_id_3) == '' || $.trim(photo_id_3) == null){
            $('.photo_id_2_error').html("<?=$this->lang->line('No Document Back to cancel')?>").fadeIn(1000).fadeOut(3000);
            $('#imgInp2').focus();
            return false;
        }else{
            $('#imgInp2').val('');
            $('#id_proof').attr('src', base_url+'assets/front/images/id_proof.png');
            return true;
        }
    });

     $("#selfie_submit").click(function(){
        var photo_id_3 = $('#imgInp3').val();       
        var error_msg = '';
        if($.trim(photo_id_3) == '' || $.trim(photo_id_3) == null){
            $('.photo_id_3_error').html('Provide Selfie Photo').fadeIn(1000).fadeOut(3000);
            $('#imgInp3').focus();
            return false;
        }else{
            $("#verification_forms4").submit();
            return true;
        }
    });
    $("#selfie_cancel").click(function(){
        var photo_id_3 = $('#imgInp3').val();
        var error_msg = '';
        if($.trim(photo_id_3) == '' || $.trim(photo_id_3) == null){
            $('.photo_id_3_error').html('No Photo to cancel').fadeIn(1000).fadeOut(3000);
            $('#imgInp3').focus();
            return false;
        }else{
            $('#imgInp3').val('');
            $('#selfie_proof').attr('src', base_url+'assets/front/images/settings_user.png');
            return true;
        }
    });

    $.validator.addMethod('ZipChecker', function() {
    }, 'Invalid zip code');

    $.validator.addMethod("lettersonly", function(value) {
        return (/^[a-zA-Z\s]*$/.test(value));
    });
    $('#bankwire').validate({
        rules: {
            currency: {
                required: true
            },
            bank_name: {
                required: true
            },
            bank_account_number: {
                required: true
            },
            bank_account_name: {
                required: true,
                lettersonly: true
            },
            bank_swift: {
                required: true
            },
            bank_address: {
                 required: true
            },
            bank_city: {
                required: true,
                lettersonly: true
            },
            bank_country: {
                required: true,
            },
            bank_postalcode: {
                required: true,
                number: true,
                maxlength: 7,
                ZipChecker: function(element) {
                  values=$("#postal_code").val();
                  if( values =="0" || values =="00" || values =="000" || values =="0000" || values =="00000"  || values =="000000"   || values =="0000000" )
                  {
                      return true;
                  }
                }
            }
        },
        messages: {
            bank_name: {
                required: "Please enter bank name"
            },
            bank_account_number: {
                required: "Please enter bank account number"
            },
            bank_account_name: {
                required: "Please enter bank account name",
                lettersonly: "Please enter letters only"
            },
            bank_swift: {
                required: "Please enter bank swift"
            },
            bank_address: {
                required: "Please enter bank address"
            },
            bank_city: {
                required: "Please enter bank city",
                lettersonly: "Please enter letters only"
            },
            bank_country: {
                required: "Please enter bank bank country"
            },
            bank_postalcode: {
                required: "Please enter postal code"
            }
        }
    });

$('#deposit_bank').validate(
{
    rules: {
      amount: {
        required: true,
        number: true,
        min: 10
      }
    },
    messages: {
      amount: {
          required: "Please enter amount",
          number: "Only enter numbers as decimal or float"
      }
    },
    invalidHandler: function(form, validator) {
        if (!validator.numberOfInvalids())
        {
            return;
        }
        else
        {
            var error_element=validator.errorList[0].element;
            error_element.focus();
        }
    },
    highlight: function (element) {
        //$(element).parent().addClass('error')
    },
    unhighlight: function (element) {
        $(element).parent().removeClass('error')
    },
    submitHandler: function(form) 
    { 
        form.submit();
    }
});


$('.fiat_amount').keyup(function(e) {
  if (/\D/g.test(this.value)) {
    this.value = this.value.replace(/\D/g, '');
  }
});

$(document).on('click', '#settings_tab li', function() {
  li = $(this).find('a').attr('id');
  $("#settings_tab li").not($(this)).removeClass('active show');
  if(li=='kyc-tab') {
    $(".kyc_contents").css("display", "block");    
  } else {
    $(".kyc_contents").css("display", "none");
  } 

});

$('.upload_pdf').change(function() {
  filename = $('.upload_pdf').val();
  if(filename!='') {
    $('.deposit_bank').removeAttr('disabled')
  }  
});

function callValidProof() {
  fileInputs = $(".imageInput");
  fileInputs1 = $(".imageInput1");

  arrInput=[]; arrInput1=[]; arrSize=[]; arrSize1=[];
  if(fileInputs.length>0) {
    for(var i = 0; i < fileInputs.length; i++){
      val = $(fileInputs[i]).val();
      size = fileInputs[i].files[0].size;
      if(val!='') {
        arrInput.push(val);
        arrSize.push(size);  
      }    
    }
    
    if((arrInput.length==2) && (arrSize[0]<2000000) && (arrSize[1]<2000000)) 
      $(".address_submit_btn").css("display", "block");
    else 
      $(".address_submit_btn").css("display", "none");
  }

  if(fileInputs1.length>0) {
    for(var i = 0; i < fileInputs1.length; i++){
      val1 = $(fileInputs1[i]).val();
      size = fileInputs1[i].files[0].size;
      if(val1!='') {
        arrInput1.push(val1);   
        arrSize1.push(size); 
      } 
    }
    if(fileInputs1.length==arrInput1.length) {
      if((arrSize1.length==1) && (arrSize1[0]<2000000)) 
        $(".address_submit_btn").css("display", "block");
      else if ((arrSize1.length==2) && (arrSize1[0]<2000000) && (arrSize1[1]<2000000)) 
        $(".address_submit_btn").css("display", "block");
      else 
        $(".address_submit_btn").css("display", "none");
    } 
  } 
}

$('.upload_pdf').change(function() {
  filename = $('.upload_pdf').val();
  if(filename!='' && this.files[0].size < 2000000) {
    $('#upload_pdf_name').html(this.files[0].name);
    $('#upload_pdf_error').html("");
    $(".kyc-confirm-btn").css("display", "block");
  }
  else{
    $('#upload_pdf_name').html(this.files[0].name);
    $('#upload_pdf_error').html("Please upload file less than 2MB.");
    $(".kyc-confirm-btn").css("display", "none");
  }  

});

</script>