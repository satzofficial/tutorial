<?php 
$this->load->view('front/common/header');
$user_id = $this->session->userdata('user_id');
?>
<!--========================== Banner Section ============================-->

<!-- breadcrumb -->
<div class="me-breadcrumb">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <div class="me-breadcrumb-box">
          <h1><?php echo $this->lang->line('Deposit');?></h1>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="me-service-single me-padder-top me-padder-bottom">
  <?php $this->load->view('front/user/sidebar_sticky');?>
  <div class="content-body">
    <section class="no-padding-top no-padding-bottom">
      <div class="container-fluid">
        <div class="row m-0 justify-content-center">
          <div class="col-md-4 mb-4 mx-auto">
            <div class="white_card bg-ltc p-4">
              <div class="row m-0">
                <div class="col-1 px-2">
                </div>
                <div class="col-7 px-4 d-flex">
                  <h6 class="my-auto">LITECOIN</h6>
                </div>
                <div class="col-4 p-0 d-flex">
                  <small class="my-auto ml-auto mr-0" id="ltc-change"></small>
                </div>
              </div>
              <hr class="bg-ltc mb-0">
              <?php 
              $action = current_url();
              $attributes = array('id'=>'myform','autocomplete'=>"off"); 
              echo form_open($action,$attributes);
              ?>
              <div id="ltcDepositAmount" class="py-2">
                <div id="ltcAmountInput" class="rounded row m-0">
                 <div class="col-2 p-0 d-flex">
                  <div class="m-auto bg-ltc py-1 px-3 rounded"><b><small class="text-center " id="ltc-toggle" 
                    style="cursor: pointer; color: rgb(44, 73, 85);">USD</small></b>
                  </div>
                </div>
                <input type="number" name="deposit_amount" class="col-10 input required" placeholder="Enter Deposit Value in $" id="ltcAmount" />
              </div>
              <hr class="bg-ltc">
              <div class="px-2">
                <button class="btn btn-ltc mx-1" id="depositLtcBtn"><small>DEPOSIT</small></button>
              </div>
            </div>
            <?php echo form_close();?> 
          </div>
        </div>
      </div>
    </div></section>    
  </div>
</div>


<!--Card Processing modal end-->
<!--========================== Footer ============================-->
<?php
$this->load->view('front/common/footer');
?>

<script type="text/javascript">

  $(document).ready(function () {

    $('#myform').validate({ // initialize the plugin
      rules: {
        deposit_amount: {
          required: true,
          number: true
        }
      }
    });

  });

</script>