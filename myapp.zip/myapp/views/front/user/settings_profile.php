<?php 
    $this->load->view('front/common/header');
    $user_id = $this->session->userdata('user_id');
    $kyc_status = $users->verify_level2_status;
?>
<style>
.upload_profile {
    min-width: 180px;
    /*background: #64afff;*/
    /*color: #fff;*/
    text-align: center;
    /*border:#fff;*/
}    
</style>
  <!-- breadcrumb -->
  <div class="me-breadcrumb">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="me-breadcrumb-box">
            <h1><?=$this->lang->line('Profile');?></h1>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- service single -->
  <div class="me-service-single me-padder-top me-padder-bottom">
<?php $this->load->view('front/user/sidebar_sticky');?>

    <div class="content-body">
        <div class="container">
            <div class="row">
                <div class="col-xxl-12 col-xl-12">
                    <div class="page-title">
                        <h4><?=$this->lang->line('Profile');?></h4>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-xxl-6 col-xl-6 col-lg-6">
                                    <div class="card">
                                        <div class="card-header">
                                            <h4 class="card-title"><?=$this->lang->line('User Profile');?></h4>
                                        </div>
                                        <div class="card-body">
                                        <?php 
                                            $attributes=array('id'=>'verification_profile_form',"autocomplete"=>"off"); 
                                              $action = front_url() . 'profile-edit';
                                            echo form_open_multipart($action,$attributes); 
                                        ?>  
                                                <div class="row g-3">
                                                    <div class="col-xxl-12 col-xl-12 col-lg-12" >
                                                        <label class="form-label"><?=$this->lang->line('Username');?></label>
                                                        <input type="text" value="<?=$users->tenrealm_username?>" name="username" id="username" class="form-control" placeholder="<?=$this->lang->line('Username');?>">
                                                    </div>

                                                    <!-- <div class="col-xxl-12">
                                                        <div class="form-file">
                                                            <label for="imgInp1" class="upload_btn upload_profile"><?=$this->lang->line('Upload Image');?></label>
                                                            <input type="file" name="profile_photo" id="imgInp1" class="imgInp" accept=".png, .jpg, .jpeg,">
                                                            <label class="form-file-label" for="customFile">
                                                            </label>
                                                        </div>
                                                    </div> -->
                                                    <div class="col-xxl-12">
                                                        <button type="submit" name="profile_form" class="btn btn-success waves-effect"><?=$this->lang->line('Save');?></button>
                                                    </div>
                                                </div>
                                            <?php echo form_close();?>
                                        </div>
                                    </div>
                                </div>
                                <!-- <div class="col-xxl-6 col-xl-6 col-lg-6">
                                    <div class="card">
                                        <div class="card-header">
                                            <h4 class="card-title">User Profile</h4>
                                        </div>
                                        <div class="card-body">
                                            <form action="#">
                                                <div class="row g-3">
                                                    <div class="col-xxl-12">
                                                      <?php $usermail = getUserEmail($users->id);?>
                                                        <label class="form-label">New Email</label>
                                                        <input type="email" id="email" name="email" disabled value="<?php echo ($usermail)?$usermail:'';?>" class="form-control" placeholder="Email">
                                                    </div>
                                                    <div class="col-xxl-12">
                                                        <label class="form-label">New Password</label>
                                                        <input type="password" name="password" class="form-control"
                                                            placeholder="**********">
                                                        <small class="mt-2 mb-0 d-block">Enable two factor authencation on the security page
                                                        </small>
                                                    </div>
                                                    <div class="col-12">
                                                        <button class="btn btn-success waves-effect">Save</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div> -->
                                <div class="col-xxl-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <h4 class="card-title"><?=$this->lang->line('Personal Information');?></h4>
                                        </div>
                                        <div class="card-body">
                                        <?php 
                                            $attributes=array('id'=>'verification_form',"autocomplete"=>"off"); 
                                              $action = front_url() . 'profile-edit';
                                            echo form_open_multipart($action,$attributes); 
                                        ?>  
                                                <div class="row g-4">
                                                    <div class="col-xxl-6 col-xl-6 col-lg-6">
                                                        <label class="form-label"><?=$this->lang->line('First Name');?></label>
                                                        <input type="text" class="form-control" id="firstname" name="firstname" value="<?=$users->tenrealm_fname?>" >
                                                    </div>
                                                    <div class="col-xxl-6 col-xl-6 col-lg-6">
                                                        <label class="form-label"><?=$this->lang->line('Last Name');?></label>
                                                        <input type="text" class="form-control" id="lastname" name="lastname" value="<?=$users->tenrealm_lname?>" >
                                                    </div>
                                                    <div class="col-xxl-6 col-xl-6 col-lg-6">
                                                      <?php $usermail = getUserEmail($users->id);?>
                                                        <label class="form-label"><?=$this->lang->line('Email');?></label>
                                                        <input type="email" id="email" name="email" disabled value="<?php echo ($usermail)?$usermail:'';?>" class="form-control">
                                                    </div>
                                                    <div class="col-xxl-6 col-xl-6 col-lg-6">
                                                        <label class="form-label"><?=$this->lang->line('Date of birth');?></label>
                                                        <input type="date" id="dob" name="dob" value="<?=$users->dob?>" class="form-control hasDatepicker" id="datepicker" autocomplete="off" >
                                                    </div>
                                                    <div class="col-xxl-6 col-xl-6 col-lg-6">
                                                        <label class="form-label"><?=$this->lang->line('Present Address');?></label>
                                                        <input type="text" id="street_address" name="street_address" value="<?=$users->street_address?>" class="form-control" >
                                                    </div>
                                                    <div class="col-xxl-6 col-xl-6 col-lg-6">
                                                        <label class="form-label"><?=$this->lang->line('Permanent Address');?></label>
                                                        <input type="text" id="street_address_2" name="street_address_2" value="<?=$users->street_address_2?>" class="form-control">
                                                    </div>
                                                    <div class="col-xxl-6 col-xl-6 col-lg-6">
                                                        <label class="form-label"><?=$this->lang->line('City');?></label>
                                                        <input type="text" id="city" name="city" class="form-control" value="<?php echo ($users->city)?$users->city:'';?>">
                                                    </div>
                                                    <div class="col-xxl-6 col-xl-6 col-lg-6">
                                                        <label class="form-label"><?=$this->lang->line('Postal Code');?></label>
                                                        <input type="text" class="form-control" id="postal_code" name="postal_code" value="<?php echo ($users->postal_code)?$users->postal_code:'';?>">
                                                    </div>
                                                    <div class="col-xxl-6 col-xl-6 col-lg-6">
                                                        <label class="form-label"><?=$this->lang->line('Country');?></label>
                                                        <select class="form-select" name="register_country" id="register_country">
                                                            <option value=""><?=$this->lang->line('Select');?></option>
                                                            <?php if($countries) {
                                                    foreach($countries as $co) {
                                                      ?>
                                                      <option <?php if($co->id==$users->country) { echo "selected"; } ?>
                                                      value ="<?php echo $co->id; ?>"><?php echo $co->country_name; ?></option>
                                                      <?php
                                                    }
                                                  } ?>

                                                            </option>
                                                        </select>
                                                    </div>


                                                    <div class="col-xxl-6 col-xl-6 col-lg-6">
                                                        <label class="form-label"><?=$this->lang->line('Phone Number');?></label>
                                                        <input type="text" class="form-control" id="phone" name="phone" value="<?php echo ($users->tenrealm_phone)?$users->tenrealm_phone:'';?>">
                                                    </div>
                                                    <div class="col-xxl-6 col-xl-6 col-lg-6">
                                                        <label class="form-label"><?=$this->lang->line('National TAX Number (TIN)');?></label>
                                                        <input type="text" class="form-control" id="national_tax_number" name="national_tax_number" value="<?php echo ($users->national_tax_number)?$users->national_tax_number:'';?>">
                                                    </div>

                                                    <div class="col-12 text-center">
                                                        <button type="submit" name="personal_form"  class="btn btn-success pl-5 pr-5 waves-effect"><?=$this->lang->line('Save');?></button>
                                                        <a style="font-weight:bold;margin:20px;color:#4699F2;display:block;" href="<?=base_url()?>settings"><?=$this->lang->line('Continue with your verification');?></a>
                                                    </div>
                                                </div>
                                            <?php echo form_close();?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
  </div>
  


<?php 
    $this->load->view('front/common/footer');
    ?>

    <script type="text/javascript">
        function readURLProfile(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#img-profile').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }
    $("#imageUpload").change(function() {
        readURLProfile(this);
    });

      $.validator.addMethod('ZipChecker', function() {
    }, 'Invalid zip code');
         $.validator.addMethod("lettersonly", function(value) {
    return (/^[a-zA-Z\s]*$/.test(value));
});

$('#verification_profile_form').validate({
    rules: {
        username: {
            required: true
        }
    },
    messages: {
        username: {
            required: "Please enter username"
        },
        
    }
});

    $('#verification_form').validate({
      rules: {
        firstname: {
          required: true
        },
        lastname: {
          required: true
        },
        dob: {
          required: true
        },
        street_address: {
          required: true
        },
        street_address_2: {
          required: true
        },
        city: {
          required: true,
          lettersonly: true
        },
        state: {
          required: true,
          lettersonly: true
        },
        register_country: {
          required: true,
        },
        postal_code: {
          required: true,
          number: true,
          maxlength: 7,
          ZipChecker: function(element) {
          values=$("#postal_code").val();

           if( values =="0" || values =="00" || values =="000" || values =="0000" || values =="00000"  || values =="000000"   || values =="0000000" )
           {
              return true;
              
           }
           
           }

        },
        phone: {
          required: true
        },
        national_tax_number: {
            required: true
        }
      },
      messages: {
        firstname: {
          required: "<?=$this->lang->line('Please enter first name');?>"
        },
        lastname: {
          required: "<?=$this->lang->line('Please enter last name');?>"
        },
        dob: {
          required: "<?=$this->lang->line('Please enter DOB');?>"
        },
        street_address: {
          required: "<?=$this->lang->line('Please enter present address');?>"
        },
        street_address_2: {
          required: "<?=$this->lang->line('Please enter permanent address');?>"
        },
        city: {
          required: "<?=$this->lang->line('Please enter city');?>",
          lettersonly: "<?=$this->lang->line('Please enter letters only');?>"
        },
        state: {
          required: "<?=$this->lang->line('Please enter state');?>",
          lettersonly: "<?=$this->lang->line('Please enter letters only');?>"
        },
        register_country: {
          required: "<?=$this->lang->line('Please select country');?>"
        },
        postal_code: {
          required: "<?=$this->lang->line('Please enter postal code');?>"
        },
        phone: {
          required: "<?=$this->lang->line('Please enter phone number');?>"
        },
        national_tax_number: {
          required: "<?=$this->lang->line('Please enter national tax number');?>"
        }
      }
    });

status = '<?=$kyc_status?>';
if(status=='Completed') {
    $(":input").attr('disabled','disabled');
}

    </script>