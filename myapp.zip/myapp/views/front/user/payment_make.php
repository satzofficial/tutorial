
<?php
 
 
 
 
 

 
$favicon  =  ($site_common['site_settings']->site_favicon) ? $site_common['site_settings']->site_favicon :'';
$english_site_name  =  ($site_common['site_settings']->english_site_name) ? $site_common['site_settings']->english_site_name :'';
$sitelogo = ($site_common['site_settings']->site_logo) ? $site_common['site_settings']->site_logo :'';
$site_email = ($site_common['site_settings']->site_email) ? $site_common['site_settings']->site_email :'';
$assets_url_var = base_url('assets/front/');
$base_url_var = base_url();
$csrf_name = $this->security->get_csrf_token_name(); // for the name
$csrf_token = $this->security->get_csrf_hash();  // for the value
$class = $this->router->fetch_class();
$method = $this->router->fetch_method();
    ?>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">

 <script src="<?php echo $assets_url_var; ?>js/jquery.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var; ?>js/jquery-ui.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var; ?>js/bootstrap.min.js?v=<?php echo date('Ymdhis'); ?>"></script>

<!-- <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>

<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
 -->
<!------ Include the above in your HEAD tag ---------->

<style type="text/css">
  .error{
    color:red;
  }
</style>

<div class="">  




<?php 

if($method=='deposit_page'){

if($currency=='USDT'){
    $currency_value=$user->beb_address;
    $deposit_address=$site_common['site_settings']->usdt_address;
    $deposit_qr=$site_common['site_settings']->usdt_image;
}

if($currency=='BUSD'){
    $currency_value=$user->busd_address;
    $deposit_address=$site_common['site_settings']->busd_address;
    $deposit_qr=$site_common['site_settings']->busd_image;
    
}

    
}else{
   if($currency=='USDT'){
    $currency_value=$user->beb_address;
    // $deposit_address=$site_common['site_settings']->usdt_address;
    // $deposit_qr=$site_common['site_settings']->usdt_image;
}

if($currency=='BUSD'){
    $currency_value=$user->busd_address;
    // $deposit_address=$site_common['site_settings']->bust_address;
    // $deposit_qr=$site_common['site_settings']->busd_image;
    
}
 
    
    
}
?>

    <div id="signupbox" style=" margin-top:50px" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">

        <div class="panel panel-info">

            <div class="panel-heading">

                <div class="panel-title"></div>

                <!--     <div style="float:right; font-size: 85%; position: relative; top:-10px"><a id="signinlink" href="/accounts/login/">Sign In</a></div> -->

            </div>  

            <div class="panel-body" >

<?php if($method=='deposit_page'){ ?>

               <img  style="    height: 148px;

               width: 195px;" src="<?php echo $deposit_qr; ?>"/>
               
               
               <?php } ?>







               <form id="subForm" method="post" action="" enctype="multipart/form-data">

                <input type='hidden' name="<?php  echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash();?>" />

                <form  class="form-horizontal" method="post" >

                  <!--       <div id="div_id_select" class="form-group required">

                            <label for="id_select"  class="control-label col-md-4  requiredField"> Select<span class="asteriskField">*</span> </label>

                            <div class="controls col-md-8 "  style="margin-bottom: 10px">

                                <label class="radio-inline"><input type="radio" checked="checked" name="select" id="id_select_1" value="S"  style="margin-bottom: 10px">Knowledge Seeker</label>

                                <label class="radio-inline"> <input type="radio" name="select" id="id_select_2" value="P"  style="margin-bottom: 10px">Knowledge Provider </label>

                            </div>

                        </div> 

                    -->


<?php if($method=='withdraw_page'){ ?>
                    <p>Confirm Your Withdrawal USDT/BUSD(Bep 20) Address</p>
                    
                    
                    <?php } else { ?>
                    
                     <p>Please Copy Deposit Address</p>
                    
                    <?php  } ?>

                    <div id="div_id_name" class="form-group required"> 



                        <div class="controls col-md-10"> 
<?php if($method=='deposit_page'){ ?>
                            <input readonly class="input-md textinput textInput form-control"   id="copy_top_header" name="name" value="<?php 
                          // echo getadminAddress(1,'LTC');
echo $deposit_address;
                            ?>" style="margin-bottom: 10px" type="text" readonly />
<?php }?>             </div>
<?php if($method=='deposit_page'){ ?>
                        <div class="controls col-md-2 "> 

                            <button id="copy_top_header_button">Copy text</button>
                            <span  class="badge bg-green-lt mt-1 show_copied_to_clipboard" style="display: none;     display: none;
    transition: all 0.5s ease 0s;
    inset-block: auto;
    width: 100%;" id="show_copied_to_clipboard">Copied to clipboard!</span>
                        </div>
                        
                        <?php } ?>

                    </div>

<?php if($method=='deposit_page'){ ?>
<p>Your Address</p> 

<div class="controls col-md-12 "> 

        <input class="input-md textinput textInput form-control" id="user_address" name="user_address"  value="<?php echo $currency_value;    ?>" style="margin-bottom: 10px" type="text" required="required" />

    </div>

<?php } else { ?>

<p>Your Withdrawal Address</p> 
<div class="controls col-md-12 "> 

        <input class="input-md textinput textInput form-control" id="user_address" name="user_address"  value="<?php echo $currency_value;    ?>" style="margin-bottom: 10px" type="text" required="required" />

    </div>

<p>Please Enter Your Withdrawal Amount</p> 

<?php  } ?>

<div id="div_id_name" class="form-group required"> 


 



    <div class="controls col-md-12 "> 

        <input class="input-md textinput textInput form-control" id="amount" name="amount" placeholder="Please Your amount" style="margin-bottom: 10px" type="text" required="required" />

    </div>

</div>


<?php if($method=='deposit_page'){ ?>
<p>Please Enter Your Transaction Hash</p> 

<div id="div_id_name" class="form-group required"> 



    <div class="controls col-md-12 "> 

        <input class="input-md textinput textInput form-control" id="hash" name="hash" placeholder="Please Phast Your Hash" style="margin-bottom: 10px" type="text"   required="required" />

    </div>

</div>



<p>Please Upload Transaction image</p>

<div id="div_id_name" class="form-group required"> 



    <div class="controls col-md-12 "> 

        <input class="input-md textinput textInput form-control" id="id_name" name="profile_photo" placeholder="Please upload image" style="margin-bottom: 10px" type="file"  required="required" />

    </div>

</div>


<?php } ?>




<div class="form-group"> 

    <div class="aab controls col-md-4 "></div>

    <div class="controls col-md-8 ">

     <input type="submit" name="Signup" value="Confirm" class="btn btn btn-primary"  id="button-id-signup" />

 </div>

</div> 



</form>



</form>

</div>

</div>

</div> 

</div>













</div>            


<!--==================================================================-->
<!-- <script src="<?php echo $assets_url_var; ?>js/jquery.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var; ?>js/jquery-ui.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var; ?>js/bootstrap.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var; ?>js/fontawesome.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var; ?>js/plugin/slick.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var; ?>js/waypoint.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var; ?>js/plugin/jquery.nice-select.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var; ?>js/wow.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var; ?>js/plugin/plugin.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var; ?>js/main.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var; ?>js/main_1.js?v=<?php echo date('Ymdhis'); ?>"></script> -->


<script src="<?php echo $assets_url_var;?>js/jquery.validate.min.js?v=<?php echo date('Ymdhis'); ?>"></script>
<script src="<?php echo $assets_url_var;?>js/additional-methods.js?v=<?php echo date('Ymdhis'); ?>"></script>

<script type="text/javascript">



   $(document).ready(function() {





    var enrollType;

  //  $("#div_id_As").hide();

  $("input[name='As']").change(function() {

    memberType = $("input[name='select']:checked").val();

    providerType = $("input[name='As']:checked").val();

    toggleIndividInfo();

});



  $("input[name='select']").change(function() {

    memberType = $("input[name='select']:checked").val();

    toggleIndividInfo();

    toggleLearnerTrainer();

});



  function toggleLearnerTrainer() {



    if (memberType == 'P' || enrollType=='company') {

        $("#cityField").hide();

        $("#providerType").show();

        $(".provider").show();

        $(".locationField").show();

        if(enrollType=='INSTITUTE'){

            $(".individ").hide();

        }



    } 

    else {

        $("#providerType").hide();

        $(".provider").hide();

        $('#name').show();

        $("#cityField").hide();

        $(".locationField").show();

        $("#instituteName").hide();

        $("#cityField").show();

        

    }

}

function toggleIndividInfo(){



    if(((typeof memberType!=='undefined' && memberType == 'TRAINER')||enrollType=='INSTITUTE') && providerType=='INDIVIDUAL'){

        $("#instituteName").hide();

        $(".individ").show();

        $('#name').show();

    }

    else if((typeof memberType!=='undefined' && memberType == 'TRAINER')|| enrollType=='INSTITUTE'){

        $('#name').hide();

        $("#instituteName").show();

        $(".individ").hide();

    }

}



});


var baseURL = "<?php echo base_url(); ?>";
var csrf_name = "<?php  echo $this->security->get_csrf_token_name(); ?>"; // for the name
var csrf_token = "<?php  echo $this->security->get_csrf_hash(); ?>";  // for the value   


    $(document).ready(function () {        
        $.validator.addMethod('totalCheck', function(value, element, params) {
            var field_1 = $('#number1').val(),
            field_2 = $('#number2').val();
            return parseInt(value) === (parseInt(field_1) + parseInt(field_2));
        }, "Enter the valid number");


     $.validator.addMethod("email_or_mobile", function(value, element) {

        if(/^\d|\w{10,10}$/.test(value)){
            value.replace(/\s+/, "");
        }
        return /^\d|\w{10,10}$/.test(value) || /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(value) //email or No
    }, "Please enter valid email or 16 digit number");



        $('#subForm').validate({ // initialize the plugin
            rules: {
                first_name: {
                    required: {
                        depends:function(){
                            $(this).val($.trim($(this).val()));
                            return true;
                        }
                    },           
                },
                last_name: {
                    required: {
                        depends:function(){
                            $(this).val($.trim($(this).val()));
                            return true;
                        }
                    },
                },
                tenrealm_email: {
                    required: {
                        depends:function(){
                            $(this).val($.trim($(this).val().replace(/\s+/, "")));
                            return true;
                        }
                    },                    
                    email_or_mobile: true,
                    remote: function() {
                                    var email = $('#tenrealm_email').val();                                    
                                    // if(/^\d{11,11}$/.test(email)){ return;}
                                    // if(/^\d$/.test(email)){ return;}   
                                    if(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(email)){
                                        return { url: baseURL + "is-not-email-exist",type: 'post',data: {'tenrealm_email':email} }    
                                    }                                    
                            },
                },
                tenrealm_password: {
                    required: {
                        depends:function(){
                            $(this).val($.trim($(this).val()));
                            return true;
                        }
                    },
                    minlength: 5
                },

            },
             messages: {
                first_name: "Enter your firstname",
                last_name: "Enter your lastname",
                tenrealm_email: {
                    required: "Enter a User ID or Email",
                    remote: jQuery.validator.format("This {0} does not exist")
                },                
            },
            errorPlacement: function(error, element) {                
              if(element.attr("name") == "tenrealm_password") {                
                error.appendTo( element.parent("div").parent('.single-input').find("div#tenrealm_password_error") );
            } else {
                error.insertAfter(element);
            }
        }
    });


    });



 $(document).ready(function() {

      $.fn.displayDecryptData = function(data){
        return CryptoJSAesJson.decrypt(data, DecryptPassword);
      }
    
      $('.copy-coinprice').tooltip();
  
     document.getElementById("copy_top_header_button").addEventListener("click", copy_password);
    function copy_password(e) {
      e.preventDefault();
      e.stopPropagation();

      var copyText = document.getElementById("copy_top_header");
      var textArea = document.createElement("textarea");

      document.body.appendChild(textArea);
      textArea.value = copyText.value;
      my_textarea = textArea;
      my_textarea.onfocus = function () {
       my_textarea.select();
       my_textarea.onfocus = undefined;
     } 
     // my_textarea.focus();
     // my_textarea.focus();
     my_textarea.select();
     document.execCommand("Copy");    
     textArea.remove();    
     document.getElementById("show_copied_to_clipboard").style.display = "flex";
     setTimeout(function() {
      var loader = document.getElementById("show_copied_to_clipboard");
      loader.style.transition = '.5s';
      // loader.style.opacity = '0';
      loader.style.visibility = 'none';
      loader.style.display = 'none';
    }, 1250);

   }
   });







</script>