<?php 
    $this->load->view('front/common/header');

    $this->load->view('front/common/flashmessage'); 
    $user_id = $this->session->userdata('user_id');

     $all_currency = $this->common_model->getTableData("currency",array("status"=>1))->result();
     //echo '<pre>';print_r($all_currency);
      if(count($all_currency))
      {
        $tot_balance = 0;
        $tot_Euro_balance = 0;
        foreach($all_currency as $cur)
        {
            $balance = getBalance($user_id,$cur->id);
            //echo $cur->online_usdprice.'--';
            //echo $cur->online_usdprice.'--';
            $usd_balance = $balance * $cur->online_usdprice;
            $eur_balance = $balance * $cur->online_europrice;

            $tot_balance += $usd_balance;
            $tot_Euro_balance += $eur_balance;
        }
      }
?>
<style type="text/css">
    
.bs-tabs .nav-tabs { margin-bottom: 2px;
    background: #f4f4f4; }
    .bs-tabs .nav-tabs > li.active > a, .nav-tabs > li.active > a:focus, .nav-tabs > li.active > a:hover { border-width: 0; }
    .bs-tabs .nav-tabs > li > a { border: none; color: #000;padding: 10px 30px;       display: block;  background: #f4f4f4;}
        .bs-tabs .nav-tabs > li.active > a, .bs-tabs .nav-tabs > li > a:hover { border: none;  color: #000 !important; }
        .bs-tabs .nav-tabs > li > a::after { content: ""; height: 2px; position: absolute; width: 100%; left: 0px; bottom: -1px; transition: all 250ms ease 0s; transform: scale(0); }
    .bs-tabs .nav-tabs > li.active > a::after, .bs-tabs .nav-tabs > li:hover > a::after { transform: scale(1);  }
.bs-tabs .tab-nav > li > a::after {  color: #fff; }
.bs-tabs .tab-pane { padding: 15px 0; }
.bs-tabs .tab-content{padding:20px;     background: #f4f4f4;}
.bs-tabs .nav-tabs > li  {    /* width: 20%; */
    text-align: center;
    color: #000;

    margin-right: 2px;}
.bs-tabs .nav-tabs > li a.active  {
    background: #4699F2; color:#FFF !important;
}


@media all and (max-width:724px){
.bs-tabs .nav-tabs > li > a > span {display:none;}   
.bs-tabs .nav-tabs > li > a {padding: 5px 5px;}
}

 #chart-area, #widget-container, .tv-main-panel {background: #000;}
.chart-page .chart-container {border: black solid 0;}

.deposit-btn {
  background: #28a745;
}
.withdraw-btn1 {
  color: black;
  background: #FFA500;
}
.wallet-button {
  color: #fff;
  background: #dc3545;
}
.me-login-title {
  font-size:16px;
}
.wallet-table-btn {
  min-width: 70px;
}
.basic-btn {
  background:#04c;
}
</style>

  <!-- breadcrumb -->
  <div class="me-breadcrumb">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="me-breadcrumb-box">
            <h1><?=$this->lang->line('Wallet');?></h1>
          </div>
        </div>
      </div>
    </div>
  </div>

<div class="me-service-single me-padder-top me-padder-bottom">
<?php $this->load->view('front/user/sidebar_sticky');?>

    <div class="content-body">
      <div class="container">
    <div class="row">
        <div class="col-lg-6">
          <div class="inner-page-header">
            <h2></h2>
          </div>
        </div>
  
        <div class="col-lg-6">
          <div class="wallet-value"> 
            <!-- <p><?=$this->lang->line('Estimated Value');?> USDT:<span> <?=number_format($tot_balance, 2);?> </span></p> -->
            <p><?=$this->lang->line('Estimated Value');?> EURO:<span> <?=number_format($tot_Euro_balance, 2);?> </span></p>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12">
          <div class="wallet-table">
            <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr>
                    <th><?=$this->lang->line('Coin');?></th>
                    <th><?=$this->lang->line('Name');?></th>
                    <th><?=$this->lang->line('Available Balance');?></th>
                    <!-- <th>USDT <?=$this->lang->line('Value');?></th> -->
                    <th>Euro <?=$this->lang->line('Value');?></th> 
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                    if(count($dig_currency) >0)
                    {
                       foreach ($dig_currency as $digital) 
                     {
                    if($digital->type=="fiat")
                    {
                        $format = 2;
                    }
                    elseif($digital->currency_symbol=="USDT")
                    {
                        $format = 6;
                    }
                    else
                    {
                        $format = 6;
                    }
                    $coin_price_val = to_decimal($wallet['Exchange AND Trading'][$digital->id], $format);
                    $coin_price = $coin_price_val * $digital->online_usdprice;

                    $userbalance = getBalance($user_id,$digital->id);
                    $USDT_Balance = $userbalance * $digital->online_usdprice;
                    // $EURO_Balance = bcmul($userbalance ,$digital->online_europrice);
                    if($digital->id==9) {
                      $EURO_Balance = $userbalance;
                    } else {
                      // echo $userbalance.'---'.$digital->online_europrice;
                      $EURO_Balance = abs($userbalance*$digital->online_europrice);
                    }
                    
                    $pairing = $this->common_model->getTableData('trade_pairs',array('from_symbol_id'=>$digital->id,'status'=>1))->row();
                      if(!empty($pairing))
                      {
                          $fromid = $pairing->from_symbol_id;
                          $fromcurr = $this->common_model->getTableData('currency',array('id'=>$fromid,'status'=>1))->row();
                          $fromSYM = $fromcurr->currency_symbol;
                          $toid = $pairing->to_symbol_id;
                          $tocurr = $this->common_model->getTableData('currency',array('id'=>$toid,'status'=>1))->row();
                          $toSYM = $tocurr->currency_symbol;

                          $traDepair = $fromSYM."_".$toSYM; 
                      }
                      else
                      {
                         $pairing = $this->common_model->getTableData('trade_pairs',array('to_symbol_id'=>$digital->id,'status'=>1))->row();
                         if(!empty($pairing))
                      {
                          $fromid = $pairing->to_symbol_id;
                          $fromcurr = $this->common_model->getTableData('currency',array('id'=>$fromid,'status'=>1))->row();
                          $fromSYM = $fromcurr->currency_symbol;

                          $toid = $pairing->from_symbol_id;
                          $tocurr = $this->common_model->getTableData('currency',array('id'=>$toid,'status'=>1))->row();
                          $toSYM = $tocurr->currency_symbol;

                          $traDepair = $toSYM."_".$fromSYM;
                      }
                      } 

                        $curId = encryptIt($digital->id);   

                      if($digital->currency_symbol=='EUR') {
                        
                        $depositText = 'Recharge';
                        $withdrawText = 'Withdraw button';
                      } else {
                        $depositText = 'Deposit button';
                        $withdrawText = 'Send';
                      }      
                        ?>
                        <tr>
                        <td><img style="margin-right:10px;" width="30px" height="30px" src="<?php echo $digital->image;?>" class="table-cryp"><span><?=$digital->currency_symbol;?></span></td>
                        <td><?php echo $digital->currency_name;?></td>
                        <td><?php echo $userbalance; ?></td>
                        <td><?php echo $EURO_Balance; ?></td> 
                        <!-- <td><?php echo number_format($EURO_Balance,2, '.', ''); ?></td>  -->
                        <td class="text-right d-flex justify-content-end">
                        <div class="col-lg-2">  
                          <?php $basic_pairId = array(1,2,3,7,9);
                          if(in_array($digital->id, $basic_pairId)) {?>
                            <a href="<?php echo base_url().'basic-exchange/'.$digital->currency_symbol.'_EUR'?>" class="wallet-table-btn basic-btn"><?=$this->lang->line('Buy/Sell');?></a>
                          <?php }?>
                        </div>

                        <div class="col-lg-3">
                          <a href="<?php echo base_url().'transaction_history/'.$curId;?>" class="wallet-table-btn wallet-button"><?=$this->lang->line('Transactions');?></a>
                        </div>  
                        <div class="col-lg-2">  
                          <a href="<?php echo base_url(); ?>withdraw/<?php echo $digital->currency_symbol;?>" class="wallet-table-btn withdraw-btn1"><?=$this->lang->line($withdrawText);?></a>
                        </div>  
                        <div class="col-lg-2">
                          <a href="<?php echo base_url(); ?>deposit/<?php echo $digital->currency_symbol;?>" class="wallet-table-btn deposit-btn"><?=$this->lang->line($depositText);?></a>  
                        </div>  
                        <div class="col-lg-2">
                          <a href="<?php echo base_url(); ?>trade/<?=$traDepair?>" class="wallet-table-btn"><?=$this->lang->line('Trading');?></a>
                        </div>  
                          
                        </td>
                    </tr>
                    <?php }}?>
                           


                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
         
        </div>     </div>

     </div>   



<?php 
 if($this->session->userdata('address')) {

?>
<div class="modal fade me-login-model address-modal">
      <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
              <button type="button" class="close me-team-close close-adrbook" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span>
              </button>
              <div class="modal-body">
                  <h1 class="me-login-title"><?=$this->lang->line('You performed an operation with this address. Do you want to add it to your address book?')?></h1>
                  <?php 
                      $faction = front_url()."address_book";
                      $fattributes = array('id'=>'address_book'); 
                      echo form_open($faction,$fattributes);
                  ?>
                      <div class="me-login-form">
                        <input type="text" id="filename" name="filename" placeholder="Name">
                        <input readonly type="text" id="coin" name="coin" placeholder="Coin" value="<?=$this->session->userdata('coin')?>">
                        <input readonly type="text" id="address" name="address" placeholder="Address" value="<?=$this->session->userdata('address')?>">
                        <div class="me-login-btn" style="margin-bottom: 10px;">
                          <button class="me-btn"><?=$this->lang->line('Save');?></button>
                        </div>
                      </div>
                  <?php
                      echo form_close();
                      ?>
                  
              </div>
          </div>
      </div>
  </div>

<?php }?>

    <!--========================== Footer ============================-->
    <?php
$this->load->view('front/common/footer');
    ?>

<script>
$('.address-modal').modal('show');  
$('#address_book').validate({
    rules: {
        filename: {
            required: true,
        },           
        coin: {
            required: true,
        },
        address: {
            required: true,
        }
    },
    messages: {
        filename: {
            required: 'Please enter Name',
        },
        coin: {
            required: 'Please enter coin',
        },
        address: {
            required: 'Please enter address',
        }
    }
});

var front_url='<?php echo front_url();?>';
$(document).on('click', '.close-adrbook', function() {

  var success = "<?=$this->lang->line('Cancelled successfully');?>";
  $.ajax({
    url: front_url+"address_destroy", 
    type: "GET",             
    success: function(data) {
      $.growl.notice({location: "cc",size:"large", title: "Share Coin Exchange", message: success });
    }
  });

});
</script>