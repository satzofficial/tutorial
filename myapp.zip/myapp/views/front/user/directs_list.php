<?php include realpath(dirname(__DIR__) . '/common/inner_header.php'); 
$prefix = get_prefix();
?>
<div class="page-body">
   <div class="container-xl">
      <ol class="breadcrumb breadcrumb-arrows mb-3" aria-label="breadcrumbs">
         <li class="breadcrumb-item"><a href="#">Affiliate</a></li>
         <li class="breadcrumb-item active" aria-current="page">Directs<span class="badge ms-2"><?php echo ($h = $overall_direct_count) ? $h : 0; ?></span></li>
      </ol>
      <div class="row row-cards">
         <div class="col-sm-12">
            <div class="card shadow radius-20">
               <div class="card-body">
                  <h4 class="card-title">All Level Directs</h4>
                  <div class="row">
                     <div class="">
                        <ul class="nav nav-tabs" data-bs-toggle="tabs">
                           <?php 
                               if($packages_arr){
                                 foreach ($packages_arr as $pack_key => $pack_value) {                                  
                                  $pack_key  =  $pack_key + 1;
                                  $pack_name = ($pack_value['package_name']) ? $pack_value['package_name'] :'';
                                  $package_id = ($pack_value['id']) ? $pack_value['id'] :'';
                               ?>
                               <li class="nav-item">
                                 <a href="#tabs-<?php echo $pack_key; ?>" class="nav-link user-nav-link <?php if($pack_key==1){ echo 'active'; } ?>" data-bs-toggle="tab" data-nav_package_id="<?php echo $package_id; ?>">
                                    <span class="lg-block"><?php echo $pack_name; ?></span> 

                                    <span class="xs-block">


                                       <?php if($pack_key==1){ ?>
                                       <!-- Download SVG icon from http://tabler-icons.io/i/moon-2 -->
                                       <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                        <path d="M16.418 4.157a8 8 0 0 0 0 15.686" />
                                        <circle cx="12" cy="12" r="9" />
                                     </svg>

                                  <?php }else if($pack_key==2){ ?>

                                     <!-- Download SVG icon from http://tabler-icons.io/i/target -->
                                     <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                        <circle cx="12" cy="12" r="1" />
                                        <circle cx="12" cy="12" r="5" />
                                        <circle cx="12" cy="12" r="9" />
                                     </svg>

                                 <?php }else if($pack_key==3){ ?>

                                     <!-- Download SVG icon from http://tabler-icons.io/i/moon-stars -->
                                     <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                        <path d="M12 3c.132 0 .263 0 .393 0a7.5 7.5 0 0 0 7.92 12.446a9 9 0 1 1 -8.313 -12.454z" />
                                        <path d="M17 4a2 2 0 0 0 2 2a2 2 0 0 0 -2 2a2 2 0 0 0 -2 -2a2 2 0 0 0 2 -2" />
                                        <path d="M19 11h2m-1 -1v2" />
                                     </svg>

                                 <?php }else if($pack_key==4){ ?>

                                     <!-- Download SVG icon from http://tabler-icons.io/i/omega -->
                                     <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M4 19h5v-1a7.35 7.35 0 1 1 6 0v1h5" /></svg>

                                       <?php }else if($pack_key==5){ ?>

                                     <!-- Download SVG icon from http://tabler-icons.io/i/moon -->
                                     <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                        <path d="M12 3c.132 0 .263 0 .393 0a7.5 7.5 0 0 0 7.92 12.446a9 9 0 1 1 -8.313 -12.454z" />
                                     </svg>

                                    <?php }else{ ?>
                                     <!-- Download SVG icon from http://tabler-icons.io/i/sun -->
                                     <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                        <circle cx="12" cy="12" r="4" />
                                        <path d="M3 12h1m8 -9v1m8 8h1m-9 8v1m-6.4 -15.4l.7 .7m12.1 -.7l-.7 .7m0 11.4l.7 .7m-12.1 -.7l-.7 .7" />
                                     </svg>
                                    <?php } ?>

                                  </span>

                               </a>
                            </li>

                            <?php } }  ?>


                        </ul>

                        <div class="card-body border-n">
                           <div class="tab-content">
                               <?php 
                              
                               if($packages_arr){
                                 foreach ($packages_arr as $pack_keys => $pack_value) {
                                  $pack_keys  =  $pack_keys + 1;
                                  $pack_name = ($pack_value['package_name']) ? $pack_value['package_name'] :'';
                                  $package_id = ($pack_value['id']) ? $pack_value['id'] :'0';
                               ?>
                            <div class="tab-pane <?php if($pack_keys==1){ echo 'active'; } ?> show" id="tabs-<?php echo $pack_keys; ?>">
                              <?php 
                              if($pack_keys == 1){
                                    echo '<input type="hidden" name="package_id" class="package_id" id="package_id" value="'.$package_id.'">';  
                                }
                              ?>
                            <div>
                                    <h4><?php echo $pack_name; ?></h4>
                                    <div id="direct-list-content-by-user-<?php echo $package_id; ?>" class="row row-cards direct-list-content-by-user-<?php echo $package_id; ?>">
                                    </div>
                                    <!-- Paginate -->
                                    <div class="pagination justify-content-center mt-2" id='pagination-<?php echo $package_id; ?>'></div>
                                 </div>
                              </div>
                               <?php } }  ?>                         
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>


<div class="modal modal-blur fade prfile-dir" id="modal-report" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog modal-lg modal-dialog-centered" role="document">
   <div class="modal-content shadow radius-20">
      <div class="modal-header">
         <h5 class="modal-title"><span id="popup-pro-name"> </span>  Profile</h5>
         <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
         <div class="row g-2 ">

            <div class="col-auto align-top" id="popup-profile-img"> </div>
            <div class="col">
                <input type="hidden" name="popup_id" id="popup-hidden-user-id" value="">
               <h4 class="card-title m-0" id="popup-username">  </h4>
               <div class="text-muted" id="popup-unique-id"> Id:  </div>
               <div class="text-muted" id="popup-email"> Mailid: </div>
               <div class="text-muted" id="popup-date-of-joining"> </div>
               <div class="text-muted" id="popup-date-total-earning"> </div>
            </div>
            <div class="col-12">
               <div class="card border-0 shadow-n">
                  <div class="card-body">
                     <div class="divide-y">
                        <div class="row popup-all-package" id="popup-all-package">
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="modal-body">
            <div class="card none-card" style="height: calc(13.6rem + 10px)">
               <div class="card-body card-body-scrollable card-body-scrollable-shadow">
                  <div class="row" id="popup-package-user-profile-list">
                  </div>
               </div>
            </div>
              <!-- Paginate -->
              <div id='pagination-popup'></div>
         </div>         
         <div class="modal-footer"> <a href="#" style="display: none;" class="btn btn-link link-secondary back-history-btn" data-back_popup_ids="" > Back </a>  <a href="#" class="btn btn-link link-secondary direct-cancel-btn" data-bs-dismiss="modal"> Cancel </a> </div>
      </div>
   </div>
</div>
</div>

<?php include realpath(dirname(__DIR__) . '/common/inner_footer.php'); ?>
<script type="text/javascript">
  $(document).ready(function() {
      var backNow = $('.back-history-btn');
      var backArrayPushItem = [];

     function showDialog2() {
            $("#dialog1").removeClass("fade").modal("hide");
            $("#dialog2").addClass("fade").modal("show");
        }
        $(function () {
            $("#dialog1").modal("show");
            $("#dialog-ok").on("click", function () {
                showDialog2();
            });
        });


        var currentPackageId = $('#package_id').val();
        $(document).on('click','.user-nav-link', function(e){
          e.preventDefault();
          var currentPackageId = $(this).data('nav_package_id');
          $('#package_id').val(currentPackageId);   
          loadPagination(0);      
        });

        


        $.fn.allpurchasedPackageList = function(package, userPackage){
            var list = '';
            $.each(package, function(index, val) {
               /* iterate through array or object */
               if ((userPackage.includes(val.id)) ){                  
                    var avatar = 'avatar bg-green-lt';
                    var badge = 'badge bg-green';                    
                }else{
                    var avatar = 'avatar bg-red-lt';
                    var badge = 'badge bg-red';                 
                }

                 list +='<div class="atv-mlm col-6">\
                                <div class="row" >\
                                   <div class="col-auto">\
                                      <span class="'+ avatar +'">\
                                         <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">\
                                            <path stroke="none" d="M0 0h24v24H0z" fill="none"/>\
                                            <circle cx="12" cy="7" r="4" />\
                                            <path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2" />\
                                         </svg>\
                                      </span>\
                                   </div>\
                                   <div class="col">\
                                      <div class="text-truncate"> <strong>'+val.package_name+'</strong> </div>\
                                   </div>\
                                   <div class="col-auto align-self-center">\
                                      <div class="'+badge+'"></div>\
                                   </div>\
                                </div>\
                             </div>';

            });
               
                return list;

        }


        $.fn.fetchedUserData = function(id){

          $.ajax({
              url: baseURL + 'display-direct-list-personal',
              type: 'POST',
              dataType: 'json',
              data: {'csrf_name' : csrf_token, 'id' : id},
              success: function(result){
                if(result.status == true){
                  let decrypt = $.fn.displayDecryptData(result.data);
                  if(decrypt.personal.pp_status == 1){
                    var pp = decrypt.personal.pp;
                    var popupProfileImg = '<span class="avatar avatar-lg" style="background-image: url('+ pp +')"></span>';
                  }else{
                    var popupProfileImg = '<span class="avatar avatar-lg" style="background-image: url('+ avatarImage +')"></span>';
                    // var popupProfileImg = '<span class="avatar avatar-lg" > ' + decrypt.personal.short_name+ '</span>';
                  }                  
                  $('#popup-hidden-user-id').val(id);
                  $('#popup-profile-img').html(popupProfileImg);
                  $('#popup-username').html(decrypt.personal.name);
                  $('#popup-pro-name').html(decrypt.personal.fname);
                  $('#popup-unique-id').html('Id : ' + decrypt.personal.unique_id);
                  $('#popup-email').html('Email Address : ' + decrypt.personal.email);
                  $('#popup-date-of-joining').html('Joining Date/Time : ' + decrypt.personal.date_of_joinings + ' UTC');
                  $('#popup-date-total-earning').html('Total Earning : ' + decrypt.personal.total_earning);
                  $('#popup-all-package').html($.fn.allpurchasedPackageList(decrypt.packages_arr, decrypt.user_packages_arr));
                  loadPopUpPagination(0);
                  // if(decrypt.length<1) {
                  
                  // }
                  $('#modal-report').modal('show');
                }

              }
          });

        }

      $(document).on('click', '.print_user_detail_popup', function(){
        var _this = $(this);
        backNow.attr('data-back_popup_ids', '').hide();
        backArrayPushItem.splice(0, backArrayPushItem.length);        
        var id = _this.data('ids'); 
        backArrayPushItem.push(id);
        backNow.attr('data-back_popup_ids', backArrayPushItem);        
        $.fn.fetchedUserData(id);        
      });
    
    $(document).on('click', 'a.deirect-pagination-cls', function(event) {
      event.preventDefault();
      /* Act on the event */
       var pageno = $(this).attr('data-ci-pagination-page');       
       loadPagination(pageno);
    });
 
     loadPagination(0);
 
     function loadPagination(pagno){
      var package_id = $('#package_id').val();
       $.ajax({
         url: baseURL + 'display-direct-list/'+ pagno,
         type: 'get',
          data: {'package_id' : package_id},
         dataType: 'json',
         success: function(response){
            let decrypt = $.fn.displayDecryptData(response.data);            
            createList(decrypt.result, decrypt.row);
            $('#pagination1').html(decrypt.pagination);
            $('.pagination').html(decrypt.pagination);
         }
       });
     }
 
     function createList(result,sno){
            
       var package_id = $('#package_id').val();
       console.log('package_id',package_id);
       sno = Number(sno);
       var bodyContent = $('#direct-list-content-by-user-' + package_id);
       bodyContent.empty();       
        $.each(result, function(index, val) {
           /* iterate through array or object */
           
           var name = val.name;
           var short_name = val.short_name;
           var image = val.pp;
           var id = val.id;
           var unique_id = val.unique_id;
           if(val.pp_status == true){
            var icon = '<span class="avatar avatar-xl avatar-rounded" style="background-image: url('+image+')"></span>'; 
           }else{
            var icon = '<span class="avatar avatar-xl avatar-rounded" style="background-image: url('+avatarImage+')"></span>'; 
            // var icon = '<span class="avatar avatar-xl avatar-rounded"> '+ short_name +' </span>';
           }
           

           var  col3_list_box ='<div class="col-md-6 col-xl-3">\
                     <div class="card shadow">\
                       <div class="card-body text-center ">\
                          <div class="mb-3"> '+ icon +' </div>\
                          <div class="card-title mb-1">' + name + '</div>\
                          <div class="text-muted">Id: '+ unique_id + '</div>\
                       </div>\
                       <a href="javascript:;"  class="card-btn print_user_detail_popup" data-ids="'+ id +'" >View full profile</a>\
                    </div>\
                 </div>';
          bodyContent.append(col3_list_box);
        });
      }





     $('#pagination-popup').on('click','a',function(e){
       e.preventDefault();       
       var pagepopupno = $(this).data('ci-pagination-page');        
       loadPopUpPagination(pagepopupno);
     });
 
     
 
     function loadPopUpPagination(pagepopupno){
      var package_id = $('#package_id').val();
      var id = $('#popup-hidden-user-id').val();
       $.ajax({
         url: baseURL + 'display-direct-popup-list/'+pagepopupno,
         type: 'get',
          data: {'package_id' : package_id, 'id' : id},
         dataType: 'json',
         success: function(response){
            let decrypt = $.fn.displayDecryptData(response.data);
            $.fn.createPopupList(decrypt.result, decrypt.row);
            $('#pagination-popup').html(decrypt.pagination);
         }
       });
     }


  $.fn.createPopupList = function(result,sno){
        // console.log(result,sno);
   var sno = Number(sno);
   var popUpbodyContent = $('#popup-package-user-profile-list');
   popUpbodyContent.empty();
   if(result.length < 1){
        popUpbodyContent.append('<level style="text-align:center;">There are no direct downlines</label>');return;   
    }
   $.each(result, function(index, val) {
     var name = val.name;
     var short_name = val.short_name;
     var image = val.pp;
     var id = val.id;
     // var unique_id = val.unique_id;
     if(val.pp_status == true){
      var icon = '<span class="avatar avatar-sm avatar-rounded" style="background-image: url('+image+')"></span>'; 
     }else{
      var icon = '<span class="avatar avatar-sm avatar-rounded" style="background-image: url('+avatarImage+')"></span>'; 
      // var icon = '<span class="avatar avatar-sm avatar-rounded"> '+ short_name +' </span>';
     }
    var   colmd6_list_box='<div class="col-md-6 col-xl-4 mb-2">\
                        <a class="card card-link popup-list-user" href="javascript:;" data-popup_ids="'+ id +'" >\
                           <div class="card-body">\
                              <div class="row">\
                                 <div class="col-auto">'+ icon +'\
                                 </div>\
                                 <div class="col">\
                                    <div class="font-weight-medium">'+ name +'</div>\
                                 </div>\
                              </div>\
                           </div>\
                        </a>\
                     </div>';
       popUpbodyContent.append(colmd6_list_box);
    });

  }



     $(document).on('click', '.popup-list-user', function(e){
        e.preventDefault();
        var _this = $(this);        
        var id = _this.data('popup_ids');
        var Already = backNow.show();        
        backArrayPushItem.push(id);
        backNow.attr('data-back_popup_ids', backArrayPushItem);
        $.fn.fetchedUserData(id);
     });


     $(document).on('click', '.back-history-btn', function(e){
      e.preventDefault();
        var AllCurrentID = $(this).attr('data-back_popup_ids');
        var arr = AllCurrentID.split(',');
        var lastPopUpId = arr[arr.length-1];
        $.fn.fetchedUserData(lastPopUpId);        
        arr.pop();
        if(arr.length < 1){   $(this).hide(); backArrayPushItem.splice(0, backArrayPushItem.length); }
        $(this).attr('data-back_popup_ids', arr);
     });
       
    });
</script>
</body>
</html>