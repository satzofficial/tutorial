<?php 
    $this->load->view('front/common/header');
    $user_id = $this->session->userdata('user_id');
$this->load->view('front/user/basic_navigation');

$userbalance = getBalance($user_id,$dig_currency->id);
// $EURO_Balance = bcmul($userbalance ,$dig_currency->online_europrice);
  $EURO_Balance = $userbalance * $dig_currency->online_europrice;

?>
<style>
.copy-address {
  font-size:25px;
  width: 50px;
}  
#amount_receive_error{
color: red;
}
.form-paywith {
  background-color: #fff !important;
  border: 0px;
  font-weight: bold;
}
.convert-coin { font-weight: bold; }
</style>
<div class="page-wrapper">
	<div class="container-xl ">
          <div class="page-header d-print-none">
            <div class="row align-items-center coinbasetab">
              <div class="col">
                <h1 class="page-title"><img class="Image-sc-1i3cgkp-0 CurrencyIcon__StyledImage-sc-12mnnqm-2 jPdGfJ" src="<?=$dig_currency->image?>" alt="BTC logo" size="46" aria-label="BTC logo "> <?=$dig_currency->currency_name?>
                  </h1>
                <!-- <div class="page-pretitle-1">
                  <?=$dig_currency->currency_name?> is not tradable in your region.
                </div> -->
              </div>
              
            </div>
          </div>

          <div class="mb-3">
            <header class="navbar navbar-expand-md navbar-light d-print-none">
              <div class="container-xl">
                <!-- <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar-menu">
                  <span class="navbar-toggler-icon"></span>
                </button> -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                  <div class="d-flex flex-column flex-md-row flex-fill align-items-stretch align-items-md-center">
                    <ul class="navbar-nav">
                      <li class="nav-item">
                        <a class="nav-link" href="<?=base_url().'basic-chart/'.$symbol?>" >
                          <span class="nav-link-title-1">
                            Overview
                          </span>
                        </a>
                      </li>
                      <li class="nav-item active">
                        <a class="nav-link" href="<?=base_url().'basic-wallet/'.$symbol?>" >
                          <span class="nav-link-title-1">
                            Wallet
                          </span>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </header>
          </div>
        </div>

    <div class="page-body">
    	<div class="container-xl">
        <div class="row">
          <div class="col-2 col-sm-2"></div>
          <div class="col-12 col-sm-8">
            
            <div class="col-12">
              <div class="card1">
                <div class="empty">
                  <div class="empty-img"><img class="Image-sc-1i3cgkp-0 CurrencyIcon__StyledImage-sc-12mnnqm-2 KkGeY TransactionNullState__CurrencyIcon-sc-9x4inz-0 dAxUIC" src="<?=$dig_currency->image?>" alt="BTC logo" size="130" aria-label="BTC logo " style="opacity: 50%;">
                  </div>
                  <p class="empty-title">
                    <?php if($userbalance==0) {
                          echo 'Your '.$dig_currency->currency_symbol.' Wallet is empty';
                        }
                        if($userbalance>0) {
                          echo $dig_currency->currency_symbol;
                        }
                    ?>
                  </p>
                <?php if($userbalance==0) { ?>  
                  <p class="empty-subtitle text-muted">
                    To start trading, you need to receive some <?=$dig_currency->currency_name?> (<?=$dig_currency->currency_symbol?>).
                  </p>
                  <div class="empty-action">
                    <a href="<?=base_url().'deposit/'.$dig_currency->currency_symbol?>" class="btn btn-primary">
                     Receive <?=$dig_currency->currency_symbol?>
                    </a>
                  </div>
                <?php }?>  
                </div>
              </div>

              <?php if($userbalance>0) {?>
                <label class="form-selectgroup-item">
                <span class="form-selectgroup-label d-flex p-3" style="cursor:default;"> <span class="form-selectgroup-label-content" style="text-align: left;"> 
                  <span class="form-selectgroup-title strong mb-1">
                    <h3 class="htftjJ"><?=$this->lang->line('Available Balance')?> : <?=$userbalance?></h3>
                  </span>
                  </span>
                </span>
                <span class="form-selectgroup-label d-flex p-3" style="cursor:default;"> <span class="form-selectgroup-label-content" style="text-align: left;"> 
                  <span class="form-selectgroup-title strong mb-1">
                    <h3 class="htftjJ">Euro <?=$this->lang->line('Value');?> : <?=$EURO_Balance?></h3>
                  </span>
                  </span>
                </span>
                </label>
              
                <div class="card1">
                 <div class="card1-footer">
                    <div style="text-align:center;">
                      <a href="<?=base_url().'withdraw/'.$dig_currency->currency_symbol?>" class="btn btn-primary ms-auto">Send</a>
                      <a href="<?=base_url().'deposit/'.$dig_currency->currency_symbol?>" class="btn btn-primary ms-auto">Receive</a>
                    </div>
                  </div>
                </div>
              
              <?php }?>


            </div>
            
          </div>
<div class="col-2 col-sm-2"></div>

          <!-- <div class="col-md-4 col-lg-4">
            <div class="col-md-12">
              <div class="card">
                <ul class="nav nav-tabs nav-fill transaction-nav" data-bs-toggle="tabs">
                  <li class="nav-item">
                    <a href="javascript:;" id="send-tab" class="nav-link active" data-bs-toggle="tab">Send</a>
                  </li>
                  <li class="nav-item">
                    <a href="javascript:;" id="receive-tab" class="nav-link" data-bs-toggle="tab">Receive</a>
                  </li>
                 </ul>
                <div class="card-body">
                  <div class="tab-content">
                    <div class="tab-pane trans-wrapper show active" id="send-tab-content">
        <?php $action = base_url().'basic-wallet/'.$dig_currency->currency_symbol;
          $attributes = array('id'=>'withdrawcoin','autocomplete'=>"off",'class'=>'deposit_form1');
          echo form_open($action,$attributes); ?>     
                      <div class="mb-3">
                        <input type="number" min="10" value="10" class="form-control" name="fiatinput" id="fiatinput" onkeyup="changeFiatCurrency(this)" placeholder="€ 0">
                        <span></span>
                      </div>

                      <div class="mb-3">
                        <label class="form-label">Value in <span class="convertcoin-lable"><?=$dig_currency->currency_symbol?></span> : <span class="convert-coin"> </span></label>
                        <input readonly type="text" class="form-control convert-coin" placeholder="Convert coin"> 
                        <input type="hidden" name="amount" class="convert-coin1">
                      </div>

                      <div class="form-floating mb-3">
                        <input type="text" name="address" class="form-control" id="floating-input" placeholder="Mobile, email, or address" onchange="validaddressFunction(this)" autocomplete="off">
                        <span></span>
                        <label for="floating-input">&#8693; <?=$this->lang->line('Withdraw address');?></label>
                        <input type="hidden" name="valid_address" class="valid_address">
                      </div>
                      <div class="mb-3">
                        <label class="form-label">Pay with</label>
                       <div class="input-icon mb-3">
                          <span class="input-icon-addon">
                          <img alt="Bitcoin logo" src="<?=$dig_currency->image?>" aria-label="<?=$dig_currency->currency_name?> logo " style="height: 32px"; class="Image-sc-1i3cgkp-0 ImageWithFallback__AbsoluteImage-ufzvsr-0 dmqghf">
                         </span>
                         <input type="text" class="form-control form-paywith" placeholder="<?=$dig_currency->currency_name?>" readonly>

                         <input type="hidden" name="ids" value="<?=$dig_currency->id?>">
                        </div>
                      </div>
                      <input type="hidden" id="hiden_fees_type" value="<?=$dig_currency->withdraw_fees_type?>">
                      <input type="hidden" id="hiden_fees" value="<?=$dig_currency->withdraw_fees?>"> 
                      <input type="hidden" id="hiden_fees_stype" value="<?=$dig_currency->sharecoin_fees_type?>">
                      <input type="hidden" id="hiden_fees_s" value="<?=$dig_currency->sharecoin_fees?>"> 
                      <p>Sharecoin Fee : <span class="send_fees_s"></span></p>  
                      <p>Fee(Other Fee) : <span class="send_fees_o"></span></p>  
                      <p>Amount You will receive : <span class="send_amount_receive_sym"></span></p>
                      <span id="amount_receive_error"></span> 


                    <div class="col-lg-12 mt-2">
                      <button <?=($userbalance==0)?'disabled':''?> class="btn btn-primary ms-auto" type="submit" name="withdrawcoin"><?=$this->lang->line('Withdraw');?></button> 

                      <input type="hidden" name="sharecoin_fee" id="sharecoin_fee">
                      <input type="hidden" name="other_fee" id="other_fee">
                      <input type="hidden" name="receive_amt" id="receive_amt">
                    </div>
                  <?php echo form_close(); ?>   
                    </div>
                     
                    <div class="tab-pane trans-wrapper" id="receive-tab-content">
                      <div class="col-12">
                        <div class="card">
                          <div class="card-header">
                            <img alt="Bitcoin logo" src="<?=$First_coin_image?>" aria-label="Qr code " style="height: 250px"; class="Image-sc-1i3cgkp-0 ImageWithFallback__AbsoluteImage-ufzvsr-0 dmqghf">
                          </div> 
                          <div class="card-footer">
                            <div class="d-flex">
                              <a href="javascript:;" class="btn btn-link">Address</a>
                              <a href="javascript:;" onclick="copy_function('<?=$coin_address?>')" class="btn btn-link"><?=substr($coin_address,0,10).'...'?><i id="copy_icofont" class="icofont-copy copy-address"></i></a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  
              </div>
            </div>
            <div class="card-footer">
              <div class="row align-items-center">
                <div class="col-auto">
                  <label><?=$dig_currency->currency_symbol?> balance</label>
                </div>
                <div class="col-auto ms-auto">
                  <label class="form-check form-switch m-0">
                    <?=$userbalance.' '.$dig_currency->currency_symbol?> ≈ €<?=$EURO_Balance?>
                  </label>
                </div>
              </div>
            </div>
            </div>

            
          </div>

        </div --> 


        </div>
      </div>
    </div>


</div>

<?php $this->load->view('front/common/footer'); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
$.validator.addMethod("noSpace", function(value, element) { 
  return value.indexOf(" ") < 0 && value != ""; 
}, "No space please and don't leave it empty");  

$('#withdrawcoin').validate(
{
    errorElement: 'span',
    rules: {
      address:{
        required: true,
        noSpace: true
      },
      fiatinput:{
        required: true,
        number:true
      }
    },
    messages: {
      address:{
        required: "<?=$this->lang->line('Please enter address');?>"
      },
      fiatinput:{
        required: "<?=$this->lang->line('Please enter amount');?>",
        number: "<?=$this->lang->line('Invalid Amount');?>"
      }
    },
    errorPlacement: function(error, element) {
      $(element).next('span').html(error);
    },
    submitHandler: function(form) 
    { 
        form.submit();
    }
});



$(document).on('click', '.transaction-nav li', function() {
  li = $(this).find('a').attr('id');

  $(".transaction-nav li a").not($(this)).removeClass('active show');
  $(".trans-wrapper").removeClass("active show");  
  if(li=='send-tab') {
    $("#send-tab").addClass("active show");      
    $("#send-tab-content").addClass("active show");    
  } else if(li=='receive-tab') {
    $("#receive-tab").addClass("active show");
    $("#receive-tab-content").addClass("active show");
  } 

});  

function copy_function(lang) 
{
  $('.copy-address').removeClass('icofont-copy');
  var tempInput = document.createElement("input");
  tempInput.value = lang;
  document.body.appendChild(tempInput);
  tempInput.select();
  document.execCommand("copy");
  document.body.removeChild(tempInput);
  $('.copy-address').addClass('icofont-check');

  $('.copy-address').fadeOut('slow', function(){
    $('.copy-address').removeClass('icofont-check');
    $(".copy-address").css("display", "block");
  });
  $('.copy-address').addClass('icofont-copy');
}

Number.prototype.noExponents= function(){
  var data= String(this).split(/[eE]/);    
  if(data.length== 1) return data[0]; 

  var  z= '', sign= this<0? '-':'',
  str= data[0].replace('.', ''),
  mag= Number(data[1])+ 1;

  if(mag<0){
      z= sign + '0.';
      while(mag++) z += '0';
      return z + str.replace(/^\-/,'');
  }
  mag -= str.length;  
  while(mag--) z += '0';
  return str + z;
}
function changeFiatCurrency(e) {
  rate1 = 0;
  euroAmt = parseFloat($(e).val());
  coin = '<?=$dig_currency->currency_symbol?>';
  
  $.getJSON('https://min-api.cryptocompare.com/data/pricemulti?fsyms=EUR&tsyms='+coin+'&api_key=a2ae4b9817a848ef5d2311a115856baa97c65d15a8b3e41cb4abf2295ed4d1aa', function(data) {

  $.each(data.EUR, function (cur, rate) { 
    fromAmt = euroAmt * rate;
    fromRate = formatter.format(fromAmt);
    if(isNaN(fromAmt)) {
      $('.convertcoin-lable').html(coin);
      $('.convert-coin').html('');
      $('.convert-coin1').val('');
      rate1 = 0;
    } else {
      rate1 +=fromRate;
      $('.convertcoin-lable').html(coin);
      $('.convert-coin').html(fromRate+' '+coin);
      $('.convert-coin1').val(fromRate);
    } 
  }); 

  fees_type = document.getElementById("hiden_fees_type").value;
  fees = document.getElementById("hiden_fees").value;
  sfees_type = document.getElementById("hiden_fees_stype").value;
  sfees = document.getElementById("hiden_fees_s").value;
  // console.log( rate1+'---'+fees_type+'--'+fees+'--'+sfees_type+'--'+sfees )
  setTimeout(function(){  
    if(fees_type=='Percent'){
        var fees_p = ((parseFloat(rate1) * parseFloat(fees))/100);
        var amount_receive = parseFloat(rate1) - parseFloat(fees_p);
    }
    else{
        var fees_p = fees;
        var amount_receive = parseFloat(rate1) - parseFloat(fees_p);
    }

    if(sfees_type=='Percent'){
        var fees_s = ((parseFloat(rate1) * parseFloat(sfees))/100);
        var fee = (parseFloat(fees_p) + parseFloat(fees_s));
        var amount_receive = parseFloat(rate1) - parseFloat(fee);
        //console.log(fees_s+'--'+fees_p+'--'+amount_receive1);
    }
    else{
        var fees_sum = (parseFloat(fees_p)+ parseFloat(sfees));
        var fees_s = sfees;
        var amount_receive = parseFloat(rate1) - parseFloat(fees_sum);
       // console.log(fees_p+'--'+sfees+'--'+amount_receive);
    }

      fees_s = (/e/.test(fees_s)) ? fees_s.noExponents() : fees_s;
      fees_p = (/e/.test(fees_p)) ? fees_p.noExponents() : fees_p;
      amount_receive = (/e/.test(amount_receive)) ? amount_receive.noExponents() : amount_receive;

      // console.log( fees_s+'--'+fees_p+'--'+amount_receive )
      $('.send_fees_s').html(fees_s);
      $('.send_fees_o').html(fees_p);
      
      if(amount_receive<=0){
        $('.send_amount_receive_sym').html('0');
        $('#amount_receive_error').html('Please enter valid amount');
      }
      else{
        $('#amount_receive_error').html('');
        $('.send_amount_receive_sym').html(amount_receive);
      }

      $('#sharecoin_fee').val(fees_s);
      $('#other_fee').val(fees_p);
      $('#receive_amt').val(amount_receive);
  }, 1000);

});
}

var front_url='<?php echo front_url(); ?>';    
function validaddressFunction(e) {
  address = $(e).val();
  $.ajax({
    url: front_url+"validaddress", 
    type: "POST",
    data:{address:address},     
    success: function(data) {
      // console.log(data) 
      if(data==0) {
        $('.valid_address').val(0);
      } else {
        $('.valid_address').val(data);
      }  
           
    }
  });
}

$(document).ready(function() {
  EuroCurrencyInput = document.getElementById("fiatinput");
    changeFiatCurrency(EuroCurrencyInput);
});

</script>