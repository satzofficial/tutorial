<?php include realpath(dirname(__DIR__) . '/common/inner_header.php'); 
$prefix = get_prefix();
$fname = $prefix.'fname';
$lname = $prefix.'lname';
$assets_url_var = base_url('assets/front/');

?>
<style type="text/css">
  .iti__arrow{     display: none;   }
  .iti__arrow { border: none; }
  .hide{ display: none; }
  #error-msg {
  color: red;
}
#valid-msg {
  color: #00C900;
}
input.error {
  border: 1px solid #FF7C7C;
}
.hide {
  display: none;
}

.iti__flag {background-image: url("path/to/flags.png");}

@media (-webkit-min-device-pixel-ratio: 2), (min-resolution: 192dpi) {
  .iti__flag {background-image: url("path/to/flags@2x.png");}
}

</style>
<link rel="stylesheet" type="text/css" href="https://intl-tel-input.com/node_modules/intl-tel-input/build/css/intlTelInput.css?1549804213570">

<div class="page-body">
  <div class="container-xl">
    <ol class="breadcrumb breadcrumb-arrows mb-3" aria-label="breadcrumbs">
      <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
      <li class="breadcrumb-item active" aria-current="page">Profile</li>
    </ol>
    <div class="row row-deck row-cards">
      <div class="col-md-12">
        <div class="card shadow radius-20">
          <div class="row">
            <div class="col-sm-2">
              <ul class="nav nav-tabs tab-v-100" data-bs-toggle="tabs">
                <li class="nav-item"> <a href="#tabs-view-17" class="nav-link tab1" data-bs-toggle="tab">Profile</a> </li>
                <li class="nav-item"> <a href="#tabs-home-17" class="nav-link tab2" data-bs-toggle="tab">Edit Profile</a> </li>
                <li class="nav-item"> <a href="#tabs-profile-17" class="nav-link tab3" data-bs-toggle="tab">Change Password</a> </li>
              </ul>
            </div>
            <div class="col-sm-8">
              <div class="card-body p-0">
                <div class="tab-content">
                  <div class="tab-pane fade active show" id="tabs-view-17">
                    <div>
                      <div class="card mt-3" >
                        <div class="card-body">
                          <div class="row g-2 align-items-center">
                            <div class="col-auto"><span class="avatar avatar-lg" style="background-image: url(<?php echo ($users->profile_picture)?$users->profile_picture: $dummy_user; ?>)"></span></div>
                            <div class="col">
                              <h4 class="card-title m-0 "> <a href="javascript:;" class="top-header-name"><?php
                                if($users->$fname && $users->$lname){
                                    $name = $users->$fname.' '. $users->$lname;                                    
                                }else{
                                  if(($users->$fname)){
                                    $name = $users->$fname;
                                  }else{
                                    $name = '';
                                  }
                                }
                                echo $name;                                   
                               ?></a> </h4>
                              <div class="text-muted"> #<?php echo preg_replace('/(?<=\d)(?=(\d{4})+$)/', ' ', ($users->unique_id) ? $users->unique_id:''); ?> </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <dl class="row py-4 p-3 py-5 pt-4 mt-0">
                        <dt class="col-5">Email Id:</dt>
                        <dd class="col-7 "><?php echo (getUserEmail($user_id)) ? strtolower(getUserEmail($user_id)) :''; ?></dd>
                        <dt class="col-5 personal-mobile-number">Mobile Number:</dt>
                        <dd class="col-7"><?php 
                        $phone = '';
                        if($users->tenrealm_phone && $users->phone_prefix){
                            $phone = $users->phone_prefix . ' ' . $users->tenrealm_phone;
                        }else if($users->tenrealm_phone){
                           $phone = $users->tenrealm_phone;
                        }
                        echo $phone;
                        ?></dd>
                        
                      </dl>
                      <div class="p-3 py-5 pt-4 mt-0">                      
                          <div class="row mt-2">
                            <div class="col-md-6">
                              <label class="labels">First Name</label>
                              <input type="text" name="firstname_readonly" class="form-control firstname_readonly" placeholder="Enter first name" value="<?php echo ($users->$fname) ? ucfirst($users->$fname) :''; ?>" readonly>                              
                            </div>
                              <div class="col-md-6">
                                <label class="labels">Last Name</label>
                                <input type="text"  name="lastname_readonly" class="form-control lastname_readonly" value="<?php echo ($users->$lname) ? ucfirst($users->$lname) :''; ?>" placeholder="Enter last name" readonly>
                              </div>
                            </div>
                            <div class="row mt-3">
                              <div class="col-md-12">
                                <label class="labels">Gender</label>
                                <select name="gender_readonly" id="gender_readonly" class="form-select gender_readonly" readonly disabled>
                                  <option <?php echo ($users->gender == 1) ? 'selected'  : ''; ?> value="1">Male</option>
                                  <option <?php echo ($users->gender == 2) ? 'selected'  : ''; ?> value="2">Female</option>
                                  <option <?php echo ($users->gender == 3) ? 'selected'  : ''; ?> value="3">Other</option>
                                </select>
                              </div>
                            </div>
                            <div class="row mt-3">
                              <div class="col-md-12">
                                <label class="labels">Email ID</label>
                                <input type="text" name="" class="form-control email_readonly" readonly placeholder="Enter email id" value="<?php echo (getUserEmail($user_id)) ? strtolower(getUserEmail($user_id)) :''; ?>" readonly>
                              </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-md-12">
                                  <label class="labels">Country</label>
                                  <input name="register_country_readonly" type="text" class="form-control register_country_readonly " value="<?php echo ($users->country) ? $users->country :''; ?>" readonly>                                  
                                </div>
                            </div>
                         

                            <div class="row mt-3">
                              <div class="col-md-12">
                                <label class="labels">Mobile Number</label>
                                <input name="phone_readonly" type="text" class="form-control phone_readonly" min="1" placeholder="Enter mobile no" value="<?php echo $phone; ?>" readonly>                                
                              </div>

                            <div class="row mt-3">
                                <div class="col-md-12">
                                  <label class="labels">USDT Address</label>
                                  <input name="beb_address_readonly" type="text" class="form-control beb_address_readonly" placeholder="Enter Bep 20 USDT address" value="<?php echo ($users->beb_address) ? $users->beb_address :''; ?>" readonly>
                                </div>
                              </div>
                              
                              
                              <div class="row mt-3">
                                <div class="col-md-12">
                                  <label class="labels">BUSD Address</label>
                                  <input name="busd_address_readonly"  type="text" class="form-control beb_address_readonly" placeholder="Enter Bep 20 BUSD address" value="<?php echo ($users->busd_address) ? $users->beb_address :''; ?>" readonly>
                                </div>
                              </div>
                              
                              
                            </div>
                          </div>

                    </div>
                  </div>
                  <div class="tab-pane fade  " id="tabs-home-17">
                    <div>
                      <div class="row">
                       
                        <?php
                         $action = '';
                         $attributes = array('id'=>'profileform','autocomplete'=>"off",'class'=>'profileform');
                         echo form_open_multipart($action,$attributes);
                         ?>
                        <input type="hidden" name="hiden-countryId" id="hiden-countryId"> 
                        <input type="hidden" name="hiden-stateId" id="hiden-stateId"> 
                        <input type="hidden" name="hiden-dialCode" id="hiden-dialCode" value=""> 
                        <input type="hidden" name="hiden-country_name" id="hiden-country_name"> 
                        <!-- <input type="hidden" name="hiden-state_name" id="hiden-state_name">  -->

                         <!-- <input type="hidden" class="form-control" id="inputtab1" name="type" autocomplete="off" value=""> -->
                         <input type="hidden" class="form-control" id="edit-pf" name="epf" autocomplete="off" value="epf">
                        <div class="col-md-3 border-right">
                          <div class="picture-container mt-3">
                            <div class="picture"><span class="position-absolute top-10">
                              
                            </span>                            
                            <div id="js-img-preview">
                               <?php if($users->profile_picture){ ?>
                                <img src="<?php echo ($users->profile_picture)? $users->profile_picture: $dummy_user; ?>" class="picture-src" id="wizardPicturePreview" title="Profile Picture">
                                <?php }else{ ?>
                                  <img src="<?php echo ($users->profile_picture)? $users->profile_picture: $dummy_user; ?>" class="picture-src" id="wizardPicturePreview" title="Profile Picture">
                                 <?php } ?>
                            </div>
                            <input type="file" name="profile_photo" value="" accept="image/png, image/jpeg, image/jpg" id="wizard-picture" class="">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="#000000" stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                <path d="M9 7h-3a2 2 0 0 0 -2 2v9a2 2 0 0 0 2 2h9a2 2 0 0 0 2 -2v-3" />
                                <path d="M9 15h3l8.5 -8.5a1.5 1.5 0 0 0 -3 -3l-8.5 8.5v3" />
                                <line x1="16" y1="5" x2="19" y2="8" />
                              </svg>
                          </div>
                          <h6 class="">Choose Picture</h6>
                        </div>
                      </div>
                       
                      <div class="col-md-9 border-right">
                        <div class="p-3 py-5 pt-4 mt-0">
                          <div class="d-flex justify-content-between align-items-center mb-3">
                            <h4 class="text-right">Profile Settings</h4>
                          </div>
                          <div class="row mt-2">
                            <div class="col-md-6">
                              <label class="labels">First Name</label>
                              <input type="text" name="firstname" class="form-control firstname" placeholder="Enter first name" value="<?php echo ($users->$fname) ? ucfirst($users->$fname) :''; ?>">
                              <!-- <span class="badge bg-red-lt">Error: This error MSG format</span>  -->
                            </div>
                              <div class="col-md-6">
                                <label class="labels">Last Name</label>
                                <input type="text"  name="lastname" class="form-control lastname" value="<?php echo ($users->$lname) ? ucfirst($users->$lname) :''; ?>" placeholder="Enter last name">
                              </div>
                            </div>
                            <div class="row mt-3">
                              <div class="col-md-12">
                                <label class="labels">Gender</label>
                                <select name="gender" id="gender" class="form-select gender" >
                                  <option <?php echo ($users->gender == 1) ? 'selected'  : ''; ?> value="1">Male</option>
                                  <option <?php echo ($users->gender == 2) ? 'selected'  : ''; ?> value="2">Female</option>
                                  <option <?php echo ($users->gender == 3) ? 'selected'  : ''; ?> value="3">Other</option>
                                </select>
                              </div>
                            </div>
                            <div class="row mt-3">
                              <div class="col-md-12">
                                <label class="labels">Email id</label>
                                <input type="text"  class="form-control" readonly placeholder="Enter email id" value="<?php echo (getUserEmail($user_id)) ? strtolower(getUserEmail($user_id)) :''; ?>">
                              </div>
                            </div>
                            
                             
                             

                              <?php if($users->tenrealm_phone && $users->phone_prefix){
                            $phone = $users->phone_prefix . ' ' . $users->tenrealm_phone;
                        }else if($users->tenrealm_phone){
                           $phone = $users->tenrealm_phone;
                        }?>
                              
                               
                              
                              <div class="row mt-3">
                                <div class="col-md-12">
                                  <label class="labels">USDT Bep 20 Address</label>
                                  <input name="beb_address" type="text" class="form-control" placeholder="Enter Bep 20 USDT address" value="<?php echo ($users->beb_address) ? $users->beb_address :''; ?>" <?php if($users->beb_address !=''){ echo  "readonly";}?>     >
                                </div>
                              </div>  
                              
                               <div class="row mt-3">
                                <div class="col-md-12">
                                  <label class="labels">BUSD Bep 20 Address </label>
                                  <input name="busd_address" type="text" class="form-control" placeholder="Enter Bep 20 BUSD address" value="<?php echo ($users->beb_address) ? $users->busd_address :''; ?>"  <?php if($users->busd_address !=''){ echo  "readonly";}?> >
                                </div>
                              </div> 
                              
                              
                                  <div class="row mt-3 alert alert-danger print-edit-status-msg" style="display:none"></div>
                              <div class="mt-5 text-left">
                                <button class="btn btn-primary btn-square profile-submit-btn" type="submit" name="edit_profile_form" value="edit_profile_form">Save Profile</button>
                              </div>                              
                            <!-- </div> -->
                          </div>
                           <?php echo form_close(); ?>
                        </div>
                      </div>
                      </div>
                    </div>
                    <div class="tab-pane fade" id="tabs-profile-17">
                      <div>
                        <div class="col-sm-6">                        
                            <?php
                             $action = '';
                             $attributes = array('id'=>'password_change_form','autocomplete'=>"off",'class'=>'change_password_form py-4');
                             echo form_open_multipart($action,$attributes);
                             ?>
                            <div class="mb-3">
                              <label class="form-label required">Current Password</label>
                              <input type="password" class="form-control" autocomplete="off" name="currentpassword" placeholder="Required...">
                            </div>
                            <div class="mb-3">
                              <label class="form-label required">New Password</label>
                              <input type="password" class="form-control"  autocomplete="off" id="password" name="password" placeholder="Required...">
                            </div>
                              <div class="mb-3">
                                <label class="form-label required">Confirm Password</label>
                                <input type="password" class="form-control"  autocomplete="off" name="cpassword" placeholder="Required...">
                              </div>
                               <div class="mb-3">
                               <div id="print-change-password-status-msg" class="alert alert-danger print-change-password-status-msg" style="display: none;"></div>
                                </div>
                              <div class="mt-5 text-left">
                                <button class="btn btn-primary btn-square " type="submit" name="change_password" value="cp">Save </button>
                              </div>                             
                            <?php echo form_close(); ?>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php include realpath(dirname(__DIR__) . '/common/inner_footer.php'); ?>

<script src="https://intl-tel-input.com/node_modules/intl-tel-input/build/js/intlTelInput.js?v=<?php echo time(); ?>"></script>
<script src="<?php echo $assets_url_var;?>js/countrystatecity.js"></script>
<script type="text/javascript">

  function readURL(input) {
  if (input.files && input.files[0]) {
      var reader = new FileReader();
      var divPointer = $('#js-img-preview');
      reader.onload = function (e) {
          // $('#wizardPicturePreview').attr('src', e.target.result).fadeIn('slow');
          divPointer.html('');
          var img = '<img src="'+e.target.result+'" class="picture-src" id="wizardPicturePreview" title="Profile Picture">';
          divPointer.html(img).fadeIn('slow');
      }
      reader.readAsDataURL(input.files[0]);
  }
}

  $(document).ready(function() {
      
      var _print_ep_status_class = $(".print-edit-status-msg");
    var profileForm = $('#profileform');
    var _print_cp_status_class = $(".print-error-msg");


      // Prepare the preview for profile picture
  $("#wizard-picture").change(function(){
      readURL(this);
  });
    
      $.fn.errorFn = (function(data){          
        if($.isEmptyObject(data.error)){          
          _print_cp_status_class.html('');
          _print_cp_status_class.css('display','none');  
        }
        return true;
      })

      $.fn.successFn = (function(data){            
        _print_cp_status_class.css('display','block');                    
        if(_error_div_amount_class.length == 0){              
          _print_cp_status_class.html(data.error);
          return true;
        }else{
          return true;              
        }     
      })




       function readURLProfile(input) {
        if (input.files && input.files[0]) {
          var reader = new FileReader();
          reader.onload = function(e) {
            $('#img-profile').attr('src', e.target.result);
          }
        reader.readAsDataURL(input.files[0]); // convert to base64 string
      }
    }
    $("#imageUpload").change(function() {
      readURLProfile(this);
    });

    $.validator.addMethod('ZipChecker', function() {
    }, 'Invalid zip code');
    $.validator.addMethod("lettersonly", function(value) {
      return (/^[a-zA-Z\s]*$/.test(value));
    });

  $.validator.addMethod("custom_number", function(value, element) {
    return this.optional(element) || value.match(/^[0-9,\+-]+$/);
  }, "Please enter a valid number");
    profileForm.validate({
      rules: {
        firstname: {
          required: true
        },
        lastname: {
          required: true
        },        
        street_address: {
          required: true
        },
        street_address: {
          required: true          
        },
        state: {
          required: true,
          lettersonly: true
        },
         beb_address: {
          required: true        
        },
         register_country: {
          required: true        
        },
        postal_code: {
          required: true,
          number: true,
          maxlength: 7,
          ZipChecker: function(element) {
            values=$("#postal_code").val();
            if( values =="0" || values =="00" || values =="000" || values =="0000" || values =="00000"  || values =="000000"   || values =="0000000" )
            {
              return true;
            }
          }
        },
        phone: {
          required: true,
          minlength:5
          // custom_number: true,
          // phoneUS: true
        },
        city: {
          required: true
        }
      },
      messages: {
        firstname: {
          required: "Please enter first name"
        },
        lastname: {
          required: "Please enter last name"
        },
        address: {
          required: "Please enter address"
        },
        city: {
          required: "Please enter city",
          lettersonly: "Please enter letters only"
        },
        state: {
          required: "Please enter state",
          lettersonly: "Please enter letters only"
        },
        postal_code: {
          required: "Please enter postal code"
        },
        phone: {
          required: "Please enter phone number"
        }
      },
      errorPlacement: function (error, element) {
          if (element.attr("name") == "phone" )
          {
            document.querySelector("#valid-msg").style.display='none';
            error.appendTo("#messageBox");
          }
      },
       submitHandler: function (form, event) {
          event.preventDefault();
          if($('#valid_phone').val() == 0){ return;}
          var form = $(form);
          profileForm.find('.print-error-msg').empty().hide();          
          $.ajax({
            url: baseURL + "profile-edit",
            type: 'POST',
            // data: new FormData(form[0]),
            cache: false,             
            processData: false,
            dataType: 'json',
            data: new FormData($('#profileform')[0]),            
            contentType: false,                
            // data: new FormData(document.getElementById("profileform")),            
            success: function(data) {                
               if(data.status == true){

                $('.firstname_readonly').val($('.firstname').val());
                $('.top-header-name').html($('.firstname').val());
                $('.lastname_readonly').val($('.lastname').val());                
                $('.register_country_readonly').val($("input[name='hiden-country_name']").val());
                $('.city_readonly').val($('.city').val());                
                $('.phone_readonly,.personal-mobile-number').val($("input[name='full']").val());                
                $('.firstname_readonly').val($('.firstname').val());
                _print_ep_status_class.removeClass('alert-danger').addClass('alert-success').show().html('').fadeIn().focus().html(data.msg).fadeOut(5000);
                if($('#wizard-picture').val().length > 0){
                  $('.avatar-sm, .avatar-xs, .avatar-lg').css("background-image", "url('"+data.data.profile_picture+"')");                  
                }                
                return true;
              }else{
                _print_ep_status_class.removeClass('alert-success').addClass('alert-danger').show().html('').fadeIn().focus().html(data.msg).fadeOut(5000);
                return;
              }                  
            },
            error: jqueryErrorHandling,
          });
          return false;
    }
    });


       var _print_cp_status_class = $(".print-change-password-status-msg");
       
    
      $.fn.errorFn1 = (function(data){  
      if (typeof(data.msg) == 'undefined' && data.msg == null) { return;}                 
        _print_cp_status_class.removeClass('alert-success').addClass('alert-danger').show().html('').html(data.msg);
        return true;
      })

      $.fn.successFn1 = (function(data){    
      if (typeof(data.msg) == 'undefined' && data.msg == null) { return;}               
      _print_cp_status_class.css('display','block');        
      _print_cp_status_class.removeClass('alert-danger').addClass('alert-success').show().html('').html(data.msg);
        return true;
      })

    var chForm =$('#password_change_form');
     chForm.validate({
      rules: {
        currentpassword: {
          required: true
        },
        password: {
          required: true,
          minlength: 5
        }, 
        cpassword: {
            required: true,
            minlength: 5,
            equalTo: "#password"
        },      
      },
      messages: {
        currentpassword: {
          required: "Please enter current password"
        },
        password: {
          required: "Please enter password"
        },
        cpassword: {
          required: "Please enter Confirm password"
        },
      },
       submitHandler: function (form, event) {
          event.preventDefault();
          chForm.find(_print_cp_status_class).empty().hide();          
          $.ajax({
            url: baseURL + "profile-edit",
            type: 'POST',
            dataType: 'json',
            data: $(form).serialize(),                  
            accepts: "application/json; charset=utf-8",
            success: function(data) {
            // console.log(data);return false;                             
              if(data.status == true){
                _print_cp_status_class.removeClass('alert-danger').addClass('alert-success').show().html('').html(data.msg);
                chForm.each(function(){
                    this.reset();
                });
                return true;
              }else{
                _print_cp_status_class.removeClass('alert-success').addClass('alert-danger').show().html('').html(data.msg);
                return;
              }                
            },
            error: jqueryErrorHandling,
          });
    }
    });



    //  $(document).on('click', '.tab1', function(event) {
    //     // event.preventDefault();
    //     /* Act on the event */
    //     $(this).addClass('active')

    //     $('.tab2').removeClass('active');
    //     $('.tab3').removeClass('active');        
    //     // alert(1);
    //     localStorage.setItem('value','hs');
    //   });


    //   $(document).on('click', '.tab2', function(event) {
    //     // event.preventDefault();
    //     /* Act on the event */

    //     $(this).addClass('active');
    //     $('.tab1').removeClass('active');
    //     $('.tab3').removeClass('active');
    //     // alert(2);  
    //     localStorage.setItem('value','e_p');

    //   });


    //    $(document).on('click', '.tab3', function(event) {
    //     // event.preventDefault();
    //     /* Act on the event */
    //     $(this).addClass('active');
    //     $(this).click();
    //     $('.tab1').removeClass('active');
    //     $('.tab2').removeClass('active') ;
    //     // alert(3);  
    //     localStorage.setItem('value','c_p');
    //   });


    // if(localStorage.getItem('value') === 'c_p'){
    //     $('.tab3').trigger('click');    
    // }else if(localStorage.getItem('value') === 'e_p'){
    //     $('.tab2').trigger('click');       
    // }else{
    //     $('.tab1').trigger('click');    
    // }
        


  });

     



// Display network error
function jqueryErrorHandling(xhr, status, exception) {
  // alert('sample EREORE');
  var responseText;
  $("#dialog").html("");
  try {
    responseText = jQuery.parseJSON(xhr.statusText);
    $("#dialog").append("<div><b>" + status + " " + exception + "</b></div>");
    $("#dialog").append("<div><u>Exception</u>:<br /><br />" + responseText.ExceptionType + "</div>");
    $("#dialog").append("<div><u>StackTrace</u>:<br /><br />" + responseText.StackTrace + "</div>");
    $("#dialog").append("<div><u>Message</u>:<br /><br />" + responseText.Message + "</div>");
  } catch (e) {
    var errorMessage = xhr.statusText;
    $("#dialog").html(errorMessage);
    $("#dialog").dialog({
      title: "Exception Details",
      autoOpen: true,
      modal: true,
      width: 700,
      buttons: {
        Close: function() {
          $(this).dialog('close');
        }
      }
    });
  }
}


var Ucountry = '<?php echo $users->country; ?>';
var phone = '<?php echo $phone; ?>';
//var Ustate = '<?php echo $users->state; ?>';
//var Ucity = '<?php echo $users->city; ?>';
var phone_prefix = '<?php echo $users->phone_prefix; ?>';

if(Ucountry!='') contryFlag = Ucountry;
else contryFlag = 'in';

if(phone_prefix!='') dialCode = phone_prefix;
else dialCode = '+91';

// console.log(contryFlag)

var errorMsg = document.querySelector("#error-msg"),  validMsg = document.querySelector("#valid-msg"), validInpMsg = document.querySelector("#valid_phone");

// here, the index maps to the error code returned from getValidationError - see readme
var errorMap = ["Invalid number", "Invalid country code", "Too short", "Too long", "Invalid number"];


var countryData = window.intlTelInputGlobals.getCountryData(),
  input = document.querySelector("#phone"),
  addressDropdown = document.querySelector("#countryId");

// init plugin
var iti = window.intlTelInput(input, {
  separateDialCode: true,
  preferredCountries:[contryFlag],
  hiddenInput: "full",
  formatOnDisplay:false,
  allowDropdown:false,
  // hiddenInput: "full_phone",
  utilsScript: "https://intl-tel-input.com/node_modules/intl-tel-input/build/js/utils.js?v=<?php echo time(); ?>" // just for formatting/placeholders etc
});


var reset = function() {
  input.classList.remove("error");
  errorMsg.innerHTML = "";
  errorMsg.classList.add("hide");
  validMsg.classList.add("hide");
};


// on blur: validate
input.addEventListener('blur', function() {
  reset();
  if (input.value.trim()) {
    if (iti.isValidNumber()) {
      validMsg.classList.remove("hide");
      validInpMsg.value='1';
      // document.getElementById("hiden-country_name").value = countryFullName;
    } else {
      validInpMsg.value='0';
      input.classList.add("error");
      var errorCode = iti.getValidationError();
      errorMsg.innerHTML = errorMap[errorCode];
      errorMsg.classList.remove("hide");
    }
  }
});

// on keyup / change flag: reset
input.addEventListener('change', reset);
input.addEventListener('keyup', reset);

// populate the country dropdown
// console.log(countryData)

var loc = new locationInfo();
for (var i = 0; i < countryData.length; i++) {
  var country = countryData[i];
  var optionNode = document.createElement("option");
  // optionNode.value = country.iso2;
  optionNode.value = country.name;
  optionNode.setAttribute('countryid', country.iso2);
  optionNode.setAttribute('dialCode', country.dialCode);
  var textNode = document.createTextNode(country.name);
  optionNode.appendChild(textNode);
  addressDropdown.appendChild(optionNode);
}
// set it's initial value
addressDropdown.value = iti.getSelectedCountryData().name;
  selectCountryId = iti.getSelectedCountryData().iso2;

  console.log(addressDropdown.value)

// loc.getStates(selectCountryId); 
countryFullName = addressDropdown.value;
countryFullName = countryFullName.replace(/[^a-zA-Z ]/g, "");
document.getElementById("hiden-dialCode").value = dialCode;
document.getElementById("hiden-countryId").value = selectCountryId;
document.getElementById("hiden-country_name").value = countryFullName;

// console.log(selectCountryId)


// listen to the telephone input for changes
input.addEventListener('countrychange', function(e) {
  document.getElementById("hiden-dialCode").value=''
  addressDropdown.value = iti.getSelectedCountryData().name;
  countryFullName = addressDropdown.value;
  countryFullName = countryFullName.replace(/[^a-zA-Z ]/g, "");
  countryid = iti.getSelectedCountryData().iso2;
  dialCode = iti.getSelectedCountryData().dialCode;
  let c = '+';
  if(dialCode==1){   	c = '+1';   }else{   	c += dialCode;   }
  document.getElementById("hiden-dialCode").value = c;  
  // $('#hiden-dialCode').val(c);
  document.getElementById("hiden-country_name").value = countryFullName;  
});


$('#iti__arrow').hide();
$(document).on('click', '.iti__flag-container', function(e){
  e.preventDefault();
  $('.iti__country-list').empty();
  return;
});

</script>
