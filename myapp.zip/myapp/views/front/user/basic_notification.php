<?php 
    $this->load->view('front/common/header');
    $user_id = $this->session->userdata('user_id');
$this->load->view('front/user/basic_navigation');
?>

<div class="page-wrapper">
        <div class="container-xl">
          <div class="page-header d-print-none">
            <div class="row align-items-center">
              <div class="col">
                <h2 class="page-title-1">
                  Notifications
                </h2>
              </div>
            </div>
          </div>
        </div>
        <div class="page-body-1">
          <div class="container-xl">
            <div class="row justify-content-center">
              <div class="col-8">
                <div class="card">
                  <div class="card-body">
                    <div class="divide-y">


                                      <div>
                                        <div class="row">

                                          <div class="col">

                                            <div class="text-truncate">
                                              <strong>Price Alert</strong>
                                            </div>
                                            <div>
                                              📈 Bitcoin (BTC) is up +4.70% to €33,431.40 in the last 24 hours.
                                            </div>
                                            <div class="text-muted">yesterday</div>
                                          </div>
                                          <div div class="col-auto align-self-center">
                                            <div class="Text__Font-sc-163p65w-0 gjnCZd StandardTextLayout__RightText-sc-19dlaax-5 gOOFkW" color="slateDark">€33,431.40</div><br>
                                            <div color="positive" class="Text__Font-sc-163p65w-0 gVaSZI StandardTextLayout__RightText-sc-19dlaax-5 gOOFkW">+4.70%</div>
                                          </div>
                                        </div>
                                      </div>
                                        <div>
                                            <div class="row">
                                              <div class="col">
                                                <div class="text-truncate">
                                                  <strong>Price Alert</strong>
                                                </div>
                                                <div>
                                                  📈 Etherum (ETh) is up +4.70% to €33,431.40 in the last 24 hours.
                                                </div>
                                                <div class="text-muted">2 days ago</div>
                                              </div>
                                              <div class="col-auto align-self-center">
                                                <div class="Text__Font-sc-163p65w-0 gjnCZd StandardTextLayout__RightText-sc-19dlaax-5 gOOFkW" color="slateDark">€33,431.40</div><br>
                                                <div color="positive" class="Text__Font-sc-163p65w-0 gVaSZI StandardTextLayout__RightText-sc-19dlaax-5 gOOFkW">+4.70%</div>
                                              </div>
                                            </div>
                                          </div>
                                         <div>
                                            <div class="row">

                                              <div class="col">
                                                <div class="text-truncate">
                                                  <strong>Price Alert</strong>
                                                </div>
                                                <div >
                                                  📈 Ethereum (ETH) is up +4.70% to €33,431.40 in the last 24 hours.
                                                </div>
                                                <div class="text-muted">today</div>
                                              </div>
                                              <div class="col-auto align-self-center">
                                                <div class="Text__Font-sc-163p65w-0 gjnCZd StandardTextLayout__RightText-sc-19dlaax-5 gOOFkW" color="slateDark">€33,431.40</div><br>
                                                <div color="positive" class="Text__Font-sc-163p65w-0 gVaSZI1 StandardTextLayout__RightText-sc-19dlaax-5 gOOFkW">-4.70%</div>
                                              </div>
                                            </div>
                                          </div>

                                          <div>
                                            <div class="row">
                                              <div class="col">
                                                <div class="text-truncate">
                                                  <strong>Price Alert</strong>
                                                </div>
                                                <div >
                                                  📈 Ethereum (ETH) is up +4.70% to €33,431.40 in the last 24 hours.
                                                </div>
                                                <div class="text-muted">today</div>
                                              </div>
                                              <div class="col-auto align-self-center">
                                                <div class="Text__Font-sc-163p65w-0 gjnCZd StandardTextLayout__RightText-sc-19dlaax-5 gOOFkW" color="slateDark">€33,431.40</div><br>
                                                <div color="positive" class="Text__Font-sc-163p65w-0 gVaSZI1 StandardTextLayout__RightText-sc-19dlaax-5 gOOFkW">-4.70%</div>
                                              </div>
                                            </div>
                                          </div>



                      </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          </div>
        </div>



<?php $this->load->view('front/common/footer'); ?>
