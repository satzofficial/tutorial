<?php
defined('BASEPATH') OR exit('No direct script access allowed');


// Form validation error config
$config['error_prefix'] = '<div class="error error_prefix">'; 
$config['error_suffix'] = '</div>';