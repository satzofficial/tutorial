<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class BTree {

	function trees($node, $side='left'){
		// Iteration start
		// Check left or right
		// Only 4 Level.

		if($node) return false;

		echo 'sakthi';exit;

	}

}

/* End of file BTree.php */
/* Location: ./application/libraries/BTree.php */