<?php
/**
 * This is a "dummy" library that just loads the actual library in the construct.
 * This technique prevents issues from CodeIgniter 3 when loading libraries that use PHP namespaces.
 * This file can be used with any PHP library that uses namespaces.  Just copy it, change the name of the class to match your library
 * and configs and go to town.
 */

defined('BASEPATH') OR exit('No direct script access allowed');

// Setup the dummy class for Cloudinary
class Cloudinarylib {

    public function __construct()
    {

        // include the cloudinary library within the dummy class
        require('cloudinary/src/Cloudinary.php');
        require 'cloudinary/src/Uploader.php';
        require 'cloudinary/src/Api.php';

        // username:bidexexchangedemo@gmail.com
        //Bidex@123

        // configure Cloudinary API connection
        \Cloudinary::config(array(
		// "cloud_name" => "satz",
//          "api_key" => "126328123586386",
//          "api_secret" => "F8m3a4Y4yJPApZyzSkuBtInaHgc"

            "cloud_name" => "dc0fe1p1q",
            "api_key" => "842222925999954",
            "api_secret" => "0Kg8nUn47QNtn48i4szw8qoS40g"


			));
    }
}